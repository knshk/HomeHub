// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:meta/meta.dart';

@immutable
class Product {
  final String id;
  final String slug;
  final String name;
  final String description;

  const Product({
    required this.id,
    required this.slug,
    required this.name,
    this.description = '',
  });

  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'] as String,
        slug: j['slug'] as String,
        name: j['name'] as String,
        description: (j['description'] as String?) ?? '',
      );
}

@immutable
class Tier {
  final String id;
  final String slug;
  final String name;
  final String description;
  final int sortOrder;
  final Map<String, dynamic> entitlements;

  const Tier({
    required this.id,
    required this.slug,
    required this.name,
    this.description = '',
    this.sortOrder = 0,
    this.entitlements = const {},
  });

  factory Tier.fromJson(Map<String, dynamic> j) => Tier(
        id: j['id'] as String,
        slug: j['slug'] as String,
        name: j['name'] as String,
        description: (j['description'] as String?) ?? '',
        sortOrder: (j['sort_order'] as int?) ?? 0,
        entitlements:
            Map<String, dynamic>.from(j['entitlements'] as Map? ?? const {}),
      );

  /// Convenience: read an entitlement value with an optional fallback.
  T? feature<T>(String key, {T? fallback}) {
    final v = entitlements[key];
    if (v is T) return v;
    return fallback;
  }
}

enum BillingModel { oneTime, subMonth, subYear, lifetime, free }

BillingModel _parseBilling(String s) {
  switch (s) {
    case 'one_time':
      return BillingModel.oneTime;
    case 'sub_month':
      return BillingModel.subMonth;
    case 'sub_year':
      return BillingModel.subYear;
    case 'lifetime':
      return BillingModel.lifetime;
    case 'free':
      return BillingModel.free;
    default:
      throw FormatException('unknown billing_model: $s');
  }
}

@immutable
class PricingPlan {
  final String id;
  final String tierId;
  final String tierSlug;
  final String slug;
  final BillingModel billingModel;
  final int amountCents;
  final String currency;
  final int trialDays;
  final DateTime? validFrom;
  final DateTime? validTo;

  const PricingPlan({
    required this.id,
    required this.tierId,
    required this.tierSlug,
    required this.slug,
    required this.billingModel,
    required this.amountCents,
    required this.currency,
    this.trialDays = 0,
    this.validFrom,
    this.validTo,
  });

  factory PricingPlan.fromJson(Map<String, dynamic> j) => PricingPlan(
        id: j['id'] as String,
        tierId: (j['tier_id'] as String?) ?? '',
        tierSlug: (j['tier_slug'] as String?) ?? '',
        slug: j['slug'] as String,
        billingModel: _parseBilling(j['billing_model'] as String),
        amountCents: (j['amount_cents'] as num).toInt(),
        currency: j['currency'] as String,
        trialDays: (j['trial_days'] as int?) ?? 0,
        validFrom: j['valid_from'] == null
            ? null
            : DateTime.parse(j['valid_from'] as String),
        validTo: j['valid_to'] == null
            ? null
            : DateTime.parse(j['valid_to'] as String),
      );

  /// Formatted like "$ 12.00 / month". Pure display helper; callers may
  /// supply their own formatter using `intl` for localization.
  String displayPrice() {
    final amt = (amountCents / 100).toStringAsFixed(2);
    switch (billingModel) {
      case BillingModel.subMonth:
        return '$currency $amt / month';
      case BillingModel.subYear:
        return '$currency $amt / year';
      case BillingModel.lifetime:
        return '$currency $amt (lifetime)';
      case BillingModel.free:
        return 'Free';
      case BillingModel.oneTime:
        return '$currency $amt';
    }
  }
}

@immutable
class ProductDetail {
  final Product product;
  final List<Tier> tiers;
  final List<PricingPlan> plans;

  const ProductDetail({
    required this.product,
    required this.tiers,
    required this.plans,
  });

  String get id => product.id;
  String get slug => product.slug;
  String get name => product.name;

  factory ProductDetail.fromJson(Map<String, dynamic> j) => ProductDetail(
        product: Product.fromJson(j),
        tiers: (j['tiers'] as List? ?? const [])
            .cast<Map<String, dynamic>>()
            .map(Tier.fromJson)
            .toList(growable: false),
        plans: (j['plans'] as List? ?? const [])
            .cast<Map<String, dynamic>>()
            .map(PricingPlan.fromJson)
            .toList(growable: false),
      );

  /// Returns the tier matching [slug] (e.g. "pro"), or null.
  Tier? tierBySlug(String slug) {
    for (final t in tiers) {
      if (t.slug == slug) return t;
    }
    return null;
  }

  /// Returns the active plans for one tier, optionally filtered by currency.
  List<PricingPlan> plansForTier(String tierSlug, {String? currency}) {
    return plans
        .where((p) =>
            p.tierSlug == tierSlug &&
            (currency == null || p.currency == currency))
        .toList(growable: false);
  }
}

class CatalogException implements Exception {
  final int? statusCode;
  final String message;
  CatalogException(this.message, {this.statusCode});
  @override
  String toString() => 'CatalogException($statusCode): $message';
}
