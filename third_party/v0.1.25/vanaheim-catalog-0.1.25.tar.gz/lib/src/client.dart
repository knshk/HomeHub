// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'types.dart';

/// Client for the License Store public catalog API.
///
/// All methods are read-only and unauthenticated. Responses are cached
/// in-memory respecting the server's `Cache-Control: max-age=...` directive.
class LicenseStoreCatalog {
  final Uri baseUrl;
  final http.Client _http;
  final Duration _defaultTtl;
  final Map<String, _CacheEntry> _cache = {};

  LicenseStoreCatalog({
    required this.baseUrl,
    http.Client? httpClient,
    Duration defaultTtl = const Duration(seconds: 60),
  })  : _http = httpClient ?? http.Client(),
        _defaultTtl = defaultTtl;

  /// List active products.
  Future<List<Product>> listProducts() async {
    final body = await _get('/v1/catalog/products');
    final ps = (body['products'] as List? ?? const [])
        .cast<Map<String, dynamic>>();
    return ps.map(Product.fromJson).toList(growable: false);
  }

  /// Full product detail: product + tiers + active pricing plans.
  Future<ProductDetail> getProduct(String slug) async {
    final body = await _get('/v1/catalog/products/${Uri.encodeComponent(slug)}');
    return ProductDetail.fromJson(body);
  }

  /// Pricing plans for a product, optionally filtered by ISO-4217 [currency].
  Future<List<PricingPlan>> getPricing(String slug, {String? currency}) async {
    var path = '/v1/catalog/products/${Uri.encodeComponent(slug)}/pricing';
    if (currency != null && currency.isNotEmpty) {
      path += '?currency=${Uri.encodeQueryComponent(currency)}';
    }
    final body = await _get(path);
    final plans = (body['plans'] as List? ?? const [])
        .cast<Map<String, dynamic>>();
    return plans.map(PricingPlan.fromJson).toList(growable: false);
  }

  /// Clear the in-memory cache (e.g. after admin actions update the catalog).
  void invalidate() => _cache.clear();

  /// Close the underlying HTTP client.
  void close() => _http.close();

  Future<Map<String, dynamic>> _get(String path) async {
    final now = DateTime.now();
    final cached = _cache[path];
    if (cached != null && cached.expires.isAfter(now)) {
      return cached.data;
    }
    final uri = baseUrl.replace(path: path.split('?').first, query: _queryOf(path));
    final res = await _http.get(uri, headers: {'Accept': 'application/json'});
    if (res.statusCode >= 400) {
      Map<String, dynamic>? err;
      try {
        err = jsonDecode(res.body) as Map<String, dynamic>;
      } catch (_) {}
      throw CatalogException(
        err?['message'] ?? err?['error'] ?? res.reasonPhrase ?? 'request failed',
        statusCode: res.statusCode,
      );
    }
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    final ttl = _parseMaxAge(res.headers['cache-control']) ?? _defaultTtl;
    _cache[path] = _CacheEntry(body, now.add(ttl));
    return body;
  }

  String? _queryOf(String path) {
    final i = path.indexOf('?');
    if (i < 0) return null;
    return path.substring(i + 1);
  }

  Duration? _parseMaxAge(String? cc) {
    if (cc == null || cc.isEmpty) return null;
    for (final p in cc.split(',')) {
      final part = p.trim();
      if (part.startsWith('max-age=')) {
        final n = int.tryParse(part.substring('max-age='.length));
        if (n != null) return Duration(seconds: n);
      }
    }
    return null;
  }
}

class _CacheEntry {
  final Map<String, dynamic> data;
  final DateTime expires;
  const _CacheEntry(this.data, this.expires);
}
