// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// License Store — Public catalog client for Dart and Flutter apps.
///
/// Use this package to render feature lists, paywalls, and pricing tables
/// from the central License Store catalog without standing up your own
/// product-side cache.
///
/// Example:
///
/// ```dart
/// import 'package:vanaheim_catalog/vanaheim_catalog.dart';
///
/// final catalog = LicenseStoreCatalog(
///   baseUrl: Uri.parse('https://licenses.example.com'),
/// );
///
/// final product = await catalog.getProduct('zenkit');
/// for (final tier in product.tiers) {
///   print('${tier.slug}: ${tier.entitlements['max_seats']} seats');
/// }
///
/// final plans = await catalog.getPricing('zenkit', currency: 'USD');
/// ```
library vanaheim_catalog;

export 'src/client.dart';
export 'src/types.dart';
