# vanaheim_catalog

Read-only Dart/Flutter client for the Vanaheim catalog public API. Use it to render feature lists, paywalls, and pricing tables in your product without standing up a product-side catalog mirror.

## Install

```yaml
dependencies:
  vanaheim_catalog:
    git:
      url: https://github.com/yourorg/license-store
      path: dart/vanaheim_catalog
```

(Switch to a pub.dev coordinate once published.)

## Use

```dart
import 'package:vanaheim_catalog/vanaheim_catalog.dart';

final catalog = LicenseStoreCatalog(
  baseUrl: Uri.parse('https://licenses.example.com'),
);

// All active products under your company
final products = await catalog.listProducts();

// Single product with tiers + entitlements + active plans
final detail = await catalog.getProduct('zenkit');
final pro    = detail.tierBySlug('pro');
final seats  = pro?.feature<int>('max_seats', fallback: 0);

// Localized pricing
final usdPlans = await catalog.getPricing('zenkit', currency: 'USD');
for (final p in usdPlans) {
  print('${p.tierSlug}: ${p.displayPrice()}');
}
```

## Notes

- Endpoints are public; no auth required.
- Responses are cached in-memory respecting `Cache-Control: max-age=...`.
- Call `catalog.invalidate()` to drop the cache (e.g. after an admin pushes a price change).
- For licensing operations (activate / verify / entitlements behind a paywall), use the separate `vanaheim` package, not this one — this is the *catalog* (display layer).
