## 0.1.25

- Ecosystem-alignment bump; SDK source unchanged since 0.1.16; version bumped
  to match Bifrost v0.1.25 release.
