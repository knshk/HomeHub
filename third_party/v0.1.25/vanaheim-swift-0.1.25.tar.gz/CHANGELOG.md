## 0.1.25

- Ecosystem-alignment bump; SDK source unchanged since 0.1.19; version bumped
  to match Bifrost v0.1.25 release.

## 0.1.0

Initial Swift release. API parity with the Flutter `license_store_sdk` 0.1.0:

- `LicenseClient` actor with `connect`, `activate`, `verify`, `transferToNewDevice`, `deactivate`, `hasFeature`, `quota`, `tier`, `expiresAt`, `entitlementsVersion`, `stateChanges` (AsyncStream), `diagnostics`, `clearDiagnostics`, `dispose`.
- HMAC-signed `SignedHttpClient` (HMAC-SHA256 via CryptoKit).
- `FirebaseAuthTokenProvider` and `FirebaseAppCheckTokenProvider` as closure-based wrappers — products bring their own Firebase iOS SDK.
- Ed25519 JWT verification via `CryptoKit.Curve25519.Signing.PublicKey.isValidSignature(_:for:)`.
- `JwksClient` actor with TTL cache + kid revocation set.
- `KeychainSecureCache` using `kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly`; preserves telemetry across `clear()`.
- `DeviceFingerprintGenerator` using IDFV (iOS/iPadOS/tvOS), IOPlatformUUID (macOS), HKDF-mixed with productSlug.
- `CertificatePinner` as a `URLSessionDelegate` that enforces SPKI SHA-256 pins inside the TLS handshake.
- `GraceStateMachine` (pure deterministic logic) consulted in `hasFeature`/`quota` — fail-closed on expired, never fail-open.
- Typed errors: `SeatCapExceededError`, `SessionRevokedError`, `TransferCooldownError(availableAt:)`, `LicenseExpiredError`, `NetworkError`, `CertificatePinError`, `AppCheckFailedError`, `JwtVerificationError`, `AuthError`, `NotConnectedError`.
- `KickedDevice` surfaced from `ActivationResult` for floating-tier bumps.
- `ErrorTelemetry` actor: bounded ring buffer (default 50), debounced persist (default 2 s), force-flush on dispose; restored on connect; never throws.
- Minimum platforms: iOS 15, macOS 12, macCatalyst 15, tvOS 15, watchOS 8.
