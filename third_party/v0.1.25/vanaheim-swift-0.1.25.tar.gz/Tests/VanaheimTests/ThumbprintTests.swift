// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import CryptoKit
import XCTest
@testable import Vanaheim

/// Cross-SDK lock-in for the JWE `apu` (PartyUInfo) thumbprint helper.
///
/// `JweCodec.swift` / `JWE_migration.md` spec: `apu = SHA-256(devicePub)` of
/// the raw 32-byte X25519 pubkey, base64url-encoded without padding. Dart's
/// `_devicePubThumbprint()` in `sdk/dart/license_store_sdk/lib/src/client.dart`
/// computes the same — these vectors lock both implementations to identical
/// byte-for-byte output so the AAD bound into a JWE matches what the server
/// cross-checks no matter which SDK encrypted the envelope.
///
/// Reference values were computed independently via Python:
///   `base64.urlsafe_b64encode(hashlib.sha256(bytes).digest()).rstrip(b'=')`
///
/// If a future code change drifts the encoding (e.g. swaps to padded
/// base64url, or hashes the SubjectPublicKeyInfo instead of the raw pub),
/// these tests fail loudly BEFORE the change ships.
final class ThumbprintTests: XCTestCase {

    // MARK: - Fixed-vector cross-SDK lock-in

    /// All-zero 32-byte pub. Reference Python:
    ///   `base64url(sha256(b'\\x00' * 32))`
    ///   → `Zmh6rfhivXdsj8GLjp-OIAiXFIVu4jOzkCpZHQ1fKSU`
    func testThumbprintZeroVector() {
        let pub = Data(repeating: 0x00, count: 32)
        let out = deviceX25519PubThumbprint(pubKey: pub)
        XCTAssertEqual(out, "Zmh6rfhivXdsj8GLjp-OIAiXFIVu4jOzkCpZHQ1fKSU")
    }

    /// All-ones 32-byte pub.
    ///   `base64url(sha256(b'\\x01' * 32))`
    ///   → `cs1uhCLEB_ttCYaQ8RMLfe1-wvf14dML2dUh8BU2N5M`
    func testThumbprintOnesVector() {
        let pub = Data(repeating: 0x01, count: 32)
        let out = deviceX25519PubThumbprint(pubKey: pub)
        XCTAssertEqual(out, "cs1uhCLEB_ttCYaQ8RMLfe1-wvf14dML2dUh8BU2N5M")
    }

    /// Incrementing-bytes 32-byte pub (0x00..0x1F).
    ///   `base64url(sha256(bytes(range(32))))`
    ///   → `Yw3NKWbEM2aRElRIu7JbT_QSpJxzLbLIq8G4WBvXEN0`
    func testThumbprintRangeVector() {
        let pub = Data((0..<32).map { UInt8($0) })
        let out = deviceX25519PubThumbprint(pubKey: pub)
        XCTAssertEqual(out, "Yw3NKWbEM2aRElRIu7JbT_QSpJxzLbLIq8G4WBvXEN0")
    }

    // MARK: - Encoding invariants

    /// base64url MUST be unpadded — JWS/JWE compact form forbids `=` padding
    /// inside any header field (RFC 7515 Appendix C, RFC 7518 §4.6.1.2).
    func testThumbprintIsUnpaddedBase64Url() {
        let pub = Data(repeating: 0xab, count: 32)
        let out = deviceX25519PubThumbprint(pubKey: pub)
        XCTAssertFalse(out.contains("="), "thumbprint must be unpadded base64url")
        XCTAssertFalse(out.contains("+"), "must use base64url alphabet (- and _)")
        XCTAssertFalse(out.contains("/"), "must use base64url alphabet (- and _)")
    }

    /// SHA-256 is 32 bytes → base64url is exactly ceil(32 * 4 / 3) = 43 chars
    /// once padding is stripped.
    func testThumbprintLengthIs43() {
        let pub = Data(repeating: 0x42, count: 32)
        let out = deviceX25519PubThumbprint(pubKey: pub)
        XCTAssertEqual(out.count, 43, "unpadded base64url of SHA-256 is 43 chars")
    }

    /// Determinism: same input → same output, always.
    func testThumbprintIsDeterministic() {
        let pub = Data(repeating: 0x7f, count: 32)
        let a = deviceX25519PubThumbprint(pubKey: pub)
        let b = deviceX25519PubThumbprint(pubKey: pub)
        XCTAssertEqual(a, b)
    }

    // MARK: - Async provider overload

    /// The async overload threads through `DeviceKeypairProvider.getPublicKey()`
    /// and produces the same byte-for-byte output as the sync helper.
    func testAsyncProviderOverloadMatchesSync() async throws {
        let stub = StubKeypair(pub: Data(repeating: 0x99, count: 32))
        let async = try await deviceX25519PubThumbprint(stub)
        let sync = deviceX25519PubThumbprint(pubKey: stub.pub)
        XCTAssertEqual(async, sync)
    }

    /// Real CryptoKit X25519 pub — exercises the typical production input
    /// shape (32 bytes from a generated keypair).
    func testThumbprintOnGeneratedX25519Key() async throws {
        let priv = Curve25519.KeyAgreement.PrivateKey()
        let pubBytes = priv.publicKey.rawRepresentation
        XCTAssertEqual(pubBytes.count, 32)
        let stub = StubKeypair(pub: pubBytes)
        let out = try await deviceX25519PubThumbprint(stub)
        XCTAssertEqual(out.count, 43)
    }

    // MARK: - ISSUE 2 (Wave 10d residual): Curve-neutral helper

    /// ISSUE 2 fix: `pubKeyThumbprint(_:)` is the new Curve-neutral helper
    /// the Ed25519 `sigKid` path in `DeviceJwsSignerImpl.swift` calls. It
    /// MUST produce byte-for-byte identical output to the legacy
    /// `deviceX25519PubThumbprint(pubKey:)` helper for the same bytes —
    /// otherwise the rename would silently change JWS `kid` values and
    /// break the server-side device-registry lookup.
    func testPubKeyThumbprintMatchesDeviceX25519Helper() {
        // Sweep a few representative shapes: all-zero, all-ones,
        // incrementing range, random-ish pattern, real Ed25519 pub, real
        // X25519 pub. Equivalence MUST hold for every input.
        let zero = Data(repeating: 0x00, count: 32)
        let ones = Data(repeating: 0xff, count: 32)
        let range = Data((0..<32).map { UInt8($0) })
        let pattern = Data(repeating: 0xab, count: 32)
        let ed = Curve25519.Signing.PrivateKey().publicKey.rawRepresentation
        let x = Curve25519.KeyAgreement.PrivateKey().publicKey.rawRepresentation

        for pub in [zero, ones, range, pattern, ed, x] {
            XCTAssertEqual(
                pubKeyThumbprint(pub),
                deviceX25519PubThumbprint(pubKey: pub),
                "Curve-neutral helper must match the legacy X25519-named helper byte-for-byte"
            )
        }
    }

    /// Pin the same three lock-in vectors against the Curve-neutral helper
    /// so a future change to ONE entry point can't drift without the other.
    func testPubKeyThumbprintHitsLockInVectors() {
        XCTAssertEqual(
            pubKeyThumbprint(Data(repeating: 0x00, count: 32)),
            "Zmh6rfhivXdsj8GLjp-OIAiXFIVu4jOzkCpZHQ1fKSU"
        )
        XCTAssertEqual(
            pubKeyThumbprint(Data(repeating: 0x01, count: 32)),
            "cs1uhCLEB_ttCYaQ8RMLfe1-wvf14dML2dUh8BU2N5M"
        )
        XCTAssertEqual(
            pubKeyThumbprint(Data((0..<32).map { UInt8($0) })),
            "Yw3NKWbEM2aRElRIu7JbT_QSpJxzLbLIq8G4WBvXEN0"
        )
    }
}

/// Minimal DeviceKeypairProvider that returns a fixed pubkey + a single,
/// in-memory CryptoKit private key. Used to drive the async overload of
/// `deviceX25519PubThumbprint` without touching the Keychain.
private struct StubKeypair: DeviceKeypairProvider {
    let pub: Data
    private let priv: Curve25519.KeyAgreement.PrivateKey

    init(pub: Data) {
        self.pub = pub
        self.priv = Curve25519.KeyAgreement.PrivateKey()
    }

    func getPublicKey() async throws -> Data { pub }
    func getPrivateKey() async throws -> Curve25519.KeyAgreement.PrivateKey { priv }
}
