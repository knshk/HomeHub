// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// Asserts every method on every gated sub-API throws `CapabilityDisabledError`
/// when its capability is disabled — BEFORE any HTTP call is dispatched.
/// We use a real `SignedHttpClient` pointed at an `invalid` host so a missed
/// gate would manifest as a network error rather than a CapabilityDisabledError.
final class SubAPICapabilityGatesTests: XCTestCase {

    private func makeHttp() -> SignedHttpClient {
        SignedHttpClient(
            signer: HmacSigner(productSlug: "test", sdkSecret: "test-secret"),
            auth: DevAuthTokenProvider(uid: "u", email: "t@example.com"),
            appCheck: NoAppCheckProvider(),
            pinner: CertificatePinner(pinnedSpkiSha256: []))
    }

    private func endpoint() -> URL { URL(string: "https://never-called.invalid")! }

    private func assertCapabilityDisabled(_ block: () async throws -> Void) async {
        do {
            try await block()
            XCTFail("Expected CapabilityDisabledError")
        } catch is CapabilityDisabledError {
            // expected
        } catch {
            XCTFail("Expected CapabilityDisabledError, got \(type(of: error))")
        }
    }

    // MARK: - Notifications

    func testNotificationsGate() async {
        let caps = SdkCapabilities(notifications: false)
        let api = NotificationsAPI(http: makeHttp(), endpoint: { self.endpoint() }, capabilities: caps)
        await assertCapabilityDisabled { _ = try await api.inbox() }
        await assertCapabilityDisabled { try await api.markRead("id") }
        await assertCapabilityDisabled { _ = try await api.getPreferences() }
        await assertCapabilityDisabled {
            _ = try await api.updatePreferences(NotificationPreferences())
        }
    }

    // MARK: - Feedback

    func testFeedbackGate() async {
        let caps = SdkCapabilities(feedback: false)
        let api = FeedbackAPI(http: makeHttp(), endpoint: { self.endpoint() }, capabilities: caps)
        await assertCapabilityDisabled { _ = try await api.submit(category: "bug") }
        await assertCapabilityDisabled { _ = try await api.nps(score: 8) }
        await assertCapabilityDisabled { _ = try await api.csat(score: 4) }
        await assertCapabilityDisabled { try await api.markPromptShown("nps_q3") }
    }

    // MARK: - Support

    func testSupportGate() async {
        let caps = SdkCapabilities(support: false)
        let api = SupportAPI(http: makeHttp(), endpoint: { self.endpoint() }, capabilities: caps)
        await assertCapabilityDisabled {
            _ = try await api.openTicket(subject: "s", body: "b")
        }
        await assertCapabilityDisabled { _ = try await api.listTickets() }
        await assertCapabilityDisabled { _ = try await api.getTicket("id") }
        await assertCapabilityDisabled {
            _ = try await api.replyTo(ticketId: "id", message: "m")
        }
    }

    // MARK: - Subscription

    func testSubscriptionGate() async {
        let caps = SdkCapabilities(subscription: false)
        let api = SubscriptionAPI(http: makeHttp(), endpoint: { self.endpoint() }, capabilities: caps)
        await assertCapabilityDisabled { _ = try await api.tiers() }
        await assertCapabilityDisabled { _ = try await api.currentPlan() }
        await assertCapabilityDisabled { try await api.upgradeTo("pro") }
        await assertCapabilityDisabled { try await api.cancel() }
        await assertCapabilityDisabled { _ = try await api.portalSessionUrl() }
    }

    // MARK: - Privacy

    func testPrivacyGate() async {
        let caps = SdkCapabilities(privacy: false)
        let api = PrivacyAPI(http: makeHttp(), endpoint: { self.endpoint() }, capabilities: caps)
        await assertCapabilityDisabled { _ = try await api.exportData() }
        await assertCapabilityDisabled {
            _ = try await api.requestErasure(confirmation: "t@example.com")
        }
        await assertCapabilityDisabled { _ = try await api.getConsents() }
    }

    // MARK: - Preferences

    func testPreferencesGate() async {
        let caps = SdkCapabilities(preferences: false)
        let api = PreferencesAPI(http: makeHttp(), endpoint: { self.endpoint() }, capabilities: caps)
        await assertCapabilityDisabled { _ = try await api.refresh() }
        await assertCapabilityDisabled { _ = try await api.update("theme", "dark") }
        await assertCapabilityDisabled { _ = try await api.updateMany(["k": "v"]) }
    }

    func testPreferencesCachedReadBypassesGate() async {
        // cachedValue is a pure-local read from the JWT-seeded snapshot. It
        // does NOT round-trip the server and intentionally bypasses the gate
        // — products that disable preferences for writes still want offline
        // read consistency.
        let caps = SdkCapabilities(preferences: false)
        let api = PreferencesAPI(http: makeHttp(), endpoint: { self.endpoint() }, capabilities: caps)
        await api.primeSnapshot(["theme": "dark"])
        let value: String? = await api.cachedValue("theme", as: String.self)
        XCTAssertEqual(value, "dark")
    }
}
