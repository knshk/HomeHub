// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import CryptoKit
import Foundation
import XCTest
@testable import Vanaheim

/// Tests for `VanaheimConfig` (renamed from v1 `LicenseStoreConfig`).
///
/// v2 contract:
///   * `projectId: Int` — required, no default (was positional in v1).
///   * `l2BaseUrl: URL` — required, no default (replaces v1 `bifrostBaseUrl`).
///   * `jweDecryptor: JwePayloadDecryptor` — required (was optional in v1).
///   * `deviceKeypairProvider: DeviceKeypairProvider` — required (was
///     optional in v1).
///   * NO `bifrostBaseUrl` field (deleted in v2; SDK no longer talks to
///     Bifrost directly — device enrollment goes through L2 instead).
///
/// We exercise the public surface: required params at their published
/// types, default optional params at their published values, and the
/// type-name lock-in (so a rename caught by symbol search).
final class VanaheimConfigTests: XCTestCase {

    // MARK: - Stubs

    private struct StubDecryptor: JwePayloadDecryptor {
        func decrypt(_ jwe: String) async throws -> String { "" }
    }
    private struct StubKeypair: DeviceKeypairProvider {
        func getPublicKey() async throws -> Data { Data(repeating: 0x01, count: 32) }
        // Conformance stub — VanaheimConfig surface tests don't exercise the
        // private-key path, but the protocol requires it post-S-09 wiring.
        func getPrivateKey() async throws -> Curve25519.KeyAgreement.PrivateKey {
            Curve25519.KeyAgreement.PrivateKey()
        }
    }

    // MARK: - Required field surface

    func testRequiredFieldsAreNonOptional() {
        let cfg = VanaheimConfig(
            projectId: 42,
            l2BaseUrl: URL(string: "https://l2.example/")!,
            jweDecryptor: StubDecryptor(),
            deviceKeypairProvider: StubKeypair()
        )
        XCTAssertEqual(cfg.projectId, 42)
        XCTAssertEqual(cfg.l2BaseUrl, URL(string: "https://l2.example/"))
        // Existence checks; types are non-optional so the compiler enforces.
        let _: JwePayloadDecryptor = cfg.jweDecryptor
        let _: DeviceKeypairProvider = cfg.deviceKeypairProvider
    }

    /// Sanity: re-reading the same field round-trips the value provided.
    func testProjectIdRoundTrip() {
        let cfg = VanaheimConfig(
            projectId: 7,
            l2BaseUrl: URL(string: "https://l2.example")!,
            jweDecryptor: StubDecryptor(),
            deviceKeypairProvider: StubKeypair()
        )
        XCTAssertEqual(cfg.projectId, 7)
    }

    // MARK: - Default optional values

    func testDefaultsForOptionalParameters() {
        let cfg = VanaheimConfig(
            projectId: 1,
            l2BaseUrl: URL(string: "https://l2.example")!,
            jweDecryptor: StubDecryptor(),
            deviceKeypairProvider: StubKeypair()
        )
        XCTAssertEqual(cfg.refreshBefore, 24 * 60 * 60)
        XCTAssertNil(cfg.hardOfflineGrace)
        XCTAssertEqual(cfg.pinnedSpkiSha256, [])
        XCTAssertEqual(cfg.jwksCacheTtl, 60 * 60)
        XCTAssertEqual(cfg.httpTimeout, 15)
        XCTAssertEqual(cfg.clockSkew, 5 * 60)
        XCTAssertFalse(cfg.allowDevAuthBypass)
    }

    func testOptionalOverridesPropagate() {
        let cfg = VanaheimConfig(
            projectId: 1,
            l2BaseUrl: URL(string: "https://l2.example")!,
            jweDecryptor: StubDecryptor(),
            deviceKeypairProvider: StubKeypair(),
            refreshBefore: 600,
            hardOfflineGrace: 7 * 24 * 60 * 60,
            pinnedSpkiSha256: ["pin-a", "pin-b"],
            jwksCacheTtl: 120,
            httpTimeout: 30,
            clockSkew: 60,
            allowDevAuthBypass: true
        )
        XCTAssertEqual(cfg.refreshBefore, 600)
        XCTAssertEqual(cfg.hardOfflineGrace, 7 * 24 * 60 * 60)
        XCTAssertEqual(cfg.pinnedSpkiSha256, ["pin-a", "pin-b"])
        XCTAssertEqual(cfg.jwksCacheTtl, 120)
        XCTAssertEqual(cfg.httpTimeout, 30)
        XCTAssertEqual(cfg.clockSkew, 60)
        XCTAssertTrue(cfg.allowDevAuthBypass)
    }

    // MARK: - Sendable conformance (compile-time check)
    //
    // VanaheimConfig must be Sendable so it can cross actor boundaries when
    // LicenseClient hands it to the SignedHttpClient and DevicesAPI.
    func testSendableConformance() {
        let cfg: any Sendable = VanaheimConfig(
            projectId: 1,
            l2BaseUrl: URL(string: "https://l2.example")!,
            jweDecryptor: StubDecryptor(),
            deviceKeypairProvider: StubKeypair()
        )
        _ = cfg
    }

    // MARK: - Type-name lock-in
    //
    // If a future refactor renames the struct we want the symbol break to
    // surface in tests, not at integrator-call-site only. The reflective
    // type-name check catches a silent rename of `VanaheimConfig` → anything
    // else.
    func testTypeNameIsVanaheimConfig() {
        let cfg = VanaheimConfig(
            projectId: 1,
            l2BaseUrl: URL(string: "https://l2.example")!,
            jweDecryptor: StubDecryptor(),
            deviceKeypairProvider: StubKeypair()
        )
        let typeName = String(describing: type(of: cfg))
        XCTAssertEqual(typeName, "VanaheimConfig",
            "type rename detected — update tests + integrator docs")
    }
}
