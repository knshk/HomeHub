// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import CryptoKit
import XCTest
@testable import Vanaheim

final class HmacSignerTests: XCTestCase {

    func testProducesDeterministicSignatureForFixedInputs() {
        let signer = HmacSigner(productSlug: "zenkit", sdkSecret: "super-secret")
        let body = #"{"hello":"world"}"#
        let ts = "1700000000"

        // Hand-compute the expected: HMAC-SHA256(secret, "ts\nproduct\nbody")
        let key = SymmetricKey(data: Data("super-secret".utf8))
        let input = "\(ts)\nzenkit\n\(body)".data(using: .utf8)!
        let expectedMac = HMAC<SHA256>.authenticationCode(for: input, using: key)
        let expectedHex = expectedMac.map { String(format: "%02x", $0) }.joined()

        // Use the signer's internal sign() with an explicit `now` so we match
        // the same timestamp. (Signer takes Date, we convert to Unix seconds.)
        let result = signer.sign(body, now: Date(timeIntervalSince1970: 1_700_000_000))
        XCTAssertEqual(result.timestamp, ts)
        XCTAssertEqual(result.signature, expectedHex)
        XCTAssertEqual(result.signature.count, 64) // sha256 hex = 64 chars
    }

    func testSignatureChangesWhenAnyInputChanges() {
        let s1 = HmacSigner(productSlug: "p", sdkSecret: "s")
        let s2 = HmacSigner(productSlug: "p", sdkSecret: "X") // different secret
        let s3 = HmacSigner(productSlug: "q", sdkSecret: "s") // different product

        let now = Date(timeIntervalSince1970: 1_700_000_000)
        let base = s1.sign("b", now: now).signature
        XCTAssertNotEqual(base, s2.sign("b", now: now).signature)
        XCTAssertNotEqual(base, s3.sign("b", now: now).signature)
        XCTAssertNotEqual(base, s1.sign("B", now: now).signature) // body diff
        XCTAssertNotEqual(base,
            s1.sign("b", now: Date(timeIntervalSince1970: 1_700_000_001)).signature) // ts diff
    }
}
