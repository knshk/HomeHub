// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

final class GraceStateMachineTests: XCTestCase {

    let sm = GraceStateMachine(refreshBefore: 24 * 60 * 60, clockSkew: 5 * 60)
    let now = Date(timeIntervalSince1970: 1_716_000_000) // 2024-05-18 UTC

    func testReturnsNoJwtWhenNoExpiry() {
        XCTAssertEqual(sm.evaluate(jwtExpiresAt: nil, now: now).state, .noJwt)
    }

    func testReturnsFreshWhenExpFarAway() {
        let d = sm.evaluate(jwtExpiresAt: now.addingTimeInterval(7 * 24 * 60 * 60), now: now)
        XCTAssertEqual(d.state, .fresh)
        XCTAssertEqual(d.timeUntilExpiry, 7 * 24 * 60 * 60)
    }

    func testReturnsRefreshNeededInsideRefreshWindow() {
        let d = sm.evaluate(jwtExpiresAt: now.addingTimeInterval(12 * 60 * 60), now: now)
        XCTAssertEqual(d.state, .refreshNeeded)
    }

    func testBoundaryExactlyAtRefreshBeforeIsRefreshNeeded() {
        let d = sm.evaluate(jwtExpiresAt: now.addingTimeInterval(24 * 60 * 60), now: now)
        XCTAssertEqual(d.state, .refreshNeeded)
    }

    func testReturnsExpiredPastSkew() {
        let d = sm.evaluate(jwtExpiresAt: now.addingTimeInterval(-10 * 60), now: now)
        XCTAssertEqual(d.state, .expired)
        XCTAssertEqual(d.sinceExpiry, 10 * 60)
    }

    func testWithinSkewPastExpStillRefreshNeeded() {
        // -2 minutes past exp is within +/- 5 min skew → not expired yet
        let d = sm.evaluate(jwtExpiresAt: now.addingTimeInterval(-2 * 60), now: now)
        XCTAssertEqual(d.state, .refreshNeeded)
    }
}
