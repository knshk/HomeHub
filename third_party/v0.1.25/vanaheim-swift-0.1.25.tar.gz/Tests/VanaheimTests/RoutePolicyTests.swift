// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// Tests for `RoutePolicy.classify` and the JWS-allowed carve-out.
///
/// Default-deny is the load-bearing invariant: any route NOT in
/// `jwsAllowedRoutes` MUST classify as `.jweRequired`. A regression that
/// silently downgrades a data-plane call to plaintext would be a security
/// incident, so these tests over-fit on purpose.
final class RoutePolicyTests: XCTestCase {

    // MARK: - Default-deny

    func testDefaultDenyForUnknownPath() {
        XCTAssertEqual(RoutePolicy.classify("/v1/account/me"), .jweRequired)
        XCTAssertEqual(RoutePolicy.classify("/v1/license/issue"), .jweRequired)
        XCTAssertEqual(RoutePolicy.classify("/v1/checkout"), .jweRequired)
        XCTAssertEqual(RoutePolicy.classify("/v1/kyc/start"), .jweRequired)
        XCTAssertEqual(RoutePolicy.classify("/totally/unknown"), .jweRequired)
    }

    func testEmptyPathClassifiesAsJweRequired() {
        // Empty / root → no match in allowlist → default-deny.
        XCTAssertEqual(RoutePolicy.classify(""), .jweRequired)
        XCTAssertEqual(RoutePolicy.classify("/"), .jweRequired)
    }

    // MARK: - Allowlist exact matches

    func testAllowlistedSplashAndCatalog() {
        XCTAssertEqual(RoutePolicy.classify("/v1/explore/splash"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/v1/catalog/explore"), .jwsAllowed)
    }

    func testAllowlistedMetadataAndHealth() {
        XCTAssertEqual(RoutePolicy.classify("/v1/meta"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/healthz"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/readyz"), .jwsAllowed)
    }

    func testAllowlistedJwks() {
        XCTAssertEqual(RoutePolicy.classify("/v1/.well-known/jwks.json"), .jwsAllowed)
    }

    // MARK: - Glob-style prefix matches under /v1/status/, /v1/docs/, /v1/marketing/

    func testStatusPrefixAllowsSubpaths() {
        XCTAssertEqual(RoutePolicy.classify("/v1/status"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/v1/status/"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/v1/status/uptime"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/v1/status/incidents/123"), .jwsAllowed)
    }

    func testDocsPrefixAllowsSubpaths() {
        XCTAssertEqual(RoutePolicy.classify("/v1/docs"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/v1/docs/"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/v1/docs/getting-started"), .jwsAllowed)
    }

    func testMarketingPrefixAllowsSubpaths() {
        XCTAssertEqual(RoutePolicy.classify("/v1/marketing"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/v1/marketing/landing"), .jwsAllowed)
    }

    // MARK: - Path-segment-aware matching

    func testPrefixMustBeSegmentAligned() {
        // `/v1/metadata` shares leading characters with `/v1/meta` but is a
        // DIFFERENT path; classifier must NOT downgrade it.
        XCTAssertEqual(RoutePolicy.classify("/v1/metadata"), .jweRequired)
        // Similarly, `/v1/statuspage` shares chars with `/v1/status/` but is
        // not the same path segment → must NOT downgrade.
        XCTAssertEqual(RoutePolicy.classify("/v1/statuspage"), .jweRequired)
        XCTAssertEqual(RoutePolicy.classify("/v1/docsearch"), .jweRequired)
    }

    func testTrailingSlashIsNormalized() {
        XCTAssertEqual(RoutePolicy.classify("/v1/meta/"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/healthz/"), .jwsAllowed)
    }

    func testQueryAndFragmentAreStripped() {
        XCTAssertEqual(RoutePolicy.classify("/healthz?foo=bar"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/v1/meta#hash"), .jwsAllowed)
        XCTAssertEqual(RoutePolicy.classify("/v1/license/issue?secret=hi"), .jweRequired)
    }

    func testCaseSensitiveClassification() {
        // HTTP paths are case-sensitive; an uppercase variant must NOT be
        // treated as an allowlisted route.
        XCTAssertEqual(RoutePolicy.classify("/V1/META"), .jweRequired)
        XCTAssertEqual(RoutePolicy.classify("/HealthZ"), .jweRequired)
    }

    // MARK: - Material-change hint (telemetry only, NOT a security control)

    func testMaterialChangeHintLicenseRoutes() {
        XCTAssertTrue(RoutePolicy.isMaterialChangeHint("/v1/license/issue"))
        XCTAssertTrue(RoutePolicy.isMaterialChangeHint("/v1/license/upgrade"))
        XCTAssertTrue(RoutePolicy.isMaterialChangeHint("/v1/license/transfer"))
        XCTAssertTrue(RoutePolicy.isMaterialChangeHint("/v1/checkout"))
        XCTAssertTrue(RoutePolicy.isMaterialChangeHint("/v1/payments/charge"))
        XCTAssertTrue(RoutePolicy.isMaterialChangeHint("/v1/kyc/start"))
    }

    func testMaterialChangeHintNonMaterial() {
        XCTAssertFalse(RoutePolicy.isMaterialChangeHint("/v1/account/me"))
        XCTAssertFalse(RoutePolicy.isMaterialChangeHint("/healthz"))
        XCTAssertFalse(RoutePolicy.isMaterialChangeHint("/v1/meta"))
        XCTAssertFalse(RoutePolicy.isMaterialChangeHint("/v1/marketing/landing"))
    }

    // MARK: - Allowlist surface lock-in
    //
    // Locks the size + content of `jwsAllowedRoutes` so a stray addition to
    // the list trips a test and routes through security review.
    func testJwsAllowedRoutesSurfaceLockIn() {
        let expected: Set<String> = [
            "/v1/explore/splash",
            "/v1/catalog/explore",
            "/v1/meta",
            "/healthz",
            "/readyz",
            "/v1/.well-known/jwks.json",
            "/v1/status/",
            "/v1/docs/",
            "/v1/marketing/",
        ]
        XCTAssertEqual(Set(RoutePolicy.jwsAllowedRoutes), expected,
            "JWS-allowed routes drifted from the audited list — security review required.")
    }
}
