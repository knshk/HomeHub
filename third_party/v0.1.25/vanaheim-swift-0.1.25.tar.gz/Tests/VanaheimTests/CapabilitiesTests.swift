// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

final class CapabilitiesTests: XCTestCase {

    func testDefaultsAllEnabled() {
        let c = SdkCapabilities.defaults
        XCTAssertTrue(c.notifications)
        XCTAssertTrue(c.feedback)
        XCTAssertTrue(c.support)
        XCTAssertTrue(c.subscription)
        XCTAssertTrue(c.privacy)
        XCTAssertTrue(c.preferences)
        XCTAssertTrue(c.telemetry)
        XCTAssertTrue(c.assistant)
        XCTAssertTrue(c.referrals)
        XCTAssertTrue(c.status)
        XCTAssertTrue(c.organization)
        XCTAssertTrue(c.offers)
        XCTAssertTrue(c.docs)
    }

    func testDefaultTunables() {
        let c = SdkCapabilities.defaults
        XCTAssertEqual(c.feedbackMaxAttachmentMb, 5)
        XCTAssertEqual(c.notificationInboxPageSize, 50)
        XCTAssertEqual(c.telemetryBatchSize, 20)
        XCTAssertEqual(c.telemetryFlushIntervalSeconds, 30)
        XCTAssertEqual(c.telemetryMaxBuffer, 500)
    }

    func testFromJsonRooted() throws {
        let json = """
        {
          "license_store_sdk": {
            "capabilities": {
              "assistant": false,
              "referrals": false,
              "telemetry": true
            },
            "defaults": {
              "telemetry_batch_size": 50,
              "notification_inbox_page_size": 25
            }
          }
        }
        """.data(using: .utf8)!
        let c = try SdkCapabilities.fromJson(json)
        XCTAssertFalse(c.assistant)
        XCTAssertFalse(c.referrals)
        XCTAssertTrue(c.telemetry)
        XCTAssertEqual(c.telemetryBatchSize, 50)
        XCTAssertEqual(c.notificationInboxPageSize, 25)
        XCTAssertTrue(c.notifications) // unmentioned → default true
    }

    func testFromJsonUnrooted() throws {
        let json = """
        { "capabilities": { "offers": false } }
        """.data(using: .utf8)!
        let c = try SdkCapabilities.fromJson(json)
        XCTAssertFalse(c.offers)
        XCTAssertTrue(c.notifications)
    }

    func testFromJsonEmpty() throws {
        let json = "{}".data(using: .utf8)!
        let c = try SdkCapabilities.fromJson(json)
        XCTAssertTrue(c.notifications)
        XCTAssertTrue(c.assistant)
    }

    func testRequireDoesNotThrowWhenEnabled() throws {
        let c = SdkCapabilities.defaults
        XCTAssertNoThrow(try c.require("assistant"))
        XCTAssertNoThrow(try c.require("telemetry"))
    }

    func testRequireThrowsCapabilityDisabledError() {
        let c = SdkCapabilities(assistant: false)
        XCTAssertThrowsError(try c.require("assistant")) { error in
            guard let e = error as? CapabilityDisabledError else {
                XCTFail("Expected CapabilityDisabledError, got \(type(of: error))")
                return
            }
            XCTAssertEqual(e.capability, "assistant")
        }
    }

    func testUnknownCapabilityForwardCompatEnabled() {
        let c = SdkCapabilities.defaults
        XCTAssertTrue(c.isEnabled("some_future_capability"))
        XCTAssertNoThrow(try c.require("some_future_capability"))
    }

    // MARK: - Formatter

    func testFormatterReturnsKeyWhenMissing() {
        let f = MessageFormatter()
        XCTAssertEqual(f.format("hello.world"), "hello.world")
    }

    func testFormatterSubstitutesVariable() {
        let f = MessageFormatter(catalog: ["greet": "Hello, {name}!"])
        XCTAssertEqual(f.format("greet", vars: ["name": "Kanishka"]),
                       "Hello, Kanishka!")
    }

    func testFormatterPluralOne() {
        let f = MessageFormatter(catalog: [
            "cart": "{count, plural, one {1 item} other {{count} items}}"
        ])
        XCTAssertEqual(f.format("cart", vars: ["count": 1]), "1 item")
    }

    func testFormatterPluralOther() {
        let f = MessageFormatter(catalog: [
            "cart": "{count, plural, one {1 item} other {{count} items}}"
        ])
        XCTAssertEqual(f.format("cart", vars: ["count": 5]), "5 items")
    }

    func testFormatterPluralZero() {
        let f = MessageFormatter(catalog: [
            "cart": "{count, plural, zero {empty cart} one {1 item} other {{count} items}}"
        ])
        XCTAssertEqual(f.format("cart", vars: ["count": 0]), "empty cart")
    }

    func testFormatterPreservesUnknownVars() {
        let f = MessageFormatter(catalog: ["msg": "Hello {missing}"])
        XCTAssertEqual(f.format("msg", vars: ["other": "x"]), "Hello {missing}")
    }

    // MARK: - select form

    func testFormatterSelectMatchedBranch() {
        let f = MessageFormatter(catalog: [
            "partner": "{role, select, partner {Partner} admin {Admin} other {Member}}"
        ])
        XCTAssertEqual(f.format("partner", vars: ["role": "partner"]), "Partner")
        XCTAssertEqual(f.format("partner", vars: ["role": "admin"]), "Admin")
    }

    func testFormatterSelectFallsBackToOther() {
        let f = MessageFormatter(catalog: [
            "partner": "{role, select, partner {Partner} other {Member}}"
        ])
        XCTAssertEqual(f.format("partner", vars: ["role": "staff"]), "Member")
        XCTAssertEqual(f.format("partner", vars: [:]), "Member")
    }

    func testFormatterSelectWithEmbeddedSubstitution() {
        let f = MessageFormatter(catalog: [
            "greet": "{role, select, partner {Welcome, partner {name}!} other {Hi, {name}}}"
        ])
        XCTAssertEqual(
            f.format("greet", vars: ["role": "partner", "name": "Kanishka"]),
            "Welcome, partner Kanishka!")
        XCTAssertEqual(
            f.format("greet", vars: ["role": "customer", "name": "Alex"]),
            "Hi, Alex")
    }

    // MARK: - reportCapability wire validation (v0.1.19)
    //
    // These tests exercise the CLIENT-SIDE regex + wire-shape constants.
    // The full HTTP round-trip lives in a separate integration suite
    // (SignedHttpClient is protocol-driven — the network path is covered
    // by SignedHttpClientJweTests + the Dart/TS parity fixtures).

    func testCapabilityKeyValidExact() throws {
        XCTAssertNoThrow(
            try CapabilityReportValidation.requireValidKey("has_ab"))
        XCTAssertNoThrow(
            try CapabilityReportValidation.requireValidKey(
                "has_offline_export"))
        XCTAssertNoThrow(
            try CapabilityReportValidation.requireValidKey(
                "has_feature_123"))
    }

    func testCapabilityKeyValidMinLength() throws {
        // 4-char prefix + 2 chars = 6 total; the {2,64} tail floor.
        XCTAssertNoThrow(
            try CapabilityReportValidation.requireValidKey("has_ab"))
    }

    func testCapabilityKeyValidMaxLength() throws {
        // 4-char prefix + 64 chars tail = 68 total.
        let tail = String(repeating: "a", count: 64)
        XCTAssertNoThrow(
            try CapabilityReportValidation.requireValidKey("has_\(tail)"))
    }

    func testCapabilityKeyRejectsEmpty() {
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey("")
        ) { error in
            guard let e = error as? CapabilityKeyInvalidError else {
                XCTFail("expected CapabilityKeyInvalidError, got \(type(of: error))")
                return
            }
            XCTAssertEqual(e.key, "")
        }
    }

    func testCapabilityKeyRejectsMissingHasPrefix() {
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey("offline_export")
        )
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey("HAS_offline")
        )
    }

    func testCapabilityKeyRejectsTooShortTail() {
        // has_ + 1 char = 5 total — regex tail floor is {2}, so fails.
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey("has_a"))
    }

    func testCapabilityKeyRejectsTooLongTail() {
        // has_ + 65 chars = 69 total — regex tail ceiling is {64}, so fails.
        let tail = String(repeating: "a", count: 65)
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey("has_\(tail)"))
    }

    func testCapabilityKeyRejectsUppercaseInTail() {
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey("has_Offline"))
    }

    func testCapabilityKeyRejectsHyphenInTail() {
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey("has_offline-export"))
    }

    func testCapabilityKeyRejectsDotInTail() {
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey("has_offline.export"))
    }

    func testCapabilityKeyRejectsEmailLike() {
        // Defence-in-depth against accidental PII in keys — matches the
        // server-side PII rejection posture (rejected via regex-shape
        // mismatch first; server does an additional PII regex check).
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey(
                "has_user@example.com"))
    }

    func testCapabilityKeyRejectsWhitespaceOnly() {
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey("   "))
    }

    func testCapabilityKeyRejectsLeadingWhitespace() {
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey(" has_ab"))
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey("has_ab "))
    }

    func testCapabilityKeyRegexIsFullyAnchored() {
        // A partial-match regex would let "prefixhas_valid_keysuffix"
        // through. We assert on the anchored full-string match.
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey(
                "xhas_offline"))
        XCTAssertThrowsError(
            try CapabilityReportValidation.requireValidKey(
                "has_offline!"))
    }

    func testCapabilityErrorEchoesKey() {
        do {
            try CapabilityReportValidation.requireValidKey("nope")
            XCTFail("expected throw")
        } catch let e as CapabilityKeyInvalidError {
            XCTAssertEqual(e.key, "nope")
            XCTAssertTrue(e.message.contains("nope"))
        } catch {
            XCTFail("wrong error type: \(type(of: error))")
        }
    }

    func testReportCapabilityWireConstantsMatchFixture() {
        // Parity guard — must match the fron-parity-fixtures.json
        // "apps.report_capability" block byte-for-byte. If either side
        // drifts, this test surfaces it in CI before a cross-SDK bug
        // ships.
        XCTAssertEqual(ReportCapabilityWire.routePath,
                       "/v1/apps/capabilities")
        XCTAssertEqual(ReportCapabilityWire.bodyKeyKey, "key")
        XCTAssertEqual(ReportCapabilityWire.bodyKeyValue, "value")
        XCTAssertEqual(ReportCapabilityWire.maxAttempts, 3)
    }

    func testReportCapabilityBodyShape() throws {
        // Confirms the exact wire body shape a call would serialize to.
        // Uses JSONSerialization + sorted keys so the byte-level output
        // is deterministic + comparable across languages.
        let body: [String: Any] = [
            ReportCapabilityWire.bodyKeyKey: "has_offline_export",
            ReportCapabilityWire.bodyKeyValue: true,
        ]
        let data = try JSONSerialization.data(
            withJSONObject: body,
            options: [.sortedKeys])
        let str = String(data: data, encoding: .utf8) ?? ""
        XCTAssertEqual(str,
            "{\"key\":\"has_offline_export\",\"value\":true}")
    }

    func testReportCapabilityKeyPatternIsPinned() {
        // The exact regex the server enforces — if this literal ever
        // shifts on either side (Alfheim, Dart, TS, Swift) the entire
        // capability report path breaks silently. Pin the string here.
        XCTAssertEqual(CapabilityReportValidation.keyPattern,
                       "^has_[a-z0-9_]{2,64}$")
    }
}
