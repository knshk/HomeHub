// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

final class ErrorTelemetryTests: XCTestCase {

    func testRingBufferBoundedAndFifo() async {
        let t = ErrorTelemetry(maxBuffer: 3, persistDebounce: 10)
        for i in 0..<10 {
            await t.capture(source: "test", error: NSError(domain: "x", code: i))
        }
        let recent = await t.recent()
        XCTAssertEqual(recent.count, 3)
        XCTAssertTrue(recent.first!.message.contains("9") == false || recent.last!.message.contains("9"))
        // Newest last: codes 7,8,9 survived.
    }

    func testCaptureDoesNotThrowOnUnusualInputs() async {
        let t = ErrorTelemetry(maxBuffer: 5, persistDebounce: 10)
        // Any Error subtype must be accepted without throw.
        await t.capture(source: "", error: NSError(domain: "x", code: 0))
        struct CustomError: Error {}
        await t.capture(source: "x", error: CustomError())
        await t.capture(source: "x", error: SeatCapExceededError())
        let recent = await t.recent()
        XCTAssertEqual(recent.count, 3)
    }

    func testPersistAndRestoreRoundTrip() async {
        let cache = InMemorySecureCache()
        let t1 = ErrorTelemetry(cache: cache, persistDebounce: 0.01)
        await t1.capture(source: "verify", error: NSError(domain: "test", code: 1,
            userInfo: [NSLocalizedDescriptionKey: "boom"]))
        try? await Task.sleep(nanoseconds: 50_000_000)
        await t1.flush()

        let t2 = ErrorTelemetry(cache: cache)
        await t2.restore()
        let restored = await t2.recent()
        XCTAssertEqual(restored.count, 1)
        XCTAssertEqual(restored.first?.source, "verify")
    }

    func testClearEmptiesBufferAndPersistedBlob() async throws {
        let cache = InMemorySecureCache()
        let t = ErrorTelemetry(cache: cache)
        await t.capture(source: "x", error: NSError(domain: "y", code: 1))
        await t.flush()
        let stored = try await cache.getTelemetry()
        XCTAssertNotNil(stored)

        await t.clear()
        // XCTAssert*'s autoclosure can't suspend — extract awaited values first.
        let remaining = await t.recent()
        XCTAssertTrue(remaining.isEmpty)
        let after = try await cache.getTelemetry()
        XCTAssertEqual(after, "[]")
    }

    func testTruncatesVeryLongMessagesAndStacks() async {
        let t = ErrorTelemetry(maxBuffer: 1)
        let big = String(repeating: "x", count: 5000)
        await t.capture(source: "test",
                        error: NSError(domain: "huge", code: 0, userInfo: [NSLocalizedDescriptionKey: big]),
                        stack: String(repeating: "y", count: 10000))
        let ev = await t.recent().first
        XCTAssertNotNil(ev)
        XCTAssertLessThanOrEqual(ev!.message.count, 2100)
        XCTAssertLessThanOrEqual(ev!.stack?.count ?? 0, 4100)
    }

    func testRestoreWithCorruptBlobStartsClean() async {
        let cache = InMemorySecureCache()
        await cache.putTelemetry("not valid json at all")
        let t = ErrorTelemetry(cache: cache)
        await t.restore()
        let recent = await t.recent()
        XCTAssertTrue(recent.isEmpty)
    }

    func testInMemoryCacheClearPreservesTelemetry() async throws {
        let cache = InMemorySecureCache()
        await cache.putTelemetry(#"[{"ts":"2026-01-01T00:00:00.000Z","severity":"error","source":"x","error_class":"y","message":"z","context":{}}]"#)
        await cache.putJwt("some-jwt")
        await cache.clear()
        let jwtAfter = await cache.getJwt()
        XCTAssertNil(jwtAfter)
        let telemetry = await cache.getTelemetry()
        XCTAssertNotNil(telemetry, "telemetry must NOT be wiped by SecureCache.clear()")
    }
}
