// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import CryptoKit
import XCTest
@testable import Vanaheim

final class JwtVerifierTests: XCTestCase {

    var keys: Curve25519.Signing.PrivateKey!
    var altKeys: Curve25519.Signing.PrivateKey!
    var pub: Data!
    var pubAlt: Data!

    override func setUp() {
        super.setUp()
        keys = Curve25519.Signing.PrivateKey()
        altKeys = Curve25519.Signing.PrivateKey()
        pub = keys.publicKey.rawRepresentation
        pubAlt = altKeys.publicKey.rawRepresentation
    }

    func goodClaims(exp: Date = Date().addingTimeInterval(3600)) -> [String: Any] {
        [
            "iss": "licenses.example.com",
            "sub": "lic_test_001",
            "aud": "zenkit",
            "acc": "acc_test_001",
            "tier": "pro",
            "ent": ["export": true],
            "ev": 3,
            "iat": Int(Date().timeIntervalSince1970),
            "nbf": Int(Date().timeIntervalSince1970) - 60,
            "exp": Int(exp.timeIntervalSince1970),
        ]
    }

    func makeJwt(claims: [String: Any], kid: String = "test-kid", alg: String = "EdDSA",
                 signingKey: Curve25519.Signing.PrivateKey? = nil) throws -> String {
        let key = signingKey ?? keys!
        let headerData = try JSONSerialization.data(withJSONObject: ["alg": alg, "typ": "JWT", "kid": kid])
        let claimsData = try JSONSerialization.data(withJSONObject: claims)
        let headerB64 = base64Url(headerData)
        let claimsB64 = base64Url(claimsData)
        let signingInput = "\(headerB64).\(claimsB64)".data(using: .utf8)!
        let sig = try key.signature(for: signingInput)
        return "\(headerB64).\(claimsB64).\(base64Url(sig))"
    }

    private func base64Url(_ data: Data) -> String {
        data.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    func testHappyPath() throws {
        let jwt = try makeJwt(claims: goodClaims())
        let out = try JwtVerifier.verifyAndDecode(
            jwt: jwt,
            publicKey: pub,
            expectedIssuer: "licenses.example.com",
            expectedAudience: "zenkit")
        XCTAssertEqual(out.licenseId, "lic_test_001")
        XCTAssertEqual(out.accountId, "acc_test_001")
        XCTAssertEqual(out.tier, "pro")
        XCTAssertEqual(out.entitlementsVersion, 3)
    }

    func testThrowsLicenseExpiredErrorOnPastExp() throws {
        let jwt = try makeJwt(claims: goodClaims(exp: Date().addingTimeInterval(-3600)))
        XCTAssertThrowsError(try JwtVerifier.verifyAndDecode(
            jwt: jwt,
            publicKey: pub,
            expectedIssuer: "licenses.example.com",
            expectedAudience: "zenkit",
            clockSkew: 30
        )) { error in
            XCTAssertTrue(error is LicenseExpiredError, "got \(type(of: error))")
        }
    }

    func testThrowsJwtVerificationErrorOnSignatureTamper() throws {
        let jwt = try makeJwt(claims: goodClaims())
        XCTAssertThrowsError(try JwtVerifier.verifyAndDecode(
            jwt: jwt,
            publicKey: pubAlt, // wrong key
            expectedIssuer: "licenses.example.com",
            expectedAudience: "zenkit"
        )) { error in
            XCTAssertTrue(error is JwtVerificationError)
        }
    }

    func testRejectsUnsupportedAlg() throws {
        let jwt = try makeJwt(claims: goodClaims(), alg: "HS256")
        XCTAssertThrowsError(try JwtVerifier.verifyAndDecode(
            jwt: jwt, publicKey: pub,
            expectedIssuer: "licenses.example.com",
            expectedAudience: "zenkit"
        )) { XCTAssertTrue($0 is JwtVerificationError) }
    }

    func testRejectsWrongAudience() throws {
        let jwt = try makeJwt(claims: goodClaims())
        XCTAssertThrowsError(try JwtVerifier.verifyAndDecode(
            jwt: jwt, publicKey: pub,
            expectedIssuer: "licenses.example.com",
            expectedAudience: "other_product"
        )) { XCTAssertTrue($0 is JwtVerificationError) }
    }

    func testRejectsWrongIssuer() throws {
        let jwt = try makeJwt(claims: goodClaims())
        XCTAssertThrowsError(try JwtVerifier.verifyAndDecode(
            jwt: jwt, publicKey: pub,
            expectedIssuer: "attacker.example.com",
            expectedAudience: "zenkit"
        )) { XCTAssertTrue($0 is JwtVerificationError) }
    }

    func testThrowsOnMissingSubClaim() throws {
        var claims = goodClaims()
        claims.removeValue(forKey: "sub")
        let jwt = try makeJwt(claims: claims)
        XCTAssertThrowsError(try JwtVerifier.verifyAndDecode(
            jwt: jwt, publicKey: pub,
            expectedIssuer: "licenses.example.com",
            expectedAudience: "zenkit"
        )) { XCTAssertTrue($0 is JwtVerificationError) }
    }

    func testThrowsOnMissingAccClaim() throws {
        var claims = goodClaims()
        claims.removeValue(forKey: "acc")
        let jwt = try makeJwt(claims: claims)
        XCTAssertThrowsError(try JwtVerifier.verifyAndDecode(
            jwt: jwt, publicKey: pub,
            expectedIssuer: "licenses.example.com",
            expectedAudience: "zenkit"
        )) { XCTAssertTrue($0 is JwtVerificationError) }
    }

    func testThrowsOnMissingTierClaim() throws {
        var claims = goodClaims()
        claims.removeValue(forKey: "tier")
        let jwt = try makeJwt(claims: claims)
        XCTAssertThrowsError(try JwtVerifier.verifyAndDecode(
            jwt: jwt, publicKey: pub,
            expectedIssuer: "licenses.example.com",
            expectedAudience: "zenkit"
        )) { XCTAssertTrue($0 is JwtVerificationError) }
    }

    func testRejectsMalformedJwt() {
        XCTAssertThrowsError(try JwtVerifier.verifyAndDecode(
            jwt: "not-a-jwt", publicKey: pub,
            expectedIssuer: "licenses.example.com",
            expectedAudience: "zenkit"
        )) { XCTAssertTrue($0 is JwtVerificationError) }
    }
}
