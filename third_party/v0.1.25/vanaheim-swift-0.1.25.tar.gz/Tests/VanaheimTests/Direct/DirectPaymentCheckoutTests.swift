// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// W6 / B-FRON.5.1 — `DirectClient.startCheckout(...)` end-to-end tests.
///
/// Each test wires `FakeBifrostDirectServer` through `MockDirectURLProtocol`
/// so the SDK's outbound JWE envelope is decrypted server-side and the
/// inner-JWS claims can be asserted on. The response is sealed back
/// through the same envelope shape the real Bifrost server emits.
final class DirectPaymentCheckoutTests: XCTestCase {

    private var keychainSvc: String!
    private var server: FakeBifrostDirectServer!
    private var session: URLSession!

    override func setUp() async throws {
        try await super.setUp()
        MockDirectURLProtocol.reset()
        keychainSvc = "io.vanaheim.sdk.direct.test.\(UUID().uuidString)"
        server = FakeBifrostDirectServer()
        server.installJwks()
        session = mockDirectSession()
    }

    override func tearDown() async throws {
        MockDirectURLProtocol.reset()
        try await super.tearDown()
    }

    // MARK: - Helpers

    private func makeClient() throws -> DirectClient {
        let cfg = makeTestDirectConfig(baseURL: server.baseURL)
        let resolver = try DirectRecipientResolver(
            bifrostBaseUrl: server.baseURL,
            session: session,
            ttl: 60,
            timeout: 5)
        let store = DirectKeypairStore(service: keychainSvc)
        return try DirectClient(
            config: cfg,
            recipientResolver: resolver,
            keypairStore: store,
            secureCache: InMemorySecureCache(),
            httpSession: session)
    }

    /// Register the SDK so durable Tier-2 calls have a device_id.
    private func registerOnce(client: DirectClient) async throws {
        server.installRoute(path: "/direct/v1/register") { _, _ in
            return [
                "device_id": "dev-checkout",
                "entitlement_jws": "h.p.s",
                "server_nonce": "n",
                "feature_list": ["base"],
                "quotas": ["calls": 5],
                "heartbeat_cadence_ms": 60_000,
            ]
        }
        _ = try await client.register(
            licenseKey: "LCS", fingerprint: "fp", appMeta: [:])
    }

    // MARK: - Happy path

    func testStartCheckoutRoundTrip() async throws {
        server.installRoute(path: "/direct/v1/payment/checkout") { claims, header in
            XCTAssertEqual(header["typ"] as? String,
                           "bifrost-direct+durable+jws")
            XCTAssertEqual(claims["aud"] as? String, "direct:payment.checkout")
            let body = claims["body"] as? [String: Any]
            XCTAssertEqual(body?["tier"] as? String, "pro")
            XCTAssertEqual(body?["billing_cycle"] as? String, "monthly")
            XCTAssertEqual(body?["currency"] as? String, "USD")
            XCTAssertEqual(body?["return_url"] as? String,
                           "https://app.example.com/return")
            XCTAssertEqual(body?["project_id"] as? String, "proj_test")
            // Provider omitted -> field absent.
            XCTAssertNil(body?["provider"])
            // Cancel URL omitted -> field absent.
            XCTAssertNil(body?["cancel_url"])
            return [
                "session_id": "cs_test_123",
                "hosted_url": "https://checkout.stripe.com/c/pay/cs_test_123",
                "expires_at_ms": 1_700_000_900_000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let result = try await client.startCheckout(
            tier: "pro",
            billingCycle: .monthly,
            currency: "USD",
            returnUrl: URL(string: "https://app.example.com/return")!)
        XCTAssertEqual(result.sessionId, "cs_test_123")
        XCTAssertEqual(result.hostedUrl.absoluteString,
                       "https://checkout.stripe.com/c/pay/cs_test_123")
        XCTAssertEqual(result.expiresAtMs, 1_700_000_900_000)
        await client.dispose()
    }

    func testStartCheckoutWithCancelUrlAndProvider() async throws {
        server.installRoute(path: "/direct/v1/payment/checkout") { claims, _ in
            let body = claims["body"] as? [String: Any]
            XCTAssertEqual(body?["cancel_url"] as? String,
                           "https://app.example.com/cancel")
            XCTAssertEqual(body?["provider"] as? String, "paddle")
            XCTAssertEqual(body?["billing_cycle"] as? String, "yearly")
            return [
                "session_id": "cs_y",
                "hosted_url": "https://paddle.test/y",
                "expires_at_ms": 1,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.startCheckout(
            tier: "team_plus",
            billingCycle: .yearly,
            currency: "EUR",
            returnUrl: URL(string: "https://app.example.com/return")!,
            cancelUrl: URL(string: "https://app.example.com/cancel"),
            provider: .paddle)
        XCTAssertEqual(r.sessionId, "cs_y")
        await client.dispose()
    }

    func testStartCheckoutEachProviderRoundTrips() async throws {
        let providers: [(DirectPaymentProvider, String)] = [
            (.stripe, "stripe"),
            (.paddle, "paddle"),
            (.lemonSqueezy, "lemon_squeezy"),
            (.razorpay, "razorpay"),
        ]
        for (p, expected) in providers {
            MockDirectURLProtocol.reset()
            server.installJwks()
            var sawProvider: String?
            server.installRoute(path: "/direct/v1/payment/checkout") { claims, _ in
                let body = claims["body"] as? [String: Any]
                sawProvider = body?["provider"] as? String
                return [
                    "session_id": "s",
                    "hosted_url": "https://x.test/",
                    "expires_at_ms": 1,
                ]
            }
            let client = try makeClient()
            try await client.connect()
            try await registerOnce(client: client)
            _ = try await client.startCheckout(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                returnUrl: URL(string: "https://app.example.com/r")!,
                provider: p)
            XCTAssertEqual(sawProvider, expected,
                           "provider \(p) must serialise as \(expected)")
            await client.dispose()
        }
    }

    // MARK: - Pre-wire validation (no round-trip)

    func testStartCheckoutRejectsNonHttpsReturnUrl() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startCheckout(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                returnUrl: URL(string: "http://app.example.com/return")!)
            XCTFail("expected .badRequest for non-https return url")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "return_url_not_https")
        }
        await client.dispose()
    }

    func testStartCheckoutRejectsNonHttpsCancelUrl() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startCheckout(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                returnUrl: URL(string: "https://app.example.com/r")!,
                cancelUrl: URL(string: "http://app.example.com/c"))
            XCTFail("expected .badRequest for non-https cancel url")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "cancel_url_not_https")
        }
        await client.dispose()
    }

    func testStartCheckoutRejectsOversizedReturnUrl() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        // 2049 chars after the prefix → over the 2048 cap.
        let pad = String(repeating: "a", count: 2049)
        do {
            _ = try await client.startCheckout(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                returnUrl: URL(string: "https://x.test/\(pad)")!)
            XCTFail("expected .badRequest for oversized return url")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "return_url_too_long")
        }
        await client.dispose()
    }

    func testStartCheckoutRejectsInvalidTierSlug() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        // Upper-case + dash both violate `[a-z0-9_]{1,64}`.
        let badTiers = ["Pro", "pro-plus", "", String(repeating: "a", count: 65)]
        for t in badTiers {
            do {
                _ = try await client.startCheckout(
                    tier: t,
                    billingCycle: .monthly,
                    currency: "USD",
                    returnUrl: URL(string: "https://x.test/")!)
                XCTFail("expected .badRequest for tier=\(t)")
            } catch DirectError.badRequest(let r) {
                XCTAssertEqual(r, "tier_invalid",
                               "tier=\(t) should be tier_invalid")
            }
        }
        await client.dispose()
    }

    func testStartCheckoutRejectsInvalidCurrency() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let badCurrencies = ["usd", "US", "USDX", "12B"]
        for c in badCurrencies {
            do {
                _ = try await client.startCheckout(
                    tier: "pro",
                    billingCycle: .monthly,
                    currency: c,
                    returnUrl: URL(string: "https://x.test/")!)
                XCTFail("expected .badRequest for currency=\(c)")
            } catch DirectError.badRequest(let r) {
                XCTAssertEqual(r, "currency_invalid",
                               "currency=\(c) should be currency_invalid")
            }
        }
        await client.dispose()
    }

    func testStartCheckoutAcceptsAllValidTierShapes() async throws {
        // Boundary: exactly 64 chars + underscores + digits.
        let edge = String(repeating: "a", count: 64)
        server.installRoute(path: "/direct/v1/payment/checkout") { _, _ in
            return [
                "session_id": "s",
                "hosted_url": "https://x.test/",
                "expires_at_ms": 1,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        for t in ["pro", "team_plus", "tier_2026", edge, "_", "a", "0"] {
            _ = try await client.startCheckout(
                tier: t,
                billingCycle: .monthly,
                currency: "INR",
                returnUrl: URL(string: "https://x.test/")!)
        }
        await client.dispose()
    }

    // MARK: - Connection gating

    func testStartCheckoutBeforeConnectThrowsNotConnected() async throws {
        let client = try makeClient()
        do {
            _ = try await client.startCheckout(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                returnUrl: URL(string: "https://x.test/")!)
            XCTFail("expected .notConnected")
        } catch DirectError.notConnected {
            // expected
        }
    }

    // MARK: - Server error taxonomy

    func testStartCheckoutMapsBadRequestErrorCode() async throws {
        server.installRoute(
            path: "/direct/v1/payment/checkout",
            statusCode: 400
        ) { _, _ in
            return [
                "error": "DIRECT_BAD_REQUEST",
                "message": "return_url_not_allowlisted",
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startCheckout(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                returnUrl: URL(string: "https://x.test/")!)
            XCTFail("expected .badRequest")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "return_url_not_allowlisted")
        }
        await client.dispose()
    }

    func testStartCheckoutMapsProviderFailedErrorCode() async throws {
        server.installRoute(
            path: "/direct/v1/payment/checkout",
            statusCode: 502
        ) { _, _ in
            return [
                "error": "DIRECT_PAYMENT_PROVIDER_FAILED",
                "message": "stripe",
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startCheckout(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                returnUrl: URL(string: "https://x.test/")!)
            XCTFail("expected .paymentProviderFailed")
        } catch DirectError.paymentProviderFailed(let p) {
            XCTAssertEqual(p, "stripe")
        }
        await client.dispose()
    }

    func testStartCheckoutMapsNoProviderConfigured() async throws {
        server.installRoute(
            path: "/direct/v1/payment/checkout",
            statusCode: 503
        ) { _, _ in
            return ["error": "DIRECT_NO_PROVIDER_CONFIGURED"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startCheckout(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                returnUrl: URL(string: "https://x.test/")!)
            XCTFail("expected .noProviderConfigured")
        } catch DirectError.noProviderConfigured {
            // expected
        }
        await client.dispose()
    }

    func testStartCheckoutSurfacesMissingFieldsAsNetwork() async throws {
        server.installRoute(path: "/direct/v1/payment/checkout") { _, _ in
            return ["session_id": "s"] // missing hosted_url + expires_at_ms
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startCheckout(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                returnUrl: URL(string: "https://x.test/")!)
            XCTFail("expected .network for incomplete payload")
        } catch DirectError.network {
            // expected
        }
        await client.dispose()
    }
}
