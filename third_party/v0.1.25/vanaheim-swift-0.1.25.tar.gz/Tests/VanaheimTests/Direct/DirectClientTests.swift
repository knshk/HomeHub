// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
import CryptoKit
@testable import Vanaheim

/// End-to-end tests for `DirectClient`. Each test wires a
/// `FakeBifrostDirectServer` through a mocked URLSession, drives the
/// client through one or more API methods, and asserts on both the
/// SDK's outbound envelope (decrypted server-side) AND the SDK's
/// observable state after the response lands.
final class DirectClientTests: XCTestCase {

    /// Per-test unique Keychain service so durable-key tests don't leak
    /// across runs.
    private var keychainSvc: String!
    private var server: FakeBifrostDirectServer!
    private var session: URLSession!

    override func setUp() async throws {
        try await super.setUp()
        MockDirectURLProtocol.reset()
        keychainSvc = "io.vanaheim.sdk.direct.test.\(UUID().uuidString)"
        server = FakeBifrostDirectServer()
        server.installJwks()
        session = mockDirectSession()
    }

    override func tearDown() async throws {
        MockDirectURLProtocol.reset()
        try await super.tearDown()
    }

    private func makeClient(cache: InMemorySecureCache? = nil) throws -> DirectClient {
        let cfg = makeTestDirectConfig(baseURL: server.baseURL)
        let resolver = try DirectRecipientResolver(
            bifrostBaseUrl: server.baseURL,
            session: session,
            ttl: 60,
            timeout: 5)
        let store = DirectKeypairStore(service: keychainSvc)
        return try DirectClient(
            config: cfg,
            recipientResolver: resolver,
            keypairStore: store,
            secureCache: cache ?? InMemorySecureCache(),
            httpSession: session)
    }

    // MARK: - connect / dispose

    func testConnectFetchesJwksAndMarksReady() async throws {
        let client = try makeClient()
        try await client.connect()
        // Calling connect twice is a no-op (no second JWKS request).
        try await client.connect()
        let captured = MockDirectURLProtocol.captured(path: server.jwksURL.path)
        XCTAssertEqual(captured.count, 1,
                       "connect() must be idempotent")
        await client.dispose()
    }

    func testCallsBeforeConnectThrowNotConnected() async throws {
        let client = try makeClient()
        do {
            _ = try await client.verify()
            XCTFail("expected .notConnected")
        } catch DirectError.notConnected {
            // expected
        } catch {
            XCTFail("expected DirectError.notConnected, got \(error)")
        }
    }

    func testConnectFailsWhenJwksHasNoX25519() async throws {
        // Install a JWKS handler that ONLY publishes the sig key.
        MockDirectURLProtocol.register(path: server.jwksURL.path) { _ in
            let body: [String: Any] = [
                "keys": [[
                    "kid": "sig-only", "kty": "OKP", "crv": "Ed25519",
                    "use": "sig", "alg": "EdDSA",
                    "x": self.server.sigKey.publicKey
                        .rawRepresentation.base64URLEncodedString(),
                ]],
            ]
            let data = try JSONSerialization.data(withJSONObject: body)
            let resp = HTTPURLResponse(
                url: self.server.jwksURL, statusCode: 200,
                httpVersion: "HTTP/1.1",
                headerFields: ["Content-Type": "application/json"])!
            return (resp, data)
        }
        let client = try makeClient()
        do {
            try await client.connect()
            XCTFail("expected throw on missing X25519 key")
        } catch DirectError.network {
            // expected — surfaced via the resolver's NetworkError → mapped
        } catch DirectError.noRecipientKey {
            // also acceptable
        } catch {
            XCTFail("expected DirectError.network or .noRecipientKey, got \(error)")
        }
    }

    // MARK: - register flow

    func testRegisterRoundTrip() async throws {
        server.installRoute(path: "/direct/v1/register") { claims, header in
            // Outbound envelope was an ephemeral-JWS; verify claim shape.
            XCTAssertEqual(header["typ"] as? String,
                           "bifrost-direct+ephemeral+jws")
            XCTAssertEqual(claims["project_id"] as? String, "proj_test")
            XCTAssertEqual(claims["aud"] as? String, "direct:register")
            return [
                "device_id": "dev-100",
                "entitlement_jws": "header.payload.sig",
                "server_nonce": "nonce-xyz",
                "tier_metadata": ["name": "pro"],
                "feature_list": ["api.export", "api.import"],
                "quotas": ["seats": 10],
                "heartbeat_cadence_ms": 30_000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        let result = try await client.register(
            licenseKey: "LCS-1",
            fingerprint: "fp-1",
            appMeta: ["app": "test"])
        XCTAssertEqual(result.deviceId, "dev-100")
        XCTAssertEqual(result.serverNonce, "nonce-xyz")
        XCTAssertEqual(result.heartbeatCadenceMs, 30_000)
        XCTAssertEqual(Set(result.featureList),
                       Set(["api.export", "api.import"]))
        XCTAssertEqual(result.quotas["seats"], 10)
        // Local entitlement snapshot must reflect the response.
        let hasFeature = await client.hasFeature("api.export")
        XCTAssertTrue(hasFeature)
        let seats = await client.quota("seats")
        XCTAssertEqual(seats, 10)
        await client.dispose()
    }

    func testRegisterErrorTaxonomy() async throws {
        server.installRoute(
            path: "/direct/v1/register",
            statusCode: 409
        ) { _, _ in
            return [
                "error": "DIRECT_LICENSE_SEAT_EXCEEDED",
                "message": "no more seats",
            ]
        }
        let client = try makeClient()
        try await client.connect()
        do {
            _ = try await client.register(
                licenseKey: "LCS-1", fingerprint: "fp", appMeta: [:])
            XCTFail("expected .licenseSeatExceeded")
        } catch DirectError.licenseSeatExceeded {
            // expected
        } catch {
            XCTFail("expected .licenseSeatExceeded, got \(error)")
        }
    }

    func testRegisterMissingFieldsSurfaceAsNetworkError() async throws {
        server.installRoute(path: "/direct/v1/register") { _, _ in
            return ["device_id": "dev-1"] // missing entitlement_jws + nonce
        }
        let client = try makeClient()
        try await client.connect()
        do {
            _ = try await client.register(
                licenseKey: "x", fingerprint: "y", appMeta: [:])
            XCTFail("expected DirectError.network on missing fields")
        } catch DirectError.network {
            // expected
        } catch {
            XCTFail("expected DirectError.network, got \(error)")
        }
    }

    // MARK: - activate / verify / heartbeat

    /// Helper: register once so subsequent durable calls have a device
    /// id + durable key.
    private func registerOnce(client: DirectClient,
                              deviceId: String = "dev-t") async throws {
        server.installRoute(path: "/direct/v1/register") { _, _ in
            return [
                "device_id": deviceId,
                "entitlement_jws": "h.p.s",
                "server_nonce": "n",
                "feature_list": ["base"],
                "quotas": ["calls": 5],
                "heartbeat_cadence_ms": 60_000,
            ]
        }
        _ = try await client.register(
            licenseKey: "LCS", fingerprint: "fp", appMeta: [:])
    }

    func testActivateRoundTrip() async throws {
        server.installRoute(path: "/direct/v1/activate") { claims, header in
            XCTAssertEqual(header["typ"] as? String,
                           "bifrost-direct+durable+jws")
            XCTAssertEqual(claims["device_id"] as? String, "dev-t")
            return [
                "entitlement_jws": "ent.jws",
                "feature_list": ["upgraded"],
                "quotas": ["calls": 50],
                "refreshed_at_ms": 1_700_000_000_000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let act = try await client.activate(licenseKey: "LCS-NEW")
        XCTAssertEqual(act.entitlementJws, "ent.jws")
        XCTAssertEqual(act.quotas["calls"], 50)
        let upgraded = await client.hasFeature("upgraded")
        XCTAssertTrue(upgraded)
        await client.dispose()
    }

    func testVerifyReportsDeactivated() async throws {
        server.installRoute(path: "/direct/v1/verify") { _, _ in
            return [
                "deactivated": true,
                "deactivated_reason": "admin_revoke",
                "deactivated_at_ms": 1_700_000_000_000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let v = try await client.verify()
        XCTAssertTrue(v.deactivated)
        XCTAssertEqual(v.deactivatedReason, "admin_revoke")
        // Local entitlements cleared on deactivation.
        let has = await client.hasFeature("base")
        XCTAssertFalse(has)
        await client.dispose()
    }

    func testHeartbeatUpdatesCadenceAndReportsRevoke() async throws {
        server.installRoute(path: "/direct/v1/heartbeat") { _, _ in
            return [
                "valid": false,
                "revoked_reason": "admin",
                "next_heartbeat_after_ms": 120_000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.heartbeat()
        XCTAssertFalse(r.valid)
        XCTAssertEqual(r.revokedReason, "admin")
        XCTAssertEqual(r.nextHeartbeatAfterMs, 120_000)
        // Local entitlements cleared on invalid response.
        let has = await client.hasFeature("base")
        XCTAssertFalse(has)
        await client.dispose()
    }

    // MARK: - deactivate

    func testDeactivateClearsLocalState() async throws {
        server.installRoute(path: "/direct/v1/deactivate") { claims, _ in
            XCTAssertEqual(claims["device_id"] as? String, "dev-t")
            return ["ok": true]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        // Sanity: register populated entitlements.
        let preFeature = await client.hasFeature("base")
        XCTAssertTrue(preFeature)
        try await client.deactivate(reason: "user_uninstall")
        let postFeature = await client.hasFeature("base")
        XCTAssertFalse(postFeature)
        let postQuota = await client.quota("calls")
        XCTAssertEqual(postQuota, 0)
        await client.dispose()
    }

    func testDeactivateUnknownReasonIsNormalised() async throws {
        server.installRoute(path: "/direct/v1/deactivate") { claims, _ in
            let body = claims["body"] as? [String: Any]
            XCTAssertEqual(body?["reason"] as? String, "user_uninstall",
                           "unknown reason must normalise to user_uninstall")
            return ["ok": true]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        try await client.deactivate(reason: "totally-unknown")
        await client.dispose()
    }

    // MARK: - catalog + ack

    func testGetCatalogReturnsParsedSnapshot() async throws {
        server.installRoute(path: "/direct/v1/catalog") { _, _ in
            return [
                "catalog_etag": "etag-1",
                "tiers": [["id": "free"], ["id": "pro"]],
                "features": [["id": "f1"]],
                "pricing_plans": [["id": "p1"]],
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let snap = try await client.getCatalog()
        XCTAssertEqual(snap.catalogEtag, "etag-1")
        XCTAssertEqual(snap.tiers.count, 2)
        XCTAssertEqual(snap.features.count, 1)
        XCTAssertEqual(snap.pricingPlans.count, 1)
        await client.dispose()
    }

    func testAcknowledgeKidRotationSendsKid() async throws {
        var sawKid: String?
        server.installRoute(path: "/direct/v1/keys/rotate-ack") { claims, _ in
            let body = claims["body"] as? [String: Any]
            sawKid = body?["acknowledged_kid"] as? String
            return ["ok": true]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        try await client.acknowledgeKidRotation(kid: "enc-77")
        XCTAssertEqual(sawKid, "enc-77")
        await client.dispose()
    }

    // MARK: - reportError

    func testReportErrorReturnsServerErrorId() async throws {
        server.installRoute(path: "/direct/v1/telemetry/error") { claims, _ in
            let body = claims["body"] as? [String: Any]
            XCTAssertEqual(body?["error_type"] as? String, "ApiCrash")
            return ["error_id": "err-xyz"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.reportError(error: DirectErrorReport(
            errorType: "ApiCrash",
            occurredAtMs: 1,
            message: "boom"))
        XCTAssertEqual(r.errorId, "err-xyz")
        await client.dispose()
    }

    // MARK: - local fast-path reads

    func testHasFeatureFailsClosedBeforeRegister() async throws {
        let client = try makeClient()
        try await client.connect()
        let has = await client.hasFeature("anything")
        XCTAssertFalse(has)
        let q = await client.quota("seats")
        XCTAssertEqual(q, 0)
        await client.dispose()
    }

    // MARK: - S-2 cert pinning

    /// Cert-pin success path: when the configured URLSession answers the
    /// challenge successfully (the MockDirectURLProtocol path bypasses
    /// the real TLS handshake), an inbound request lands normally —
    /// the cert-pin wiring doesn't break the happy path.
    func testCertPinSuccessPathRequestProceeds() async throws {
        // The default test client routes through MockDirectURLProtocol
        // which doesn't go through a real TLS handshake at all, so the
        // CertificatePinner delegate (if attached) would never see the
        // challenge. The success-side regression is therefore implicit
        // in every other DirectClientTests test that hits a route via
        // the fake — they all pass with cert-pin wired into the
        // DirectClient init path.
        let client = try makeClient()
        try await client.connect()
        server.installRoute(path: "/direct/v1/catalog") { _, _ in
            return ["catalog_etag": "etag-pin-ok"]
        }
        try await registerOnce(client: client)
        let snap = try await client.getCatalog()
        XCTAssertEqual(snap.catalogEtag, "etag-pin-ok",
                       "cert-pin-wired session must still complete normal requests")
        await client.dispose()
    }

    /// Cert-pin failure path: simulate URLError(.cancelled) — the wire-
    /// shape URLSession surfaces when the CertificatePinner delegate
    /// answers `.cancelAuthenticationChallenge` — and assert the
    /// DirectClient surfaces it as DirectError.certPinFailed.
    func testCertPinFailureSurfacesAsCertPinFailedError() async throws {
        // Register a route that throws URLError(.cancelled) so the
        // session-side data(for:) call rejects with the pin-failure-
        // equivalent error code.
        let url = server.baseURL.appendingPathComponent("direct/v1/catalog")
        MockDirectURLProtocol.register(path: url.path) { _ in
            throw URLError(.cancelled)
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.getCatalog()
            XCTFail("expected DirectError.certPinFailed")
        } catch DirectError.certPinFailed {
            // expected
        } catch {
            XCTFail("expected .certPinFailed, got \(error)")
        }
        await client.dispose()
    }

    /// Cert-pin failure also covers the secureConnectionFailed +
    /// serverCertificateUntrusted URLError codes (TLS handshake
    /// failure modes that adjacent to pin mismatches).
    func testSecureConnectionFailedAlsoSurfacesAsCertPinFailedError() async throws {
        let url = server.baseURL.appendingPathComponent("direct/v1/catalog")
        MockDirectURLProtocol.register(path: url.path) { _ in
            throw URLError(.secureConnectionFailed)
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.getCatalog()
            XCTFail("expected DirectError.certPinFailed")
        } catch DirectError.certPinFailed {
            // expected
        } catch {
            XCTFail("expected .certPinFailed, got \(error)")
        }
        await client.dispose()
    }

    // MARK: - S-5 device-revoked wipe

    /// Verify-side device-revoked confirmation must wipe the durable
    /// keypair store so subsequent Tier-2 calls fail-CLOSED.
    func testVerifyDeactivatedWipesDurableKeypair() async throws {
        server.installRoute(path: "/direct/v1/verify") { _, _ in
            return [
                "deactivated": true,
                "deactivated_reason": "admin_revoke",
                "deactivated_at_ms": 1_700_000_000_000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        _ = try await client.verify()
        // Next Tier-2 call must surface .notConnected because the
        // durable keypair + device id slots have been cleared.
        do {
            _ = try await client.activate(licenseKey: "anything")
            XCTFail("expected .notConnected after device revoke wipe")
        } catch DirectError.notConnected {
            // expected
        } catch {
            XCTFail("expected .notConnected, got \(error)")
        }
        await client.dispose()
    }
}
