// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// W6 / B-FRON.5.5 — `DirectClient.verifyIapReceipt(...)` end-to-end
/// tests. Covers both the valid path (returns minted entitlement JWS)
/// and the invalid path (server returns `valid=false` with a narrow
/// reason taxonomy).
final class DirectPaymentIapVerifyTests: XCTestCase {

    private var keychainSvc: String!
    private var server: FakeBifrostDirectServer!
    private var session: URLSession!

    override func setUp() async throws {
        try await super.setUp()
        MockDirectURLProtocol.reset()
        keychainSvc = "io.vanaheim.sdk.direct.test.\(UUID().uuidString)"
        server = FakeBifrostDirectServer()
        server.installJwks()
        session = mockDirectSession()
    }

    override func tearDown() async throws {
        MockDirectURLProtocol.reset()
        try await super.tearDown()
    }

    private func makeClient() throws -> DirectClient {
        let cfg = makeTestDirectConfig(baseURL: server.baseURL)
        let resolver = try DirectRecipientResolver(
            bifrostBaseUrl: server.baseURL,
            session: session,
            ttl: 60,
            timeout: 5)
        let store = DirectKeypairStore(service: keychainSvc)
        return try DirectClient(
            config: cfg,
            recipientResolver: resolver,
            keypairStore: store,
            secureCache: InMemorySecureCache(),
            httpSession: session)
    }

    private func registerOnce(client: DirectClient) async throws {
        server.installRoute(path: "/direct/v1/register") { _, _ in
            return [
                "device_id": "dev-iap",
                "entitlement_jws": "h.p.s",
                "server_nonce": "n",
                "feature_list": ["base"],
                "quotas": [:],
                "heartbeat_cadence_ms": 60_000,
            ]
        }
        _ = try await client.register(
            licenseKey: "LCS", fingerprint: "fp", appMeta: [:])
    }

    // MARK: - Valid path

    func testVerifyIapReceiptValidRoundTrip() async throws {
        server.installRoute(path: "/direct/v1/payment/iap-verify") { claims, _ in
            XCTAssertEqual(claims["aud"] as? String,
                           "direct:payment.iap-verify")
            let body = claims["body"] as? [String: Any]
            XCTAssertEqual(body?["platform"] as? String, "ios")
            XCTAssertEqual(body?["receipt"] as? String, "MIIa...test_receipt")
            return [
                "valid": true,
                "license_key": "LCS-IAP",
                "tier": "pro",
                "valid_until": 1_700_900_000_000,
                "entitlement_jws": "ent.h.p.s",
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.verifyIapReceipt(
            platform: .ios, receipt: "MIIa...test_receipt")
        XCTAssertTrue(r.valid)
        XCTAssertEqual(r.licenseKey, "LCS-IAP")
        XCTAssertEqual(r.tier, "pro")
        XCTAssertEqual(r.validUntil, 1_700_900_000_000)
        XCTAssertEqual(r.entitlementJws, "ent.h.p.s")
        XCTAssertNil(r.reason)
        await client.dispose()
    }

    func testVerifyIapReceiptAndroidPlatformWired() async throws {
        var sawPlatform: String?
        server.installRoute(path: "/direct/v1/payment/iap-verify") { claims, _ in
            let body = claims["body"] as? [String: Any]
            sawPlatform = body?["platform"] as? String
            return ["valid": true, "entitlement_jws": "e"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        _ = try await client.verifyIapReceipt(
            platform: .android,
            receipt: "google-play-purchase-token-abc")
        XCTAssertEqual(sawPlatform, "android")
        await client.dispose()
    }

    // MARK: - Invalid reason taxonomy

    func testVerifyIapReceiptInvalidExpired() async throws {
        server.installRoute(path: "/direct/v1/payment/iap-verify") { _, _ in
            return ["valid": false, "reason": "expired"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.verifyIapReceipt(
            platform: .ios, receipt: "x")
        XCTAssertFalse(r.valid)
        XCTAssertEqual(r.reason, .expired)
        XCTAssertNil(r.entitlementJws)
        XCTAssertNil(r.licenseKey)
        await client.dispose()
    }

    func testVerifyIapReceiptInvalidMalformed() async throws {
        server.installRoute(path: "/direct/v1/payment/iap-verify") { _, _ in
            return ["valid": false, "reason": "malformed"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.verifyIapReceipt(
            platform: .ios, receipt: "x")
        XCTAssertFalse(r.valid)
        XCTAssertEqual(r.reason, .malformed)
        await client.dispose()
    }

    func testVerifyIapReceiptInvalidNotSubscribed() async throws {
        server.installRoute(path: "/direct/v1/payment/iap-verify") { _, _ in
            return ["valid": false, "reason": "not_subscribed"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.verifyIapReceipt(
            platform: .ios, receipt: "x")
        XCTAssertFalse(r.valid)
        XCTAssertEqual(r.reason, .notSubscribed)
        await client.dispose()
    }

    func testVerifyIapReceiptInvalidUnknownReasonFallsBack() async throws {
        // Server emits a reason the SDK doesn't recognise — must fall
        // back to `.unknown` rather than crash.
        server.installRoute(path: "/direct/v1/payment/iap-verify") { _, _ in
            return ["valid": false, "reason": "brand_new_taxonomy_value"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.verifyIapReceipt(
            platform: .ios, receipt: "x")
        XCTAssertFalse(r.valid)
        XCTAssertEqual(r.reason, .unknown)
        await client.dispose()
    }

    func testVerifyIapReceiptInvalidMissingReasonFallsBack() async throws {
        server.installRoute(path: "/direct/v1/payment/iap-verify") { _, _ in
            return ["valid": false] // no `reason` field
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.verifyIapReceipt(
            platform: .ios, receipt: "x")
        XCTAssertFalse(r.valid)
        XCTAssertEqual(r.reason, .unknown)
        await client.dispose()
    }

    // MARK: - Client-side validation (pre-wire)

    func testVerifyIapReceiptRejectsEmptyReceipt() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.verifyIapReceipt(
                platform: .ios, receipt: "")
            XCTFail("expected .badRequest for empty receipt")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "receipt_empty")
        }
        await client.dispose()
    }

    func testVerifyIapReceiptRejectsOversizedReceipt() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        // 24577 chars → over the 24 KB (24576-byte) cap. The cap was
        // bumped from 16 KB → 24 KB in the W6 fix-pass to match Dart.
        let big = String(repeating: "x", count: 24576 + 1)
        do {
            _ = try await client.verifyIapReceipt(
                platform: .ios, receipt: big)
            XCTFail("expected .badRequest for oversized receipt")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "iap_receipt_too_large")
        }
        await client.dispose()
    }

    func testVerifyIapReceiptAcceptsReceiptAtCapBoundary() async throws {
        server.installRoute(path: "/direct/v1/payment/iap-verify") { _, _ in
            return ["valid": false, "reason": "malformed"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        // Exactly 24 KB — should be accepted (cap is inclusive of 24576).
        let atCap = String(repeating: "x", count: 24576)
        let r = try await client.verifyIapReceipt(
            platform: .ios, receipt: atCap)
        XCTAssertFalse(r.valid)
        await client.dispose()
    }

    /// FIX S-Fix 3 regression — a 32 KB receipt (well above the 24 KB
    /// cap) MUST surface as `.badRequest("iap_receipt_too_large")`
    /// without a wire round-trip.
    func testVerifyIapReceiptRejects32KbReceipt() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let big = String(repeating: "z", count: 32 * 1024)
        do {
            _ = try await client.verifyIapReceipt(
                platform: .ios, receipt: big)
            XCTFail("expected .badRequest for 32 KB receipt")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "iap_receipt_too_large")
        }
        await client.dispose()
    }

    // MARK: - Connection gating

    func testVerifyIapReceiptBeforeConnectThrows() async throws {
        let client = try makeClient()
        do {
            _ = try await client.verifyIapReceipt(
                platform: .ios, receipt: "x")
            XCTFail("expected .notConnected")
        } catch DirectError.notConnected {
            // expected
        }
    }

    // MARK: - Server error taxonomy

    func testVerifyIapReceiptMapsIapReceiptInvalid() async throws {
        // Adapter-side rejection lands as a plaintext 400 with the
        // coarse code.
        server.installRoute(
            path: "/direct/v1/payment/iap-verify",
            statusCode: 400
        ) { _, _ in
            return [
                "error": "DIRECT_IAP_RECEIPT_INVALID",
                "message": "malformed",
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.verifyIapReceipt(
                platform: .ios, receipt: "x")
            XCTFail("expected .iapReceiptInvalid")
        } catch DirectError.iapReceiptInvalid(let r) {
            XCTAssertEqual(r, "malformed")
        }
        await client.dispose()
    }

    func testVerifyIapReceiptMapsProviderFailed() async throws {
        server.installRoute(
            path: "/direct/v1/payment/iap-verify",
            statusCode: 502
        ) { _, _ in
            return [
                "error": "DIRECT_PAYMENT_PROVIDER_FAILED",
                "message": "apple_iap",
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.verifyIapReceipt(
                platform: .ios, receipt: "x")
            XCTFail("expected .paymentProviderFailed")
        } catch DirectError.paymentProviderFailed(let p) {
            XCTAssertEqual(p, "apple_iap")
        }
        await client.dispose()
    }

    func testVerifyIapReceiptMapsRateLimited() async throws {
        server.installRoute(
            path: "/direct/v1/payment/iap-verify",
            statusCode: 429
        ) { _, _ in
            return [
                "error": "DIRECT_RATE_LIMIT",
                "retry_after_ms": 60_000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.verifyIapReceipt(
                platform: .ios, receipt: "x")
            XCTFail("expected .rateLimited")
        } catch DirectError.rateLimited(let ms) {
            XCTAssertEqual(ms, 60_000)
        }
        await client.dispose()
    }
}
