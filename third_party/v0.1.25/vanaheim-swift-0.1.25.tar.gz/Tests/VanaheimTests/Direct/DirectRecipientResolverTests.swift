// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
import CryptoKit
@testable import Vanaheim

/// Tests for `DirectRecipientResolver` — JWKS fetcher + verify-key
/// publisher for FRON mode.
///
/// W5 fix-pass (S-4) regressions cover the new HTTPS pin on the
/// constructor: a plaintext `http://` Bifrost URL is rejected unless
/// the host is `localhost` / `127.0.0.1` / `::1` (the loopback
/// carve-out for unit tests + local emulator loops).
final class DirectRecipientResolverTests: XCTestCase {

    // MARK: - S-4 HTTPS pin

    func testRejectsPlainHttpProductionUrl() {
        // Generic `http://bifrost.example.com` — must fail-closed.
        let bad = URL(string: "http://bifrost.example.com")!
        XCTAssertThrowsError(try DirectRecipientResolver(
            bifrostBaseUrl: bad)) { err in
            XCTAssertTrue(err is DirectInsecureBaseUrlError,
                          "non-HTTPS prod URL must throw DirectInsecureBaseUrlError, got \(err)")
        }
    }

    func testRejectsPlainHttpRfc1918Url() {
        // A corporate LAN URL is NOT a safe carve-out — only
        // loopback hosts are permitted on the http path.
        let bad = URL(string: "http://10.0.0.5:8080")!
        XCTAssertThrowsError(try DirectRecipientResolver(
            bifrostBaseUrl: bad)) { err in
            XCTAssertTrue(err is DirectInsecureBaseUrlError)
        }
    }

    func testRejectsPlainHttpPublicCidrHost() {
        // Any non-loopback hostname is rejected, even if it
        // syntactically "looks like" a private host.
        let bad = URL(string: "http://192.168.1.10")!
        XCTAssertThrowsError(try DirectRecipientResolver(
            bifrostBaseUrl: bad)) { err in
            XCTAssertTrue(err is DirectInsecureBaseUrlError)
        }
    }

    func testAcceptsHttpsProductionUrl() throws {
        let good = URL(string: "https://bifrost.example.com")!
        let r = try DirectRecipientResolver(bifrostBaseUrl: good)
        XCTAssertEqual(r.url.absoluteString,
                       "https://bifrost.example.com/direct/v1/.well-known/jwks.json")
    }

    func testAcceptsHttpLocalhostForTests() throws {
        let local = URL(string: "http://localhost:5001")!
        XCTAssertNoThrow(try DirectRecipientResolver(bifrostBaseUrl: local))
    }

    func testAcceptsHttp127Loopback() throws {
        let lo = URL(string: "http://127.0.0.1:8081")!
        XCTAssertNoThrow(try DirectRecipientResolver(bifrostBaseUrl: lo))
    }

    func testAcceptsHttpIpv6Loopback() throws {
        // IPv6 loopback — URL.host strips the brackets so the check
        // compares against the bare "::1" form.
        let lo6 = URL(string: "http://[::1]:8082")!
        XCTAssertNoThrow(try DirectRecipientResolver(bifrostBaseUrl: lo6))
    }

    func testRejectsUnknownScheme() {
        let bad = URL(string: "ftp://bifrost.example.com")!
        XCTAssertThrowsError(try DirectRecipientResolver(
            bifrostBaseUrl: bad)) { err in
            XCTAssertTrue(err is DirectInsecureBaseUrlError)
        }
    }

    func testRejectsHttpHostThatContainsLocalhostAsSubstring() {
        // Trick host like `http://localhost.attacker.com` MUST NOT
        // pass the loopback carve-out — equality, not substring.
        let bad = URL(string: "http://localhost.attacker.com")!
        XCTAssertThrowsError(try DirectRecipientResolver(
            bifrostBaseUrl: bad)) { err in
            XCTAssertTrue(err is DirectInsecureBaseUrlError,
                          "subdomain-confusion bypass must NOT carve through")
        }
    }
}
