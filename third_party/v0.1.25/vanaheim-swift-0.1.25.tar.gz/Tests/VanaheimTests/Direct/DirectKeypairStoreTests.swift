// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
import CryptoKit
@testable import Vanaheim

/// Tests for `DirectKeypairStore` — Keychain-backed Ed25519 device key
/// store with an ephemeral → durable promotion model.
///
/// Each test uses a unique Keychain service identifier so concurrent /
/// re-run tests don't see each other's residue. The store wipes its
/// slots at the start of every test (in `setUp`).
final class DirectKeypairStoreTests: XCTestCase {

    // Per-test unique service so parallel tests + re-runs are isolated.
    private var service: String!
    private var store: DirectKeypairStore!

    override func setUp() async throws {
        try await super.setUp()
        // ProcessInfo.uuid + the test method name keeps the service
        // unique across test methods AND across CI machine reuse.
        let id = UUID().uuidString
        service = "io.vanaheim.sdk.direct.test.\(id)"
        store = DirectKeypairStore(service: service)
        await store.clear() // belt-and-braces
    }

    override func tearDown() async throws {
        await store.clear()
        try await super.tearDown()
    }

    func testEphemeralKeyIsGeneratedAndCached() async throws {
        let k1 = try await store.ensureEphemeralKey()
        let k2 = try await store.ensureEphemeralKey()
        // Same Ed25519 raw representation across calls — cached.
        XCTAssertEqual(k1.rawRepresentation, k2.rawRepresentation)
    }

    func testRequireDurableKeyThrowsBeforeRegister() async {
        do {
            _ = try await store.requireDurableKey()
            XCTFail("expected .notConnected")
        } catch DirectError.notConnected {
            // expected
        } catch {
            XCTFail("expected DirectError.notConnected, got \(error)")
        }
    }

    func testRequireDeviceIdThrowsBeforeRegister() async {
        do {
            _ = try await store.requireDeviceId()
            XCTFail("expected .notConnected")
        } catch DirectError.notConnected {
            // expected
        } catch {
            XCTFail("expected DirectError.notConnected, got \(error)")
        }
    }

    func testPromoteEphemeralWithoutEnsureThrows() async {
        // Skip the ensureEphemeralKey step → promote should fail.
        do {
            try await store.promoteEphemeralToDurable(deviceId: "dev-x")
            XCTFail("expected DirectError on missing ephemeral")
        } catch is DirectError {
            // expected — message is "register flow out of order"
        } catch {
            XCTFail("expected DirectError, got \(error)")
        }
    }

    func testPromoteAttachesDurableIdentity() async throws {
        let eph = try await store.ensureEphemeralKey()
        try await store.promoteEphemeralToDurable(deviceId: "dev-1")
        // The durable key should now equal the ephemeral one.
        let durable = try await store.requireDurableKey()
        XCTAssertEqual(durable.rawRepresentation, eph.rawRepresentation)
        // Device id is queryable.
        let did = try await store.requireDeviceId()
        XCTAssertEqual(did, "dev-1")
        // hasDurableIdentity should report true now.
        let has = await store.hasDurableIdentity()
        XCTAssertTrue(has)
    }

    func testServerNoncePutGetClear() async {
        await store.putServerNonce("nonce-abc")
        let got = await store.getServerNonce()
        XCTAssertEqual(got, "nonce-abc")
        await store.clearServerNonce()
        let gone = await store.getServerNonce()
        XCTAssertNil(gone)
    }

    func testClearWipesAllSlots() async throws {
        _ = try await store.ensureEphemeralKey()
        try await store.promoteEphemeralToDurable(deviceId: "dev-clr")
        await store.putServerNonce("nonce-clr")
        // Sanity: everything present.
        let has1 = await store.hasDurableIdentity()
        XCTAssertTrue(has1)
        // Clear.
        await store.clear()
        // Durable identity gone; device id throws; nonce gone.
        let has2 = await store.hasDurableIdentity()
        XCTAssertFalse(has2)
        do {
            _ = try await store.requireDeviceId()
            XCTFail("expected .notConnected after clear")
        } catch DirectError.notConnected {
            // expected
        } catch {
            XCTFail("expected DirectError.notConnected, got \(error)")
        }
        let nonce = await store.getServerNonce()
        XCTAssertNil(nonce)
    }

    func testRehydrateLoadsFromKeychain() async throws {
        _ = try await store.ensureEphemeralKey()
        try await store.promoteEphemeralToDurable(deviceId: "dev-reh")

        // Fresh store on the same service: rehydrate should pick up
        // the durable identity from Keychain.
        let other = DirectKeypairStore(service: service)
        let hasBefore = await other.hasDurableIdentity()
        // (Loads lazily — hasDurableIdentity probes the Keychain
        // directly; should be true.)
        XCTAssertTrue(hasBefore)
        await other.rehydrate()
        let did = try await other.requireDeviceId()
        XCTAssertEqual(did, "dev-reh")
    }

    func testRehydrateNoOpWhenEmpty() async {
        let other = DirectKeypairStore(service: service)
        await other.rehydrate() // must not throw
        let has = await other.hasDurableIdentity()
        XCTAssertFalse(has)
    }

    func testTwoStoresOnDifferentServicesDoNotCrossContaminate() async throws {
        let svc2 = "\(service!).other"
        let store2 = DirectKeypairStore(service: svc2)
        // Register on store1.
        _ = try await store.ensureEphemeralKey()
        try await store.promoteEphemeralToDurable(deviceId: "dev-1")
        // store2 must be empty.
        let has = await store2.hasDurableIdentity()
        XCTAssertFalse(has, "different services must not see each other")
        await store2.clear() // cleanup
    }
}
