// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// Pins the wire-code → `DirectError` mapping in
/// `DirectErrorMapper.map(...)`. Every supported FRON wire code (per the
/// server-side `_license-helpers.ts` taxonomy) MUST round-trip through
/// the SDK as the matching enum case — a probe that exfiltrated a wire
/// code and got back the wrong taxonomy case would mis-route the host
/// product's UX (e.g. retrying a terminal error or surfacing rate-limit
/// when the user is actually revoked).
final class DirectErrorTaxonomyTests: XCTestCase {

    func testLicenseInvalidMapsWithReason() {
        let e = DirectErrorMapper.map(
            statusCode: 400,
            wireCode: "DIRECT_LICENSE_INVALID",
            message: "bad key")
        if case .licenseInvalid(let r) = e {
            XCTAssertEqual(r, "bad key")
        } else {
            XCTFail("expected .licenseInvalid, got \(e)")
        }
    }

    func testSeatExceededMapsToCase() {
        let e = DirectErrorMapper.map(
            statusCode: 409,
            wireCode: "DIRECT_LICENSE_SEAT_EXCEEDED",
            message: nil)
        guard case .licenseSeatExceeded = e else {
            XCTFail("expected .licenseSeatExceeded, got \(e)"); return
        }
    }

    func testLicenseExpiredMapsToCase() {
        let e = DirectErrorMapper.map(
            statusCode: 410,
            wireCode: "DIRECT_LICENSE_EXPIRED",
            message: nil)
        guard case .licenseExpired = e else {
            XCTFail("expected .licenseExpired, got \(e)"); return
        }
    }

    func testFingerprintAlreadyRegisteredAcceptsBothAliases() {
        let a = DirectErrorMapper.map(
            statusCode: 409,
            wireCode: "DIRECT_FINGERPRINT_ALREADY_REGISTERED",
            message: nil)
        let b = DirectErrorMapper.map(
            statusCode: 409,
            wireCode: "DIRECT_REGISTER_FINGERPRINT_ALREADY_REGISTERED",
            message: nil)
        guard case .fingerprintAlreadyRegistered = a else {
            XCTFail("expected .fingerprintAlreadyRegistered (a), got \(a)"); return
        }
        guard case .fingerprintAlreadyRegistered = b else {
            XCTFail("expected .fingerprintAlreadyRegistered (b), got \(b)"); return
        }
    }

    func testRateLimitedCarriesRetryAfter() {
        let e = DirectErrorMapper.map(
            statusCode: 429,
            wireCode: "DIRECT_RATE_LIMIT",
            message: nil,
            retryAfterMs: 12345)
        guard case .rateLimited(let ms) = e else {
            XCTFail("expected .rateLimited, got \(e)"); return
        }
        XCTAssertEqual(ms, 12345)
    }

    func testRateLimitedAcceptsAliasRateLimited() {
        let e = DirectErrorMapper.map(
            statusCode: 429,
            wireCode: "DIRECT_RATE_LIMITED",
            message: nil,
            retryAfterMs: 999)
        guard case .rateLimited(let ms) = e else {
            XCTFail("expected .rateLimited, got \(e)"); return
        }
        XCTAssertEqual(ms, 999)
    }

    func testJweDecryptFailedMapsToCase() {
        let e = DirectErrorMapper.map(
            statusCode: 400,
            wireCode: "DIRECT_JWE_DECRYPT_FAILED",
            message: nil)
        guard case .jweDecryptFailed = e else {
            XCTFail("expected .jweDecryptFailed, got \(e)"); return
        }
    }

    func testProjectDisabledMapsToCase() {
        let e = DirectErrorMapper.map(
            statusCode: 403,
            wireCode: "DIRECT_PROJECT_DISABLED",
            message: nil)
        guard case .projectDisabled = e else {
            XCTFail("expected .projectDisabled, got \(e)"); return
        }
    }

    func testFcmTokenReusedMapsToCase() {
        let e = DirectErrorMapper.map(
            statusCode: 409,
            wireCode: "DIRECT_FCM_TOKEN_REUSED",
            message: nil)
        guard case .fcmTokenReused = e else {
            XCTFail("expected .fcmTokenReused, got \(e)"); return
        }
    }

    func testUnknownCodeFallsBackToServer() {
        let e = DirectErrorMapper.map(
            statusCode: 500,
            wireCode: "DIRECT_NEVER_SEEN_BEFORE",
            message: "wat",
            retryAfterMs: nil)
        guard case .server(let s, let w, let m) = e else {
            XCTFail("expected .server, got \(e)"); return
        }
        XCTAssertEqual(s, 500)
        XCTAssertEqual(w, "DIRECT_NEVER_SEEN_BEFORE")
        XCTAssertEqual(m, "wat")
    }

    func testNilWireCodeFallsBackToServer() {
        let e = DirectErrorMapper.map(
            statusCode: 502,
            wireCode: nil,
            message: nil)
        guard case .server(let s, let w, _) = e else {
            XCTFail("expected .server, got \(e)"); return
        }
        XCTAssertEqual(s, 502)
        XCTAssertNil(w)
    }

    /// Wire code matching is case-insensitive — the server emits upper-
    /// case but be defensive against lower-case leaks.
    func testWireCodeMatchingIsCaseInsensitive() {
        let e = DirectErrorMapper.map(
            statusCode: 410,
            wireCode: "direct_license_expired",
            message: nil)
        guard case .licenseExpired = e else {
            XCTFail("expected .licenseExpired (case-insensitive), got \(e)"); return
        }
    }

    // ── W6 Fix-pass-2 / S-Fix 1 — new `reason` + `provider` params ──
    //
    // The sealed-error envelope splits structured fields off the human
    // message: DirectErrorMapper.map(reason:provider:) accepts them
    // verbatim. `reason` takes precedence over `message` (the parser
    // prefers the structured field); `provider` takes precedence over
    // `message` for paymentProviderFailed.

    /// licenseInvalid prefers the structured `reason` over `message`.
    func testLicenseInvalidPrefersReasonOverMessage() {
        let e = DirectErrorMapper.map(
            statusCode: 0,
            wireCode: "DIRECT_LICENSE_INVALID",
            message: "free-form",
            reason: "expired_payload")
        guard case .licenseInvalid(let r) = e else {
            XCTFail("expected .licenseInvalid, got \(e)"); return
        }
        XCTAssertEqual(r, "expired_payload",
                       "structured reason MUST win over free-form message")
    }

    /// iapReceiptInvalid plumbs `reason` (the narrow taxonomy SDK forks
    /// UX on — expired/malformed/not_subscribed/unknown).
    func testIapReceiptInvalidPlumbsReason() {
        let e = DirectErrorMapper.map(
            statusCode: 0,
            wireCode: "DIRECT_IAP_RECEIPT_INVALID",
            message: nil,
            reason: "not_subscribed")
        guard case .iapReceiptInvalid(let r) = e else {
            XCTFail("expected .iapReceiptInvalid, got \(e)"); return
        }
        XCTAssertEqual(r, "not_subscribed")
    }

    /// paymentProviderFailed plumbs the dedicated `provider` field.
    func testPaymentProviderFailedPrefersProviderOverMessage() {
        let e = DirectErrorMapper.map(
            statusCode: 0,
            wireCode: "DIRECT_PAYMENT_PROVIDER_FAILED",
            message: "razorpay-message",
            reason: nil,
            provider: "stripe")
        guard case .paymentProviderFailed(let p) = e else {
            XCTFail("expected .paymentProviderFailed, got \(e)"); return
        }
        XCTAssertEqual(p, "stripe",
                       "dedicated `provider` claim MUST win over the " +
                       "legacy `message`-folded shape")
    }

    /// paymentProviderFailed falls back to `message` when `provider`
    /// is absent (legacy server emission compat).
    func testPaymentProviderFailedFallsBackToMessage() {
        let e = DirectErrorMapper.map(
            statusCode: 0,
            wireCode: "DIRECT_PAYMENT_PROVIDER_FAILED",
            message: "paddle",
            reason: nil,
            provider: nil)
        guard case .paymentProviderFailed(let p) = e else {
            XCTFail("expected .paymentProviderFailed, got \(e)"); return
        }
        XCTAssertEqual(p, "paddle",
                       "legacy server emission (provider folded into " +
                       "message) MUST still resolve the tag")
    }

    /// deviceRevoked plumbs `reason` for the SDK's wipe-on-revoke flow.
    func testDeviceRevokedPlumbsReason() {
        let e = DirectErrorMapper.map(
            statusCode: 0,
            wireCode: "DIRECT_DEVICE_REVOKED",
            message: nil,
            reason: "key_rotation")
        guard case .deviceRevoked(let r) = e else {
            XCTFail("expected .deviceRevoked, got \(e)"); return
        }
        XCTAssertEqual(r, "key_rotation")
    }

    /// `description` must be stable across every case so log scraping
    /// tools (server side) can pivot on it.
    func testDescriptionsAreNonEmpty() {
        let cases: [DirectError] = [
            .licenseInvalid(reason: "x"),
            .licenseSeatExceeded,
            .licenseExpired,
            .fingerprintAlreadyRegistered,
            .fcmTokenReused,
            .rateLimited(retryAfterMs: 1),
            .projectDisabled,
            .jweDecryptFailed,
            .jwsInvalid,
            .replayDetected,
            .kidNotPublished,
            .telemetryNotWired,
            .server(statusCode: 500, wireCode: "X", message: "m"),
            .network(message: "boom", cause: nil),
            .notConnected,
            .noRecipientKey,
        ]
        for c in cases {
            XCTAssertFalse(c.description.isEmpty,
                           "description for \(c) should not be empty")
            XCTAssertTrue(c.description.hasPrefix("DirectError."),
                          "description for \(c) should be namespaced")
        }
    }
}
