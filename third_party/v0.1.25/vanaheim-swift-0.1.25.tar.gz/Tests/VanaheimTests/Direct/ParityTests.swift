// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
import CryptoKit
import Foundation
@testable import Vanaheim

// ─────────────────────────────────────────────────────────────────────
// ParityTests — cross-SDK wire-byte parity for the Vanaheim FRON
// envelope.
//
// Loads the shared canonical fixture at
// `bifrost/packages/api-types/src/fron-parity-fixtures.json` — the same
// file the Dart twin (`vanaheim/dart/vanaheim/test/direct/parity_test
// .dart`) loads — and verifies the Swift SDK's emitted inner-JWS claim
// shape, header, and outer-JWE header match exactly.
//
// Source-of-truth: bifrost/.../direct/jws-verifier.ts (DirectJwsClaims
// interface). The top-level claim schema is {aud, iat, nbf, exp, jti,
// project_id, device_id?, body}. Route-specific payload nests inside
// `body` (parsed by parseDirectBody after the identity verify).
//
// What is NOT byte-equal across languages (by design):
//   * The outer JWE itself (fresh ephemeral X25519 per call + random
//     AES-GCM nonce).
//   * The Ed25519 signature segment (depends on JSON serialisation
//     ordering, which differs between Dart `jsonEncode` and Swift
//     `JSONSerialization.data(.sortedKeys)`).
//
// What MUST be byte-equal:
//   * JWS header fields (alg, typ, device_pub_jwk for ephemeral mode)
//   * JWS top-level claims (aud, iat, nbf, exp, jti, project_id,
//     device_id?)
//   * JWS body wrapper keys (sorted, per body_keys_sorted fixture field)
//   * Outer JWE header pins (alg, enc, typ, lcs_v)
// ─────────────────────────────────────────────────────────────────────

final class ParityTests: XCTestCase {

    // MARK: - Fixture loading

    /// Resolves the shared fixture path. Falls back to a hardcoded
    /// absolute path that matches the task spec when run from the
    /// monorepo. Throws if neither resolves.
    private static func loadFixture() throws -> [String: Any] {
        let absolute = "/Users/kanishka/kk_apps/ajtek.io_lc/bifrost/" +
            "packages/api-types/src/fron-parity-fixtures.json"
        var url = URL(fileURLWithPath: absolute)
        if !FileManager.default.fileExists(atPath: url.path) {
            // Walk up from this source file to monorepo root then into
            // bifrost. Tests/VanaheimTests/Direct/ParityTests.swift →
            // ../../../../bifrost/packages/api-types/src/...
            let here = URL(fileURLWithPath: #filePath)
            url = here.deletingLastPathComponent()
                .deletingLastPathComponent()
                .deletingLastPathComponent()
                .deletingLastPathComponent()
                .deletingLastPathComponent()
                .deletingLastPathComponent()
                .appendingPathComponent("bifrost/packages/api-types/src/" +
                                        "fron-parity-fixtures.json")
        }
        let data = try Data(contentsOf: url)
        guard let map = try JSONSerialization.jsonObject(with: data)
                as? [String: Any] else {
            throw NSError(domain: "ParityTests", code: 1,
                          userInfo: [NSLocalizedDescriptionKey:
                                      "fixture is not a JSON object"])
        }
        return map
    }

    // MARK: - Hex helpers

    private static func hexToData(_ hex: String) -> Data {
        var out = Data()
        out.reserveCapacity(hex.count / 2)
        var idx = hex.startIndex
        while idx < hex.endIndex {
            let next = hex.index(idx, offsetBy: 2)
            if let b = UInt8(hex[idx..<next], radix: 16) {
                out.append(b)
            }
            idx = next
        }
        return out
    }

    // MARK: - Deterministic identity construction

    /// Build a Curve25519.Signing.PrivateKey from a 32-byte seed.
    /// CryptoKit accepts the raw 32-byte scalar as the
    /// `rawRepresentation`. The Dart twin uses `ed25519_edwards`
    /// `newKeyFromSeed(seed)` over the same 32 bytes — both produce the
    /// same Ed25519 keypair.
    private static func signingKeyFromSeed(_ seed: Data) throws
        -> Curve25519.Signing.PrivateKey
    {
        return try Curve25519.Signing.PrivateKey(rawRepresentation: seed)
    }

    /// Build a fixed recipient X25519 keypair. Seed = 32 bytes of 0x03,
    /// matching the Dart twin's recipient seed so both sides could in
    /// principle decrypt each other's envelopes (in practice we don't
    /// — outer JWE is non-deterministic — but the pub byte vector is
    /// identical so the JWE header's `kid` + `epk` recipient binding
    /// matches).
    private static func fixedRecipientKey() throws
        -> (priv: Curve25519.KeyAgreement.PrivateKey, pub: Data)
    {
        let seed = Data(repeating: 3, count: 32)
        let priv = try Curve25519.KeyAgreement.PrivateKey(
            rawRepresentation: seed)
        return (priv: priv, pub: priv.publicKey.rawRepresentation)
    }

    /// Split a compact inner JWS into (header, claims).
    private static func decodeInnerJws(_ compact: String) throws
        -> (header: [String: Any], claims: [String: Any])
    {
        let parts = compact.split(separator: ".",
                                  omittingEmptySubsequences: false)
            .map(String.init)
        guard parts.count == 3 else {
            throw NSError(domain: "ParityTests", code: 2,
                          userInfo: [NSLocalizedDescriptionKey:
                                      "inner JWS not 3 segments"])
        }
        guard let hdrBytes = Data(base64URLEncoded: parts[0]),
              let claimsBytes = Data(base64URLEncoded: parts[1]),
              let hdr = try JSONSerialization.jsonObject(with: hdrBytes)
                as? [String: Any],
              let claims = try JSONSerialization.jsonObject(with: claimsBytes)
                as? [String: Any] else {
            throw NSError(domain: "ParityTests", code: 3)
        }
        return (header: hdr, claims: claims)
    }

    // MARK: - Tests

    /// Fixture loads + carries the expected deterministic inputs.
    func testFixtureLoadsAndShape() throws {
        let fixture = try Self.loadFixture()
        XCTAssertNotNil(fixture["$schema_version"] as? String)
        let inputs = fixture["deterministic_test_inputs"]
            as? [String: Any] ?? [:]
        XCTAssertEqual(inputs["project_id"] as? String, "proj_parity_test")
        XCTAssertEqual(inputs["device_id"] as? String, "dev_parity_test_001")
        XCTAssertEqual(inputs["request_id"] as? String,
                       "req-parity-fixed-0001")
        XCTAssertEqual(inputs["now_ms"] as? Int, 1_700_000_000_000)
    }

    /// Register (Mode A / ephemeral) — claim shape matches the fixture's
    /// `expected_register_jws_claims`. This is the canonical wire shape
    /// the Bifrost server's `verifyDirectInnerJws` enforces.
    func testRegisterInnerJwsClaimsParity() throws {
        let fixture = try Self.loadFixture()
        let inputs = fixture["deterministic_test_inputs"] as! [String: Any]
        let exp = fixture["expected_register_jws_claims"] as! [String: Any]
        let hdrExp = fixture["expected_inner_jws_header_register"]
            as! [String: Any]
        let jweExp = fixture["expected_outer_jwe_header"] as! [String: Any]

        let seed = Self.hexToData(
            inputs["ephemeral_ed25519_seed_hex"] as! String)
        let signing = try Self.signingKeyFromSeed(seed)
        let rec = try Self.fixedRecipientKey()
        let recipient = DirectRecipient(
            kid: inputs["recipient_kid"] as! String,
            x25519Pub: rec.pub)

        let builder = DirectRequestBuilder(
            projectId: inputs["project_id"] as! String,
            jwsLifetimeMs: inputs["jws_lifetime_ms"] as! Int)
        // Build the body the way DirectClient.register would: the
        // ephemeral_pubkey body field equals header.device_pub_jwk.x.
        let pubX = signing.publicKey.rawRepresentation
            .base64URLEncodedString()
        let body: [String: Any] = [
            "license_key": inputs["license_key"] as! String,
            "fingerprint": inputs["fingerprint"] as! String,
            "ephemeral_pubkey": pubX,
            "app_meta": inputs["app_meta"] as! [String: Any],
        ]

        let env = try builder.build(
            mode: .ephemeral,
            audience: exp["aud"] as! String,
            signingKey: signing,
            deviceId: nil,
            body: body,
            recipient: recipient,
            nowMs: inputs["now_ms"] as? Int,
            requestId: inputs["request_id"] as? String)

        // Decrypt outer JWE with the recipient priv.
        let codec = JweCodec()
        let (plaintext, jweHeader) = try codec.decryptCompact(
            jwe: env.compactJwe,
            devicePriv: rec.priv)
        let inner = String(data: plaintext, encoding: .utf8) ?? ""
        let (hdr, claims) = try Self.decodeInnerJws(inner)

        // Outer JWE header pins.
        XCTAssertEqual(jweHeader.raw["alg"] as? String,
                       jweExp["alg"] as? String)
        XCTAssertEqual(jweHeader.raw["enc"] as? String,
                       jweExp["enc"] as? String)
        XCTAssertEqual(jweHeader.raw["typ"] as? String,
                       jweExp["typ"] as? String)
        XCTAssertEqual(jweHeader.raw["lcs_v"] as? Int,
                       jweExp["lcs_v"] as? Int)

        // Inner JWS header pins.
        XCTAssertEqual(hdr["alg"] as? String, hdrExp["alg"] as? String)
        XCTAssertEqual(hdr["typ"] as? String, hdrExp["typ"] as? String)
        let devicePubPresent = (hdr["device_pub_jwk"] as? [String: Any]) != nil
        XCTAssertEqual(devicePubPresent,
                       hdrExp["device_pub_jwk_present"] as? Bool)

        // Canonical claim names — aud + jti per server DirectJwsClaims.
        XCTAssertEqual(claims["aud"] as? String, exp["aud"] as? String,
                       "server contract pins claim name 'aud'")
        XCTAssertEqual(claims["iat"] as? Int, exp["iat"] as? Int)
        XCTAssertEqual(claims["nbf"] as? Int, exp["nbf"] as? Int)
        XCTAssertEqual(claims["exp"] as? Int, exp["exp"] as? Int)
        XCTAssertEqual(claims["jti"] as? String, exp["jti"] as? String,
                       "server contract pins claim name 'jti'")
        XCTAssertEqual(claims["project_id"] as? String,
                       exp["project_id"] as? String)
        let didPresent = claims["device_id"] != nil
        XCTAssertEqual(didPresent, exp["device_id_present"] as? Bool)

        // Body wrapper keys (sorted) per fixture.
        guard let bodyMap = claims["body"] as? [String: Any] else {
            XCTFail("body wrapper missing"); return
        }
        let actualKeys = bodyMap.keys.sorted()
        let expectedKeys = (exp["body_keys_sorted"] as! [String])
        XCTAssertEqual(actualKeys, expectedKeys)

        // ephemeral_pubkey body field MUST byte-equal header
        // device_pub_jwk.x.
        let jwk = hdr["device_pub_jwk"] as! [String: Any]
        XCTAssertEqual(bodyMap["ephemeral_pubkey"] as? String,
                       jwk["x"] as? String)
    }

    /// Verify (Mode B / durable) — claim shape matches the fixture's
    /// `expected_durable_jws_claims`.
    func testDurableVerifyInnerJwsClaimsParity() throws {
        let fixture = try Self.loadFixture()
        let inputs = fixture["deterministic_test_inputs"] as! [String: Any]
        let exp = fixture["expected_durable_jws_claims"] as! [String: Any]
        let hdrExp = fixture["expected_inner_jws_header_durable"]
            as! [String: Any]

        let seed = Self.hexToData(
            inputs["durable_ed25519_seed_hex"] as! String)
        let signing = try Self.signingKeyFromSeed(seed)
        let rec = try Self.fixedRecipientKey()
        let recipient = DirectRecipient(
            kid: inputs["recipient_kid"] as! String,
            x25519Pub: rec.pub)

        let builder = DirectRequestBuilder(
            projectId: inputs["project_id"] as! String,
            jwsLifetimeMs: inputs["jws_lifetime_ms"] as! Int)

        let env = try builder.build(
            mode: .durable,
            audience: exp["aud"] as! String,
            signingKey: signing,
            deviceId: inputs["device_id"] as? String,
            body: [:],
            recipient: recipient,
            nowMs: inputs["now_ms"] as? Int,
            requestId: inputs["request_id"] as? String)

        let codec = JweCodec()
        let (plaintext, _) = try codec.decryptCompact(
            jwe: env.compactJwe,
            devicePriv: rec.priv)
        let inner = String(data: plaintext, encoding: .utf8) ?? ""
        let (hdr, claims) = try Self.decodeInnerJws(inner)

        // Durable header.
        XCTAssertEqual(hdr["alg"] as? String, hdrExp["alg"] as? String)
        XCTAssertEqual(hdr["typ"] as? String, hdrExp["typ"] as? String)
        let devicePubPresent = (hdr["device_pub_jwk"] as? [String: Any]) != nil
        XCTAssertEqual(devicePubPresent,
                       hdrExp["device_pub_jwk_present"] as? Bool,
                       "durable header MUST NOT embed device_pub_jwk")

        // Durable claims.
        XCTAssertEqual(claims["aud"] as? String, exp["aud"] as? String)
        XCTAssertEqual(claims["iat"] as? Int, exp["iat"] as? Int)
        XCTAssertEqual(claims["nbf"] as? Int, exp["nbf"] as? Int)
        XCTAssertEqual(claims["exp"] as? Int, exp["exp"] as? Int)
        XCTAssertEqual(claims["jti"] as? String, exp["jti"] as? String)
        XCTAssertEqual(claims["project_id"] as? String,
                       exp["project_id"] as? String)
        XCTAssertEqual(claims["device_id"] as? String,
                       exp["device_id"] as? String,
                       "durable mode REQUIRES top-level device_id per " +
                       "DirectJwsClaims (Mode B)")
    }

    /// Every known error code carries http/sealed/sdk_action so both
    /// SDKs have the same surface for error-handling decisions.
    func testErrorEnvelopeShapePins() throws {
        let fixture = try Self.loadFixture()
        let env = fixture["error_envelope"] as! [String: Any]
        let known = env["known_codes"] as! [String: Any]
        for (code, raw) in known {
            guard let entry = raw as? [String: Any] else {
                XCTFail("\(code) entry malformed"); continue
            }
            XCTAssertNotNil(entry["http"] as? Int,
                            "\(code) missing http status")
            XCTAssertNotNil(entry["sealed"] as? Bool,
                            "\(code) missing sealed flag")
            XCTAssertNotNil(entry["sdk_action"] as? String,
                            "\(code) missing sdk_action guidance")
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // W6 — FRON payment surface parity (B-FRON.5.*)
    //
    // Six Tier-2 (durable mode) endpoints share the durable inner-JWS
    // shape. Each endpoint has a fixture-pinned `aud_swift`, body keys,
    // and per-field body shape. The shared helper drives the same
    // DirectRequestBuilder.build(.durable, ...) used in production.
    // ─────────────────────────────────────────────────────────────────

    /// Per-endpoint helper — build a durable envelope, decrypt it, and
    /// assert (a) durable header pins, (b) every top-level claim, (c)
    /// body-keys-sorted, (d) body field round-trip. The fixture supplies
    /// every expected value so adding a new endpoint = adding a fixture
    /// entry, no test rewrite.
    private func assertPaymentEndpointParity(
        endpointKey: String,
        routePath: String,
        fixture: [String: Any]
    ) throws {
        let inputs = fixture["deterministic_test_inputs"]
            as! [String: Any]
        let paymentClaims =
            fixture["expected_payment_jws_claims"] as! [String: Any]
        let paymentBodies =
            fixture["payment_endpoint_bodies"] as! [String: Any]
        let durHdrExp =
            fixture["expected_inner_jws_header_durable"] as! [String: Any]
        let exp = paymentClaims[endpointKey] as! [String: Any]
        let endpointMeta = paymentBodies[routePath] as! [String: Any]
        let body = endpointMeta["body"] as! [String: Any]

        // Build the durable envelope using the SAME builder DirectClient
        // routes payment calls through.
        let seed = Self.hexToData(
            inputs["durable_ed25519_seed_hex"] as! String)
        let signing = try Self.signingKeyFromSeed(seed)
        let rec = try Self.fixedRecipientKey()
        let recipient = DirectRecipient(
            kid: inputs["recipient_kid"] as! String,
            x25519Pub: rec.pub)
        let builder = DirectRequestBuilder(
            projectId: inputs["project_id"] as! String,
            jwsLifetimeMs: inputs["jws_lifetime_ms"] as! Int)
        let env = try builder.build(
            mode: .durable,
            audience: exp["aud_swift"] as! String,
            signingKey: signing,
            deviceId: inputs["device_id"] as? String,
            body: body,
            recipient: recipient,
            nowMs: inputs["now_ms"] as? Int,
            requestId: inputs["request_id"] as? String)

        let codec = JweCodec()
        let (plaintext, _) = try codec.decryptCompact(
            jwe: env.compactJwe,
            devicePriv: rec.priv)
        let inner = String(data: plaintext, encoding: .utf8) ?? ""
        let (hdr, claims) = try Self.decodeInnerJws(inner)

        // Durable header pins.
        XCTAssertEqual(hdr["alg"] as? String,
                       durHdrExp["alg"] as? String,
                       "\(endpointKey) durable header alg pin")
        XCTAssertEqual(hdr["typ"] as? String,
                       durHdrExp["typ"] as? String,
                       "\(endpointKey) durable header typ pin")
        let devicePubPresent =
            (hdr["device_pub_jwk"] as? [String: Any]) != nil
        XCTAssertEqual(devicePubPresent,
                       durHdrExp["device_pub_jwk_present"] as? Bool,
                       "\(endpointKey) MUST NOT embed device_pub_jwk " +
                       "(Mode B — durable)")

        // Per-endpoint top-level claims. Swift SDK emits the colon-
        // namespaced shape (`direct:payment.checkout`); the fixture
        // records this under `aud_swift`.
        XCTAssertEqual(claims["aud"] as? String,
                       exp["aud_swift"] as? String,
                       "\(endpointKey) aud must match fixture aud_swift " +
                       "(Swift SDK emits colon-namespaced shape; the " +
                       "cross-SDK audience-style divergence is documented " +
                       "in $payment_audience_dialect_note)")
        XCTAssertEqual(claims["iat"] as? Int, exp["iat"] as? Int,
                       "\(endpointKey) iat parity")
        XCTAssertEqual(claims["nbf"] as? Int, exp["nbf"] as? Int,
                       "\(endpointKey) nbf parity")
        XCTAssertEqual(claims["exp"] as? Int, exp["exp"] as? Int,
                       "\(endpointKey) exp parity")
        XCTAssertEqual(claims["jti"] as? String, exp["jti"] as? String,
                       "\(endpointKey) jti parity")
        XCTAssertEqual(claims["project_id"] as? String,
                       exp["project_id"] as? String,
                       "\(endpointKey) project_id parity")
        XCTAssertEqual(claims["device_id"] as? String,
                       exp["device_id"] as? String,
                       "\(endpointKey) device_id REQUIRED in durable mode")

        // Body wrapper keys (sorted) per fixture.
        guard let bodyMap = claims["body"] as? [String: Any] else {
            XCTFail("\(endpointKey) body wrapper missing"); return
        }
        let actualKeys = bodyMap.keys.sorted()
        let expectedKeys = (exp["body_keys_sorted"] as! [String])
        XCTAssertEqual(actualKeys, expectedKeys,
                       "\(endpointKey) body_keys_sorted parity")

        // Body field round-trip (snake_case wire shape). We only assert
        // primitive equality for String/Int/Bool — nested map/array
        // comparison would need a deep-equals helper. For the payment
        // surface every field IS a primitive, so this covers it.
        for (key, raw) in body {
            if let s = raw as? String {
                XCTAssertEqual(bodyMap[key] as? String, s,
                               "\(endpointKey) body field '\(key)' " +
                               "round-trip")
            } else if let n = raw as? Int {
                XCTAssertEqual(bodyMap[key] as? Int, n,
                               "\(endpointKey) body field '\(key)' " +
                               "round-trip")
            } else if let b = raw as? Bool {
                XCTAssertEqual(bodyMap[key] as? Bool, b,
                               "\(endpointKey) body field '\(key)' " +
                               "round-trip")
            } else {
                XCTAssertNotNil(bodyMap[key],
                                "\(endpointKey) body field '\(key)' " +
                                "missing after round-trip")
            }
        }
    }

    func testPaymentCheckoutInnerJwsClaimsParity() throws {
        let fixture = try Self.loadFixture()
        try assertPaymentEndpointParity(
            endpointKey: "checkout",
            routePath: "/direct/v1/payment/checkout",
            fixture: fixture)
    }

    func testPaymentIntentInnerJwsClaimsParity() throws {
        let fixture = try Self.loadFixture()
        try assertPaymentEndpointParity(
            endpointKey: "intent",
            routePath: "/direct/v1/payment/intent",
            fixture: fixture)
    }

    func testPaymentPortalInnerJwsClaimsParity() throws {
        let fixture = try Self.loadFixture()
        try assertPaymentEndpointParity(
            endpointKey: "portal",
            routePath: "/direct/v1/payment/portal",
            fixture: fixture)
    }

    func testPaymentRestoreInnerJwsClaimsParity() throws {
        let fixture = try Self.loadFixture()
        try assertPaymentEndpointParity(
            endpointKey: "restore",
            routePath: "/direct/v1/payment/restore",
            fixture: fixture)
    }

    func testPaymentIapVerifyInnerJwsClaimsParity() throws {
        let fixture = try Self.loadFixture()
        try assertPaymentEndpointParity(
            endpointKey: "iap_verify",
            routePath: "/direct/v1/payment/iap-verify",
            fixture: fixture)
    }

    func testPaymentRefreshInnerJwsClaimsParity() throws {
        let fixture = try Self.loadFixture()
        try assertPaymentEndpointParity(
            endpointKey: "refresh",
            routePath: "/direct/v1/payment/refresh",
            fixture: fixture)
    }

    /// Every endpoint declares its response payload shape (required keys
    /// — either `payload_required` for the plain shapes, or the iap-
    /// verify-style `payload_{valid,invalid}_required` pair).
    func testPaymentResponsePayloadsShape() throws {
        let fixture = try Self.loadFixture()
        let payloads =
            fixture["payment_response_payloads"] as! [String: Any]
        for (key, raw) in payloads {
            if key.hasPrefix("$") { continue }
            guard let v = raw as? [String: Any] else {
                XCTFail("\(key) entry malformed"); continue
            }
            let hasPlain = v["payload_required"] is [String]
            let hasIapPair = (v["payload_valid_required"] is [String]) &&
                             (v["payload_invalid_required"] is [String])
            XCTAssertTrue(hasPlain || hasIapPair,
                          "\(key) response spec must declare either " +
                          "payload_required OR the iap-verify-style " +
                          "payload_{valid,invalid}_required pair")
        }
    }

    /// Restore endpoint must publish its hard invariants
    /// (count>0 IMPLIES jws!=null) so both SDKs implement the same
    /// guardrail.
    func testPaymentRestoreInvariantsRecorded() throws {
        let fixture = try Self.loadFixture()
        let payloads =
            fixture["payment_response_payloads"] as! [String: Any]
        let restore = payloads["/direct/v1/payment/restore"]
            as! [String: Any]
        XCTAssertNotNil(restore["payload_invariants"] as? [String],
                        "restore must publish hard invariants " +
                        "(B-FRON.5.4 / count>0 IMPLIES jws!=null)")
    }

    /// IAP reason taxonomy parity — the four narrow strings the SDK
    /// forks UX on (DirectIapInvalidReason).
    func testPaymentIapReasonTaxonomyParity() throws {
        let fixture = try Self.loadFixture()
        let payloads =
            fixture["payment_response_payloads"] as! [String: Any]
        let iap = payloads["/direct/v1/payment/iap-verify"]
            as! [String: Any]
        let reasons = iap["reason_enum"] as! [String]
        for r in ["expired", "malformed", "not_subscribed", "unknown"] {
            XCTAssertTrue(reasons.contains(r),
                          "iap reason '\(r)' missing from fixture enum")
        }
    }

    /// Every new payment error code carries http/sealed/sdk_action +
    /// a wire_shape so both SDKs implement the same wiring.
    func testPaymentErrorCodesShape() throws {
        let fixture = try Self.loadFixture()
        let codes = fixture["payment_error_codes"] as! [String: Any]
        for (code, raw) in codes {
            if code.hasPrefix("$") { continue }
            guard let entry = raw as? [String: Any] else {
                XCTFail("\(code) entry malformed"); continue
            }
            XCTAssertNotNil(entry["http"] as? Int,
                            "\(code) missing http status")
            XCTAssertNotNil(entry["sealed"] as? Bool,
                            "\(code) missing sealed flag")
            XCTAssertNotNil(entry["sdk_action"] as? String,
                            "\(code) missing sdk_action guidance")
            XCTAssertNotNil(entry["wire_shape"] as? [String: Any],
                            "\(code) missing wire_shape spec")
        }
    }

    /// DIRECT_IAP_RECEIPT_INVALID wire-body has a top-level `reason`
    /// field so the SDK can fork UX. (The other error envelopes carry
    /// only code + message.)
    func testPaymentIapErrorWireCarriesReason() throws {
        let fixture = try Self.loadFixture()
        let codes = fixture["payment_error_codes"] as! [String: Any]
        let iap = codes["DIRECT_IAP_RECEIPT_INVALID"] as! [String: Any]
        let wire = iap["wire_shape"] as! [String: Any]
        XCTAssertNotNil(wire["reason"],
                        "DIRECT_IAP_RECEIPT_INVALID wire MUST carry a " +
                        "reason field — SDK forks UX on it")
    }

    // ─────────────────────────────────────────────────────────────────
    // W6 Fix-pass-2 — response_envelope_shape +
    // sealed_error_envelope_samples + endpoint_response_samples
    //
    // Fixture-shape pins for the canonical FRON response shape (both the
    // success leg and the sealed-error leg), four concrete sealed-error
    // sample envelopes, and per-endpoint success-payload samples. These
    // are documentation-grade pins that make the canonical wire shape
    // explicit in the shared fixture — any divergence between the server
    // emission, the Dart parser, and the Swift parser is surfaced in
    // review (see the response_envelope_shape.$claim_placement_note
    // for the current Dart-vs-Swift/server divergence).
    // ─────────────────────────────────────────────────────────────────

    /// response_envelope_shape block exists with both legs and the
    /// expected claim skeleton.
    func testResponseEnvelopeShapePins() throws {
        let fixture = try Self.loadFixture()
        let block = fixture["response_envelope_shape"] as! [String: Any]
        XCTAssertNotNil(block["success_path"],
                        "response_envelope_shape MUST declare success_path")
        XCTAssertNotNil(block["sealed_error_path"],
                        "response_envelope_shape MUST declare " +
                        "sealed_error_path")

        let success = block["success_path"] as! [String: Any]
        let sealed = block["sealed_error_path"] as! [String: Any]
        let successShape = success["shape"] as! [String: Any]
        let sealedShape = sealed["shape"] as! [String: Any]

        for claim in ["iss", "iat", "nbf", "exp", "aud"] {
            XCTAssertNotNil(successShape[claim],
                            "success_path.shape missing claim \"\(claim)\"")
            XCTAssertNotNil(sealedShape[claim],
                            "sealed_error_path.shape missing claim " +
                            "\"\(claim)\"")
        }

        // Iss pin: both legs use the same Bifrost issuer string.
        XCTAssertEqual(successShape["iss"] as? String, "bifrost-direct")
        XCTAssertEqual(sealedShape["iss"] as? String, "bifrost-direct")

        // Success carries `payload`; sealed-error carries `error` and NOT
        // `payload` (matches the Dart parser's top-level error-claim
        // read path; the Swift parser currently unwraps payload first —
        // see the $claim_placement_note follow-up).
        XCTAssertNotNil(successShape["payload"],
                        "success_path.shape MUST carry payload claim")
        XCTAssertNotNil(sealedShape["error"],
                        "sealed_error_path.shape MUST carry error claim")
        XCTAssertNil(sealedShape["payload"],
                     "sealed_error_path.shape MUST NOT carry payload " +
                     "(per the comment: \"payload claim is absent\")")

        // Sealed-error.error inner shape carries the four-field
        // projection the SDK forks UX on.
        let errShape = sealedShape["error"] as! [String: Any]
        for field in ["code", "reason", "provider", "retry_after_ms"] {
            XCTAssertNotNil(errShape[field],
                            "sealed_error_path.shape.error missing " +
                            "\"\(field)\"")
        }
    }

    /// Four canonical sealed-error samples exist + carry the expected
    /// structured projection (reason / provider / retry_after_ms / plain).
    func testSealedErrorEnvelopeSamplesShape() throws {
        let fixture = try Self.loadFixture()
        let samples =
            fixture["sealed_error_envelope_samples"] as! [String: Any]
        for sampleKey in [
            "DIRECT_IAP_RECEIPT_INVALID_expired",
            "DIRECT_PAYMENT_PROVIDER_FAILED_stripe",
            "DIRECT_RATE_LIMITED_5000ms",
            "DIRECT_BAD_REQUEST_plain",
        ] {
            guard let sample = samples[sampleKey] as? [String: Any] else {
                XCTFail("sealed_error_envelope_samples missing " +
                        "\"\(sampleKey)\""); continue
            }
            guard let claims =
                    sample["inner_jws_claims"] as? [String: Any] else {
                XCTFail("\(sampleKey) missing inner_jws_claims"); continue
            }
            for c in ["iat", "nbf", "exp", "iss", "aud"] {
                XCTAssertNotNil(claims[c],
                                "\(sampleKey) claims missing \"\(c)\"")
            }
            XCTAssertEqual(claims["iss"] as? String, "bifrost-direct",
                           "\(sampleKey) iss pin")
            let err = claims["error"] as! [String: Any]
            XCTAssertNotNil(err["code"] as? String,
                            "\(sampleKey) error.code must be a string")
            // Sealed-error envelope contract: payload claim is absent.
            XCTAssertNil(claims["payload"],
                         "\(sampleKey) MUST NOT carry payload claim")
        }
    }

    func testSealedErrorIapReceiptInvalidCarriesReasonExpired() throws {
        let fixture = try Self.loadFixture()
        let samples =
            fixture["sealed_error_envelope_samples"] as! [String: Any]
        let s = samples["DIRECT_IAP_RECEIPT_INVALID_expired"]
            as! [String: Any]
        let claims = s["inner_jws_claims"] as! [String: Any]
        let err = claims["error"] as! [String: Any]
        XCTAssertEqual(err["code"] as? String, "DIRECT_IAP_RECEIPT_INVALID")
        XCTAssertEqual(err["reason"] as? String, "expired")
    }

    func testSealedErrorPaymentProviderFailedCarriesProviderStripe() throws {
        let fixture = try Self.loadFixture()
        let samples =
            fixture["sealed_error_envelope_samples"] as! [String: Any]
        let s = samples["DIRECT_PAYMENT_PROVIDER_FAILED_stripe"]
            as! [String: Any]
        let claims = s["inner_jws_claims"] as! [String: Any]
        let err = claims["error"] as! [String: Any]
        XCTAssertEqual(err["code"] as? String,
                       "DIRECT_PAYMENT_PROVIDER_FAILED")
        XCTAssertEqual(err["provider"] as? String, "stripe")
    }

    func testSealedErrorRateLimitedCarriesRetryAfterMs5000() throws {
        let fixture = try Self.loadFixture()
        let samples =
            fixture["sealed_error_envelope_samples"] as! [String: Any]
        let s = samples["DIRECT_RATE_LIMITED_5000ms"] as! [String: Any]
        let claims = s["inner_jws_claims"] as! [String: Any]
        let err = claims["error"] as! [String: Any]
        XCTAssertEqual(err["code"] as? String, "DIRECT_RATE_LIMITED")
        XCTAssertEqual(err["retry_after_ms"] as? Int, 5000)
    }

    func testSealedErrorBadRequestPlainOnlyCarriesCode() throws {
        let fixture = try Self.loadFixture()
        let samples =
            fixture["sealed_error_envelope_samples"] as! [String: Any]
        let s = samples["DIRECT_BAD_REQUEST_plain"] as! [String: Any]
        let claims = s["inner_jws_claims"] as! [String: Any]
        let err = claims["error"] as! [String: Any]
        XCTAssertEqual(err["code"] as? String, "DIRECT_BAD_REQUEST")
        XCTAssertNil(err["reason"],
                     "BAD_REQUEST plain MUST NOT carry reason")
        XCTAssertNil(err["provider"],
                     "BAD_REQUEST plain MUST NOT carry provider")
        XCTAssertNil(err["retry_after_ms"],
                     "BAD_REQUEST plain MUST NOT carry retry_after_ms")
    }

    /// Every endpoint sample wraps its success body under the `payload`
    /// claim (per sendDirectJweResponse contract on the server).
    func testEndpointResponseSamplesWrapPayload() throws {
        let fixture = try Self.loadFixture()
        let samples =
            fixture["endpoint_response_samples"] as! [String: Any]
        for (key, raw) in samples {
            if key.hasPrefix("$") { continue }
            guard let sample = raw as? [String: Any] else {
                XCTFail("\(key) entry malformed"); continue
            }
            guard let claims =
                    sample["inner_jws_claims"] as? [String: Any] else {
                XCTFail("\(key) missing inner_jws_claims"); continue
            }
            XCTAssertNotNil(claims["payload"] as? [String: Any],
                            "\(key) success sample MUST wrap body under " +
                            "\"payload\" claim (per sendDirectJweResponse " +
                            "contract)")
            for c in ["iat", "nbf", "exp", "iss", "aud"] {
                XCTAssertNotNil(claims[c],
                                "\(key) claims missing \"\(c)\"")
            }
            XCTAssertEqual(claims["iss"] as? String, "bifrost-direct",
                           "\(key) iss pin")
        }
    }

    /// All 9 known FRON routes have a sample in endpoint_response_samples.
    func testEndpointResponseSamplesCoverAllRoutes() throws {
        let fixture = try Self.loadFixture()
        let samples =
            fixture["endpoint_response_samples"] as! [String: Any]
        for route in [
            "/direct/v1/register",
            "/direct/v1/verify",
            "/direct/v1/heartbeat",
            "/direct/v1/payment/checkout",
            "/direct/v1/payment/intent",
            "/direct/v1/payment/portal",
            "/direct/v1/payment/restore",
            "/direct/v1/payment/iap-verify",
            "/direct/v1/payment/refresh",
        ] {
            XCTAssertNotNil(samples[route],
                            "endpoint_response_samples missing route " +
                            "\"\(route)\"")
        }
    }

    /// Every post-verify payment error MUST be sealed inside the JWE
    /// envelope. The SDK must refuse to drive destructive state on a
    /// plaintext payment-error envelope (matches the DIRECT_DEVICE_REVOKED
    /// invariant from the original error_envelope block).
    func testPaymentPostVerifyErrorsAreSealed() throws {
        let fixture = try Self.loadFixture()
        let codes = fixture["payment_error_codes"] as! [String: Any]
        for code in [
            "DIRECT_PAYMENT_PROVIDER_FAILED",
            "DIRECT_NO_PROVIDER_CONFIGURED",
            "DIRECT_NO_ACTIVE_SUBSCRIPTION",
            "DIRECT_SESSION_NOT_FOUND",
            "DIRECT_SESSION_NOT_COMPLETE",
            "DIRECT_IAP_RECEIPT_INVALID",
        ] {
            let v = codes[code] as! [String: Any]
            XCTAssertEqual(v["sealed"] as? Bool, true,
                           "\(code) is a post-verify (handler) error " +
                           "and MUST be sealed inside the JWE envelope " +
                           "— SDK refuses to drive destructive state " +
                           "on a plaintext payment error")
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // S-Fix 3 (W6 Fix-pass-2) — audience namespace audit.
    //
    // The Bifrost server pins the canonical DIRECT_AUD constants in
    // `bifrost/.../direct/jws-verifier.ts` (lines 110-120). The Dart
    // SDK mirrors them as kDirectAud* constants in
    // `vanaheim/dart/.../direct_client.dart` lines 53-64. Swift was
    // briefly out of sync on two routes (`keys.rotate-ack` vs
    // `keys.rotate_ack`; `notifications.register-fcm` vs
    // `notifications.register_fcm`) — fix-pass-2 aligns them.
    //
    // The payment surface (`direct:payment.*`) intentionally retains
    // its dash dialect on Swift per the fixture's
    // $payment_audience_dialect_note; that divergence is documented
    // and tracked separately.
    //
    // This regression drives each of the eleven non-payment Tier-2
    // audiences through the DirectRequestBuilder and asserts the
    // emitted `aud` claim matches the canonical underscore form. Adds
    // a fence against accidental dash/underscore drift in the future.
    // ─────────────────────────────────────────────────────────────────

    /// Drive a build() for the given audience + mode and assert the
    /// emitted inner-JWS `aud` claim round-trips byte-for-byte.
    private func assertEmittedAudienceMatches(
        _ audience: String,
        mode: DirectJwsMode = .durable
    ) throws {
        let fixture = try Self.loadFixture()
        let inputs = fixture["deterministic_test_inputs"]
            as! [String: Any]
        let seedKey: String = (mode == .ephemeral)
            ? "ephemeral_ed25519_seed_hex"
            : "durable_ed25519_seed_hex"
        let seed = Self.hexToData(inputs[seedKey] as! String)
        let signing = try Self.signingKeyFromSeed(seed)
        let rec = try Self.fixedRecipientKey()
        let recipient = DirectRecipient(
            kid: inputs["recipient_kid"] as! String,
            x25519Pub: rec.pub)
        let builder = DirectRequestBuilder(
            projectId: inputs["project_id"] as! String,
            jwsLifetimeMs: inputs["jws_lifetime_ms"] as! Int)
        let env = try builder.build(
            mode: mode,
            audience: audience,
            signingKey: signing,
            deviceId: (mode == .durable)
                ? (inputs["device_id"] as? String) : nil,
            body: [:],
            recipient: recipient,
            nowMs: inputs["now_ms"] as? Int,
            requestId: inputs["request_id"] as? String)
        let codec = JweCodec()
        let (plaintext, _) = try codec.decryptCompact(
            jwe: env.compactJwe, devicePriv: rec.priv)
        let inner = String(data: plaintext, encoding: .utf8) ?? ""
        let (_, claims) = try Self.decodeInnerJws(inner)
        XCTAssertEqual(claims["aud"] as? String, audience,
                       "audience must round-trip byte-for-byte; the " +
                       "canonical underscore/dash dialect is " +
                       "load-bearing for the Bifrost server's audience " +
                       "check (jws-verifier.ts DIRECT_AUD).")
    }

    /// register audience pins to the canonical `direct:register`.
    func testCanonicalAudRegister() throws {
        try assertEmittedAudienceMatches("direct:register",
                                         mode: .ephemeral)
    }

    /// activate audience pins to the canonical `direct:activate`.
    func testCanonicalAudActivate() throws {
        try assertEmittedAudienceMatches("direct:activate")
    }

    /// verify audience pins to the canonical `direct:verify`.
    func testCanonicalAudVerify() throws {
        try assertEmittedAudienceMatches("direct:verify")
    }

    /// heartbeat audience pins to the canonical `direct:heartbeat`.
    func testCanonicalAudHeartbeat() throws {
        try assertEmittedAudienceMatches("direct:heartbeat")
    }

    /// deactivate audience pins to the canonical `direct:deactivate`.
    func testCanonicalAudDeactivate() throws {
        try assertEmittedAudienceMatches("direct:deactivate")
    }

    /// catalog audience pins to the canonical `direct:catalog`.
    func testCanonicalAudCatalog() throws {
        try assertEmittedAudienceMatches("direct:catalog")
    }

    /// keys.rotate_ack pins to the UNDERSCORE form (W6 fix-pass-2 S-Fix
    /// 3 alignment — previously Swift used dash form).
    func testCanonicalAudKeysRotateAck() throws {
        try assertEmittedAudienceMatches("direct:keys.rotate_ack")
    }

    /// notifications.register_fcm pins to the UNDERSCORE form (W6
    /// fix-pass-2 S-Fix 3 alignment — previously dash form).
    func testCanonicalAudNotificationsRegisterFcm() throws {
        try assertEmittedAudienceMatches(
            "direct:notifications.register_fcm")
    }

    /// notifications.ack canonical `direct:notifications.ack`.
    func testCanonicalAudNotificationsAck() throws {
        try assertEmittedAudienceMatches("direct:notifications.ack")
    }

    /// telemetry.stats canonical `direct:telemetry.stats`.
    func testCanonicalAudTelemetryStats() throws {
        try assertEmittedAudienceMatches("direct:telemetry.stats")
    }

    /// telemetry.error canonical `direct:telemetry.error`.
    func testCanonicalAudTelemetryError() throws {
        try assertEmittedAudienceMatches("direct:telemetry.error")
    }
}
