// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// Tests for `DirectHeartbeatScheduler` — the periodic heartbeat ticker
/// that swallows errors and honours server-supplied cadence updates.
final class DirectHeartbeatSchedulerTests: XCTestCase {

    private actor TickSpy {
        private(set) var calls: Int = 0
        private(set) var throwOnce: Bool = false
        func bump() { calls += 1 }
        func count() -> Int { calls }
        func armThrow() { throwOnce = true }
        func shouldThrow() -> Bool {
            if throwOnce { throwOnce = false; return true }
            return false
        }
    }

    func testInitialCadenceClampToFloor() async {
        let s = DirectHeartbeatScheduler(initialCadenceMs: 60_000)
        await s.updateCadence(10) // below 1s floor → clamp to 1000
        let c = await s.currentCadenceMs
        XCTAssertEqual(c, 1000, "cadence below 1s floor must clamp up")
    }

    func testCadenceClampToCeiling() async {
        let s = DirectHeartbeatScheduler(initialCadenceMs: 60_000)
        await s.updateCadence(100 * 24 * 60 * 60 * 1000) // 100 days
        let c = await s.currentCadenceMs
        XCTAssertEqual(c, 24 * 60 * 60 * 1000, "ceiling clamp at 1d")
    }

    func testCadenceWithinBoundsPropagates() async {
        let s = DirectHeartbeatScheduler(initialCadenceMs: 60_000)
        await s.updateCadence(45_000)
        let c = await s.currentCadenceMs
        XCTAssertEqual(c, 45_000)
    }

    func testStartIsIdempotent() async {
        let s = DirectHeartbeatScheduler(initialCadenceMs: 60_000)
        let spy = TickSpy()
        await s.start { await spy.bump() }
        let r1 = await s.isRunning
        XCTAssertTrue(r1)
        // Second start should be a no-op — the first task keeps running.
        await s.start { await spy.bump() }
        let r2 = await s.isRunning
        XCTAssertTrue(r2)
        await s.stop()
        let r3 = await s.isRunning
        XCTAssertFalse(r3)
    }

    func testStopIsIdempotent() async {
        let s = DirectHeartbeatScheduler(initialCadenceMs: 60_000)
        await s.stop() // never started
        let r1 = await s.isRunning
        XCTAssertFalse(r1)
        await s.start { /* no-op */ }
        await s.stop()
        await s.stop() // second stop is fine
        let r2 = await s.isRunning
        XCTAssertFalse(r2)
    }

    func testTickFiresAtCadence() async throws {
        let s = DirectHeartbeatScheduler(initialCadenceMs: 1000)
        let spy = TickSpy()
        await s.start { await spy.bump() }
        // Wait ~1.2s to catch at least one tick. Anything more makes
        // the test slow without buying extra signal.
        try await Task.sleep(nanoseconds: 1_200_000_000)
        await s.stop()
        let calls = await spy.count()
        XCTAssertGreaterThanOrEqual(calls, 1,
                                    "at least one tick should have fired")
    }

    func testTickErrorIsSwallowed() async throws {
        let s = DirectHeartbeatScheduler(initialCadenceMs: 1000)
        let spy = TickSpy()
        await spy.armThrow()
        await s.start {
            if await spy.shouldThrow() {
                throw NSError(domain: "test-tick", code: 1)
            }
            await spy.bump()
        }
        try await Task.sleep(nanoseconds: 2_500_000_000)
        await s.stop()
        // Even though tick 1 threw, the scheduler kept going + tick 2
        // (or later) ran successfully.
        let calls = await spy.count()
        XCTAssertGreaterThanOrEqual(calls, 1,
                                    "scheduler must survive a thrown tick")
    }

    func testStopCancelsInFlightSleep() async throws {
        let s = DirectHeartbeatScheduler(initialCadenceMs: 60_000) // 60s
        let spy = TickSpy()
        await s.start { await spy.bump() }
        // The scheduler is sleeping for 60s; stop should not block.
        let start = Date()
        await s.stop()
        let elapsed = Date().timeIntervalSince(start)
        XCTAssertLessThan(elapsed, 1.0, "stop() must not block on the long sleep")
        let r = await s.isRunning
        XCTAssertFalse(r)
    }

    func testStartAfterStopRestarts() async throws {
        let s = DirectHeartbeatScheduler(initialCadenceMs: 1000)
        let spy = TickSpy()
        await s.start { await spy.bump() }
        try await Task.sleep(nanoseconds: 1_200_000_000)
        await s.stop()
        let first = await spy.count()
        XCTAssertGreaterThanOrEqual(first, 1)
        // Restart with a new closure — second pass should fire too.
        await s.start { await spy.bump() }
        try await Task.sleep(nanoseconds: 1_200_000_000)
        await s.stop()
        let second = await spy.count()
        XCTAssertGreaterThan(second, first)
    }

    func testCadenceUpdateMidRunDoesNotCrashScheduler() async throws {
        let s = DirectHeartbeatScheduler(initialCadenceMs: 60_000)
        let spy = TickSpy()
        await s.start { await spy.bump() }
        await s.updateCadence(1000) // honoured by the NEXT tick
        try await Task.sleep(nanoseconds: 1_500_000_000)
        await s.stop()
        // We don't assert a specific count — depends on when the
        // running sleep was scheduled. The important invariant: the
        // scheduler is still alive + the new cadence is in effect.
        let c = await s.currentCadenceMs
        XCTAssertEqual(c, 1000)
    }
}
