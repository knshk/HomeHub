// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// W6 / B-FRON.5.6 — `DirectClient.refreshAfterPayment(...)` end-to-end
/// tests. The refresh path mints a fresh entitlement JWS off the
/// already-completed checkout-session row + pushes the snapshot into
/// the in-actor cache so subsequent `hasFeature` / `quota` reads
/// reflect the post-payment state without a separate `verify()` call.
final class DirectPaymentRefreshTests: XCTestCase {

    private var keychainSvc: String!
    private var server: FakeBifrostDirectServer!
    private var session: URLSession!

    override func setUp() async throws {
        try await super.setUp()
        MockDirectURLProtocol.reset()
        keychainSvc = "io.vanaheim.sdk.direct.test.\(UUID().uuidString)"
        server = FakeBifrostDirectServer()
        server.installJwks()
        session = mockDirectSession()
    }

    override func tearDown() async throws {
        MockDirectURLProtocol.reset()
        try await super.tearDown()
    }

    private func makeClient() throws -> DirectClient {
        let cfg = makeTestDirectConfig(baseURL: server.baseURL)
        let resolver = try DirectRecipientResolver(
            bifrostBaseUrl: server.baseURL,
            session: session,
            ttl: 60,
            timeout: 5)
        let store = DirectKeypairStore(service: keychainSvc)
        return try DirectClient(
            config: cfg,
            recipientResolver: resolver,
            keypairStore: store,
            secureCache: InMemorySecureCache(),
            httpSession: session)
    }

    private func registerOnce(client: DirectClient) async throws {
        server.installRoute(path: "/direct/v1/register") { _, _ in
            return [
                "device_id": "dev-refresh",
                "entitlement_jws": "h.p.s",
                "server_nonce": "n",
                "feature_list": ["base"],
                "quotas": ["calls": 5],
                "heartbeat_cadence_ms": 60_000,
            ]
        }
        _ = try await client.register(
            licenseKey: "LCS", fingerprint: "fp", appMeta: [:])
    }

    // MARK: - Happy path

    func testRefreshAfterPaymentRoundTrip() async throws {
        server.installRoute(path: "/direct/v1/payment/refresh") { claims, _ in
            XCTAssertEqual(claims["aud"] as? String, "direct:payment.refresh")
            let body = claims["body"] as? [String: Any]
            XCTAssertEqual(body?["session_id"] as? String, "cs_test_xyz")
            XCTAssertEqual(body?["project_id"] as? String, "proj_test")
            return [
                "entitlement_jws": "fresh.ent.jws",
                "tier_metadata": ["name": "pro"],
                "feature_list": ["pro_feat", "api.export"],
                "quotas": ["calls": 500, "seats": 10],
                "refreshed_at_ms": 1_700_000_999_000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.refreshAfterPayment(sessionId: "cs_test_xyz")
        XCTAssertEqual(r.entitlementJws, "fresh.ent.jws")
        XCTAssertEqual(Set(r.featureList), Set(["pro_feat", "api.export"]))
        XCTAssertEqual(r.quotas["calls"], 500)
        XCTAssertEqual(r.quotas["seats"], 10)
        XCTAssertEqual(r.refreshedAtMs, 1_700_000_999_000)
        XCTAssertFalse(r.deactivated)
        await client.dispose()
    }

    func testRefreshAfterPaymentOmitsSessionIdWhenNil() async throws {
        var sawSessionKey = true
        server.installRoute(path: "/direct/v1/payment/refresh") { claims, _ in
            let body = claims["body"] as? [String: Any]
            // body["session_id"] should NOT be present at all.
            sawSessionKey = (body?["session_id"] != nil)
            return [
                "entitlement_jws": "e",
                "feature_list": [String](),
                "quotas": [String: Int](),
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        _ = try await client.refreshAfterPayment()
        XCTAssertFalse(sawSessionKey,
                       "session_id key must be absent when caller omits it")
        await client.dispose()
    }

    // MARK: - Cache snapshot mutation

    func testRefreshUpdatesEntitlementSnapshot() async throws {
        // Register seeds the cache with feature=["base"], quotas={calls:5}.
        // Refresh should overwrite to the post-payment snapshot.
        server.installRoute(path: "/direct/v1/payment/refresh") { _, _ in
            return [
                "entitlement_jws": "e",
                "feature_list": ["upgraded_feature", "premium_export"],
                "quotas": ["calls": 9999, "seats": 100],
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        // Pre-refresh: cache reflects the register snapshot.
        let pre = await client.hasFeature("base")
        XCTAssertTrue(pre)
        let preUpgraded = await client.hasFeature("upgraded_feature")
        XCTAssertFalse(preUpgraded)
        _ = try await client.refreshAfterPayment(sessionId: "cs_y")
        // Post-refresh: cache reflects the refresh snapshot.
        let postUpgraded = await client.hasFeature("upgraded_feature")
        XCTAssertTrue(postUpgraded,
                      "refreshAfterPayment must push fresh features into cache")
        let postBase = await client.hasFeature("base")
        XCTAssertFalse(postBase,
                       "old features must be evicted on refresh")
        let postQuota = await client.quota("calls")
        XCTAssertEqual(postQuota, 9999,
                       "quota must reflect post-payment value")
        let postSeats = await client.quota("seats")
        XCTAssertEqual(postSeats, 100)
        await client.dispose()
    }

    // MARK: - Connection gating

    func testRefreshBeforeConnectThrows() async throws {
        let client = try makeClient()
        do {
            _ = try await client.refreshAfterPayment(sessionId: "x")
            XCTFail("expected .notConnected")
        } catch DirectError.notConnected {
            // expected
        }
    }

    // MARK: - Server error taxonomy

    func testRefreshMapsSessionNotFound() async throws {
        server.installRoute(
            path: "/direct/v1/payment/refresh",
            statusCode: 404
        ) { _, _ in
            return ["error": "DIRECT_SESSION_NOT_FOUND"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.refreshAfterPayment(sessionId: "missing")
            XCTFail("expected .sessionNotFound")
        } catch DirectError.sessionNotFound {
            // expected
        }
        await client.dispose()
    }

    func testRefreshMapsSessionNotComplete() async throws {
        server.installRoute(
            path: "/direct/v1/payment/refresh",
            statusCode: 409
        ) { _, _ in
            return ["error": "DIRECT_SESSION_NOT_COMPLETE"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.refreshAfterPayment(sessionId: "pending")
            XCTFail("expected .sessionNotComplete")
        } catch DirectError.sessionNotComplete {
            // expected
        }
        await client.dispose()
    }

    func testRefreshMissingEntitlementJwsSurfacesAsNetwork() async throws {
        server.installRoute(path: "/direct/v1/payment/refresh") { _, _ in
            return [
                // entitlement_jws missing
                "feature_list": [String](),
                "quotas": [String: Int](),
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.refreshAfterPayment(sessionId: "x")
            XCTFail("expected .network")
        } catch DirectError.network {
            // expected
        }
        await client.dispose()
    }

    func testRefreshTolerantOfMissingOptionalFields() async throws {
        // Only entitlement_jws is required; everything else may be
        // absent (server can omit when nothing changed).
        server.installRoute(path: "/direct/v1/payment/refresh") { _, _ in
            return ["entitlement_jws": "fresh.e"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.refreshAfterPayment()
        XCTAssertEqual(r.entitlementJws, "fresh.e")
        XCTAssertTrue(r.featureList.isEmpty)
        XCTAssertTrue(r.quotas.isEmpty)
        XCTAssertFalse(r.deactivated)
        await client.dispose()
    }
}
