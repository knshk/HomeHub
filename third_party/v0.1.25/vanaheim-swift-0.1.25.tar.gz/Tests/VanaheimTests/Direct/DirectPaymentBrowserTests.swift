// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

#if canImport(AuthenticationServices) && (os(iOS) || os(macOS) || targetEnvironment(macCatalyst))
import AuthenticationServices

/// W6 fix-pass (S-Fix 1) regressions for `DirectPaymentBrowser.openUrl(_:)`.
///
/// The browser façade now pins HTTPS on the URL it hands to
/// ASWebAuthenticationSession — any other scheme MUST surface as
/// `DirectError.badRequest("non_https_browser_url")` BEFORE the session
/// is constructed. This defends against:
///
///   - SDK / server skew leaking a `http://` URL through to the browser
///     (provider-side allowlists are the load-bearing defence; the
///     client check is the early surface).
///   - `javascript:` / `file:` / `data:` schemes that ASWebAuthenticationSession
///     would silently load (some platform versions admit them).
///   - Accidental use of the deep-link callback scheme as a URL to OPEN
///     (the callback scheme is for the URL the provider redirects TO,
///     never one we hand to the browser).
///
/// The fix is a one-line guard at the top of `openUrl(_:)`; the tests
/// below cover every non-https branch that should now reject.
@available(iOS 12.0, macOS 10.15, macCatalyst 13.0, *)
@MainActor
final class DirectPaymentBrowserTests: XCTestCase {

    // MARK: - S-Fix 1 — non-https URL rejection

    func testOpenUrlRejectsHttpScheme() async throws {
        let browser = DirectPaymentBrowser(callbackScheme: "myapp")
        let url = URL(string: "http://insecure.example.com/checkout")!
        do {
            _ = try await browser.openUrl(url)
            XCTFail("expected DirectError.badRequest for http URL")
        } catch DirectError.badRequest(let reason) {
            XCTAssertEqual(reason, "non_https_browser_url",
                           "non-https URL must surface a typed reason")
        } catch {
            XCTFail("expected DirectError.badRequest, got \(error)")
        }
    }

    func testOpenUrlRejectsCustomAppScheme() async throws {
        let browser = DirectPaymentBrowser(callbackScheme: "myapp")
        // Custom-scheme URLs are legitimate for the CALLBACK side but
        // must never be handed to ASWebAuthenticationSession as the
        // URL to load — would either fail to load or open in an
        // unexpected handler.
        let url = URL(string: "myapp://payment-return?session_id=cs_x")!
        do {
            _ = try await browser.openUrl(url)
            XCTFail("expected DirectError.badRequest for custom scheme URL")
        } catch DirectError.badRequest(let reason) {
            XCTAssertEqual(reason, "non_https_browser_url")
        } catch {
            XCTFail("expected DirectError.badRequest, got \(error)")
        }
    }

    func testOpenUrlRejectsFileScheme() async throws {
        let browser = DirectPaymentBrowser(callbackScheme: "myapp")
        let url = URL(string: "file:///etc/passwd")!
        do {
            _ = try await browser.openUrl(url)
            XCTFail("expected DirectError.badRequest for file URL")
        } catch DirectError.badRequest(let reason) {
            XCTAssertEqual(reason, "non_https_browser_url")
        } catch {
            XCTFail("expected DirectError.badRequest, got \(error)")
        }
    }

    func testOpenUrlRejectsJavascriptScheme() async throws {
        let browser = DirectPaymentBrowser(callbackScheme: "myapp")
        // `javascript:` would execute in the WebKit context — a classic
        // XSS surface on a permissive in-app browser implementation.
        guard let url = URL(string: "javascript:alert(1)") else {
            // `javascript:` URL construction may fail on some platforms;
            // skip rather than fault the framework.
            return
        }
        do {
            _ = try await browser.openUrl(url)
            XCTFail("expected DirectError.badRequest for javascript URL")
        } catch DirectError.badRequest(let reason) {
            XCTAssertEqual(reason, "non_https_browser_url")
        } catch {
            XCTFail("expected DirectError.badRequest, got \(error)")
        }
    }

    func testOpenUrlRejectsUppercaseHttp() async throws {
        // The scheme check is `lowercased()` — make sure `HTTP://` still
        // gets rejected (a server that quotes back the URL in mixed
        // case is the realistic attack surface).
        let browser = DirectPaymentBrowser(callbackScheme: "myapp")
        let url = URL(string: "HTTP://insecure.example.com/x")!
        do {
            _ = try await browser.openUrl(url)
            XCTFail("expected DirectError.badRequest for HTTP URL")
        } catch DirectError.badRequest(let reason) {
            XCTAssertEqual(reason, "non_https_browser_url")
        } catch {
            XCTFail("expected DirectError.badRequest, got \(error)")
        }
    }

    // MARK: - Existing callback-scheme guard still wins on https URLs

    func testOpenUrlOnHttpsStillEnforcesCallbackSchemePresent() async throws {
        // An https URL passes the S-Fix 1 gate but the empty callback
        // scheme guard fires next — preserves the existing config-error
        // behaviour after the fix.
        let browser = DirectPaymentBrowser(callbackScheme: "")
        let url = URL(string: "https://checkout.stripe.com/pay/cs_test")!
        do {
            _ = try await browser.openUrl(url)
            XCTFail("expected missingCallbackScheme")
        } catch DirectPaymentBrowserError.missingCallbackScheme {
            // expected
        } catch {
            XCTFail("expected DirectPaymentBrowserError.missingCallbackScheme, got \(error)")
        }
    }
}

#endif // canImport(AuthenticationServices)
