// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// W6 / B-FRON.5.2 — `DirectClient.startNativePayment(...)` end-to-end
/// tests. Native payments mint a provider-side payment intent the host
/// product passes to the platform native sheet (Stripe Payment Sheet /
/// Apple Pay / Google Pay).
final class DirectPaymentNativeTests: XCTestCase {

    private var keychainSvc: String!
    private var server: FakeBifrostDirectServer!
    private var session: URLSession!

    override func setUp() async throws {
        try await super.setUp()
        MockDirectURLProtocol.reset()
        keychainSvc = "io.vanaheim.sdk.direct.test.\(UUID().uuidString)"
        server = FakeBifrostDirectServer()
        server.installJwks()
        session = mockDirectSession()
    }

    override func tearDown() async throws {
        MockDirectURLProtocol.reset()
        try await super.tearDown()
    }

    private func makeClient() throws -> DirectClient {
        let cfg = makeTestDirectConfig(baseURL: server.baseURL)
        let resolver = try DirectRecipientResolver(
            bifrostBaseUrl: server.baseURL,
            session: session,
            ttl: 60,
            timeout: 5)
        let store = DirectKeypairStore(service: keychainSvc)
        return try DirectClient(
            config: cfg,
            recipientResolver: resolver,
            keypairStore: store,
            secureCache: InMemorySecureCache(),
            httpSession: session)
    }

    private func registerOnce(client: DirectClient) async throws {
        server.installRoute(path: "/direct/v1/register") { _, _ in
            return [
                "device_id": "dev-native",
                "entitlement_jws": "h.p.s",
                "server_nonce": "n",
                "feature_list": ["base"],
                "quotas": [:],
                "heartbeat_cadence_ms": 60_000,
            ]
        }
        _ = try await client.register(
            licenseKey: "LCS", fingerprint: "fp", appMeta: [:])
    }

    // MARK: - Happy path

    func testStartNativePaymentRoundTrip() async throws {
        server.installRoute(path: "/direct/v1/payment/intent") { claims, _ in
            XCTAssertEqual(claims["aud"] as? String, "direct:payment.intent")
            let body = claims["body"] as? [String: Any]
            XCTAssertEqual(body?["tier"] as? String, "pro")
            XCTAssertEqual(body?["billing_cycle"] as? String, "monthly")
            XCTAssertEqual(body?["currency"] as? String, "USD")
            XCTAssertEqual(body?["platform"] as? String, "ios")
            XCTAssertEqual(body?["project_id"] as? String, "proj_test")
            return [
                "intent_id": "pi_test_xyz",
                "client_secret": "pi_test_xyz_secret_abc",
                "expires_at_ms": 1_700_000_000_000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.startNativePayment(
            tier: "pro",
            billingCycle: .monthly,
            currency: "USD",
            platform: .ios)
        XCTAssertEqual(r.intentId, "pi_test_xyz")
        XCTAssertEqual(r.clientSecret, "pi_test_xyz_secret_abc")
        XCTAssertEqual(r.expiresAtMs, 1_700_000_000_000)
        await client.dispose()
    }

    func testStartNativePaymentEachPlatformRoundTrips() async throws {
        for (platform, wire) in [
            (DirectNativePaymentPlatform.ios, "ios"),
            (DirectNativePaymentPlatform.android, "android"),
            (DirectNativePaymentPlatform.web, "web"),
        ] {
            MockDirectURLProtocol.reset()
            server.installJwks()
            var sawPlatform: String?
            server.installRoute(path: "/direct/v1/payment/intent") { claims, _ in
                let body = claims["body"] as? [String: Any]
                sawPlatform = body?["platform"] as? String
                return [
                    "intent_id": "i",
                    "client_secret": "s",
                    "expires_at_ms": 1,
                ]
            }
            let client = try makeClient()
            try await client.connect()
            try await registerOnce(client: client)
            _ = try await client.startNativePayment(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                platform: platform)
            XCTAssertEqual(sawPlatform, wire,
                           "platform \(platform) must serialise as \(wire)")
            await client.dispose()
        }
    }

    func testStartNativePaymentWithProviderOverride() async throws {
        server.installRoute(path: "/direct/v1/payment/intent") { claims, _ in
            let body = claims["body"] as? [String: Any]
            XCTAssertEqual(body?["provider"] as? String, "razorpay")
            return [
                "intent_id": "i",
                "client_secret": "s",
                "expires_at_ms": 1,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        _ = try await client.startNativePayment(
            tier: "pro",
            billingCycle: .yearly,
            currency: "INR",
            platform: .android,
            provider: .razorpay)
        await client.dispose()
    }

    func testStartNativePaymentOmitsProviderWhenNil() async throws {
        server.installRoute(path: "/direct/v1/payment/intent") { claims, _ in
            let body = claims["body"] as? [String: Any]
            XCTAssertNil(body?["provider"],
                         "provider must be absent when caller passes nil")
            return [
                "intent_id": "i",
                "client_secret": "s",
                "expires_at_ms": 1,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        _ = try await client.startNativePayment(
            tier: "pro",
            billingCycle: .monthly,
            currency: "USD",
            platform: .ios)
        await client.dispose()
    }

    // MARK: - Pre-wire validation

    func testStartNativePaymentRejectsInvalidTier() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startNativePayment(
                tier: "BAD-TIER",
                billingCycle: .monthly,
                currency: "USD",
                platform: .ios)
            XCTFail("expected .badRequest")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "tier_invalid")
        }
        await client.dispose()
    }

    func testStartNativePaymentRejectsInvalidCurrency() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startNativePayment(
                tier: "pro",
                billingCycle: .monthly,
                currency: "usd",
                platform: .ios)
            XCTFail("expected .badRequest")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "currency_invalid")
        }
        await client.dispose()
    }

    // MARK: - Connection gating

    func testStartNativePaymentBeforeConnectThrows() async throws {
        let client = try makeClient()
        do {
            _ = try await client.startNativePayment(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                platform: .ios)
            XCTFail("expected .notConnected")
        } catch DirectError.notConnected {
            // expected
        }
    }

    // MARK: - Server error taxonomy

    func testStartNativePaymentMapsRateLimited() async throws {
        server.installRoute(
            path: "/direct/v1/payment/intent",
            statusCode: 429
        ) { _, _ in
            return [
                "error": "DIRECT_RATE_LIMIT",
                "message": "slow down",
                "retry_after_ms": 5000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startNativePayment(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                platform: .ios)
            XCTFail("expected .rateLimited")
        } catch DirectError.rateLimited(let ms) {
            XCTAssertEqual(ms, 5000)
        }
        await client.dispose()
    }

    func testStartNativePaymentMissingFieldsSurfacesAsNetwork() async throws {
        server.installRoute(path: "/direct/v1/payment/intent") { _, _ in
            // No client_secret, no expires_at_ms.
            return ["intent_id": "i"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startNativePayment(
                tier: "pro",
                billingCycle: .monthly,
                currency: "USD",
                platform: .ios)
            XCTFail("expected .network")
        } catch DirectError.network {
            // expected
        }
        await client.dispose()
    }

    func testStartNativePaymentMapsBadRequestErrorCode() async throws {
        server.installRoute(
            path: "/direct/v1/payment/intent",
            statusCode: 400
        ) { _, _ in
            return [
                "error": "DIRECT_BAD_REQUEST",
                "message": "currency_not_supported",
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.startNativePayment(
                tier: "pro",
                billingCycle: .monthly,
                currency: "AAA",
                platform: .ios)
            XCTFail("expected .badRequest")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "currency_not_supported")
        }
        await client.dispose()
    }
}
