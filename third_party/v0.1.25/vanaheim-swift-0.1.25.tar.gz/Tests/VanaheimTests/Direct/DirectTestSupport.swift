// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit
import XCTest
@testable import Vanaheim

// ─────────────────────────────────────────────────────────────────────
// DirectTestSupport — shared mocking primitives for the FRON / Direct
// XCTest suite.
//
// Contents:
//   1. `MockDirectURLProtocol` — pluggable URLProtocol subclass that
//      lets a test register per-URL handlers that produce stub
//      (HTTPURLResponse, body) pairs. Mounted via an injected
//      URLSession configured with a custom URLProtocolClasses list.
//   2. `mockSession()` factory — builds a URLSession that routes all
//      requests through MockDirectURLProtocol.
//   3. `FakeBifrostDirectServer` — orchestrator that ties the URL
//      protocol mock to a fixed pair of (Ed25519 sig key, X25519 enc
//      key), so a test can:
//        - serve a JWKS the resolver will accept
//        - decrypt the SDK's outbound JWE envelope
//        - assert on the inner JWS shape
//        - seal a synthetic response that the SDK's response parser
//          will accept
//   4. Helper: build a DirectConfig wired to the mock session's base
//      URL with safe defaults (short timeouts, instant flush intervals).
// ─────────────────────────────────────────────────────────────────────

// MARK: - MockDirectURLProtocol

/// URLProtocol that lets tests register handlers keyed by URL path.
/// Thread-safe — uses a lock around the static handler map so a
/// concurrent test (XCTest may parallelise) doesn't race.
final class MockDirectURLProtocol: URLProtocol {
    /// Handler signature: receives the URLRequest, returns the response
    /// + body bytes. Throwing surfaces as a URLSession error.
    typealias Handler = (URLRequest) throws -> (HTTPURLResponse, Data)

    private static let lock = NSLock()
    private static var handlers: [String: Handler] = [:]
    /// Captured requests — keyed by URL path, value is the full request
    /// (headers + body) for cross-checking inside the test.
    private static var captures: [String: [URLRequest]] = [:]
    /// Captured request bodies (URLProtocol strips the body off the
    /// URLRequest when handed to the protocol's `request` accessor;
    /// we re-inject from the HTTPBodyStream here).
    private static var capturedBodies: [String: [Data]] = [:]

    /// Register a handler for the given URL path. Subsequent matching
    /// requests invoke this handler.
    static func register(path: String, handler: @escaping Handler) {
        lock.lock()
        defer { lock.unlock() }
        handlers[path] = handler
    }

    /// Drop all registered handlers + captured requests. Call from
    /// XCTestCase.tearDown so state doesn't leak across test methods.
    static func reset() {
        lock.lock()
        defer { lock.unlock() }
        handlers.removeAll()
        captures.removeAll()
        capturedBodies.removeAll()
    }

    /// Returns the captured requests for the given path.
    static func captured(path: String) -> [URLRequest] {
        lock.lock()
        defer { lock.unlock() }
        return captures[path] ?? []
    }

    /// Returns the captured request body bytes for the given path.
    static func capturedBody(path: String) -> [Data] {
        lock.lock()
        defer { lock.unlock() }
        return capturedBodies[path] ?? []
    }

    // MARK: URLProtocol API

    override class func canInit(with request: URLRequest) -> Bool {
        guard let url = request.url else { return false }
        lock.lock()
        defer { lock.unlock() }
        return handlers[url.path] != nil
    }

    override class func canonicalRequest(for request: URLRequest) -> URLRequest {
        return request
    }

    override func startLoading() {
        guard let url = request.url,
              let handler = Self.handlerFor(path: url.path) else {
            client?.urlProtocol(self, didFailWithError: URLError(.unsupportedURL))
            return
        }
        // Capture (request + body) before invoking handler so the test
        // can assert on what the SDK sent.
        let bodyData: Data = {
            if let d = request.httpBody { return d }
            if let stream = request.httpBodyStream {
                stream.open()
                defer { stream.close() }
                var bytes: [UInt8] = []
                let bufSize = 4096
                var buf = [UInt8](repeating: 0, count: bufSize)
                while stream.hasBytesAvailable {
                    let read = stream.read(&buf, maxLength: bufSize)
                    if read <= 0 { break }
                    bytes.append(contentsOf: buf[0..<read])
                }
                return Data(bytes)
            }
            return Data()
        }()
        Self.capture(path: url.path, request: request, body: bodyData)

        do {
            let (resp, body) = try handler(request)
            client?.urlProtocol(self, didReceive: resp, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: body)
            client?.urlProtocolDidFinishLoading(self)
        } catch {
            client?.urlProtocol(self, didFailWithError: error)
        }
    }

    override func stopLoading() {}

    private static func handlerFor(path: String) -> Handler? {
        lock.lock()
        defer { lock.unlock() }
        return handlers[path]
    }

    private static func capture(path: String, request: URLRequest, body: Data) {
        lock.lock()
        defer { lock.unlock() }
        captures[path, default: []].append(request)
        capturedBodies[path, default: []].append(body)
    }
}

// MARK: - URLSession factory

/// Builds a URLSession that routes through the mock protocol. Used
/// everywhere we need to inject a session into the FRON SDK.
func mockDirectSession() -> URLSession {
    let cfg = URLSessionConfiguration.ephemeral
    cfg.protocolClasses = [MockDirectURLProtocol.self]
    cfg.timeoutIntervalForRequest = 10
    cfg.timeoutIntervalForResource = 10
    return URLSession(configuration: cfg)
}

// MARK: - FakeBifrostDirectServer

/// In-process fake of the Bifrost FRON server. Holds:
///   * a fixed Ed25519 keypair (for serving the JWKS sig key — the SDK
///     doesn't actually verify response signatures yet, but it does
///     accept the sig key as part of the JWKS payload)
///   * a fixed X25519 keypair (the enc key the SDK seals requests to)
/// and exposes helpers for installing the JWKS handler + installing a
/// per-route handler that decrypts the SDK's request, runs a test-
/// supplied responder against the inner JWS claims, and seals the
/// response back to the SDK's ephemeral epk.
final class FakeBifrostDirectServer {
    let baseURL: URL
    let jwksURL: URL
    let sigKid: String = "sig-test-1"
    let encKid: String = "enc-test-1"
    let sigKey: Curve25519.Signing.PrivateKey
    let encKey: Curve25519.KeyAgreement.PrivateKey

    init(baseURL: URL = URL(string: "https://bifrost.test")!) {
        self.baseURL = baseURL
        // Resolver normalises a trailing slash off.
        var s = baseURL.absoluteString
        if s.hasSuffix("/") { s.removeLast() }
        self.jwksURL = URL(string: "\(s)/direct/v1/.well-known/jwks.json")!
        self.sigKey = Curve25519.Signing.PrivateKey()
        self.encKey = Curve25519.KeyAgreement.PrivateKey()
    }

    /// JWKS body the SDK's resolver will accept (contains an X25519 enc
    /// key + an Ed25519 sig key).
    func jwksBody() -> Data {
        let body: [String: Any] = [
            "keys": [
                [
                    "kid": sigKid,
                    "kty": "OKP",
                    "crv": "Ed25519",
                    "use": "sig",
                    "alg": "EdDSA",
                    "x": sigKey.publicKey.rawRepresentation
                        .base64URLEncodedString(),
                ],
                [
                    "kid": encKid,
                    "kty": "OKP",
                    "crv": "X25519",
                    "use": "enc",
                    "alg": "ECDH-ES",
                    "x": encKey.publicKey.rawRepresentation
                        .base64URLEncodedString(),
                ],
            ],
        ]
        return try! JSONSerialization.data(withJSONObject: body)
    }

    /// Install the standard JWKS handler.
    func installJwks() {
        MockDirectURLProtocol.register(path: jwksURL.path) { _ in
            let resp = HTTPURLResponse(
                url: self.jwksURL,
                statusCode: 200,
                httpVersion: "HTTP/1.1",
                headerFields: ["Content-Type": "application/json"])!
            return (resp, self.jwksBody())
        }
    }

    /// Install a handler for the given FRON route path. The `responder`
    /// closure receives the decrypted inner JWS claims as a
    /// `[String: Any]` plus the JWS header — it returns the JSON map
    /// that should be sealed into the response.
    ///
    /// `statusCode` lets a test simulate a 4xx/5xx error path. When
    /// `statusCode != 2xx`, the response body is plain JSON (not
    /// sealed), matching the FRON server's pre-seal error projection.
    func installRoute(
        path: String,
        statusCode: Int = 200,
        responder: @escaping (_ claims: [String: Any], _ header: [String: Any]) -> [String: Any]
    ) {
        let url = baseURL.appendingPathComponent(
            String(path.drop(while: { $0 == "/" })))
        MockDirectURLProtocol.register(path: url.path) { req in
            // URLProtocol receives the body via httpBodyStream when the
            // request was created via URLSession.data(for:). Try both.
            let reqBody = self.requestBodyData(req)
            // For the 2xx path, decrypt the SDK's envelope first so the
            // responder can branch on the claims.
            if (200...299).contains(statusCode) {
                let bodyText = String(data: reqBody, encoding: .ascii) ?? ""
                let (claims, header) = try self.decryptInnerJws(compactJwe: bodyText)
                let respJson = responder(claims, header)
                // FIX S-1 (test parity) — the SDK's response parser now
                // verifies the inner Ed25519 JWS + pins envelope typ +
                // pins jti / aud. Seal the response with the same
                // envelope shape the real Bifrost server emits.
                let projectId = claims["project_id"] as? String ?? "proj_test"
                let requestId = claims["jti"] as? String ?? "00000000-0000-7000-8000-000000000000"
                let sealed = try self.sealResponse(
                    json: respJson,
                    requestJwe: bodyText,
                    projectId: projectId,
                    requestId: requestId)
                let resp = HTTPURLResponse(
                    url: url,
                    statusCode: statusCode,
                    httpVersion: "HTTP/1.1",
                    headerFields: ["Content-Type": "application/jose+json"])!
                return (resp, sealed.data(using: .ascii)!)
            } else {
                // Error path — body is plain JSON, no seal. The
                // responder still runs (with empty claims) so a test
                // can return any custom error envelope.
                let respJson = responder([:], [:])
                let data = try JSONSerialization.data(withJSONObject: respJson)
                let resp = HTTPURLResponse(
                    url: url,
                    statusCode: statusCode,
                    httpVersion: "HTTP/1.1",
                    headerFields: ["Content-Type": "application/json"])!
                return (resp, data)
            }
        }
    }

    /// URLProtocol hands the request with body data lost — they're
    /// available only via `httpBodyStream`. Read whichever is non-nil.
    private func requestBodyData(_ req: URLRequest) -> Data {
        if let d = req.httpBody, !d.isEmpty { return d }
        if let stream = req.httpBodyStream {
            stream.open()
            defer { stream.close() }
            var out = Data()
            let bufSize = 4096
            var buf = [UInt8](repeating: 0, count: bufSize)
            while stream.hasBytesAvailable {
                let read = stream.read(&buf, maxLength: bufSize)
                if read <= 0 { break }
                out.append(buf, count: read)
            }
            return out
        }
        return Data()
    }

    // MARK: - JWE decrypt/seal (server-side)

    /// Decrypts the SDK's outbound JWE envelope, extracts the inner JWS,
    /// and returns (claims, header) maps.
    func decryptInnerJws(compactJwe: String) throws -> ([String: Any], [String: Any]) {
        let codec = JweCodec()
        let (plaintext, _) = try codec.decryptCompact(
            jwe: compactJwe,
            devicePriv: encKey)
        let innerJws = String(data: plaintext, encoding: .utf8) ?? ""
        let parts = innerJws.split(separator: ".",
                                   omittingEmptySubsequences: false)
            .map(String.init)
        guard parts.count == 3 else {
            throw NSError(domain: "FakeBifrost", code: 1,
                          userInfo: [NSLocalizedDescriptionKey:
                                      "inner JWS has \(parts.count) segments"])
        }
        guard let hdrBytes = Data(base64URLEncoded: parts[0]),
              let header = try JSONSerialization.jsonObject(with: hdrBytes)
                as? [String: Any] else {
            throw NSError(domain: "FakeBifrost", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "bad JWS header"])
        }
        guard let claimsBytes = Data(base64URLEncoded: parts[1]),
              let claims = try JSONSerialization.jsonObject(with: claimsBytes)
                as? [String: Any] else {
            throw NSError(domain: "FakeBifrost", code: 3,
                          userInfo: [NSLocalizedDescriptionKey: "bad JWS claims"])
        }
        return (claims, header)
    }

    /// Seals a JSON response body using the same envelope shape the
    /// real Bifrost server emits — inner Ed25519 JWS (signed by the
    /// fake's `sigKey`) wrapped in a single-recipient JWE addressed to
    /// the SDK's request-side ephemeral X25519 epk.
    ///
    /// The inner JWS carries `aud: projectId` + `jti: requestId` so the
    /// SDK's response parser's correlation pins succeed. The outer
    /// JWE carries `typ: bifrost-direct+jwe` + `lcs_v: 2` to satisfy
    /// the envelope pins.
    func sealResponse(
        json: [String: Any],
        requestJwe: String,
        projectId: String = "proj_test",
        requestId: String = "00000000-0000-7000-8000-000000000000"
    ) throws -> String {
        // 1. Extract the SDK's request-side X25519 epk so we seal back
        //    to the same one-shot keypair.
        let parts = requestJwe.split(separator: ".",
                                     omittingEmptySubsequences: false)
            .map(String.init)
        guard parts.count == 5,
              let headerBytes = Data(base64URLEncoded: parts[0]),
              let header = try JSONSerialization.jsonObject(with: headerBytes)
                as? [String: Any],
              let epkMap = header["epk"] as? [String: Any],
              let xStr = epkMap["x"] as? String,
              let epkBytes = Data(base64URLEncoded: xStr) else {
            throw NSError(domain: "FakeBifrost", code: 10,
                          userInfo: [NSLocalizedDescriptionKey: "bad request envelope"])
        }
        let epkPub = try Curve25519.KeyAgreement.PublicKey(
            rawRepresentation: epkBytes)

        // 2. Build + sign the inner JWS. typ pinned to the server-side
        //    `bifrost-direct+server+jws`; claims carry `payload` wrapper.
        let innerJws = try signInnerResponseJws(
            payload: json,
            projectId: projectId,
            requestId: requestId)

        // 3. Wrap in a single-recipient JWE with the FRON `typ` /
        //    `lcs_v` pins. Mirrors `wrapJweCompact` on the server.
        return try sealJweForSdk(
            plaintextJws: innerJws,
            sdkEpkPub: epkPub)
    }

    /// Build + sign the inner Ed25519 JWS the server stamps on every
    /// FRON response. Mirrors `sendDirectJweResponse` in
    /// `bifrost/.../_license-helpers.ts`.
    func signInnerResponseJws(
        payload: [String: Any],
        projectId: String,
        requestId: String
    ) throws -> String {
        let nowSec = Int(Date().timeIntervalSince1970)
        let claims: [String: Any] = [
            "iss": "test-bifrost",
            "iat": nowSec,
            "nbf": nowSec,
            "exp": nowSec + 60,
            "aud": projectId,
            "jti": requestId,
            "payload": payload,
        ]
        let header: [String: Any] = [
            "alg": "EdDSA",
            "typ": DirectWireConstants.serverJwsTyp,
            "kid": sigKid,
        ]
        let headerJson = try JSONSerialization.data(
            withJSONObject: header, options: [.sortedKeys])
        let claimsJson = try JSONSerialization.data(
            withJSONObject: claims, options: [.sortedKeys])
        let headerB64 = headerJson.base64URLEncodedString()
        let claimsB64 = claimsJson.base64URLEncodedString()
        let signingInput = "\(headerB64).\(claimsB64)".data(using: .ascii)!
        let sig = try sigKey.signature(for: signingInput)
        return "\(headerB64).\(claimsB64).\(sig.base64URLEncodedString())"
    }

    /// Seal a JWS plaintext under a FRON-shaped single-recipient JWE
    /// addressed to the SDK's request-side ephemeral epk. Mirrors the
    /// outer-JWE shape `sendDirectJweResponse` produces.
    func sealJweForSdk(
        plaintextJws: String,
        sdkEpkPub: Curve25519.KeyAgreement.PublicKey
    ) throws -> String {
        // 1. Fresh server-side ephemeral X25519 keypair.
        let epk = Curve25519.KeyAgreement.PrivateKey()
        let epkPubBytes = epk.publicKey.rawRepresentation
        let apu = pubKeyThumbprint(epkPubBytes)
        let apv = "sdk-epk"

        // 2. Protected header — FRON pins.
        let headerMap: [String: Any] = [
            "alg": "ECDH-ES",
            "enc": "A256GCM",
            "kid": "sdk-epk",
            "epk": [
                "kty": "OKP",
                "crv": "X25519",
                "x": epkPubBytes.base64URLEncodedString(),
            ],
            "apu": apu,
            "apv": apv,
            "typ": DirectWireConstants.jweTyp,
            "cty": "JWT",
            "lcs_v": DirectWireConstants.lcsVersion,
        ]
        let headerJson = try JSONSerialization.data(
            withJSONObject: headerMap, options: [.sortedKeys])
        let headerB64 = headerJson.base64URLEncodedString()

        // 3. Derive CEK via ECDH-ES → ConcatKDF (same math as the SDK).
        let cekBytes = try deriveCekConcat(
            myPriv: epk, peerPub: sdkEpkPub, apu: apu, apv: apv)
        let cek = SymmetricKey(data: cekBytes)

        // 4. AES-GCM seal.
        let aadBytes = headerB64.data(using: .ascii)!
        let sealed = try AES.GCM.seal(
            Data(plaintextJws.utf8),
            using: cek,
            authenticating: aadBytes)
        let nonceBytes = sealed.nonce.withUnsafeBytes { Data($0) }

        // 5. Compact serialisation.
        return [
            headerB64,
            "",
            nonceBytes.base64URLEncodedString(),
            sealed.ciphertext.base64URLEncodedString(),
            sealed.tag.base64URLEncodedString(),
        ].joined(separator: ".")
    }

    /// ConcatKDF (NIST SP 800-56A §5.8.1) — duplicated here so the
    /// fake server stays self-contained.
    private func deriveCekConcat(
        myPriv: Curve25519.KeyAgreement.PrivateKey,
        peerPub: Curve25519.KeyAgreement.PublicKey,
        apu: String,
        apv: String
    ) throws -> Data {
        let shared = try myPriv.sharedSecretFromKeyAgreement(with: peerPub)
        let z = shared.withUnsafeBytes { Data($0) }
        let algId = Array("A256GCM".utf8)
        let apuBytes = Array(apu.utf8)
        let apvBytes = Array(apv.utf8)
        var otherInfo = Data()
        func u32be(_ v: Int) -> Data {
            var d = Data(count: 4)
            let u = UInt32(v).bigEndian
            withUnsafeBytes(of: u) { ptr in
                d.replaceSubrange(0..<4, with: ptr)
            }
            return d
        }
        otherInfo.append(u32be(algId.count))
        otherInfo.append(contentsOf: algId)
        otherInfo.append(u32be(apuBytes.count))
        otherInfo.append(contentsOf: apuBytes)
        otherInfo.append(u32be(apvBytes.count))
        otherInfo.append(contentsOf: apvBytes)
        otherInfo.append(u32be(256))
        var hashInput = Data()
        hashInput.append(u32be(1))
        hashInput.append(z)
        hashInput.append(otherInfo)
        return Data(SHA256.hash(data: hashInput))
    }
}

// MARK: - DirectConfig factory

/// Builds a DirectConfig wired to the test server with tight timeouts
/// so tests run fast.
func makeTestDirectConfig(
    baseURL: URL = URL(string: "https://bifrost.test")!,
    projectId: String = "proj_test"
) -> DirectConfig {
    return DirectConfig(
        projectId: projectId,
        bifrostBaseUrl: baseURL,
        pinnedSpkiSha256: [],
        jwksCacheTtl: 60,
        httpTimeout: 5,
        clockSkew: 60,
        defaultHeartbeatCadenceMs: 60_000,
        statsFlushInterval: 60,
        statsFlushBatchSize: 50,
        statsBufferCapacity: 500,
        jwsTokenLifetimeMs: 60_000)
}
