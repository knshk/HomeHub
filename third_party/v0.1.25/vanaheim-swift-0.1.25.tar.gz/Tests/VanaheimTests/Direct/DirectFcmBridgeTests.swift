// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// Tests for `DirectFcmBridge` — the lightweight APNs/FCM token
/// coordinator that dedupes against the last-sent value before forwarding
/// to the FRON `notifications/register-fcm` endpoint.
final class DirectFcmBridgeTests: XCTestCase {

    /// Wires a counting callback for use in dedupe tests.
    private actor CallSpy {
        private(set) var calls: [(String, DirectPushPlatform)] = []
        func record(_ token: String, _ platform: DirectPushPlatform) {
            calls.append((token, platform))
        }
        func count() -> Int { calls.count }
        func snapshot() -> [(String, DirectPushPlatform)] { calls }
    }

    func testSubmitFiresCallbackOnFirstToken() async throws {
        let bridge = DirectFcmBridge()
        let spy = CallSpy()
        await bridge.attach { token, platform in
            await spy.record(token, platform)
        }
        try await bridge.submit(token: "tok-1", platform: .ios)
        let count = await spy.count()
        XCTAssertEqual(count, 1)
        let last = await bridge.currentToken
        XCTAssertEqual(last, "tok-1")
    }

    func testSubmitDedupesIdenticalTokens() async throws {
        let bridge = DirectFcmBridge()
        let spy = CallSpy()
        await bridge.attach { token, platform in
            await spy.record(token, platform)
        }
        try await bridge.submit(token: "tok-1", platform: .ios)
        try await bridge.submit(token: "tok-1", platform: .ios)
        try await bridge.submit(token: "tok-1", platform: .ios)
        let count = await spy.count()
        XCTAssertEqual(count, 1, "dedupe should suppress identical re-submissions")
    }

    func testSubmitForwardsOnTokenChange() async throws {
        let bridge = DirectFcmBridge()
        let spy = CallSpy()
        await bridge.attach { token, platform in
            await spy.record(token, platform)
        }
        try await bridge.submit(token: "tok-a", platform: .ios)
        try await bridge.submit(token: "tok-b", platform: .ios)
        try await bridge.submit(token: "tok-c", platform: .ios)
        let count = await spy.count()
        XCTAssertEqual(count, 3)
        let last = await bridge.currentToken
        XCTAssertEqual(last, "tok-c")
    }

    func testEmptyTokenIsDropped() async throws {
        let bridge = DirectFcmBridge()
        let spy = CallSpy()
        await bridge.attach { token, platform in
            await spy.record(token, platform)
        }
        try await bridge.submit(token: "", platform: .ios)
        try await bridge.submit(token: "   ", platform: .ios) // whitespace
        let count = await spy.count()
        XCTAssertEqual(count, 0, "empty / whitespace tokens must be dropped")
        let last = await bridge.currentToken
        XCTAssertNil(last)
    }

    func testTokenIsTrimmedBeforeForward() async throws {
        let bridge = DirectFcmBridge()
        let spy = CallSpy()
        await bridge.attach { token, platform in
            await spy.record(token, platform)
        }
        try await bridge.submit(token: "  tok-trim  \n", platform: .android)
        let snapshot = await spy.snapshot()
        XCTAssertEqual(snapshot.count, 1)
        XCTAssertEqual(snapshot[0].0, "tok-trim")
        XCTAssertEqual(snapshot[0].1, .android)
    }

    func testFailedSubmitDoesNotPoisonDedupe() async throws {
        // A throwing callback represents a transient server failure —
        // the bridge must NOT mark the token as last-sent so the next
        // submit (same token) DOES retry.
        let bridge = DirectFcmBridge()
        actor RetrySpy {
            var attempts = 0
            var failNext = true
            func next() -> Bool {
                attempts += 1
                let f = failNext
                failNext = false
                return f
            }
        }
        let spy = RetrySpy()
        await bridge.attach { _, _ in
            if await spy.next() {
                throw NSError(domain: "test", code: 1)
            }
        }
        do {
            try await bridge.submit(token: "tok-retry", platform: .ios)
            XCTFail("expected throw on first submit")
        } catch {
            // expected
        }
        let last1 = await bridge.currentToken
        XCTAssertNil(last1, "transient failure must not record last-sent")
        // Retry succeeds.
        try await bridge.submit(token: "tok-retry", platform: .ios)
        let last2 = await bridge.currentToken
        XCTAssertEqual(last2, "tok-retry")
    }

    func testDetachStopsForwarding() async throws {
        let bridge = DirectFcmBridge()
        let spy = CallSpy()
        await bridge.attach { token, platform in
            await spy.record(token, platform)
        }
        try await bridge.submit(token: "tok-x", platform: .ios)
        await bridge.detach()
        // Post-detach submit is silently dropped (matches docstring).
        try await bridge.submit(token: "tok-y", platform: .ios)
        let count = await spy.count()
        XCTAssertEqual(count, 1)
    }

    func testResetForgetsLastSent() async throws {
        let bridge = DirectFcmBridge()
        let spy = CallSpy()
        await bridge.attach { token, platform in
            await spy.record(token, platform)
        }
        try await bridge.submit(token: "tok-z", platform: .ios)
        await bridge.reset()
        try await bridge.submit(token: "tok-z", platform: .ios)
        let count = await spy.count()
        XCTAssertEqual(count, 2, "after reset, the same token must be re-forwarded")
    }

    func testApnsHexHelperFormat() {
        let raw = Data([0x12, 0xAB, 0x00, 0xFF])
        let hex = directFcmTokenHexFromAPNsDeviceToken(raw)
        XCTAssertEqual(hex, "12ab00ff")
    }

    func testApnsHexHelperEmptyInput() {
        let raw = Data()
        let hex = directFcmTokenHexFromAPNsDeviceToken(raw)
        XCTAssertEqual(hex, "")
    }
}
