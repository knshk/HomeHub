// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
import CryptoKit
@testable import Vanaheim

/// Wire-format tests for `DirectRequestBuilder`. Each test builds a
/// request, decrypts the outer JWE with the recipient's X25519 private
/// key, and verifies the inner Ed25519 JWS shape so the SDK's outbound
/// envelope is provably what the FRON server (and the Dart twin) expect.
///
/// Cross-language parity: the same wire shape produced here MUST be
/// decryptable by the Dart twin's parser. We pin the JWE typ
/// (`bifrost-direct+jwe`), the JWS typ per mode, the apu thumbprint
/// binding, and the claim schema.
final class DirectRequestBuilderTests: XCTestCase {

    private struct Decoded {
        let jweHeader: [String: Any]
        let innerJwsCompact: String
        let jwsHeader: [String: Any]
        let jwsClaims: [String: Any]
        let signatureValid: Bool
    }

    /// Helper: build an envelope, decrypt with the recipient priv key,
    /// then split the inner JWS into header + claims + verify signature.
    private func decodeOutbound(
        builder: DirectRequestBuilder,
        mode: DirectJwsMode,
        signingKey: Curve25519.Signing.PrivateKey,
        recipientPriv: Curve25519.KeyAgreement.PrivateKey,
        recipientKid: String,
        body: [String: Any],
        audience: String,
        deviceId: String?,
        nowMs: Int? = nil
    ) throws -> (envelope: DirectRequestEnvelope, decoded: Decoded) {
        let recipient = DirectRecipient(
            kid: recipientKid,
            x25519Pub: recipientPriv.publicKey.rawRepresentation)
        let envelope = try builder.build(
            mode: mode,
            audience: audience,
            signingKey: signingKey,
            deviceId: deviceId,
            body: body,
            recipient: recipient,
            nowMs: nowMs)

        // Decrypt the outer JWE with the recipient private key.
        let codec = JweCodec()
        let (plaintext, jweHeader) = try codec.decryptCompact(
            jwe: envelope.compactJwe,
            devicePriv: recipientPriv)
        let inner = String(data: plaintext, encoding: .utf8) ?? ""

        let parts = inner.split(separator: ".",
                                omittingEmptySubsequences: false)
            .map(String.init)
        XCTAssertEqual(parts.count, 3, "inner JWS must be 3 segments")
        guard parts.count == 3,
              let hdrBytes = Data(base64URLEncoded: parts[0]),
              let claimsBytes = Data(base64URLEncoded: parts[1]),
              let sigBytes = Data(base64URLEncoded: parts[2]),
              let hdr = try JSONSerialization.jsonObject(with: hdrBytes)
                as? [String: Any],
              let claims = try JSONSerialization.jsonObject(with: claimsBytes)
                as? [String: Any] else {
            throw NSError(domain: "test", code: 1)
        }
        // Verify the Ed25519 signature with the signing pubkey.
        let signingInput = "\(parts[0]).\(parts[1])".data(using: .ascii)!
        let valid = signingKey.publicKey.isValidSignature(
            sigBytes, for: signingInput)

        let decoded = Decoded(
            jweHeader: jweHeader.raw,
            innerJwsCompact: inner,
            jwsHeader: hdr,
            jwsClaims: claims,
            signatureValid: valid)
        return (envelope, decoded)
    }

    // MARK: - Ephemeral mode (register)

    func testRegisterEnvelopeHasEphemeralTypAndDevicePubJwk() throws {
        let builder = DirectRequestBuilder(projectId: "proj_x",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = Curve25519.KeyAgreement.PrivateKey()
        let (_, decoded) = try decodeOutbound(
            builder: builder,
            mode: .ephemeral,
            signingKey: signing,
            recipientPriv: recip,
            recipientKid: "enc-1",
            body: ["license_key": "LCS-XYZ"],
            audience: "direct:register",
            deviceId: nil)

        // JWS header
        XCTAssertEqual(decoded.jwsHeader["alg"] as? String, "EdDSA")
        XCTAssertEqual(decoded.jwsHeader["typ"] as? String,
                       "bifrost-direct+ephemeral+jws")
        guard let pk = decoded.jwsHeader["device_pub_jwk"]
                as? [String: Any] else {
            XCTFail("ephemeral JWS must embed device_pub_jwk")
            return
        }
        XCTAssertEqual(pk["kty"] as? String, "OKP")
        XCTAssertEqual(pk["crv"] as? String, "Ed25519")
        XCTAssertEqual(
            pk["x"] as? String,
            signing.publicKey.rawRepresentation.base64URLEncodedString())
        // Signature must verify.
        XCTAssertTrue(decoded.signatureValid)
    }

    // MARK: - Durable mode (everything else)

    func testDurableEnvelopeHasDurableTypAndDeviceIdClaim() throws {
        let builder = DirectRequestBuilder(projectId: "proj_y",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = Curve25519.KeyAgreement.PrivateKey()
        let (_, decoded) = try decodeOutbound(
            builder: builder,
            mode: .durable,
            signingKey: signing,
            recipientPriv: recip,
            recipientKid: "enc-7",
            body: ["foo": "bar"],
            audience: "direct:verify",
            deviceId: "dev-42")

        XCTAssertEqual(decoded.jwsHeader["alg"] as? String, "EdDSA")
        XCTAssertEqual(decoded.jwsHeader["typ"] as? String,
                       "bifrost-direct+durable+jws")
        XCTAssertNil(decoded.jwsHeader["device_pub_jwk"],
                     "durable JWS must NOT embed device_pub_jwk")
        XCTAssertEqual(decoded.jwsClaims["device_id"] as? String, "dev-42")
        XCTAssertEqual(decoded.jwsClaims["project_id"] as? String, "proj_y")
        XCTAssertEqual(decoded.jwsClaims["aud"] as? String, "direct:verify")
        XCTAssertTrue(decoded.signatureValid)
    }

    func testDurableModeRequiresDeviceId() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = DirectRecipient(
            kid: "enc-1",
            x25519Pub: Curve25519.KeyAgreement.PrivateKey()
                .publicKey.rawRepresentation)
        XCTAssertThrowsError(try builder.build(
            mode: .durable,
            audience: "direct:verify",
            signingKey: signing,
            deviceId: nil,
            body: [:],
            recipient: recip)) { err in
            guard case DirectError.notConnected = err else {
                XCTFail("expected .notConnected, got \(err)"); return
            }
        }
    }

    func testDurableModeRejectsEmptyDeviceId() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = DirectRecipient(
            kid: "enc-1",
            x25519Pub: Curve25519.KeyAgreement.PrivateKey()
                .publicKey.rawRepresentation)
        XCTAssertThrowsError(try builder.build(
            mode: .durable,
            audience: "direct:verify",
            signingKey: signing,
            deviceId: "",
            body: [:],
            recipient: recip)) { err in
            guard case DirectError.notConnected = err else {
                XCTFail("expected .notConnected, got \(err)"); return
            }
        }
    }

    // MARK: - JWE outer-envelope shape

    func testJweHeaderPinsTypAndAlg() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = Curve25519.KeyAgreement.PrivateKey()
        let (_, decoded) = try decodeOutbound(
            builder: builder,
            mode: .ephemeral,
            signingKey: signing,
            recipientPriv: recip,
            recipientKid: "enc-99",
            body: [:],
            audience: "direct:register",
            deviceId: nil)
        XCTAssertEqual(decoded.jweHeader["typ"] as? String,
                       "bifrost-direct+jwe")
        XCTAssertEqual(decoded.jweHeader["alg"] as? String, "ECDH-ES")
        XCTAssertEqual(decoded.jweHeader["enc"] as? String, "A256GCM")
        XCTAssertEqual(decoded.jweHeader["kid"] as? String, "enc-99")
        XCTAssertEqual(decoded.jweHeader["lcs_v"] as? Int, 2)
        XCTAssertNil(decoded.jweHeader["project_id"],
                     "FRON envelope MUST omit project_id from JWE header")
        XCTAssertNil(decoded.jweHeader["route_path"])
        XCTAssertNil(decoded.jweHeader["request_id"])
    }

    func testApuIsSha256OfEphemeralX25519PubKey() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = Curve25519.KeyAgreement.PrivateKey()
        let (envelope, decoded) = try decodeOutbound(
            builder: builder,
            mode: .ephemeral,
            signingKey: signing,
            recipientPriv: recip,
            recipientKid: "enc-x",
            body: [:],
            audience: "direct:register",
            deviceId: nil)
        // The apu must match SHA-256(epk.pub) per the spec.
        let expected = pubKeyThumbprint(
            envelope.ephemeralPrivKey.publicKey.rawRepresentation)
        XCTAssertEqual(decoded.jweHeader["apu"] as? String, expected)
        XCTAssertEqual(decoded.jweHeader["apv"] as? String, "enc-x")
    }

    func testJtiIsUniquePerRequest() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = Curve25519.KeyAgreement.PrivateKey()
        var jtis = Set<String>()
        for _ in 0..<10 {
            let (_, decoded) = try decodeOutbound(
                builder: builder,
                mode: .durable,
                signingKey: signing,
                recipientPriv: recip,
                recipientKid: "enc",
                body: [:],
                audience: "direct:verify",
                deviceId: "dev-1")
            jtis.insert(decoded.jwsClaims["jti"] as? String ?? "")
        }
        XCTAssertEqual(jtis.count, 10, "jti must be unique per request")
    }

    func testIatNbfExpRelationship() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = Curve25519.KeyAgreement.PrivateKey()
        let fixedNow = 1_700_000_000_000
        let (_, decoded) = try decodeOutbound(
            builder: builder,
            mode: .durable,
            signingKey: signing,
            recipientPriv: recip,
            recipientKid: "enc",
            body: [:],
            audience: "direct:verify",
            deviceId: "dev-1",
            nowMs: fixedNow)
        XCTAssertEqual(decoded.jwsClaims["iat"] as? Int, fixedNow)
        XCTAssertEqual(decoded.jwsClaims["nbf"] as? Int, fixedNow)
        XCTAssertEqual(decoded.jwsClaims["exp"] as? Int, fixedNow + 60_000)
    }

    func testFreshEphemeralX25519PerRequest() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = DirectRecipient(
            kid: "enc",
            x25519Pub: Curve25519.KeyAgreement.PrivateKey()
                .publicKey.rawRepresentation)
        let e1 = try builder.build(
            mode: .durable, audience: "x", signingKey: signing,
            deviceId: "dev", body: [:], recipient: recip)
        let e2 = try builder.build(
            mode: .durable, audience: "x", signingKey: signing,
            deviceId: "dev", body: [:], recipient: recip)
        XCTAssertNotEqual(
            e1.ephemeralPrivKey.publicKey.rawRepresentation,
            e2.ephemeralPrivKey.publicKey.rawRepresentation,
            "ephemeral X25519 must be fresh per request (forward secrecy)")
        XCTAssertNotEqual(e1.compactJwe, e2.compactJwe,
                          "envelopes must not byte-collide across requests")
    }

    func testBodyShapeIsPlacedUnderClaimBody() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = Curve25519.KeyAgreement.PrivateKey()
        let body: [String: Any] = [
            "license_key": "L-1",
            "extra": ["nested": true],
        ]
        let (_, decoded) = try decodeOutbound(
            builder: builder,
            mode: .ephemeral,
            signingKey: signing,
            recipientPriv: recip,
            recipientKid: "enc",
            body: body,
            audience: "direct:register",
            deviceId: nil)
        guard let inner = decoded.jwsClaims["body"] as? [String: Any] else {
            XCTFail("body claim missing"); return
        }
        XCTAssertEqual(inner["license_key"] as? String, "L-1")
    }

    // MARK: - S-3 wire compat parity with Dart fix

    /// Pin the iat/nbf/exp units to MILLISECONDS-since-epoch — matches
    /// the Dart fix-pass + the server-side `jws-verifier.ts` interface
    /// docstring (`iat: number` documented as ms-since-epoch).
    func testIatNbfExpEmittedAsMilliseconds() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = Curve25519.KeyAgreement.PrivateKey()
        // Use a recent-ish ms timestamp (Nov 2026) so its magnitude is
        // unambiguously milliseconds (a seconds-encoded value would be
        // 10 digits, ms is 13).
        let nowMs = 1_762_000_000_000
        let (_, decoded) = try decodeOutbound(
            builder: builder,
            mode: .durable,
            signingKey: signing,
            recipientPriv: recip,
            recipientKid: "enc",
            body: [:],
            audience: "direct:verify",
            deviceId: "dev-1",
            nowMs: nowMs)
        let iat = decoded.jwsClaims["iat"] as? Int ?? 0
        let exp = decoded.jwsClaims["exp"] as? Int ?? 0
        XCTAssertEqual(iat, nowMs)
        XCTAssertEqual(exp, nowMs + 60_000)
        XCTAssertGreaterThan(iat, 1_000_000_000_000,
                             "iat magnitude must be ms (>13 digits) not seconds")
    }

    /// The whole route-specific body MUST land under the `body` claim
    /// of the inner JWS (the server reads `payload.body` in
    /// `parseDirectBody`). Top-level claims are reserved for the
    /// SIGNED-tier identity (project_id / device_id / jti / iat / etc.).
    func testBodyWrapperShapePreservesAllInputFields() throws {
        let builder = DirectRequestBuilder(projectId: "proj-x",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = Curve25519.KeyAgreement.PrivateKey()
        let body: [String: Any] = [
            "license_key": "LCS-100",
            "fingerprint": "fp-abc",
            "ephemeral_pubkey": "pubkey-xyz",
            "app_meta": [
                "os": "macOS",
                "os_version": "26.0",
                "app_version": "1.2.3",
                "locale": "en-US",
            ],
        ]
        let (_, decoded) = try decodeOutbound(
            builder: builder,
            mode: .ephemeral,
            signingKey: signing,
            recipientPriv: recip,
            recipientKid: "enc",
            body: body,
            audience: "direct:register",
            deviceId: nil)
        guard let inner = decoded.jwsClaims["body"] as? [String: Any] else {
            XCTFail("body wrapper missing"); return
        }
        XCTAssertEqual(inner["license_key"] as? String, "LCS-100")
        XCTAssertEqual(inner["fingerprint"] as? String, "fp-abc")
        XCTAssertEqual(inner["ephemeral_pubkey"] as? String, "pubkey-xyz")
        // Reserved top-level fields MUST still be top-level (NOT
        // duplicated inside body).
        XCTAssertEqual(decoded.jwsClaims["project_id"] as? String, "proj-x")
        XCTAssertNotNil(decoded.jwsClaims["iat"])
        XCTAssertNotNil(decoded.jwsClaims["jti"])
    }

    /// On `register` (ephemeral mode) the `ephemeral_pubkey` body field
    /// the SDK ships MUST byte-equal the `device_pub_jwk.x` JWS header
    /// field. The server cross-checks the two to bind the wire body to
    /// the keypair that signed it (B-FRON.2.2 SECURITY: "cross-device
    /// key-reuse guard"). Caller responsibility — the `DirectClient`
    /// register flow stamps the same key into both fields; this test
    /// proves the contract end-to-end.
    func testRegisterBodyEphemeralPubkeyMatchesJwsHeaderDevicePubJwkX() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = Curve25519.KeyAgreement.PrivateKey()
        // Caller-side: build the body the way DirectClient.register
        // does — `ephemeral_pubkey` derived from the SAME signing key
        // whose pubkey lands in device_pub_jwk.x.
        let pubX = signing.publicKey.rawRepresentation
            .base64URLEncodedString()
        let body: [String: Any] = [
            "license_key": "LCS-1",
            "ephemeral_pubkey": pubX,
        ]
        let (_, decoded) = try decodeOutbound(
            builder: builder,
            mode: .ephemeral,
            signingKey: signing,
            recipientPriv: recip,
            recipientKid: "enc",
            body: body,
            audience: "direct:register",
            deviceId: nil)
        guard let inner = decoded.jwsClaims["body"] as? [String: Any] else {
            XCTFail("body wrapper missing"); return
        }
        guard let jwk = decoded.jwsHeader["device_pub_jwk"] as? [String: Any],
              let headerX = jwk["x"] as? String else {
            XCTFail("device_pub_jwk missing on ephemeral JWS"); return
        }
        XCTAssertEqual(inner["ephemeral_pubkey"] as? String, headerX,
                       "body.ephemeral_pubkey MUST equal JWS header device_pub_jwk.x")
    }

    /// Builder-supplied requestId surfaces as the JWS `jti` AND as the
    /// envelope's `requestId` so the response parser can echo-pin it.
    func testBuilderThreadsRequestIdIntoJtiAndEnvelope() throws {
        let builder = DirectRequestBuilder(projectId: "proj",
                                           jwsLifetimeMs: 60_000)
        let signing = Curve25519.Signing.PrivateKey()
        let recip = DirectRecipient(
            kid: "enc",
            x25519Pub: Curve25519.KeyAgreement.PrivateKey()
                .publicKey.rawRepresentation)
        let env = try builder.build(
            mode: .durable,
            audience: "direct:verify",
            signingKey: signing,
            deviceId: "dev",
            body: [:],
            recipient: recip,
            requestId: "fixed-req-id")
        XCTAssertEqual(env.requestId, "fixed-req-id")
    }
}
