// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// Tests for `DirectStatsBatcher` — the in-memory ring buffer + auto-
/// flush scheduler that buffers stats events until either the size
/// threshold or the interval triggers a flush.
final class DirectStatsBatcherTests: XCTestCase {

    /// Captures flushed batches for assertions.
    private actor FlushSpy {
        private(set) var batches: [[DirectStatEvent]] = []
        var failNextN: Int = 0

        func handle(_ events: [DirectStatEvent]) throws {
            if failNextN > 0 {
                failNextN -= 1
                throw NSError(domain: "test-flush-fail", code: 1)
            }
            batches.append(events)
        }
        func batchCount() -> Int { batches.count }
        func totalEvents() -> Int { batches.reduce(0) { $0 + $1.count } }
        func setFailNext(_ n: Int) { failNextN = n }
    }

    private func makeEvent(_ name: String, count: Int = 1) -> DirectStatEvent {
        DirectStatEvent(
            eventName: name,
            occurredAtMs: Int(Date().timeIntervalSince1970 * 1000),
            count: count)
    }

    func testAddBuffersUntilBatchSize() async {
        let cache = InMemorySecureCache()
        let batcher = DirectStatsBatcher(
            bufferCapacity: 100,
            flushBatchSize: 3,
            flushInterval: 3600,
            cache: cache)
        let spy = FlushSpy()
        await batcher.start { events in try await spy.handle(events) }
        defer { Task { await batcher.stop() } }

        await batcher.add(makeEvent("a"))
        await batcher.add(makeEvent("b"))
        let before = await spy.batchCount()
        XCTAssertEqual(before, 0, "no flush until batch-size threshold")

        await batcher.add(makeEvent("c"))
        let after = await spy.batchCount()
        XCTAssertEqual(after, 1)
        let total = await spy.totalEvents()
        XCTAssertEqual(total, 3)
    }

    func testFlushImmediateDrainsBuffer() async {
        let cache = InMemorySecureCache()
        let batcher = DirectStatsBatcher(
            bufferCapacity: 100,
            flushBatchSize: 1000, // never trip size threshold
            flushInterval: 3600,
            cache: cache)
        let spy = FlushSpy()
        await batcher.start { events in try await spy.handle(events) }
        defer { Task { await batcher.stop() } }

        await batcher.add(makeEvent("x"))
        await batcher.add(makeEvent("y"))
        let depth1 = await batcher.bufferedCount
        XCTAssertEqual(depth1, 2)

        await batcher.flushImmediate()
        let depth2 = await batcher.bufferedCount
        XCTAssertEqual(depth2, 0)
        let total = await spy.totalEvents()
        XCTAssertEqual(total, 2)
    }

    func testRingBufferDropsOldestOnOverflow() async {
        let cache = InMemorySecureCache()
        let batcher = DirectStatsBatcher(
            bufferCapacity: 3,
            flushBatchSize: 1000, // disable auto-flush by size
            flushInterval: 3600,
            cache: cache)
        let spy = FlushSpy()
        await batcher.start { events in try await spy.handle(events) }
        defer { Task { await batcher.stop() } }

        await batcher.add(makeEvent("first"))
        await batcher.add(makeEvent("second"))
        await batcher.add(makeEvent("third"))
        await batcher.add(makeEvent("fourth")) // boots "first"
        await batcher.add(makeEvent("fifth"))  // boots "second"

        let depth = await batcher.bufferedCount
        XCTAssertEqual(depth, 3)
        await batcher.flushImmediate()
        let snapshot = await spy.batches
        XCTAssertEqual(snapshot.count, 1)
        let names = snapshot[0].map { $0.eventName }
        XCTAssertEqual(names, ["third", "fourth", "fifth"])
    }

    func testBulkAddRespectsThreshold() async {
        let cache = InMemorySecureCache()
        let batcher = DirectStatsBatcher(
            bufferCapacity: 100,
            flushBatchSize: 2,
            flushInterval: 3600,
            cache: cache)
        let spy = FlushSpy()
        await batcher.start { events in try await spy.handle(events) }
        defer { Task { await batcher.stop() } }

        await batcher.add([makeEvent("a"), makeEvent("b"), makeEvent("c")])
        let count = await spy.batchCount()
        XCTAssertEqual(count, 1)
        let total = await spy.totalEvents()
        XCTAssertEqual(total, 3,
                       "the whole bulk add should flush (size > threshold)")
    }

    func testPersistAndRehydrateRoundTrip() async {
        let cache = InMemorySecureCache()
        let batcher1 = DirectStatsBatcher(
            bufferCapacity: 100,
            flushBatchSize: 1000,
            flushInterval: 3600,
            cache: cache)
        await batcher1.add(makeEvent("evt-1", count: 5))
        await batcher1.add(makeEvent("evt-2", count: 7))
        await batcher1.persist()
        // Confirm a payload landed in the secure cache.
        let raw = await cache.getRaw(kDirectStatsBufferKey)
        XCTAssertNotNil(raw)

        // Fresh batcher rehydrates from the same cache.
        let batcher2 = DirectStatsBatcher(
            bufferCapacity: 100,
            flushBatchSize: 1000,
            flushInterval: 3600,
            cache: cache)
        await batcher2.rehydrate()
        let depth = await batcher2.bufferedCount
        XCTAssertEqual(depth, 2)
        // Cache slot must be cleared after rehydrate so a subsequent
        // persist doesn't double-count.
        let raw2 = await cache.getRaw(kDirectStatsBufferKey)
        XCTAssertNil(raw2)
    }

    func testPersistOnEmptyClearsPriorBlob() async {
        let cache = InMemorySecureCache()
        await cache.putRaw(kDirectStatsBufferKey, "[]")
        let batcher = DirectStatsBatcher(
            bufferCapacity: 100,
            flushBatchSize: 1000,
            flushInterval: 3600,
            cache: cache)
        await batcher.persist() // empty buffer
        let raw = await cache.getRaw(kDirectStatsBufferKey)
        XCTAssertNil(raw, "empty persist should also clear the cache slot")
    }

    func testFlushFailureReEnqueuesEvents() async {
        let cache = InMemorySecureCache()
        let batcher = DirectStatsBatcher(
            bufferCapacity: 100,
            flushBatchSize: 1000,
            flushInterval: 3600,
            cache: cache)
        let spy = FlushSpy()
        await spy.setFailNext(1)
        await batcher.start { events in try await spy.handle(events) }
        defer { Task { await batcher.stop() } }

        await batcher.add(makeEvent("retry-me"))
        await batcher.flushImmediate() // fails — events back into buffer
        let depth1 = await batcher.bufferedCount
        XCTAssertEqual(depth1, 1, "failed flush should re-enqueue events")
        await batcher.flushImmediate() // succeeds now
        let total = await spy.totalEvents()
        XCTAssertEqual(total, 1)
        let depth2 = await batcher.bufferedCount
        XCTAssertEqual(depth2, 0)
    }

    func testFlushImmediateNoOpWhenEmpty() async {
        let cache = InMemorySecureCache()
        let batcher = DirectStatsBatcher(
            bufferCapacity: 100,
            flushBatchSize: 10,
            flushInterval: 3600,
            cache: cache)
        let spy = FlushSpy()
        await batcher.start { events in try await spy.handle(events) }
        defer { Task { await batcher.stop() } }
        await batcher.flushImmediate()
        let count = await spy.batchCount()
        XCTAssertEqual(count, 0)
    }

    func testRehydrateWithCorruptBlobIsTolerated() async {
        let cache = InMemorySecureCache()
        await cache.putRaw(kDirectStatsBufferKey, "not valid json")
        let batcher = DirectStatsBatcher(
            bufferCapacity: 100,
            flushBatchSize: 1000,
            flushInterval: 3600,
            cache: cache)
        await batcher.rehydrate()
        // Buffer stays empty; the bad blob is purged.
        let depth = await batcher.bufferedCount
        XCTAssertEqual(depth, 0)
        let raw = await cache.getRaw(kDirectStatsBufferKey)
        XCTAssertNil(raw)
    }

    func testCapacityIsClampedToMinimumOne() async {
        let cache = InMemorySecureCache()
        let batcher = DirectStatsBatcher(
            bufferCapacity: 0,   // invalid; should clamp to 1
            flushBatchSize: 0,   // invalid; should clamp to 1
            flushInterval: 0,    // invalid; should clamp to 1
            cache: cache)
        let spy = FlushSpy()
        await batcher.start { events in try await spy.handle(events) }
        defer { Task { await batcher.stop() } }
        // batchSize clamp == 1 → first add should immediately flush.
        await batcher.add(makeEvent("only"))
        let count = await spy.batchCount()
        XCTAssertEqual(count, 1)
    }
}
