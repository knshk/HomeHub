// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
import CryptoKit
@testable import Vanaheim

/// Tests for `DirectResponseParser` — unwraps + verifies the server's
/// sealed JSON payload addressed to the SDK's request-side ephemeral epk.
///
/// W5 fix-pass (S-1) regressions cover the new pins:
///   - outer JWE typ + lcs_v
///   - request_id correlation (inner-JWS `jti`)
///   - inner JWS signature against JWKS verify keys (unsigned reject)
///   - route_path mismatch on outer header (when emitted)
final class DirectResponseParserTests: XCTestCase {

    // ── Test fixtures ─────────────────────────────────────────────────

    /// Fresh per-test crypto state — SDK ephemeral epk + server signing
    /// key + a matching `verifyKeys` set.
    private struct Fixture {
        let sdkEpk: Curve25519.KeyAgreement.PrivateKey
        let sigKey: Curve25519.Signing.PrivateKey
        let sigKid: String
        var verifyKeys: [DirectVerifyKey] {
            [DirectVerifyKey(
                kid: sigKid,
                publicKey: sigKey.publicKey.rawRepresentation)]
        }
    }

    private func makeFixture() -> Fixture {
        return Fixture(
            sdkEpk: Curve25519.KeyAgreement.PrivateKey(),
            sigKey: Curve25519.Signing.PrivateKey(),
            sigKid: "sig-test-1")
    }

    /// Build + sign an inner FRON response JWS the way Bifrost's
    /// `sendDirectJweResponse` would. Then JWE-seal to the SDK's epk
    /// using the FRON envelope shape.
    private func sealForSdk(
        payload: [String: Any],
        fixture: Fixture,
        projectId: String = "proj_test",
        requestId: String = "req-1",
        overrideOuterTyp: String? = nil,
        overrideOuterLcsV: Any? = nil,
        overrideOuterRoutePath: String? = nil,
        overrideOuterRequestId: String? = nil,
        signerOverride: Curve25519.Signing.PrivateKey? = nil,
        skipInnerSignature: Bool = false,
        innerTyp: String = DirectWireConstants.serverJwsTyp
    ) throws -> String {
        return try sealForSdkWithClaims(
            extraClaims: [:],
            payload: payload,
            fixture: fixture,
            projectId: projectId,
            requestId: requestId,
            overrideOuterTyp: overrideOuterTyp,
            overrideOuterLcsV: overrideOuterLcsV,
            overrideOuterRoutePath: overrideOuterRoutePath,
            overrideOuterRequestId: overrideOuterRequestId,
            signerOverride: signerOverride,
            skipInnerSignature: skipInnerSignature,
            innerTyp: innerTyp)
    }

    /// Lower-level helper — also lets the caller stamp arbitrary EXTRA
    /// claims at the top of the inner JWS (e.g. a top-level `error`
    /// claim, which is the canonical W6 fix-pass-2 sealed-error wire).
    /// When `payload` is nil the wrapper key is omitted entirely (the
    /// fixture's sealed-error sample has no payload claim).
    private func sealForSdkWithClaims(
        extraClaims: [String: Any],
        payload: [String: Any]?,
        fixture: Fixture,
        projectId: String = "proj_test",
        requestId: String = "req-1",
        overrideOuterTyp: String? = nil,
        overrideOuterLcsV: Any? = nil,
        overrideOuterRoutePath: String? = nil,
        overrideOuterRequestId: String? = nil,
        signerOverride: Curve25519.Signing.PrivateKey? = nil,
        skipInnerSignature: Bool = false,
        innerTyp: String = DirectWireConstants.serverJwsTyp
    ) throws -> String {
        // 1. Inner JWS.
        let nowSec = Int(Date().timeIntervalSince1970)
        var claims: [String: Any] = [
            "iss": "test-bifrost",
            "iat": nowSec,
            "nbf": nowSec,
            "exp": nowSec + 60,
            "aud": projectId,
            "jti": requestId,
        ]
        if let p = payload { claims["payload"] = p }
        for (k, v) in extraClaims { claims[k] = v }
        let header: [String: Any] = [
            "alg": "EdDSA",
            "typ": innerTyp,
            "kid": fixture.sigKid,
        ]
        let headerJson = try JSONSerialization.data(
            withJSONObject: header, options: [.sortedKeys])
        let claimsJson = try JSONSerialization.data(
            withJSONObject: claims, options: [.sortedKeys])
        let headerB64 = headerJson.base64URLEncodedString()
        let claimsB64 = claimsJson.base64URLEncodedString()
        let signingInput = "\(headerB64).\(claimsB64)".data(using: .ascii)!
        let sigB64: String
        if skipInnerSignature {
            sigB64 = "AAAA"
        } else {
            let signer = signerOverride ?? fixture.sigKey
            let sig = try signer.signature(for: signingInput)
            sigB64 = sig.base64URLEncodedString()
        }
        let innerJws = "\(headerB64).\(claimsB64).\(sigB64)"

        // 2. Outer JWE — manually build to permit overriding the typ /
        //    lcs_v / route_path / request_id for negative tests.
        let epk = Curve25519.KeyAgreement.PrivateKey()
        let epkPubBytes = epk.publicKey.rawRepresentation
        let apu = pubKeyThumbprint(epkPubBytes)
        let apv = "sdk-epk"
        var outerHeader: [String: Any] = [
            "alg": "ECDH-ES",
            "enc": "A256GCM",
            "kid": "sdk-epk",
            "epk": [
                "kty": "OKP",
                "crv": "X25519",
                "x": epkPubBytes.base64URLEncodedString(),
            ],
            "apu": apu,
            "apv": apv,
            "cty": "JWT",
        ]
        if let t = overrideOuterTyp {
            if !t.isEmpty { outerHeader["typ"] = t }
        } else {
            outerHeader["typ"] = DirectWireConstants.jweTyp
        }
        if let l = overrideOuterLcsV {
            outerHeader["lcs_v"] = l
        } else {
            outerHeader["lcs_v"] = DirectWireConstants.lcsVersion
        }
        if let rp = overrideOuterRoutePath {
            outerHeader["route_path"] = rp
        }
        if let rid = overrideOuterRequestId {
            outerHeader["request_id"] = rid
        }
        let outerHeaderBytes = try JSONSerialization.data(
            withJSONObject: outerHeader, options: [.sortedKeys])
        let outerHeaderB64 = outerHeaderBytes.base64URLEncodedString()

        // CEK derivation — same ConcatKDF as the SDK side.
        let shared = try epk.sharedSecretFromKeyAgreement(
            with: fixture.sdkEpk.publicKey)
        let z = shared.withUnsafeBytes { Data($0) }
        let algId = Array("A256GCM".utf8)
        let apuB = Array(apu.utf8)
        let apvB = Array(apv.utf8)
        func u32be(_ v: Int) -> Data {
            var d = Data(count: 4)
            let u = UInt32(v).bigEndian
            withUnsafeBytes(of: u) { ptr in
                d.replaceSubrange(0..<4, with: ptr)
            }
            return d
        }
        var otherInfo = Data()
        otherInfo.append(u32be(algId.count))
        otherInfo.append(contentsOf: algId)
        otherInfo.append(u32be(apuB.count))
        otherInfo.append(contentsOf: apuB)
        otherInfo.append(u32be(apvB.count))
        otherInfo.append(contentsOf: apvB)
        otherInfo.append(u32be(256))
        var hashInput = Data()
        hashInput.append(u32be(1))
        hashInput.append(z)
        hashInput.append(otherInfo)
        let cekBytes = Data(SHA256.hash(data: hashInput))
        let cek = SymmetricKey(data: cekBytes)

        let aad = outerHeaderB64.data(using: .ascii)!
        let sealed = try AES.GCM.seal(
            Data(innerJws.utf8), using: cek, authenticating: aad)
        let nonceBytes = sealed.nonce.withUnsafeBytes { Data($0) }

        return [
            outerHeaderB64,
            "",
            nonceBytes.base64URLEncodedString(),
            sealed.ciphertext.base64URLEncodedString(),
            sealed.tag.base64URLEncodedString(),
        ].joined(separator: ".")
    }

    // ── Happy path ────────────────────────────────────────────────────

    func testParseAndVerifyRoundTrip() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["device_id": "dev-r1", "feature_list": ["a", "b"]],
            fixture: fx,
            projectId: "proj_test",
            requestId: "req-42")
        let parsed = try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-42",
            expectedRoutePath: "/direct/v1/activate",
            expectedProjectId: "proj_test")
        XCTAssertEqual(parsed.json["device_id"] as? String, "dev-r1")
        XCTAssertEqual(parsed.signingKid, fx.sigKid)
    }

    // ── S-1a — outer envelope typ + lcs_v pins ────────────────────────

    func testRejectsResponseMissingOuterTypPin() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            overrideOuterTyp: "")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-1",
            expectedRoutePath: "/direct/v1/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err),
                          "missing outer typ must surface as jwsInvalid")
        }
    }

    func testRejectsResponseWithWrongOuterTyp() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            overrideOuterTyp: "lcs+jwe") // L2 typ — must NOT pass FRON pin
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-1",
            expectedRoutePath: "/direct/v1/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err))
        }
    }

    func testRejectsResponseMissingLcsVersion() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            overrideOuterLcsV: NSNull())
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-1",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err))
        }
    }

    func testRejectsResponseWithWrongLcsVersion() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            overrideOuterLcsV: 1)
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-1",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err))
        }
    }

    // ── S-1b — request_id correlation pin ─────────────────────────────

    func testRejectsResponseWithMismatchedRequestId() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        // Server signs response with request_id = "wrong-req" but the
        // SDK expected "req-42".
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            requestId: "wrong-req")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-42",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err),
                          "request_id mismatch must reject")
        }
    }

    func testRejectsResponseWithMismatchedOuterRequestIdEvenIfInnerMatches() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            requestId: "req-42",
            overrideOuterRequestId: "attacker-req")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-42",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err),
                          "outer-header request_id mismatch must reject")
        }
    }

    // ── S-1d — inner JWS signature verification ───────────────────────

    func testRejectsResponseWithUnsignedInnerJws() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            skipInnerSignature: true)
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-1",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err),
                          "unsigned/forged inner JWS must reject")
        }
    }

    func testRejectsResponseSignedByWrongKey() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let rogueSigner = Curve25519.Signing.PrivateKey()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            signerOverride: rogueSigner)
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-1",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err),
                          "wrong-key inner JWS must reject")
        }
    }

    func testRejectsResponseWhenKidNotInJwks() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx)
        // Empty verify-key set — the response's kid will not resolve.
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: [],
            expectedRequestId: "req-1",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err))
        }
    }

    func testRejectsResponseWithWrongInnerTyp() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        // Use a request-side typ — must NOT pass the server-typ pin.
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            innerTyp: "bifrost-direct+ephemeral+jws")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-1",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err),
                          "cross-typed inner JWS must reject")
        }
    }

    // ── S-1c — route_path pin (when emitted on outer header) ──────────

    func testRejectsResponseWithMismatchedRoutePath() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            overrideOuterRoutePath: "/direct/v1/heartbeat")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-1",
            expectedRoutePath: "/direct/v1/activate",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err),
                          "wrong-route response must reject")
        }
    }

    func testAcceptsResponseWithMatchingRoutePath() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            overrideOuterRoutePath: "/direct/v1/activate")
        XCTAssertNoThrow(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-1",
            expectedRoutePath: "/direct/v1/activate",
            expectedProjectId: "proj_test"))
    }

    // ── aud / project-id correlation pin ──────────────────────────────

    func testRejectsResponseWithWrongProjectAud() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["ok": true],
            fixture: fx,
            projectId: "wrong-proj")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-1",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err),
                          "aud / project_id mismatch must reject")
        }
    }

    // ── S-Fix 1 (W6 fix-pass-2) — sealed-error envelope: Dict shape ──
    //
    // The W6 fix-pass-2 pins the canonical wire shape: `claims.error` is
    // a Dictionary `{ code, reason?, provider?, retry_after_ms? }` (per
    // `bifrost/.../_license-helpers.ts` `DirectSealedErrorPayload`).
    // The pre-W6 SDK read `body["error"]` as a String, which (a) failed
    // to plumb the structured `reason` / `provider` / `retry_after_ms`
    // fields and (b) was the spoofable wire that fix-pass-2 closes.
    //
    // These regressions cover:
    //   * Dict-shaped error at the top of `claims` → mapped to typed
    //     DirectError with `reason` + `provider` plumbed.
    //   * String-shaped `error` claim is REJECTED with .jwsInvalid
    //     (regression on the pre-W6 spoofable wire).
    //   * Back-compat: Dict under `claims.payload.error` (where Bifrost
    //     currently emits it) is also honoured until the server-side
    //     migration converges.

    /// Canonical wire: `claims.error = { code, reason }`. Parser must
    /// surface .licenseInvalid with the structured reason.
    func testSealedErrorEnvelopeMapsToTypedError() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdkWithClaims(
            extraClaims: [
                "error": [
                    "code": "DIRECT_LICENSE_INVALID",
                    "reason": "bad key",
                ],
            ],
            payload: nil,
            fixture: fx,
            requestId: "req-err-1")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-err-1",
            expectedRoutePath: "/direct/v1/verify",
            expectedProjectId: "proj_test")) { err in
            guard case DirectError.licenseInvalid(let reason) = err else {
                XCTFail("expected .licenseInvalid, got \(err)")
                return
            }
            XCTAssertEqual(reason, "bad key",
                           "structured reason must round-trip from " +
                           "claims.error.reason into the typed case")
        }
    }

    /// `claims.error.provider` must reach
    /// DirectError.paymentProviderFailed.provider.
    func testSealedErrorEnvelopeProviderTagPlumbed() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdkWithClaims(
            extraClaims: [
                "error": [
                    "code": "DIRECT_PAYMENT_PROVIDER_FAILED",
                    "provider": "stripe",
                ],
            ],
            payload: nil,
            fixture: fx,
            requestId: "req-err-2")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-err-2",
            expectedRoutePath: "/direct/v1/payment/checkout",
            expectedProjectId: "proj_test")) { err in
            guard case DirectError.paymentProviderFailed(let p) = err else {
                XCTFail("expected .paymentProviderFailed, got \(err)")
                return
            }
            XCTAssertEqual(p, "stripe",
                           "provider tag must be plumbed from " +
                           "claims.error.provider")
        }
    }

    /// `claims.error.retry_after_ms` must reach
    /// DirectError.rateLimited.retryAfterMs.
    func testSealedErrorEnvelopeRateLimitRetryAfterPlumbed() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdkWithClaims(
            extraClaims: [
                "error": [
                    "code": "DIRECT_RATE_LIMIT",
                    "retry_after_ms": 5000,
                ],
            ],
            payload: nil,
            fixture: fx,
            requestId: "req-err-3")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-err-3",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            guard case DirectError.rateLimited(let ms) = err else {
                XCTFail("expected .rateLimited, got \(err)")
                return
            }
            XCTAssertEqual(ms, 5000,
                           "retry_after_ms must round-trip into the " +
                           "typed case so the SDK paces correctly")
        }
    }

    /// `claims.error.reason` plumbs into .deviceRevoked.
    func testSealedErrorEnvelopeSurfacesOverEvenValidEnvelopePins() throws {
        // The sealed-error path runs AFTER outer typ / lcs_v / route /
        // request_id / aud / signature pins all pass. So a forged
        // outer envelope still rejects with .jwsInvalid; only a
        // genuinely-sealed error envelope surfaces the typed code.
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdkWithClaims(
            extraClaims: [
                "error": [
                    "code": "DIRECT_DEVICE_REVOKED",
                    "reason": "key_rotation",
                ],
            ],
            payload: nil,
            fixture: fx,
            requestId: "req-err-4")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-err-4",
            expectedRoutePath: "/direct/v1/heartbeat",
            expectedProjectId: "proj_test")) { err in
            guard case DirectError.deviceRevoked(let r) = err else {
                XCTFail("expected .deviceRevoked, got \(err)")
                return
            }
            XCTAssertEqual(r, "key_rotation")
        }
    }

    /// IAP narrow-reason taxonomy round-trips through
    /// `claims.error.reason` (matches the parity fixture's
    /// `DIRECT_IAP_RECEIPT_INVALID_expired` sample).
    func testSealedErrorEnvelopeIapReceiptReasonPlumbed() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdkWithClaims(
            extraClaims: [
                "error": [
                    "code": "DIRECT_IAP_RECEIPT_INVALID",
                    "reason": "expired",
                ],
            ],
            payload: nil,
            fixture: fx,
            requestId: "req-err-iap")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-err-iap",
            expectedRoutePath: "/direct/v1/payment/iap-verify",
            expectedProjectId: "proj_test")) { err in
            guard case DirectError.iapReceiptInvalid(let r) = err else {
                XCTFail("expected .iapReceiptInvalid, got \(err)")
                return
            }
            XCTAssertEqual(r, "expired",
                           "IAP narrow reason taxonomy must round-trip " +
                           "from claims.error.reason")
        }
    }

    /// REGRESSION: a String-shaped error claim is the pre-W6 spoofable
    /// wire that fix-pass-2 closes. The parser MUST reject it as
    /// .jwsInvalid rather than silently mapping or treating as success.
    func testStringErrorClaimIsRejected() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdkWithClaims(
            extraClaims: [
                "error": "DIRECT_LICENSE_INVALID",
            ],
            payload: nil,
            fixture: fx,
            requestId: "req-str-1")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-str-1",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err),
                          "String-shape `error` claim is the pre-W6 " +
                          "spoofable wire — MUST be rejected as " +
                          ".jwsInvalid, never mapped or treated as ok. " +
                          "Got: \(err)")
        }
    }

    /// REGRESSION: sealed-error envelope with a missing `code` field is
    /// malformed and MUST be rejected, never fall through to the
    /// success-path body extraction.
    func testSealedErrorWithoutCodeIsRejected() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdkWithClaims(
            extraClaims: [
                "error": [
                    "reason": "no code field",
                ],
            ],
            payload: nil,
            fixture: fx,
            requestId: "req-nocode-1")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-nocode-1",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            XCTAssertTrue(self.isJwsInvalid(err),
                          "sealed-error envelope missing `code` must " +
                          "refuse, not quietly treat as success")
        }
    }

    /// S-Fix 2 — payload unwrap. Success body lives under
    /// `claims.payload` (not flat at the top). Verifies the parser
    /// correctly surfaces the wrapped payload as `parsed.json`.
    func testSuccessBodyUnwrappedFromPayloadClaim() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: [
                "device_id": "dev-unwrap-1",
                "feature_list": ["alpha", "beta"],
                "nested": ["k": "v"],
            ],
            fixture: fx,
            projectId: "proj_test",
            requestId: "req-unwrap-1")
        let parsed = try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-unwrap-1",
            expectedRoutePath: "/direct/v1/activate",
            expectedProjectId: "proj_test")
        XCTAssertEqual(parsed.json["device_id"] as? String, "dev-unwrap-1",
                       "payload unwrap must surface inner fields directly")
        XCTAssertEqual(parsed.json["feature_list"] as? [String],
                       ["alpha", "beta"])
        // Reserved JWS-claim namespace MUST NOT leak into the parsed
        // success body (they live in the wrapping claim envelope, not
        // the handler payload).
        XCTAssertNil(parsed.json["iat"],
                     "reserved claim `iat` must not leak into success body")
        XCTAssertNil(parsed.json["aud"],
                     "reserved claim `aud` must not leak into success body")
        XCTAssertNil(parsed.json["jti"],
                     "reserved claim `jti` must not leak into success body")
        XCTAssertNil(parsed.json["payload"],
                     "wrapper key `payload` must not leak into success body")
    }

    /// Back-compat: server CURRENTLY nests `error` under `payload.error`
    /// (the canonical fixture pins top-level but the server-side
    /// migration is tracked separately). The parser must honour both
    /// placements so the SDK works through the migration window.
    func testSealedErrorUnderPayloadStillMaps() throws {
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: [
                "error": [
                    "code": "DIRECT_PROJECT_DISABLED",
                ],
            ],
            fixture: fx,
            requestId: "req-payload-err")
        XCTAssertThrowsError(try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-payload-err",
            expectedRoutePath: "/x",
            expectedProjectId: "proj_test")) { err in
            guard case DirectError.projectDisabled = err else {
                XCTFail("expected .projectDisabled, got \(err)")
                return
            }
        }
    }

    func testSuccessEnvelopeWithoutErrorClaimStillReturnsPayload() throws {
        // Make sure the sealed-error branch DOESN'T fire when the
        // payload has no `error` claim — the success path must still
        // round-trip the payload through.
        let fx = makeFixture()
        let parser = DirectResponseParser()
        let sealed = try sealForSdk(
            payload: ["session_id": "cs_x", "hosted_url": "https://x.test/"],
            fixture: fx,
            requestId: "req-ok-1")
        let parsed = try parser.parseAndVerify(
            compactJwe: sealed,
            requestKey: fx.sdkEpk,
            verifyKeys: fx.verifyKeys,
            expectedRequestId: "req-ok-1",
            expectedRoutePath: "/direct/v1/payment/checkout",
            expectedProjectId: "proj_test")
        XCTAssertEqual(parsed.json["session_id"] as? String, "cs_x")
    }

    // ── Existing legacy parser surface (back-compat smoke) ────────────

    func testParseJsonErrorRoundTrip() throws {
        let parser = DirectResponseParser()
        let body: [String: Any] = [
            "error": "DIRECT_LICENSE_INVALID",
            "message": "bad key",
            "retry_after_ms": 1234,
        ]
        let data = try JSONSerialization.data(withJSONObject: body)
        let parsed = try parser.parseJsonError(data: data)
        XCTAssertEqual(parsed["error"] as? String, "DIRECT_LICENSE_INVALID")
        XCTAssertEqual(parsed["message"] as? String, "bad key")
        XCTAssertEqual(parsed["retry_after_ms"] as? Int, 1234)
    }

    func testParseJsonErrorFailsOnNonJson() {
        let parser = DirectResponseParser()
        let data = Data("not json".utf8)
        XCTAssertThrowsError(try parser.parseJsonError(data: data)) { err in
            if case DirectError.network = err {
                // expected
            } else {
                XCTFail("expected DirectError.network, got \(err)")
            }
        }
    }

    func testParseJsonErrorFailsOnJsonArray() throws {
        let parser = DirectResponseParser()
        let data = try JSONSerialization.data(withJSONObject: ["a", "b"])
        XCTAssertThrowsError(try parser.parseJsonError(data: data)) { err in
            if case DirectError.network = err {
                // expected
            } else {
                XCTFail("expected DirectError.network, got \(err)")
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private func isJwsInvalid(_ err: Error) -> Bool {
        if case DirectError.jwsInvalid = err { return true }
        return false
    }
}
