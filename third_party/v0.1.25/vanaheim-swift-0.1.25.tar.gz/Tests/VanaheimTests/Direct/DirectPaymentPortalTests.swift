// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// W6 / B-FRON.5.3 — `DirectClient.openPortal(...)` end-to-end tests.
/// The portal endpoint mints a provider-side customer-portal session so
/// the user can manage payment methods + cancel/pause their subscription.
final class DirectPaymentPortalTests: XCTestCase {

    private var keychainSvc: String!
    private var server: FakeBifrostDirectServer!
    private var session: URLSession!

    override func setUp() async throws {
        try await super.setUp()
        MockDirectURLProtocol.reset()
        keychainSvc = "io.vanaheim.sdk.direct.test.\(UUID().uuidString)"
        server = FakeBifrostDirectServer()
        server.installJwks()
        session = mockDirectSession()
    }

    override func tearDown() async throws {
        MockDirectURLProtocol.reset()
        try await super.tearDown()
    }

    private func makeClient() throws -> DirectClient {
        let cfg = makeTestDirectConfig(baseURL: server.baseURL)
        let resolver = try DirectRecipientResolver(
            bifrostBaseUrl: server.baseURL,
            session: session,
            ttl: 60,
            timeout: 5)
        let store = DirectKeypairStore(service: keychainSvc)
        return try DirectClient(
            config: cfg,
            recipientResolver: resolver,
            keypairStore: store,
            secureCache: InMemorySecureCache(),
            httpSession: session)
    }

    private func registerOnce(client: DirectClient) async throws {
        server.installRoute(path: "/direct/v1/register") { _, _ in
            return [
                "device_id": "dev-portal",
                "entitlement_jws": "h.p.s",
                "server_nonce": "n",
                "feature_list": ["base"],
                "quotas": [:],
                "heartbeat_cadence_ms": 60_000,
            ]
        }
        _ = try await client.register(
            licenseKey: "LCS", fingerprint: "fp", appMeta: [:])
    }

    // MARK: - Happy path

    func testOpenPortalRoundTrip() async throws {
        server.installRoute(path: "/direct/v1/payment/portal") { claims, _ in
            XCTAssertEqual(claims["aud"] as? String, "direct:payment.portal")
            let body = claims["body"] as? [String: Any]
            XCTAssertEqual(body?["return_url"] as? String,
                           "https://app.example.com/manage")
            XCTAssertEqual(body?["project_id"] as? String, "proj_test")
            return [
                "portal_url": "https://billing.stripe.com/p/session/test_abc",
                "expires_at_ms": 1_700_000_900_000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.openPortal(
            returnUrl: URL(string: "https://app.example.com/manage")!)
        XCTAssertEqual(r.portalUrl.absoluteString,
                       "https://billing.stripe.com/p/session/test_abc")
        XCTAssertEqual(r.expiresAtMs, 1_700_000_900_000)
        await client.dispose()
    }

    // MARK: - Pre-wire validation

    func testOpenPortalRejectsNonHttpsReturnUrl() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.openPortal(
                returnUrl: URL(string: "http://app.example.com/manage")!)
            XCTFail("expected .badRequest")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "return_url_not_https")
        }
        await client.dispose()
    }

    func testOpenPortalRejectsOversizedReturnUrl() async throws {
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let pad = String(repeating: "x", count: 2049)
        do {
            _ = try await client.openPortal(
                returnUrl: URL(string: "https://x.test/\(pad)")!)
            XCTFail("expected .badRequest")
        } catch DirectError.badRequest(let r) {
            XCTAssertEqual(r, "return_url_too_long")
        }
        await client.dispose()
    }

    // MARK: - Connection gating

    func testOpenPortalBeforeConnectThrows() async throws {
        let client = try makeClient()
        do {
            _ = try await client.openPortal(
                returnUrl: URL(string: "https://x.test/")!)
            XCTFail("expected .notConnected")
        } catch DirectError.notConnected {
            // expected
        }
    }

    // MARK: - Server error taxonomy

    func testOpenPortalMapsNoActiveSubscription() async throws {
        server.installRoute(
            path: "/direct/v1/payment/portal",
            statusCode: 409
        ) { _, _ in
            return ["error": "DIRECT_NO_ACTIVE_SUBSCRIPTION"]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.openPortal(
                returnUrl: URL(string: "https://x.test/")!)
            XCTFail("expected .noActiveSubscription")
        } catch DirectError.noActiveSubscription {
            // expected
        }
        await client.dispose()
    }

    func testOpenPortalMapsProviderFailed() async throws {
        server.installRoute(
            path: "/direct/v1/payment/portal",
            statusCode: 502
        ) { _, _ in
            return [
                "error": "DIRECT_PAYMENT_PROVIDER_FAILED",
                "message": "stripe",
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.openPortal(
                returnUrl: URL(string: "https://x.test/")!)
            XCTFail("expected .paymentProviderFailed")
        } catch DirectError.paymentProviderFailed(let p) {
            XCTAssertEqual(p, "stripe")
        }
        await client.dispose()
    }

    func testOpenPortalMissingFieldsSurfacesAsNetwork() async throws {
        server.installRoute(path: "/direct/v1/payment/portal") { _, _ in
            return [:] // empty payload
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.openPortal(
                returnUrl: URL(string: "https://x.test/")!)
            XCTFail("expected .network")
        } catch DirectError.network {
            // expected
        }
        await client.dispose()
    }
}
