// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import XCTest
@testable import Vanaheim

/// W6 / B-FRON.5.4 — `DirectClient.restorePurchases(...)` end-to-end
/// tests. Restore re-binds purchases tied to (project, device); the
/// server guarantees that `restored_count > 0 -> entitlement_jws != nil`
/// (the SDK mirrors that invariant client-side as defense-in-depth).
final class DirectPaymentRestoreTests: XCTestCase {

    private var keychainSvc: String!
    private var server: FakeBifrostDirectServer!
    private var session: URLSession!

    override func setUp() async throws {
        try await super.setUp()
        MockDirectURLProtocol.reset()
        keychainSvc = "io.vanaheim.sdk.direct.test.\(UUID().uuidString)"
        server = FakeBifrostDirectServer()
        server.installJwks()
        session = mockDirectSession()
    }

    override func tearDown() async throws {
        MockDirectURLProtocol.reset()
        try await super.tearDown()
    }

    private func makeClient() throws -> DirectClient {
        let cfg = makeTestDirectConfig(baseURL: server.baseURL)
        let resolver = try DirectRecipientResolver(
            bifrostBaseUrl: server.baseURL,
            session: session,
            ttl: 60,
            timeout: 5)
        let store = DirectKeypairStore(service: keychainSvc)
        return try DirectClient(
            config: cfg,
            recipientResolver: resolver,
            keypairStore: store,
            secureCache: InMemorySecureCache(),
            httpSession: session)
    }

    private func registerOnce(client: DirectClient) async throws {
        server.installRoute(path: "/direct/v1/register") { _, _ in
            return [
                "device_id": "dev-restore",
                "entitlement_jws": "h.p.s",
                "server_nonce": "n",
                "feature_list": ["base"],
                "quotas": [:],
                "heartbeat_cadence_ms": 60_000,
            ]
        }
        _ = try await client.register(
            licenseKey: "LCS", fingerprint: "fp", appMeta: [:])
    }

    // MARK: - Happy path

    func testRestorePurchasesRoundTrip() async throws {
        server.installRoute(path: "/direct/v1/payment/restore") { claims, _ in
            XCTAssertEqual(claims["aud"] as? String, "direct:payment.restore")
            let body = claims["body"] as? [String: Any]
            XCTAssertEqual(body?["platform"] as? String, "ios")
            return [
                "restored": [
                    [
                        "license_key": "LCS-A",
                        "tier": "pro",
                        "valid_until": 1_700_500_000_000,
                    ],
                    [
                        "license_key": "LCS-B",
                        "tier": "team",
                        "valid_until": 1_700_900_000_000,
                    ],
                ],
                "entitlement_jws": "ent.h.p.s",
                "restored_count": 2,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.restorePurchases(platform: .ios)
        XCTAssertEqual(r.restoredCount, 2)
        XCTAssertEqual(r.entitlementJws, "ent.h.p.s")
        XCTAssertEqual(r.restored.count, 2)
        XCTAssertEqual(r.restored[0].licenseKey, "LCS-A")
        XCTAssertEqual(r.restored[0].tier, "pro")
        XCTAssertEqual(r.restored[0].validUntil, 1_700_500_000_000)
        XCTAssertEqual(r.restored[1].licenseKey, "LCS-B")
        await client.dispose()
    }

    func testRestorePurchasesEmpty() async throws {
        server.installRoute(path: "/direct/v1/payment/restore") { _, _ in
            return [
                "restored": [[String: Any]](),
                "restored_count": 0,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.restorePurchases(platform: .android)
        XCTAssertEqual(r.restoredCount, 0)
        XCTAssertTrue(r.restored.isEmpty)
        XCTAssertNil(r.entitlementJws)
        await client.dispose()
    }

    func testRestorePurchasesAndroidPlatformWired() async throws {
        var sawPlatform: String?
        server.installRoute(path: "/direct/v1/payment/restore") { claims, _ in
            let body = claims["body"] as? [String: Any]
            sawPlatform = body?["platform"] as? String
            return ["restored": [[String: Any]](), "restored_count": 0]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        _ = try await client.restorePurchases(platform: .android)
        XCTAssertEqual(sawPlatform, "android")
        await client.dispose()
    }

    func testRestoreDerivesCountFromArrayWhenAbsent() async throws {
        server.installRoute(path: "/direct/v1/payment/restore") { _, _ in
            return [
                "restored": [
                    [
                        "license_key": "LCS-A",
                        "tier": "pro",
                        "valid_until": 1,
                    ],
                ],
                "entitlement_jws": "ent.h.p.s",
                // restored_count omitted on purpose
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        let r = try await client.restorePurchases(platform: .ios)
        XCTAssertEqual(r.restoredCount, 1,
                       "count should fall back to array length")
        await client.dispose()
    }

    // MARK: - Invariant enforcement

    func testRestoreInvariantViolationSurfacesAsNetwork() async throws {
        // count > 0 but no JWS — must hard-fail rather than admit the
        // contradictory shape.
        server.installRoute(path: "/direct/v1/payment/restore") { _, _ in
            return [
                "restored": [
                    [
                        "license_key": "LCS-A",
                        "tier": "pro",
                        "valid_until": 1,
                    ],
                ],
                "restored_count": 1,
                // no entitlement_jws
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.restorePurchases(platform: .ios)
            XCTFail("expected .network for invariant violation")
        } catch DirectError.network {
            // expected
        }
        await client.dispose()
    }

    func testRestoreOversizedListSurfacesAsNetwork() async throws {
        // Server should never ship >1000 rows; if it does, the SDK
        // must reject before allocating the snapshot.
        var rows: [[String: Any]] = []
        for i in 0..<1001 {
            rows.append([
                "license_key": "LCS-\(i)",
                "tier": "pro",
                "valid_until": 1,
            ])
        }
        server.installRoute(path: "/direct/v1/payment/restore") { _, _ in
            return [
                "restored": rows,
                "entitlement_jws": "ent",
                "restored_count": rows.count,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.restorePurchases(platform: .ios)
            XCTFail("expected .network for oversized restore")
        } catch DirectError.network {
            // expected
        }
        await client.dispose()
    }

    func testRestoreRowMissingFieldsSurfacesAsNetwork() async throws {
        server.installRoute(path: "/direct/v1/payment/restore") { _, _ in
            return [
                "restored": [
                    // missing `tier`
                    [
                        "license_key": "LCS-A",
                        "valid_until": 1,
                    ],
                ],
                "entitlement_jws": "ent",
                "restored_count": 1,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.restorePurchases(platform: .ios)
            XCTFail("expected .network for missing row fields")
        } catch DirectError.network {
            // expected
        }
        await client.dispose()
    }

    // MARK: - Connection gating

    func testRestoreBeforeConnectThrows() async throws {
        let client = try makeClient()
        do {
            _ = try await client.restorePurchases(platform: .ios)
            XCTFail("expected .notConnected")
        } catch DirectError.notConnected {
            // expected
        }
    }

    // MARK: - Server error taxonomy

    func testRestoreMapsRateLimited() async throws {
        server.installRoute(
            path: "/direct/v1/payment/restore",
            statusCode: 429
        ) { _, _ in
            return [
                "error": "DIRECT_RATE_LIMIT",
                "retry_after_ms": 2000,
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.restorePurchases(platform: .ios)
            XCTFail("expected .rateLimited")
        } catch DirectError.rateLimited(let ms) {
            XCTAssertEqual(ms, 2000)
        }
        await client.dispose()
    }

    func testRestoreMapsProviderFailed() async throws {
        server.installRoute(
            path: "/direct/v1/payment/restore",
            statusCode: 502
        ) { _, _ in
            return [
                "error": "DIRECT_PAYMENT_PROVIDER_FAILED",
                "message": "restore",
            ]
        }
        let client = try makeClient()
        try await client.connect()
        try await registerOnce(client: client)
        do {
            _ = try await client.restorePurchases(platform: .android)
            XCTFail("expected .paymentProviderFailed")
        } catch DirectError.paymentProviderFailed(let p) {
            XCTAssertEqual(p, "restore")
        }
        await client.dispose()
    }
}
