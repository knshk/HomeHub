// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import CryptoKit
import XCTest
@testable import Vanaheim

/// Locks the day-1 SDK contract for §2A.1 / §2A.6 / §2A.10 / §2A.12:
///
///   * cfg + cfg_v parsed; missing → safe defaults
///   * roles parsed as [String]; non-string elements filtered
///   * org_id + org_role parsed; empty → nil
///   * prefs_v + locale parsed; missing → safe defaults
///   * unknown / wrong-typed claims silently ignored (forward-compat)
///
/// Swift parity for sdk/dart/license_store_sdk/test/runtime_config_test.dart.
final class RuntimeConfigClaimsTests: XCTestCase {

    var keys: Curve25519.Signing.PrivateKey!
    var pub: Data!

    override func setUp() {
        super.setUp()
        keys = Curve25519.Signing.PrivateKey()
        pub = keys.publicKey.rawRepresentation
    }

    private func baseClaims(exp: Date = Date().addingTimeInterval(3600)) -> [String: Any] {
        [
            "iss": "licenses.example.com",
            "sub": "lic_x",
            "aud": "zenkit",
            "acc": "acc_x",
            "tier": "pro",
            "ent": ["export": true],
            "ev": 1,
            "iat": Int(Date().timeIntervalSince1970),
            "nbf": Int(Date().timeIntervalSince1970) - 60,
            "exp": Int(exp.timeIntervalSince1970),
        ]
    }

    private func makeJwt(_ claims: [String: Any]) throws -> String {
        let headerData = try JSONSerialization.data(
            withJSONObject: ["alg": "EdDSA", "typ": "JWT", "kid": "test-kid"])
        let claimsData = try JSONSerialization.data(withJSONObject: claims)
        let headerB64 = b64u(headerData)
        let claimsB64 = b64u(claimsData)
        let signingInput = "\(headerB64).\(claimsB64)".data(using: .utf8)!
        let sig = try keys.signature(for: signingInput)
        return "\(headerB64).\(claimsB64).\(b64u(sig))"
    }

    private func b64u(_ data: Data) -> String {
        data.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    private func decode(_ jwt: String) throws -> LicenseJwtClaims {
        try JwtVerifier.verifyAndDecode(
            jwt: jwt,
            publicKey: pub,
            expectedIssuer: "licenses.example.com",
            expectedAudience: "zenkit")
    }

    // MARK: - 2A.1 runtime config

    func testParsesCfgAndVersion() throws {
        var claims = baseClaims()
        claims["cfg"] = [
            "feature.support.tickets.enabled": true,
            "max_devices": 5,
            "region_kill_switch": false,
        ]
        claims["cfg_v"] = 12
        let out = try decode(try makeJwt(claims))
        XCTAssertEqual(out.configVersion, 12)
        XCTAssertEqual(out.config["feature.support.tickets.enabled"]?.value as? Bool, true)
        XCTAssertEqual(out.config["max_devices"]?.value as? Int, 5)
        XCTAssertEqual(out.config["region_kill_switch"]?.value as? Bool, false)
    }

    func testDefaultsCfgEmpty() throws {
        let out = try decode(try makeJwt(baseClaims()))
        XCTAssertTrue(out.config.isEmpty)
        XCTAssertEqual(out.configVersion, 0)
    }

    func testCfgWrongTypeFallsBackEmpty() throws {
        var claims = baseClaims()
        claims["cfg"] = "not-a-map"
        let out = try decode(try makeJwt(claims))
        XCTAssertTrue(out.config.isEmpty)
    }

    // MARK: - 2A.6 roles + org

    func testParsesRolesFiltersNonStrings() throws {
        var claims = baseClaims()
        claims["roles"] = ["customer", "partner", 42, "", "admin"] as [Any]
        let out = try decode(try makeJwt(claims))
        XCTAssertEqual(out.roles, ["customer", "partner", "admin"])
    }

    func testRolesDefaultsEmpty() throws {
        let out = try decode(try makeJwt(baseClaims()))
        XCTAssertTrue(out.roles.isEmpty)
    }

    func testRolesWrongTypeFallsBackEmpty() throws {
        var claims = baseClaims()
        claims["roles"] = "customer"
        let out = try decode(try makeJwt(claims))
        XCTAssertTrue(out.roles.isEmpty)
    }

    func testParsesOrgIdAndRole() throws {
        var claims = baseClaims()
        claims["org_id"] = "org_acme"
        claims["org_role"] = "admin"
        let out = try decode(try makeJwt(claims))
        XCTAssertEqual(out.orgId, "org_acme")
        XCTAssertEqual(out.orgRole, "admin")
    }

    func testOrgFieldsDefaultNil() throws {
        let out = try decode(try makeJwt(baseClaims()))
        XCTAssertNil(out.orgId)
        XCTAssertNil(out.orgRole)
    }

    func testEmptyStringOrgIdBecomesNil() throws {
        var claims = baseClaims()
        claims["org_id"] = ""
        let out = try decode(try makeJwt(claims))
        XCTAssertNil(out.orgId)
    }

    // MARK: - 2A.10 + 2A.12

    func testParsesPrefsVersionAndLocale() throws {
        var claims = baseClaims()
        claims["prefs_v"] = 4
        claims["locale"] = "en-IN"
        let out = try decode(try makeJwt(claims))
        XCTAssertEqual(out.preferencesVersion, 4)
        XCTAssertEqual(out.locale, "en-IN")
    }

    func testPrefsAndLocaleDefaultSafe() throws {
        let out = try decode(try makeJwt(baseClaims()))
        XCTAssertEqual(out.preferencesVersion, 0)
        XCTAssertNil(out.locale)
    }

    // MARK: - forward-compat

    func testUnknownClaimsSilentlyIgnored() throws {
        var claims = baseClaims()
        claims["some_future_claim"] = ["nested": [1, 2, 3]]
        claims["another_future"] = "whatever"
        let out = try decode(try makeJwt(claims))
        XCTAssertEqual(out.licenseId, "lic_x")
    }
}
