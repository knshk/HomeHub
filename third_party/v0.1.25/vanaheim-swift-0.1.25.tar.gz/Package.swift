// swift-tools-version:5.9
// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited
// Release: v0.1.25 — current release tag intent (SwiftPM versioning is driven by git tags; this comment tracks the intended tag for this commit).
// v0.1.25: ecosystem-alignment bump (SDK source unchanged since 0.1.19; version bumped to match Bifrost v0.1.25 release).
// v0.1.19: unified Bifrost/Alfheim/Vanaheim bump — adds `reportCapability(_:_:)` to LicenseClient (POST /v1/apps/capabilities, PAK-JWE per-project scope). Client-side key regex `^has_[a-z0-9_]{2,64}$` + 429 exponential backoff. Cross-language SDK parity with Dart + TS (see fron-parity-fixtures.json §apps).
// Vanaheim — official Swift SDK for License Store.
// Mirrors the public API of the Flutter `license_store_sdk` package so a
// product team's mental model is identical across both stacks.

import PackageDescription

let package = Package(
    name: "Vanaheim",
    platforms: [
        // iOS 15 / macOS 12 are the floors for async/await + CryptoKit
        // Curve25519 verify(_:for:) availability. Earlier targets need
        // an adapter or a different verification path; we don't support them.
        .iOS(.v15),
        .macOS(.v12),
        .macCatalyst(.v15),
        .tvOS(.v15),
        .watchOS(.v8),
    ],
    products: [
        .library(name: "Vanaheim", targets: ["Vanaheim"]),
    ],
    dependencies: [
        // Firebase is OPTIONAL — products that don't use Firebase Auth /
        // App Check can inject their own AuthTokenProvider /
        // AppCheckTokenProvider. We don't pull in Firebase here so the
        // package stays small; products add Firebase to their app target.
    ],
    targets: [
        .target(
            name: "Vanaheim",
            dependencies: [],
            path: "Sources/Vanaheim"
        ),
        .testTarget(
            name: "VanaheimTests",
            dependencies: ["Vanaheim"],
            path: "Tests/VanaheimTests"
        ),
    ]
)
