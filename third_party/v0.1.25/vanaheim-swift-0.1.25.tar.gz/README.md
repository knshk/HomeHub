# Vanaheim (Swift)

Official Swift SDK for the License Store backend. Mirrors the public API of the Flutter `license_store_sdk` package so a product team's mental model is identical across both stacks.

Supports iOS 15+, iPadOS 15+, macOS 12+, macCatalyst 15+, tvOS 15+, watchOS 8+.

## Install

```swift
// Package.swift
dependencies: [
    .package(url: "https://github.com/yourorg/license-store", from: "0.1.0")
],
targets: [
    .target(name: "MyApp", dependencies: [
        .product(name: "Vanaheim", package: "vanaheim"),
    ]),
]
```

## Onboarding — get your product credentials

Before integration, your product needs to be registered with License Store. While self-serve admin UI is post-MVP, the manual flow is:

1. **Open a ticket** with the platform team (Slack: `#license-store-onboarding`, email: `platform-team@<your-company>`) with:
   - Product name + URL-safe slug (e.g. `zenkit`, `bookworm`)
   - Tier ladder (e.g. `base`, `plus`, `pro`)
   - Per-tier entitlements (features + quotas)
   - Pricing and billing model
2. Platform team registers the product and provisions a per-product SDK secret.
3. You receive **two values**:
   - `LS_PRODUCT_SLUG` — passed to `LicenseClient.connect(productSlug:)`
   - `LS_SDK_SECRET` — keep in Keychain or build config (NOT Info.plist)
4. **Secret rotation:** email platform team. Old + new are valid in parallel for 30 days.

> The SDK secret is not the only line of defense — Firebase App Check is what actually proves "this is your real app on a non-rooted device." Both layers must be wired for production. See `LICENSE_FLOW.md` §4.

## Prerequisites

- Firebase project (Firebase Auth + App Check) configured for your bundle ID. Add the iOS SDKs via SwiftPM (`https://github.com/firebase/firebase-ios-sdk`).
- App Check provider per platform:
  - iOS / iPadOS / macCatalyst → App Attest (with DeviceCheck fallback)
  - macOS 14+ → App Attest
- A signed-in `FirebaseAuth.Auth.auth().currentUser` (SDK calls your provider closure on every request).

## Quick start

```swift
import FirebaseAuth
import FirebaseAppCheck
import Vanaheim

let auth = FirebaseAuthTokenProvider { force in
    guard let user = Auth.auth().currentUser else {
        throw AuthError("Firebase user not signed in")
    }
    return try await user.getIDToken(forcingRefresh: force)
}

let appCheck = FirebaseAppCheckTokenProvider { force in
    let token = try await AppCheck.appCheck().token(forcingRefresh: force)
    return token.token
}

let client = try await LicenseClient.connect(
    controlPlaneUrl: URL(string: "https://licenses.example.com")!,
    productSlug: "zenkit",
    sdkSecret: ProcessInfo.processInfo.environment["LS_SDK_SECRET"]!,
    auth: auth,
    appCheck: appCheck
)

let result = try await client.activate(deviceName: "iPhone 15 Pro")
if let kicked = result.kickedDevice {
    showSnackbar("Signed out on \(kicked.deviceName ?? "another device")")
}

if await client.hasFeature("export") {
    // unlock export
}
let seatLimit: Int? = await client.quota("max_seats")

// Observe state changes (tier change, session revoked, expired)
Task {
    for await change in client.stateChanges {
        switch change.kind {
        case .entitlementsUpdated:
            updateUi()
        case .sessionRevoked:
            lockUi("Used on another device")
        case .expired:
            showPaywall()
        default: break
        }
    }
}
```

## Typed errors

| Error | Trigger | UX |
|---|---|---|
| `SeatCapExceededError` | Hard-lock tier; cap is full | Prompt user to transfer or upgrade |
| `SessionRevokedError` | Floating tier; another device claimed the session | Lock UI; show "signed out elsewhere" |
| `TransferCooldownError` | Hard-lock; transfer attempted before cooldown | Surface `availableAt` |
| `LicenseExpiredError` | Cached JWT expired, refresh failed | Show paywall |
| `AppCheckFailedError` | Device failed Firebase App Check | Likely non-genuine; refuse |
| `NetworkError` | Transient network/server failure | Retry with backoff |
| `JwtVerificationError` | Server returned an invalid JWT | Treat as compromised; clear cache |
| `CertificatePinError` | TLS chain leaf SPKI mismatch (MITM) | Refuse the connection |

## What the SDK does for you

- **Online verify** — refreshes JWT periodically in background.
- **Offline verify** — every `hasFeature` / `quota` is signature-checked locally against pinned JWKS. No network on hot path.
- **Offline grace** — uses cached JWT until `exp`. Past exp = explicit `LicenseExpiredError`, never fail-open.
- **Floating-tier bump** — `activate()` reports `kickedDevice`; bumped device's verify raises `SessionRevokedError`.
- **Hard-lock transfer** — `transferToNewDevice()` with cooldown enforcement.
- **Entitlements staleness** — when server bumps `entitlements_version`, `entitlementsUpdated` fires on `stateChanges`.

## Diagnostics — recent errors

```swift
let bundle = await client.diagnostics(limit: 20)
// {generated_at, events: [{ts, severity, source, error_class, message, stack, context}, ...]}
// Attach to support tickets, copy to clipboard, etc.
```

Properties:

- Non-blocking, non-throwing capture.
- Bounded ring buffer (default 50), oldest drops first.
- Persisted to Keychain (not Info.plist, not UserDefaults).
- Survives sign-out (`client.deactivate()` does NOT wipe diagnostics).
- Call `client.clearDiagnostics()` to drop everything.
- **No secrets ever** — only typed-exception `String(describing:)` + stack.

## Certificate pinning

```swift
let cfg = LicenseStoreConfig(
    pinnedSpkiSha256: [
        "AAAAA…current SPKI hash…",
        "BBBBB…next SPKI hash…",
    ]
)
```

Two pins active during rotation windows. Empty list = no pinning (dev only).

## Testing without Firebase

```swift
let client = try await LicenseClient.connect(
    controlPlaneUrl: URL(string: "http://localhost:8080")!,
    productSlug: "zenkit",
    sdkSecret: "dev-shared-secret",
    auth: DevAuthTokenProvider(uid: "dev-uid", email: "dev@example.com"),
    appCheck: NoAppCheckProvider(),
    cache: InMemorySecureCache()
)
```

The dev backend (`FIREBASE_PROJECT_ID` unset) accepts `dev:<uid>:<email>` tokens and bypasses App Check.

## License

Internal — see LICENSE file.
