// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Returns a fresh Firebase ID token for the currently signed-in user.
/// Inject a custom implementation for tests or non-Firebase auth.
public protocol AuthTokenProvider: Sendable {
    func getIdToken(forceRefresh: Bool) async throws -> String
}

public extension AuthTokenProvider {
    func getIdToken() async throws -> String {
        try await getIdToken(forceRefresh: false)
    }
}

/// Firebase-backed implementation. We don't import the Firebase Auth iOS
/// SDK from the Vanaheim package (keeps the dependency tree small);
/// the consuming app constructs a `FirebaseAuthTokenProvider` and passes a
/// closure that calls `Auth.auth().currentUser?.getIDToken(...)`.
///
/// Example wiring in the product:
///
/// ```swift
/// import FirebaseAuth
/// let provider = FirebaseAuthTokenProvider { force in
///     guard let user = Auth.auth().currentUser else {
///         throw AuthError("Firebase user not signed in")
///     }
///     return try await user.getIDToken(forcingRefresh: force)
/// }
/// ```
public struct FirebaseAuthTokenProvider: AuthTokenProvider {
    public let fetch: @Sendable (_ forceRefresh: Bool) async throws -> String

    public init(fetch: @escaping @Sendable (_ forceRefresh: Bool) async throws -> String) {
        self.fetch = fetch
    }

    public func getIdToken(forceRefresh: Bool) async throws -> String {
        try await fetch(forceRefresh)
    }
}

/// Dev-only: returns `dev:<uid>:<email>` which the backend accepts when
/// `FIREBASE_PROJECT_ID` is unset. NEVER ship in production.
public struct DevAuthTokenProvider: AuthTokenProvider {
    public let uid: String
    public let email: String

    public init(uid: String, email: String) {
        self.uid = uid
        self.email = email
    }

    public func getIdToken(forceRefresh: Bool) async throws -> String {
        "dev:\(uid):\(email)"
    }
}

/// Default-position placeholder for `LicenseClient.connect(auth: ...)`.
/// The Swift SDK does not bundle the Firebase iOS SDK as a dependency,
/// so unlike Flutter we cannot construct a real default. This placeholder
/// throws AuthError on first use with a clear message pointing the
/// integrator at FirebaseAuthTokenProvider / DevAuthTokenProvider.
///
/// API-parity rationale: matches Flutter's "auth defaults to
/// FirebaseAuthTokenProvider()" call-site shape so `connect()` can be
/// invoked without naming `auth:`, while preserving Swift's "bring your
/// own Firebase dependency" model.
public struct UnconfiguredAuthTokenProvider: AuthTokenProvider {
    public init() {}
    public func getIdToken(forceRefresh: Bool) async throws -> String {
        throw AuthError(
            "No AuthTokenProvider configured. Pass auth: FirebaseAuthTokenProvider { ... } " +
            "to LicenseClient.connect(), or DevAuthTokenProvider for local dev."
        )
    }
}
