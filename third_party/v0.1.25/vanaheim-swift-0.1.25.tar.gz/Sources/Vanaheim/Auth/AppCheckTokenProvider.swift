// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Returns a fresh Firebase App Check token attesting this is our official
/// app on a non-tampered device.
public protocol AppCheckTokenProvider: Sendable {
    func getToken(forceRefresh: Bool) async throws -> String?
}

public extension AppCheckTokenProvider {
    func getToken() async throws -> String? {
        try await getToken(forceRefresh: false)
    }
}

/// Firebase App Check wrapper. Same pattern as `FirebaseAuthTokenProvider`
/// — product app provides the closure that calls
/// `AppCheck.appCheck().token(forcingRefresh:)`.
public struct FirebaseAppCheckTokenProvider: AppCheckTokenProvider {
    public let fetch: @Sendable (_ forceRefresh: Bool) async throws -> String?

    public init(fetch: @escaping @Sendable (_ forceRefresh: Bool) async throws -> String?) {
        self.fetch = fetch
    }

    public func getToken(forceRefresh: Bool) async throws -> String? {
        try await fetch(forceRefresh)
    }
}

/// No-op provider for local dev / tests when the backend's
/// `FIREBASE_PROJECT_NUMBER` is empty (App Check is bypassed there).
public struct NoAppCheckProvider: AppCheckTokenProvider {
    public init() {}
    public func getToken(forceRefresh: Bool) async throws -> String? { nil }
}
