// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import Security

/// Opaque secure-storage wrapper. Products NEVER get raw access — the only
/// operations are put/get/clear scoped to the SDK's namespace.
///
/// Default impl uses the iOS/macOS Keychain (kSecClassGenericPassword),
/// kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly accessibility. Inject
/// a custom `SecureCache` for tests via the connect() factory.
public protocol SecureCache: Sendable {
    func putJwt(_ jwt: String) async throws
    func getJwt() async throws -> String?
    func putLicenseId(_ id: String) async throws
    func getLicenseId() async throws -> String?
    func putActivationId(_ id: String) async throws
    func getActivationId() async throws -> String?
    func putRegionEndpoint(_ url: String) async throws
    func getRegionEndpoint() async throws -> String?
    // Telemetry: JSON-serialized [TelemetryEvent]. Kept in the same secure
    // namespace as JWT/IDs (may contain stack traces). NOT cleared by
    // clear() so a sign-out doesn't wipe diagnostic history.
    func putTelemetry(_ json: String) async throws
    func getTelemetry() async throws -> String?

    /// Read a value stored under an arbitrary key. Used by §2A/§2B sub-APIs
    /// (telemetry buffer, AI assistant cache, etc.) that need scoped
    /// persistence without proliferating bespoke get/put methods on this
    /// protocol. Keys SHOULD be namespaced (e.g. `telemetry_buffer_v1`).
    func getRaw(_ key: String) async throws -> String?

    /// Write a raw value under an arbitrary key.
    func putRaw(_ key: String, _ value: String) async throws

    /// Delete a raw value.
    func deleteRaw(_ key: String) async throws

    func clear() async throws
}

/// Production implementation backed by the system Keychain.
public final class KeychainSecureCache: SecureCache {
    private let service: String
    private let accessGroup: String?

    public init(service: String = "com.licensestore.sdk", accessGroup: String? = nil) {
        self.service = service
        self.accessGroup = accessGroup
    }

    private enum Key: String, CaseIterable {
        case jwt = "ls_jwt_v1"
        case licenseId = "ls_license_id_v1"
        case activationId = "ls_activation_id_v1"
        case regionEndpoint = "ls_region_endpoint_v1"
        case telemetry = "ls_telemetry_v1"

        /// Keys that get wiped by clear(). Telemetry deliberately excluded.
        static var clearable: [Key] { [.jwt, .licenseId, .activationId, .regionEndpoint] }
    }

    // MARK: SecureCache

    public func putJwt(_ jwt: String) async throws { try write(.jwt, jwt) }
    public func getJwt() async throws -> String? { read(.jwt) }
    public func putLicenseId(_ id: String) async throws { try write(.licenseId, id) }
    public func getLicenseId() async throws -> String? { read(.licenseId) }
    public func putActivationId(_ id: String) async throws { try write(.activationId, id) }
    public func getActivationId() async throws -> String? { read(.activationId) }
    public func putRegionEndpoint(_ url: String) async throws { try write(.regionEndpoint, url) }
    public func getRegionEndpoint() async throws -> String? { read(.regionEndpoint) }
    public func putTelemetry(_ json: String) async throws { try write(.telemetry, json) }
    public func getTelemetry() async throws -> String? { read(.telemetry) }

    public func clear() async throws {
        for k in Key.clearable {
            try? delete(k)
        }
        // Telemetry intentionally preserved across sign-out (per protocol doc).
        // Raw namespaced entries also preserved — sub-APIs that need
        // sign-out clearing must call deleteRaw explicitly.
    }

    // MARK: - SecureCache (raw)

    public func getRaw(_ key: String) async throws -> String? {
        readRaw("ls_raw_\(key)")
    }

    public func putRaw(_ key: String, _ value: String) async throws {
        try writeRaw("ls_raw_\(key)", value)
    }

    public func deleteRaw(_ key: String) async throws {
        try deleteRawKey("ls_raw_\(key)")
    }

    private func writeRaw(_ account: String, _ value: String) throws {
        let data = Data(value.utf8)
        var attrs = baseRawQuery(account)
        attrs[kSecValueData as String] = data
        attrs[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        var status = SecItemAdd(attrs as CFDictionary, nil)
        if status == errSecDuplicateItem {
            let update: [String: Any] = [kSecValueData as String: data]
            status = SecItemUpdate(baseRawQuery(account) as CFDictionary, update as CFDictionary)
        }
        guard status == errSecSuccess else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status), userInfo: [
                NSLocalizedDescriptionKey: "Keychain raw write failed (status \(status))",
            ])
        }
    }

    private func readRaw(_ account: String) -> String? {
        var q = baseRawQuery(account)
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        q[kSecReturnData as String] = true
        var item: CFTypeRef?
        let status = SecItemCopyMatching(q as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func deleteRawKey(_ account: String) throws {
        let status = SecItemDelete(baseRawQuery(account) as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status), userInfo: [
                NSLocalizedDescriptionKey: "Keychain raw delete failed (status \(status))",
            ])
        }
    }

    private func baseRawQuery(_ account: String) -> [String: Any] {
        var q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
        if let group = accessGroup {
            q[kSecAttrAccessGroup as String] = group
        }
        return q
    }

    // MARK: - Keychain helpers

    private func baseQuery(_ key: Key) -> [String: Any] {
        var q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key.rawValue,
        ]
        if let group = accessGroup {
            q[kSecAttrAccessGroup as String] = group
        }
        return q
    }

    private func write(_ key: Key, _ value: String) throws {
        let data = Data(value.utf8)
        var attrs = baseQuery(key)
        attrs[kSecValueData as String] = data
        attrs[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly

        var status = SecItemAdd(attrs as CFDictionary, nil)
        if status == errSecDuplicateItem {
            let update: [String: Any] = [kSecValueData as String: data]
            status = SecItemUpdate(baseQuery(key) as CFDictionary, update as CFDictionary)
        }
        guard status == errSecSuccess else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status), userInfo: [
                NSLocalizedDescriptionKey: "Keychain write failed (status \(status))",
            ])
        }
    }

    private func read(_ key: Key) -> String? {
        var q = baseQuery(key)
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        q[kSecReturnData as String] = true
        var item: CFTypeRef?
        let status = SecItemCopyMatching(q as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func delete(_ key: Key) throws {
        let status = SecItemDelete(baseQuery(key) as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status), userInfo: [
                NSLocalizedDescriptionKey: "Keychain delete failed (status \(status))",
            ])
        }
    }
}

/// In-memory cache for tests. NOT for production.
public actor InMemorySecureCache: SecureCache {
    private var map: [String: String] = [:]

    public init() {}

    public func putJwt(_ jwt: String) { map["jwt"] = jwt }
    public func getJwt() -> String? { map["jwt"] }
    public func putLicenseId(_ id: String) { map["license_id"] = id }
    public func getLicenseId() -> String? { map["license_id"] }
    public func putActivationId(_ id: String) { map["activation_id"] = id }
    public func getActivationId() -> String? { map["activation_id"] }
    public func putRegionEndpoint(_ url: String) { map["region_endpoint"] = url }
    public func getRegionEndpoint() -> String? { map["region_endpoint"] }
    public func putTelemetry(_ json: String) { map["telemetry"] = json }
    public func getTelemetry() -> String? { map["telemetry"] }

    public func getRaw(_ key: String) -> String? { map["raw_\(key)"] }
    public func putRaw(_ key: String, _ value: String) { map["raw_\(key)"] = value }
    public func deleteRaw(_ key: String) { map.removeValue(forKey: "raw_\(key)") }

    public func clear() {
        // Preserve telemetry + raw entries to match KeychainSecureCache semantics.
        let t = map["telemetry"]
        let raws = map.filter { $0.key.hasPrefix("raw_") }
        map.removeAll()
        if let t = t { map["telemetry"] = t }
        for (k, v) in raws { map[k] = v }
    }
}
