// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit

// ─────────────────────────────────────────────────────────────────────
// DirectClient — top-level orchestrator for FRON / Direct mode.
//
// Surface mirrors the Dart twin (sdk/dart/vanaheim/lib/src/direct/
// direct_client.dart) field-for-field — same method names, same arg
// shapes, same return-type taxonomy. A host product written against
// the Dart SDK can re-skin against Swift with zero per-method
// translation.
//
// What this file does:
//
//   1. `connect()`           → fetch JWKS, prepare ephemeral keypair,
//                              rehydrate persisted state.
//   2. `register(...)`       → Tier 1 ephemeral-JWS call; promotes
//                              ephemeral → durable on success.
//   3. `activate / verify /
//       heartbeat /
//       deactivate / catalog /
//       acknowledgeKidRotation /
//       registerFcmToken /
//       ackNotification /
//       sendStats /
//       reportError`         → Tier 2 durable-JWS calls.
//   4. `hasFeature(_) -> Bool`
//      `quota(_) -> Int`     → local entitlement reads off the most
//                              recent register/activate/verify response.
//
// The DirectClient does NOT touch the existing `LicenseClient` — the
// two modes are intentionally segregated. The host product picks one
// at construction time via `VanaheimConfig.mode`.
//
// Concurrency: actor. Every public method awaits to enter the actor;
// the request builder + response parser are stateless value types so
// they can be called freely from inside the actor without re-entering.
// ─────────────────────────────────────────────────────────────────────

public actor DirectClient {

    // ── Config + collaborators ──────────────────────────────────────
    // `internal` so the W6 payment-method extension in the sibling
    // `DirectPaymentClient.swift` can read `config.projectId` without
    // a separate public surface. `DirectConfig` is `Sendable` + value-
    // typed, so cross-file actor reads are safe.
    internal let config: DirectConfig
    private let recipientResolver: DirectRecipientResolver
    private let keypairStore: DirectKeypairStore
    private let requestBuilder: DirectRequestBuilder
    private let responseParser: DirectResponseParser
    private let httpSession: URLSession
    private let secureCache: SecureCache
    private let fcmBridge: DirectFcmBridge
    private let statsBatcher: DirectStatsBatcher
    private let heartbeatScheduler: DirectHeartbeatScheduler

    // ── State ───────────────────────────────────────────────────────
    /// True after `connect()` returns + before `dispose()`.
    private var connected: Bool = false

    /// Local entitlement snapshot — populated from the most recent
    /// register / activate / verify response. The SDK does NOT verify
    /// the inner JWS signature against the server's Ed25519 sig keys
    /// here (that lives behind a future wave); the snapshot is treated
    /// as authoritative because the OUTER JWE was sealed by the server
    /// with a key the SDK trusts via JWKS.
    private var featureSet: Set<String> = []
    private var quotaMap: [String: Int] = [:]

    public init(
        config: DirectConfig,
        recipientResolver: DirectRecipientResolver? = nil,
        keypairStore: DirectKeypairStore? = nil,
        secureCache: SecureCache? = nil,
        httpSession: URLSession? = nil
    ) throws {
        self.config = config
        // FIX S-2 — wire CertificatePinner into the URLSession path
        // EVERY HTTP call (JWKS fetch + FRON envelope POST) makes. The
        // caller is allowed to inject its own session; when they do we
        // assume they've already wrapped pinning themselves (the
        // `mockDirectSession()` test helper does exactly this without
        // pinning so unit tests can run without a real TLS handshake).
        // When the caller supplies nil we build a session with a
        // CertificatePinner delegate from `config.pinnedSpkiSha256`.
        let session: URLSession
        if let provided = httpSession {
            session = provided
        } else {
            let cfg = URLSessionConfiguration.ephemeral
            cfg.timeoutIntervalForRequest = config.httpTimeout
            cfg.timeoutIntervalForResource = config.httpTimeout
            let pinner = CertificatePinner(
                pinnedSpkiSha256: config.pinnedSpkiSha256)
            session = URLSession(
                configuration: cfg,
                delegate: pinner,
                delegateQueue: nil)
        }
        self.httpSession = session
        // FIX S-4 — resolver rejects non-HTTPS base URLs at construction.
        // We propagate the throw out of `init` so a misconfigured host
        // product fails-fast at DirectClient construction rather than
        // shipping plaintext FRON traffic.
        self.recipientResolver = try (recipientResolver
            ?? DirectRecipientResolver(
                bifrostBaseUrl: config.bifrostBaseUrl,
                session: session,
                ttl: config.jwksCacheTtl,
                timeout: config.httpTimeout))
        self.keypairStore = keypairStore ?? DirectKeypairStore()
        let cache = secureCache ?? KeychainSecureCache()
        self.secureCache = cache
        self.requestBuilder = DirectRequestBuilder(
            projectId: config.projectId,
            jwsLifetimeMs: config.jwsTokenLifetimeMs)
        self.responseParser = DirectResponseParser(
            allowedClockSkew: config.clockSkew)
        self.fcmBridge = DirectFcmBridge()
        self.statsBatcher = DirectStatsBatcher(
            bufferCapacity: config.statsBufferCapacity,
            flushBatchSize: config.statsFlushBatchSize,
            flushInterval: config.statsFlushInterval,
            cache: cache)
        self.heartbeatScheduler = DirectHeartbeatScheduler(
            initialCadenceMs: config.defaultHeartbeatCadenceMs)
    }

    // ── Public surface — connect/dispose ────────────────────────────

    /// Pulls JWKS, rehydrates durable identity from Keychain, rehydrates
    /// any persisted stats buffer, and marks the SDK as ready. Safe to
    /// call multiple times — second call is a no-op.
    public func connect() async throws {
        if connected { return }
        // Pre-warm the recipient JWKS. A failure here surfaces to the
        // caller as a typed `DirectError.noRecipientKey` / `.network`
        // (via the resolver's `NetworkError`); we don't auto-retry
        // because the host product is in a better position to surface
        // the failure (offline boot, certificate pin mismatch, etc.).
        do {
            _ = try await recipientResolver.get()
        } catch let e as LicenseStoreError {
            throw DirectError.network(message: e.message,
                                      cause: e.cause.map { "\($0)" })
        }
        await keypairStore.rehydrate()
        await statsBatcher.rehydrate()
        // Wire the bridges that need a callback into us. We have to
        // capture self as a closure here — DirectClient is an actor,
        // so we go through `Task { await self.<method> }` to bridge
        // sync closures into actor calls.
        await fcmBridge.attach { [weak self] token, platform in
            try await self?.registerFcmTokenInternal(
                token: token, platform: platform)
        }
        await statsBatcher.start { [weak self] events in
            try await self?.flushStats(events: events)
        }
        connected = true
    }

    /// Stops the heartbeat + stats schedulers, persists any pending
    /// stats, and clears in-process caches. Safe to call multiple
    /// times.
    public func dispose() async {
        if !connected { return }
        connected = false
        await heartbeatScheduler.stop()
        await statsBatcher.stop()
        await statsBatcher.persist()
        await fcmBridge.detach()
    }

    // ── Public surface — license cycle ──────────────────────────────

    /// Tier 1 — `/direct/v1/register`. Ephemeral-JWS: the embedded
    /// Ed25519 pubkey becomes the durable device identity once the
    /// server accepts.
    public func register(
        licenseKey: String,
        fingerprint: String,
        appMeta: [String: Any]
    ) async throws -> RegisterResult {
        try requireConnected()
        let signingKey = try await keypairStore.ensureEphemeralKey()
        let ephemeralPubX = signingKey.publicKey.rawRepresentation
            .base64URLEncodedString()
        let body: [String: Any] = [
            "project_id": config.projectId,
            "license_key": licenseKey,
            "ephemeral_pubkey": ephemeralPubX,
            "fingerprint": fingerprint,
            "app_meta": appMeta,
        ]
        let json = try await postJson(
            route: "/direct/v1/register",
            audience: "direct:register",
            mode: .ephemeral,
            signingKey: signingKey,
            body: body)
        // Required fields per `bifrost/.../handlers/licenses.ts`
        // handleRegister response shape.
        guard let deviceId = json["device_id"] as? String,
              let entitlementJws = json["entitlement_jws"] as? String,
              let serverNonce = json["server_nonce"] as? String else {
            throw DirectError.network(
                message: "register response missing required fields")
        }
        let tierMeta = json["tier_metadata"] as? [String: Any] ?? [:]
        let features = (json["feature_list"] as? [String]) ?? []
        let quotas = decodeIntMap(json["quotas"])
        let cadenceMs = (json["heartbeat_cadence_ms"] as? Int)
            ?? config.defaultHeartbeatCadenceMs

        // Promote the ephemeral keypair to durable + persist device id.
        do {
            try await keypairStore.promoteEphemeralToDurable(
                deviceId: deviceId)
        } catch let e as KeychainError {
            throw DirectError.network(
                message: "Keychain write failed during register promotion",
                cause: e.message)
        }
        await keypairStore.putServerNonce(serverNonce)
        // Update the in-memory entitlement snapshot.
        featureSet = Set(features)
        quotaMap = quotas
        // Spin up the heartbeat scheduler at the server-requested
        // cadence.
        await heartbeatScheduler.updateCadence(cadenceMs)
        await heartbeatScheduler.start { [weak self] in
            _ = try await self?.heartbeat()
        }
        return RegisterResult(
            deviceId: deviceId,
            entitlementJws: entitlementJws,
            tierMetadata: tierMeta,
            featureList: features,
            quotas: quotas,
            serverNonce: serverNonce,
            heartbeatCadenceMs: cadenceMs)
    }

    /// Tier 2 — `/direct/v1/activate`. Binds a license_key to the
    /// (already-registered) device + mints a fresh entitlement bundle.
    public func activate(licenseKey: String) async throws -> ActivateResult {
        try requireConnected()
        let body: [String: Any] = [
            "project_id": config.projectId,
            "license_key": licenseKey,
        ]
        let json = try await postDurableJson(
            route: "/direct/v1/activate",
            audience: "direct:activate",
            body: body)
        guard let jws = json["entitlement_jws"] as? String else {
            throw DirectError.network(
                message: "activate response missing entitlement_jws")
        }
        let tierMeta = json["tier_metadata"] as? [String: Any] ?? [:]
        let features = (json["feature_list"] as? [String]) ?? []
        let quotas = decodeIntMap(json["quotas"])
        let refreshedAtMs = json["refreshed_at_ms"] as? Int ?? 0
        featureSet = Set(features)
        quotaMap = quotas
        return ActivateResult(
            entitlementJws: jws,
            tierMetadata: tierMeta,
            featureList: features,
            quotas: quotas,
            refreshedAtMs: refreshedAtMs)
    }

    /// Tier 2 — `/direct/v1/verify`. Re-mints the entitlement bundle
    /// for this device. Used as the cold-start + refresh-window check.
    public func verify() async throws -> VerifyResult {
        try requireConnected()
        let body: [String: Any] = [
            "project_id": config.projectId,
        ]
        let json = try await postDurableJson(
            route: "/direct/v1/verify",
            audience: "direct:verify",
            body: body)
        let deactivated = (json["deactivated"] as? Bool) ?? false
        let deactivatedReason = json["deactivated_reason"] as? String
        let deactivatedAtMs = json["deactivated_at_ms"] as? Int
        let jws = json["entitlement_jws"] as? String
        let tierMeta = json["tier_metadata"] as? [String: Any] ?? [:]
        let features = (json["feature_list"] as? [String]) ?? []
        let quotas = decodeIntMap(json["quotas"])
        let refreshedAtMs = json["refreshed_at_ms"] as? Int
        if !deactivated {
            featureSet = Set(features)
            quotaMap = quotas
        } else {
            // FIX S-5 — server reports device revoked (sealed JWE
            // response, signature already verified by
            // `parseAndVerify`). Wipe the durable keypair + device id
            // + nonce so the host product cannot accidentally keep
            // hitting Tier-2 endpoints with a dead identity, and so
            // local `hasFeature` / `quota` reads fail-CLOSED for any
            // gating UI that already had the entitlement snapshot.
            await handleVerifiedDeviceRevoked()
        }
        return VerifyResult(
            entitlementJws: jws,
            tierMetadata: tierMeta,
            featureList: features,
            quotas: quotas,
            refreshedAtMs: refreshedAtMs,
            deactivated: deactivated,
            deactivatedReason: deactivatedReason,
            deactivatedAtMs: deactivatedAtMs)
    }

    /// Tier 2 — `/direct/v1/heartbeat`. Liveness ping; also surfaces
    /// admin-side revocation.
    public func heartbeat() async throws -> HeartbeatResult {
        try requireConnected()
        let body: [String: Any] = [
            "project_id": config.projectId,
        ]
        let json = try await postDurableJson(
            route: "/direct/v1/heartbeat",
            audience: "direct:heartbeat",
            body: body)
        let valid = (json["valid"] as? Bool) ?? false
        let nextAfterMs = (json["next_heartbeat_after_ms"] as? Int)
            ?? config.defaultHeartbeatCadenceMs
        let revokedReason = json["revoked_reason"] as? String

        // Push the server-supplied cadence into the scheduler so the
        // next tick honours it.
        await heartbeatScheduler.updateCadence(nextAfterMs)

        if !valid {
            // FIX S-5 — same posture as verify(): a verified-envelope
            // heartbeat that reports valid=false means the device has
            // been revoked. Wipe local state so subsequent calls
            // fail-CLOSED.
            await handleVerifiedDeviceRevoked()
        }
        return HeartbeatResult(
            valid: valid,
            revokedReason: revokedReason,
            nextHeartbeatAfterMs: nextAfterMs)
    }

    /// Tier 2 — `/direct/v1/deactivate`. Graceful: clears local state
    /// AFTER the server confirms.
    public func deactivate(reason: String) async throws {
        try requireConnected()
        let normalised = ["user_uninstall", "device_swap", "admin"]
            .contains(reason) ? reason : "user_uninstall"
        let body: [String: Any] = [
            "project_id": config.projectId,
            "reason": normalised,
        ]
        _ = try await postDurableJson(
            route: "/direct/v1/deactivate",
            audience: "direct:deactivate",
            body: body)
        // Local cleanup — order matters: stop the heartbeat first so
        // an in-flight tick can't race with the Keychain clear.
        await heartbeatScheduler.stop()
        await keypairStore.clear()
        await fcmBridge.reset()
        featureSet = []
        quotaMap = [:]
    }

    /// Tier 2 — `/direct/v1/catalog`. Returns the full catalog
    /// snapshot (tiers / features / pricing plans).
    public func getCatalog() async throws -> CatalogSnapshot {
        try requireConnected()
        let body: [String: Any] = [
            "project_id": config.projectId,
        ]
        let json = try await postDurableJson(
            route: "/direct/v1/catalog",
            audience: "direct:catalog",
            body: body)
        let etag = json["catalog_etag"] as? String
        let tiers = (json["tiers"] as? [[String: Any]]) ?? []
        let features = (json["features"] as? [[String: Any]]) ?? []
        let plans = (json["pricing_plans"] as? [[String: Any]]) ?? []
        return CatalogSnapshot(
            catalogEtag: etag,
            tiers: tiers,
            features: features,
            pricingPlans: plans)
    }

    /// Tier 2 — `/direct/v1/keys/rotate-ack`. Records that the SDK has
    /// observed + processed the given kid rotation.
    public func acknowledgeKidRotation(kid: String) async throws {
        try requireConnected()
        let body: [String: Any] = [
            "project_id": config.projectId,
            "acknowledged_kid": kid,
        ]
        // S-Fix 3 (W6 fix-pass-2) — audience values use the underscore
        // dialect (`rotate_ack`, not `rotate-ack`) per the Bifrost
        // server's canonical DIRECT_AUD constant
        // (`bifrost/.../direct/jws-verifier.ts` line 118) and the Dart
        // SDK's `kDirectAudKeysRotateAck` (`direct:keys.rotate_ack`).
        // Route PATH still uses the dash form (matches the HTTP URL).
        _ = try await postDurableJson(
            route: "/direct/v1/keys/rotate-ack",
            audience: "direct:keys.rotate_ack",
            body: body)
    }

    // ── Notifications ───────────────────────────────────────────────

    /// Tier 2 — `/direct/v1/notifications/register-fcm`. Routes
    /// through the bridge so duplicate submissions are dedup'd.
    public func registerFcmToken(
        token: String,
        platform: DirectPushPlatform
    ) async throws {
        try requireConnected()
        try await fcmBridge.submit(token: token, platform: platform)
    }

    /// Called by `DirectFcmBridge` after the dedupe check. Public-
    /// internal so the bridge can target it via a weak self closure.
    fileprivate func registerFcmTokenInternal(
        token: String,
        platform: DirectPushPlatform
    ) async throws {
        let body: [String: Any] = [
            "project_id": config.projectId,
            "fcm_token": token,
            "platform": platform.rawValue,
        ]
        // S-Fix 3 (W6 fix-pass-2) — audience uses underscore dialect
        // (`register_fcm`) per Bifrost canonical
        // (`bifrost/.../direct/jws-verifier.ts` line 119) and the Dart
        // SDK's `kDirectAudNotificationsRegisterFcm`. Route PATH still
        // uses the dash form (matches the HTTP URL).
        _ = try await postDurableJson(
            route: "/direct/v1/notifications/register-fcm",
            audience: "direct:notifications.register_fcm",
            body: body)
    }

    /// Tier 2 — `/direct/v1/notifications/ack`.
    public func ackNotification(
        notificationId: String,
        receivedAtMs: Int,
        displayed: Bool? = nil
    ) async throws {
        try requireConnected()
        var body: [String: Any] = [
            "project_id": config.projectId,
            "notification_id": notificationId,
            "received_at_ms": receivedAtMs,
        ]
        if let d = displayed {
            body["displayed"] = d
        }
        _ = try await postDurableJson(
            route: "/direct/v1/notifications/ack",
            audience: "direct:notifications.ack",
            body: body)
    }

    // ── Telemetry ───────────────────────────────────────────────────

    /// Tier 2 — `/direct/v1/telemetry/stats`. Events are queued
    /// through the batcher; this method returns the per-batch accept/
    /// reject counts from the most recent flush. For most call sites
    /// the returned counts are zero (the batcher accepted the event
    /// into the buffer; the actual send happens later) — call sites
    /// that need synchronous accept/reject feedback should
    /// `await statsBatcher.flushImmediate()` first.
    public func sendStats(events: [DirectStatEvent]) async throws -> StatsResult {
        try requireConnected()
        await statsBatcher.add(events)
        return StatsResult(
            acceptedEventCount: 0,
            rejectedEventCount: 0,
            rejectionReasons: [])
    }

    /// Tier 2 — `/direct/v1/telemetry/error`. Synchronous: error
    /// reports bypass the batcher (the server-side rate-limit is
    /// tight; one-shot semantics are easier to reason about).
    public func reportError(error: DirectErrorReport) async throws -> ErrorResult {
        try requireConnected()
        var body: [String: Any] = [
            "project_id": config.projectId,
            "error_type": error.errorType,
            "occurred_at_ms": error.occurredAtMs,
        ]
        if let m = error.message { body["message"] = m }
        if let s = error.stack { body["stack"] = s }
        if let c = error.context { body["context"] = c }
        if let f = error.fingerprint { body["fingerprint"] = f }
        let json = try await postDurableJson(
            route: "/direct/v1/telemetry/error",
            audience: "direct:telemetry.error",
            body: body)
        let errorId = (json["error_id"] as? String) ?? ""
        return ErrorResult(errorId: errorId)
    }

    // ── Local entitlement evaluation ────────────────────────────────

    /// Local fast-path entitlement check. Returns the snapshot value
    /// from the most recent register/activate/verify response. Reads
    /// fail-closed (returns false when not connected / not registered).
    ///
    /// NOTE: nonisolated access to actor state isn't expressible as a
    /// `func` here without going through an awaited call. We expose
    /// async variants below (`hasFeatureAsync`) and a SYNC accessor
    /// via a snapshot box if a future wave needs it; the Dart twin
    /// also uses async accessors for the same reason.
    public func hasFeature(_ name: String) -> Bool {
        // Inside an actor method this is a synchronous read of
        // actor-isolated state — the caller already needed `await`
        // to reach this method, so the actor is held; no race.
        return featureSet.contains(name)
    }

    /// Local fast-path quota lookup. Returns 0 when the quota is not
    /// present.
    public func quota(_ name: String) -> Int {
        return quotaMap[name] ?? 0
    }

    /// Exposes the batcher so the host product's app-background hook
    /// can persist the pending events explicitly.
    public func statsBuffer() -> DirectStatsBatcher { statsBatcher }

    /// Exposes the FCM bridge so the host product can wire APNs
    /// callbacks directly to it without going through DirectClient.
    public func fcm() -> DirectFcmBridge { fcmBridge }

    /// Exposes the heartbeat scheduler for diagnostics + testing.
    /// Renamed (vs. the spec's `heartbeat()`) so the Swift compiler
    /// can disambiguate from the network-facing
    /// `heartbeat() async throws -> HeartbeatResult` — Swift cannot
    /// overload on return type alone.
    public func heartbeatScheduler_() -> DirectHeartbeatScheduler {
        heartbeatScheduler
    }

    // ── Internals — HTTP + envelope plumbing ────────────────────────

    internal func requireConnected() throws {
        if !connected {
            throw DirectError.notConnected
        }
    }

    /// Mutates the in-memory entitlement snapshot from a fresh
    /// register/activate/verify/refresh response. Used by both this
    /// file's license-cycle methods and the W6 payment-extension's
    /// `refreshAfterPayment(...)` so the snapshot stays single-sourced.
    internal func applyEntitlementSnapshot(
        features: [String],
        quotas: [String: Int]
    ) {
        featureSet = Set(features)
        quotaMap = quotas
    }

    private func flushStats(events: [DirectStatEvent]) async throws {
        if events.isEmpty { return }
        let body: [String: Any] = [
            "project_id": config.projectId,
            "events": events.map { e in
                var m: [String: Any] = [
                    "event_name": e.eventName,
                    "occurred_at_ms": e.occurredAtMs,
                    "count": e.count,
                ]
                if let d = e.dimensions { m["dimensions"] = d }
                return m
            },
        ]
        _ = try await postDurableJson(
            route: "/direct/v1/telemetry/stats",
            audience: "direct:telemetry.stats",
            body: body)
    }

    /// Convenience wrapper for the common case: durable mode + load
    /// device id + sign + send.
    ///
    /// `internal` access so the W6 payment-method extension (sibling
    /// file `DirectPaymentClient.swift`) can flow through the SAME
    /// envelope path as register / activate / verify / heartbeat. No
    /// new crypto path is introduced for the payment surface.
    internal func postDurableJson(
        route: String,
        audience: String,
        body: [String: Any]
    ) async throws -> [String: Any] {
        let signingKey = try await keypairStore.requireDurableKey()
        return try await postJson(
            route: route,
            audience: audience,
            mode: .durable,
            signingKey: signingKey,
            body: body)
    }

    /// Builds + posts a single FRON request. Handles the one-shot
    /// retry on `jweDecryptFailed` (server-side kid rotation): force-
    /// refresh the JWKS, re-build, re-post.
    private func postJson(
        route: String,
        audience: String,
        mode: DirectJwsMode,
        signingKey: Curve25519.Signing.PrivateKey,
        body: [String: Any]
    ) async throws -> [String: Any] {
        let url = config.bifrostBaseUrl.appendingPathComponent(
            String(route.drop(while: { $0 == "/" })))
        var deviceId: String? = nil
        if mode == .durable {
            deviceId = try await keypairStore.requireDeviceId()
        }
        do {
            return try await postOnce(
                url: url,
                audience: audience,
                mode: mode,
                signingKey: signingKey,
                deviceId: deviceId,
                body: body)
        } catch DirectError.jweDecryptFailed {
            // Server-side kid rotation — refresh JWKS + retry once.
            _ = try await recipientResolver.forceRefresh()
            return try await postOnce(
                url: url,
                audience: audience,
                mode: mode,
                signingKey: signingKey,
                deviceId: deviceId,
                body: body)
        }
    }

    private func postOnce(
        url: URL,
        audience: String,
        mode: DirectJwsMode,
        signingKey: Curve25519.Signing.PrivateKey,
        deviceId: String?,
        body: [String: Any]
    ) async throws -> [String: Any] {
        let recipient = try await recipientResolver.get()
        let envelope = try requestBuilder.build(
            mode: mode,
            audience: audience,
            signingKey: signingKey,
            deviceId: deviceId,
            body: body,
            recipient: recipient)
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/jose+json",
                     forHTTPHeaderField: "Content-Type")
        req.setValue("application/jose+json",
                     forHTTPHeaderField: "Accept")
        req.timeoutInterval = config.httpTimeout
        req.httpBody = envelope.compactJwe.data(using: .ascii)

        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await httpSession.data(for: req)
        } catch let e as URLError where e.code == .timedOut {
            throw DirectError.network(message: "request timeout",
                                      cause: "\(e)")
        } catch let e as URLError where
            e.code == .cancelled || e.code == .serverCertificateUntrusted ||
            e.code == .secureConnectionFailed {
            // FIX S-2 — `CertificatePinner` answers a pin failure with
            // `cancelAuthenticationChallenge`, which URLSession surfaces
            // as `URLError(.cancelled)`. We translate that to the
            // typed cert-pin failure case so the host product can
            // distinguish a genuine pin-rotation event from a generic
            // network blip. `.secureConnectionFailed` /
            // `.serverCertificateUntrusted` cover the same posture for
            // pin mismatches that surface earlier in the TLS state
            // machine.
            throw DirectError.certPinFailed
        } catch {
            throw DirectError.network(
                message: "transport failure",
                cause: "\(error)")
        }
        guard let http = response as? HTTPURLResponse else {
            throw DirectError.network(message: "non-HTTP response")
        }
        // Resolve verify-keys ONCE per request — we need them on both
        // the success and the (sealed-error) paths to integrity-check
        // the inner JWS.
        let verifyKeys = (try? await recipientResolver.verifyKeys()) ?? []
        let requestPath = url.path
        if (200...299).contains(http.statusCode) {
            // Success — parse + verify the sealed response.
            let bodyText = String(data: data, encoding: .utf8) ?? ""
            let parsed = try responseParser.parseAndVerify(
                compactJwe: bodyText,
                requestKey: envelope.ephemeralPrivKey,
                verifyKeys: verifyKeys,
                expectedRequestId: envelope.requestId,
                expectedRoutePath: requestPath,
                expectedProjectId: config.projectId)
            return parsed.json
        }
        // Error path — body is plain JSON (the server's error
        // projection runs OUTSIDE the response-seal middleware).
        //
        // FIX S-7 — the plaintext error path is UNAUTHENTICATED. We
        // surface it as a typed DirectError for UX (the SDK still
        // needs to honour Retry-After, distinguish .licenseInvalid
        // from .licenseExpired, etc.) but we DO NOT let it trigger
        // destructive local actions. The keypair-wipe path for
        // DIRECT_DEVICE_REVOKED gates exclusively on a verified
        // sealed-error envelope (see `handleVerifiedDeviceRevoked` —
        // currently the FRON server emits revoke as a 200 JWE body
        // field on `/verify` + `/heartbeat`, NOT as a plaintext error,
        // so this path is the safe one).
        let retryAfterMs = http.value(forHTTPHeaderField: "Retry-After")
            .flatMap { Int($0) }
            .map { $0 * 1000 }
        let errorJson = (try? responseParser.parseJsonError(data: data))
            ?? [:]
        // The FRON error envelope shape:
        //   { "error": "<CODE>", "message": "<text>",
        //     "retry_after_ms": <opt> }
        let wireCode = errorJson["error"] as? String
        let message = errorJson["message"] as? String
        let bodyRetry = errorJson["retry_after_ms"] as? Int
        let mapped = DirectErrorMapper.map(
            statusCode: http.statusCode,
            wireCode: wireCode,
            message: message,
            retryAfterMs: bodyRetry ?? retryAfterMs)
        // FIX S-7 — explicit guard: if the plaintext mapper produced a
        // .deviceRevoked we DO NOT wipe local state here. The wipe
        // only fires from the verified path inside `verify()` /
        // `heartbeat()` (see `handleVerifiedDeviceRevoked`). Surface
        // the typed error so the host product can branch UX, but
        // preserve the durable identity until the next sealed
        // confirmation lands.
        throw mapped
    }

    /// Called from `verify()` / `heartbeat()` after the server's
    /// sealed JWE response confirmed the device has been revoked.
    /// Wipes the durable keypair, device id, server nonce, and
    /// in-memory entitlement snapshot so subsequent `hasFeature` /
    /// `quota` reads fail-CLOSED (Fix S-5).
    ///
    /// SECURITY: this method MUST only be called from a code path that
    /// has cryptographically verified the revoke signal (i.e. the
    /// signal landed inside a `parseAndVerify`'d envelope). The
    /// plaintext-error path in `postOnce` deliberately does NOT call
    /// this — see Fix S-7 for the rationale.
    private func handleVerifiedDeviceRevoked() async {
        await heartbeatScheduler.stop()
        await keypairStore.clear()
        await fcmBridge.reset()
        featureSet = []
        quotaMap = [:]
    }

    /// Convert a JSON map's number values to `Int` (skipping anything
    /// that can't be coerced).
    private func decodeIntMap(_ raw: Any?) -> [String: Int] {
        guard let m = raw as? [String: Any] else { return [:] }
        var out: [String: Int] = [:]
        for (k, v) in m {
            if let n = v as? Int { out[k] = n }
            else if let n = v as? NSNumber { out[k] = n.intValue }
        }
        return out
    }
}
