// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit

// ─────────────────────────────────────────────────────────────────────
// DirectRequestBuilder — assembles the JWE+JWS envelope for a single
// FRON request.
//
// Wire shape (must match Bifrost's expectation exactly — see
// `bifrost/.../direct/jwe-recipient.ts` + `direct/jws-verifier.ts`):
//
//   1. Inner JWS (compact Ed25519, alg=EdDSA)
//      header: {
//        "alg": "EdDSA",
//        "typ": "bifrost-direct+ephemeral+jws"  // register only
//             | "bifrost-direct+durable+jws",   // every other endpoint
//        "device_pub_jwk": { kty, crv, x }     // ephemeral only —
//                                              // embedded pubkey BECOMES
//                                              // the durable identity
//      }
//      claims: {
//        "aud": "direct:<route_name>",
//        "iat": <ms>, "nbf": <ms>, "exp": <ms>,
//        "jti": <uuid>,
//        "project_id": <string>,
//        "device_id": <string>,         // durable only
//        "body": { ... }                // route-specific request body
//      }
//
//   2. Outer JWE (single-recipient compact, ECDH-ES + A256GCM)
//      protected header: {
//        "alg": "ECDH-ES",
//        "enc": "A256GCM",
//        "kid": <Bifrost-enc-kid>,
//        "epk": { kty: "OKP", crv: "X25519", x: <ephemeral b64url> },
//        "apu": <SHA-256 thumbprint of ephemeral X25519 pubkey>,
//        "apv": <Bifrost recipient kid>,
//        "typ": "bifrost-direct+jwe",
//        "lcs_v": 2
//      }
//      plaintext: the inner JWS compact-serialised bytes
//
// We can't reuse `JweCodec.encryptForRecipient` directly because that
// codec hard-codes `typ=lcs+jwe` + L2-flavoured AAD fields. The FRON
// envelope has its own typ ("bifrost-direct+jwe") and OMITS the L2-
// only fields (project_id / route_path / request_id) from the JWE
// protected header — those live inside the inner JWS instead.
//
// We therefore reimplement the seal step inline. The crypto primitives
// (X25519 ECDH + ConcatKDF + AES-GCM seal) are still standard CryptoKit
// — no new crypto, just a different envelope shape.
// ─────────────────────────────────────────────────────────────────────

/// Inner-JWS mode discriminator. The two modes share the same Ed25519
/// signing key once the device is registered — they differ only in
/// the JWS `typ` and the presence of the embedded `device_pub_jwk`
/// header on Mode A.
public enum DirectJwsMode: Sendable, Equatable {
    /// Tier 1 — `/direct/v1/register`. Embeds the ephemeral pubkey in
    /// the header; signed by a freshly-generated keypair.
    case ephemeral
    /// Tier 2 — everything else. Signed by the durable keypair
    /// promoted from the ephemeral after register accepted.
    case durable
}

/// Result of `DirectRequestBuilder.build(...)`. The caller posts
/// `compactJwe` to the FRON endpoint with `Content-Type:
/// application/jose+json`, then threads `ephemeralPrivKey` into the
/// response parser so the server's epk-sealed reply can be opened.
public struct DirectRequestEnvelope: @unchecked Sendable {
    /// Full 5-segment JWE compact-serialisation string.
    public let compactJwe: String
    /// Recipient kid the JWE was sealed against — used for diagnostics
    /// when the server responds with `jweDecryptFailed`.
    public let recipientKid: String
    /// X25519 private half of the request's ephemeral keypair. The
    /// server seals its response to the SDK's epk (rather than maintain
    /// a device X25519 registry) — so we MUST keep this around until
    /// the response lands. Single-shot: discarded after the response
    /// parses.
    public let ephemeralPrivKey: Curve25519.KeyAgreement.PrivateKey
    /// `jti` the SDK stamped on the inner JWS for this request. The
    /// response parser echo-verifies this against the inner-JWS `jti`
    /// claim on the server's reply (Fix S-1b — cross-request replay
    /// defence).
    public let requestId: String

    public init(
        compactJwe: String,
        recipientKid: String,
        ephemeralPrivKey: Curve25519.KeyAgreement.PrivateKey,
        requestId: String
    ) {
        self.compactJwe = compactJwe
        self.recipientKid = recipientKid
        self.ephemeralPrivKey = ephemeralPrivKey
        self.requestId = requestId
    }
}

/// Stateless envelope builder. Holds no caches; every call freshly
/// signs + encrypts.
public struct DirectRequestBuilder: Sendable {
    private let projectId: String
    private let jwsLifetimeMs: Int

    /// Wire constants — pinned exactly to what the FRON server expects.
    /// Bumping any of these here without a matching server bump will
    /// hard-break every request.
    private static let kJweTyp = "bifrost-direct+jwe"
    private static let kJweLcsVersion = 2
    private static let kJweAlg = "ECDH-ES"
    private static let kJweEnc = "A256GCM"
    private static let kCurveX25519 = "X25519"
    private static let kKtyOkp = "OKP"

    public init(projectId: String, jwsLifetimeMs: Int) {
        self.projectId = projectId
        self.jwsLifetimeMs = jwsLifetimeMs
    }

    /// Builds the full JWE-of-JWS envelope.
    ///
    /// - `mode`: ephemeral (register) vs durable (everything else)
    /// - `audience`: stable route-name string (e.g. `"direct:activate"`)
    /// - `signingKey`: ephemeral or durable Ed25519 — caller picks
    /// - `deviceId`: required in durable mode, ignored in ephemeral
    /// - `body`: JSON-encodable map placed under the JWS `body` claim
    /// - `recipient`: Bifrost X25519 enc key (from
    ///   `DirectRecipientResolver.get()`)
    /// - `nowMs`: optional injection point for tests
    public func build(
        mode: DirectJwsMode,
        audience: String,
        signingKey: Curve25519.Signing.PrivateKey,
        deviceId: String?,
        body: [String: Any],
        recipient: DirectRecipient,
        nowMs: Int? = nil,
        requestId: String? = nil
    ) throws -> DirectRequestEnvelope {

        let now = nowMs ?? Int(Date().timeIntervalSince1970 * 1000)
        let jti = requestId ?? UUID().uuidString

        // ── 1. Sign the inner JWS ───────────────────────────────────
        let innerJws = try buildInnerJws(
            mode: mode,
            audience: audience,
            signingKey: signingKey,
            deviceId: deviceId,
            body: body,
            nowMs: now,
            requestId: jti)

        // ── 2. Seal the JWE around the inner JWS ────────────────────
        let recipientPub: Curve25519.KeyAgreement.PublicKey
        do {
            recipientPub = try Curve25519.KeyAgreement.PublicKey(
                rawRepresentation: recipient.x25519Pub)
        } catch {
            throw DirectError.network(
                message: "Bifrost recipient X25519 pubkey rejected by " +
                         "CryptoKit",
                cause: "\(error)")
        }

        // Fresh ephemeral X25519 keypair — single-flight, NEVER reused
        // across requests (RFC 7518 §4.6 + the FRON anti-reuse ledger).
        let epk = Curve25519.KeyAgreement.PrivateKey()
        let epkPubBytes = epk.publicKey.rawRepresentation
        let apuThumb = pubKeyThumbprint(epkPubBytes)

        // Protected header — FRON-flavoured. Note: NO project_id /
        // route_path / request_id here (those live inside the inner
        // JWS claims). Bifrost's `_parseHeaderForAllowlist` only reads
        // alg / enc / kid / typ / lcs_v / epk; we still ship `apu` and
        // `apv` for parity with the spec language even though the
        // server does not currently allowlist-check them here.
        let header: [String: Any] = [
            "alg": Self.kJweAlg,
            "enc": Self.kJweEnc,
            "kid": recipient.kid,
            "epk": [
                "kty": Self.kKtyOkp,
                "crv": Self.kCurveX25519,
                "x": epkPubBytes.base64URLEncodedString(),
            ],
            "apu": apuThumb,
            "apv": recipient.kid,
            "typ": Self.kJweTyp,
            "lcs_v": Self.kJweLcsVersion,
        ]
        let headerBytes: Data
        do {
            headerBytes = try JSONSerialization.data(
                withJSONObject: header, options: [.sortedKeys])
        } catch {
            throw DirectError.network(
                message: "JWE header JSON serialization failed",
                cause: "\(error)")
        }
        let headerB64 = headerBytes.base64URLEncodedString()

        // ── 3. Derive CEK via ECDH-ES → ConcatKDF (RFC 7518 §4.6) ───
        let cekBytes: Data
        do {
            cekBytes = try Self.deriveCek(
                myPriv: epk,
                peerPub: recipientPub,
                apu: apuThumb,
                apv: recipient.kid)
        } catch let e as DirectError {
            throw e
        } catch {
            throw DirectError.network(
                message: "JWE CEK derivation failed",
                cause: "\(error)")
        }
        let cek = SymmetricKey(data: cekBytes)

        // ── 4. AES-GCM seal ────────────────────────────────────────
        guard let aadBytes = headerB64.data(using: .ascii) else {
            throw DirectError.network(
                message: "JWE protected header b64url is not ASCII")
        }
        let sealed: AES.GCM.SealedBox
        do {
            sealed = try AES.GCM.seal(Data(innerJws.utf8),
                                      using: cek,
                                      authenticating: aadBytes)
        } catch {
            throw DirectError.network(
                message: "AES-GCM seal failed",
                cause: "\(error)")
        }
        let nonceBytes = sealed.nonce.withUnsafeBytes { Data($0) }

        // ── 5. Compact serialization ───────────────────────────────
        let parts = [
            headerB64,
            "", // encrypted_key — empty per RFC 7518 §4.6 direct ECDH-ES
            nonceBytes.base64URLEncodedString(),
            sealed.ciphertext.base64URLEncodedString(),
            sealed.tag.base64URLEncodedString(),
        ]
        return DirectRequestEnvelope(
            compactJwe: parts.joined(separator: "."),
            recipientKid: recipient.kid,
            ephemeralPrivKey: epk,
            requestId: jti)
    }

    /// Builds the compact Ed25519 inner JWS. Exposed at file scope so
    /// `DirectResponseParser` (response-side verifier) can reuse the
    /// same header/claims serialisation conventions.
    public func buildInnerJws(
        mode: DirectJwsMode,
        audience: String,
        signingKey: Curve25519.Signing.PrivateKey,
        deviceId: String?,
        body: [String: Any],
        nowMs: Int,
        requestId: String? = nil
    ) throws -> String {
        var header: [String: Any] = [
            "alg": "EdDSA",
        ]
        switch mode {
        case .ephemeral:
            header["typ"] = "bifrost-direct+ephemeral+jws"
            let pubX = signingKey.publicKey.rawRepresentation
                .base64URLEncodedString()
            header["device_pub_jwk"] = [
                "kty": "OKP",
                "crv": "Ed25519",
                "x": pubX,
            ]
        case .durable:
            header["typ"] = "bifrost-direct+durable+jws"
        }

        var claims: [String: Any] = [
            "aud": audience,
            "iat": nowMs,
            "nbf": nowMs,
            "exp": nowMs + jwsLifetimeMs,
            "jti": requestId ?? UUID().uuidString,
            "project_id": projectId,
            "body": body,
        ]
        if mode == .durable {
            guard let did = deviceId, !did.isEmpty else {
                throw DirectError.notConnected
            }
            claims["device_id"] = did
        }

        let headerJson = try JSONSerialization.data(
            withJSONObject: header, options: [.sortedKeys])
        let headerB64 = headerJson.base64URLEncodedString()
        let claimsJson = try JSONSerialization.data(
            withJSONObject: claims, options: [.sortedKeys])
        let claimsB64 = claimsJson.base64URLEncodedString()
        let signingInput = "\(headerB64).\(claimsB64)"
        guard let signingBytes = signingInput.data(using: .ascii) else {
            throw DirectError.network(
                message: "inner JWS signing input not ASCII-encodable")
        }
        let signature: Data
        do {
            signature = try signingKey.signature(for: signingBytes)
        } catch {
            throw DirectError.network(
                message: "Ed25519 sign failed",
                cause: "\(error)")
        }
        return "\(signingInput).\(signature.base64URLEncodedString())"
    }

    // ── ConcatKDF (RFC 7518 §4.6.2 / NIST SP 800-56A §5.8.1) ────────
    //
    // Same shape as `JweCodec.deriveCek` (we can't reuse the private
    // helper across modules — the codec keeps it file-private). Lifted
    // verbatim so the byte-for-byte CEK math stays in lockstep with
    // the existing L2 path; if a future refactor pulls `deriveCek`
    // out of `JweCodec` as a public helper, swap this for the shared
    // entry point.

    private static func deriveCek(
        myPriv: Curve25519.KeyAgreement.PrivateKey,
        peerPub: Curve25519.KeyAgreement.PublicKey,
        apu: String,
        apv: String
    ) throws -> Data {
        let shared: SharedSecret
        do {
            shared = try myPriv.sharedSecretFromKeyAgreement(with: peerPub)
        } catch {
            throw DirectError.network(
                message: "X25519 sharedSecretFromKeyAgreement failed",
                cause: "\(error)")
        }
        let z = shared.withUnsafeBytes { Data($0) }
        if z.count != 32 {
            throw DirectError.network(
                message: "X25519 shared secret must be 32 bytes, got " +
                         "\(z.count)")
        }
        let algId = Array(kJweEnc.utf8)
        let apuBytes = Array(apu.utf8)
        let apvBytes = Array(apv.utf8)
        var otherInfo = Data()
        otherInfo.append(uint32BE(algId.count))
        otherInfo.append(contentsOf: algId)
        otherInfo.append(uint32BE(apuBytes.count))
        otherInfo.append(contentsOf: apuBytes)
        otherInfo.append(uint32BE(apvBytes.count))
        otherInfo.append(contentsOf: apvBytes)
        otherInfo.append(uint32BE(256))
        var hashInput = Data()
        hashInput.append(uint32BE(1))
        hashInput.append(z)
        hashInput.append(otherInfo)
        let digest = SHA256.hash(data: hashInput)
        let cek = Data(digest)
        if cek.count != 32 {
            throw DirectError.network(
                message: "ConcatKDF produced \(cek.count) bytes, expected 32")
        }
        return cek
    }

    private static func uint32BE(_ v: Int) -> Data {
        var out = Data(count: 4)
        let u = UInt32(v).bigEndian
        withUnsafeBytes(of: u) { ptr in
            out.replaceSubrange(0..<4, with: ptr)
        }
        return out
    }
}
