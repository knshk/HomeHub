// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit

// ─────────────────────────────────────────────────────────────────────
// DirectRecipientResolver — pulls + caches Bifrost's X25519 enc pubkey
// AND its Ed25519 sig pubkey set from
// `{bifrostBaseUrl}/direct/v1/.well-known/jwks.json`.
//
// Bifrost publishes its key set via a single JWKS endpoint (Tier 0 —
// plaintext HTTPS). The body shape:
//
//   { "keys": [
//       { "kid": "sig-7", "kty": "OKP", "crv": "Ed25519",
//         "use": "sig", "alg": "EdDSA", "x": "<b64url 32B>" },
//       { "kid": "enc-7", "kty": "OKP", "crv": "X25519",
//         "use": "enc", "alg": "ECDH-ES", "x": "<b64url 32B>" }
//   ] }
//
// The resolver extracts BOTH:
//   * The most-recent X25519 enc key (use=='enc' or alg=='ECDH-ES') —
//     surfaced via `get()` for the request-side JWE recipient binding.
//   * The full Ed25519 sig set (use=='sig' or alg=='EdDSA') — surfaced
//     via `verifyKeys()` for the response-side JWS verifier (Fix S-1d).
//
// On `forceRefresh()` the cache is invalidated; the SDK calls this on a
// `JweDecryptFailed` response (the server's stale-kid rejection path)
// so a rotation propagates without an SDK restart.
//
// FIX S-4 (W5 fix-pass) — non-HTTPS URLs are rejected at construction
// time except for `localhost` / `127.0.0.1` (carve-out for unit tests +
// local emulator runs). A plaintext-HTTP Bifrost URL would defeat the
// entire JWE-of-JWS envelope by exposing the request-id + epk on the
// wire to any path observer; we fail-closed early so a misconfigured
// host product cannot ship plaintext FRON traffic by accident.
//
// Single-flight: concurrent callers share one in-flight task so a
// burst of pre-warm requests doesn't trigger N parallel JWKS fetches.
// ─────────────────────────────────────────────────────────────────────

/// One resolved Bifrost recipient (X25519 enc key). The codec needs
/// both the raw 32-byte pubkey AND the kid (it lands in the JWE
/// header so the server can pick the right active/previous privkey).
public struct DirectRecipient: Sendable, Equatable {
    /// JWKS `kid` for the resolved key. Goes into the outbound JWE
    /// header so the server's resolver can pick the right private
    /// counterpart from its active/previous overlap set.
    public let kid: String

    /// Raw 32-byte X25519 public key. CryptoKit's
    /// `Curve25519.KeyAgreement.PublicKey(rawRepresentation:)` accepts
    /// this verbatim.
    public let x25519Pub: Data

    public init(kid: String, x25519Pub: Data) {
        self.kid = kid
        self.x25519Pub = x25519Pub
    }
}

/// Thrown by `DirectRecipientResolver` when the configured base URL is
/// rejected at construction time. Fail-closed: the host product MUST
/// configure an HTTPS Bifrost URL (or use `localhost` / `127.0.0.1` in
/// tests).
public final class DirectInsecureBaseUrlError: LicenseStoreError {
    public init(url: URL) {
        super.init(
            "Direct mode rejected non-HTTPS bifrostBaseUrl: \(url). " +
            "Configure HTTPS (production) or http://localhost / " +
            "http://127.0.0.1 (tests only)."
        )
    }
}

/// Fetches + caches the Bifrost recipient X25519 enc key + Ed25519 sig
/// set for FRON mode.
public actor DirectRecipientResolver {

    /// Full `.well-known/jwks.json` URL (constructed at init from
    /// `bifrostBaseUrl`). `nonisolated` so call sites can read it
    /// without entering the actor (the URL is immutable after init).
    public nonisolated let url: URL

    private let session: URLSession
    private let ttl: TimeInterval
    private let timeout: TimeInterval

    private var cached: DirectRecipient?
    private var cachedVerifyKeys: [DirectVerifyKey] = []
    private var fetchedAt: Date = .distantPast
    private var inFlight: Task<DirectRecipient, Error>?

    /// Constructs the resolver. Rejects non-HTTPS schemes (except the
    /// localhost / 127.0.0.1 carve-out) so a misconfigured host product
    /// cannot accidentally ship FRON traffic over plaintext HTTP.
    public init(
        bifrostBaseUrl: URL,
        session: URLSession = .shared,
        ttl: TimeInterval = 60 * 60,
        timeout: TimeInterval = 15
    ) throws {
        try Self.assertSecureUrl(bifrostBaseUrl)
        // Defensively normalize: strip any trailing slash so appending
        // `/direct/v1/.well-known/jwks.json` doesn't double the
        // separator.
        var base = bifrostBaseUrl.absoluteString
        if base.hasSuffix("/") {
            base.removeLast()
        }
        self.url = URL(string: "\(base)/direct/v1/.well-known/jwks.json")
            ?? bifrostBaseUrl
        self.session = session
        self.ttl = ttl
        self.timeout = timeout
    }

    /// Non-throwing legacy initializer kept for source compatibility
    /// with call sites that pre-date the S-4 HTTPS pin. Production code
    /// should migrate to the throwing initializer above; this
    /// convenience traps on insecure URLs so a refactor doesn't
    /// silently re-introduce the plaintext-HTTP path.
    public static func make(
        bifrostBaseUrl: URL,
        session: URLSession = .shared,
        ttl: TimeInterval = 60 * 60,
        timeout: TimeInterval = 15
    ) throws -> DirectRecipientResolver {
        return try DirectRecipientResolver(
            bifrostBaseUrl: bifrostBaseUrl,
            session: session,
            ttl: ttl,
            timeout: timeout)
    }

    /// Returns the current recipient key, fetching if cold or stale.
    /// Mirrors `L2KeysClient.get()` so call sites are uniform.
    public func get() async throws -> DirectRecipient {
        if let c = cached, !isStale() {
            return c
        }
        return try await refresh()
    }

    /// Returns the cached Ed25519 verify-key set (the JWKS `use:"sig"`
    /// half). Populated as a side effect of `get()` / `forceRefresh()`.
    /// Used by `DirectResponseParser.parseAndVerify` to check the
    /// server's inner-JWS signature against the publisher's published
    /// pubkeys.
    public func verifyKeys() async throws -> [DirectVerifyKey] {
        if cached == nil || isStale() {
            _ = try await refresh()
        }
        return cachedVerifyKeys
    }

    /// Forces a network refresh, bypassing the TTL cache. Called by
    /// `DirectClient` after a `jweDecryptFailed` response — the most
    /// likely cause is a server-side kid rotation, so we re-poll the
    /// JWKS before the retry.
    public func forceRefresh() async throws -> DirectRecipient {
        fetchedAt = .distantPast
        cached = nil
        cachedVerifyKeys = []
        return try await refresh()
    }

    /// Drops the cached key. Used in tests + explicit `dispose()`.
    public func invalidate() {
        cached = nil
        cachedVerifyKeys = []
        fetchedAt = .distantPast
    }

    private func isStale() -> Bool {
        Date().timeIntervalSince(fetchedAt) > ttl
    }

    private func refresh() async throws -> DirectRecipient {
        if let inFlight = inFlight {
            return try await inFlight.value
        }
        let task = Task<DirectRecipient, Error> { [weak self] in
            guard let self else {
                throw NetworkError("direct_jwks: client deallocated")
            }
            return try await self.doFetch()
        }
        inFlight = task
        defer { inFlight = nil }
        return try await task.value
    }

    private func doFetch() async throws -> DirectRecipient {
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.timeoutInterval = timeout

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: req)
        } catch let e as URLError where e.code == .timedOut {
            throw NetworkError("direct_jwks: timeout", cause: e)
        } catch {
            throw NetworkError(
                "direct_jwks: \(error.localizedDescription)",
                cause: error)
        }

        guard let http = response as? HTTPURLResponse else {
            throw NetworkError("direct_jwks: non-HTTP response")
        }
        if !(200...299).contains(http.statusCode) {
            throw NetworkError(
                "direct_jwks: HTTP \(http.statusCode)",
                statusCode: http.statusCode)
        }

        let body: [String: Any]
        do {
            guard let parsed = try JSONSerialization.jsonObject(with: data)
                as? [String: Any] else {
                throw NetworkError("direct_jwks: body is not a JSON object")
            }
            body = parsed
        } catch let e as LicenseStoreError {
            throw e
        } catch {
            throw NetworkError("direct_jwks: malformed body: \(error)",
                               cause: error)
        }

        guard let keys = body["keys"] as? [[String: Any]] else {
            throw NetworkError("direct_jwks: missing keys array")
        }
        // Pick the FIRST X25519 enc key. The server publishes at most
        // one active + one previous; the active row comes first per
        // the publisher's ordering, so this is correct.
        var picked: DirectRecipient?
        var sigKeys: [DirectVerifyKey] = []
        for jwk in keys {
            guard let kty = jwk["kty"] as? String, kty == "OKP" else { continue }
            let use = jwk["use"] as? String
            let alg = jwk["alg"] as? String
            guard let kid = jwk["kid"] as? String, !kid.isEmpty,
                  let xStr = jwk["x"] as? String,
                  let xBytes = Data(base64URLEncoded: xStr),
                  xBytes.count == 32 else {
                continue
            }
            switch (jwk["crv"] as? String) {
            case "X25519":
                if picked == nil && (use == "enc" || alg == "ECDH-ES") {
                    picked = DirectRecipient(kid: kid, x25519Pub: xBytes)
                }
            case "Ed25519":
                if use == "sig" || alg == "EdDSA" {
                    sigKeys.append(DirectVerifyKey(kid: kid, publicKey: xBytes))
                }
            default:
                continue
            }
        }
        guard let recipient = picked else {
            throw NetworkError("direct_jwks: no X25519 enc key published")
        }
        cached = recipient
        cachedVerifyKeys = sigKeys
        fetchedAt = Date()
        return recipient
    }

    // ── S-4 HTTPS pin ─────────────────────────────────────────────────

    /// Validates that `url` uses `https://` OR is a loopback `http://`
    /// host (localhost / 127.0.0.1 — for unit tests + local emulator
    /// loops). Anything else throws `DirectInsecureBaseUrlError`.
    ///
    /// Loopback IPv6 (`::1`) is also accepted; CIDR matching is
    /// deliberately omitted (a misconfigured RFC1918 private network
    /// like 10.0.0.x is NOT a safe carve-out — exposing FRON traffic
    /// to a corporate LAN observer still defeats the envelope's
    /// confidentiality properties).
    static func assertSecureUrl(_ url: URL) throws {
        let scheme = (url.scheme ?? "").lowercased()
        if scheme == "https" { return }
        if scheme == "http" {
            let host = (url.host ?? "").lowercased()
            // Strip percent-escapes IPv6 brackets keep on the host
            // component (e.g. `[::1]` → `::1` is the form URL.host
            // returns on Apple platforms).
            if host == "localhost" || host == "127.0.0.1" || host == "::1" {
                return
            }
        }
        throw DirectInsecureBaseUrlError(url: url)
    }
}
