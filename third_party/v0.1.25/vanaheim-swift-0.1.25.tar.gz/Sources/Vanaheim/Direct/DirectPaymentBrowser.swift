// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

#if canImport(AuthenticationServices) && (os(iOS) || os(macOS) || targetEnvironment(macCatalyst))
import AuthenticationServices

// ─────────────────────────────────────────────────────────────────────
// DirectPaymentBrowser — host-app-side glue for opening checkout /
// portal URLs in an in-app browser AND surfacing the return-URL
// callback to the SDK.
//
// We use `ASWebAuthenticationSession` (iOS 12+ / macOS 10.15+ /
// macCatalyst 13+) rather than `SFSafariViewController` for two
// reasons:
//
//   1. ASWebAuthenticationSession returns the return-URL via an OS-
//      level callback once the user lands on the configured scheme.
//      SFSafariViewController would require the host app to wire its
//      own `UIApplication.openURL` / scene-delegate plumbing — that
//      is fragile (universal-link entitlement glue) and easy to get
//      wrong (return-URL spoofing).
//
//   2. ASWebAuthenticationSession runs inside a separate process so
//      the host app's tab state is isolated from any provider-side
//      cookies — defence-in-depth against cookie pollution.
//
// The browser helper is NOT a hard dependency of the payment surface:
//   - The wire calls (`startCheckout` / `openPortal`) work without it.
//   - A host product that wants its own browser glue (e.g. a custom
//     in-app `WKWebView` with extra UI) can ignore this helper and
//     consume the `CheckoutSession.hostedUrl` / `PortalSession.portalUrl`
//     directly.
//
// SECURITY:
//   - Scheme pinning: the host product MUST pass the deep-link
//     callback scheme (matching its `Info.plist` URL scheme +
//     `Associated Domains` entitlement). The browser refuses to open
//     a session when the configured scheme is empty.
//   - The browser never logs the hosted URL (could carry one-shot
//     query-string tokens).
//   - Return-URL host equality is checked against the originally-
//     requested return URL — a provider that redirects us to a
//     different host (e.g. an attacker-controlled redirect chain)
//     surfaces as `.returnUrlMismatch`.
// ─────────────────────────────────────────────────────────────────────

/// Callback fired when the in-app browser session resolves. Wired by
/// the host app and invoked by `DirectPaymentBrowser` (or directly
/// from the host product's own URL-scheme handler — the typealias is
/// reused on both code paths so the host product's binding shape is
/// uniform).
///
/// `Result.success(URL)` is the full return URL the provider
/// redirected to (with all query params intact); the host product
/// can extract `session_id` / `payment_intent` / etc. from it.
public typealias DeepLinkReturnHandler = @Sendable (Result<URL, Error>) -> Void

/// Errors surfaced from `DirectPaymentBrowser` open calls. These are
/// CLIENT-side (no wire round-trip happened) so they live outside the
/// `DirectError` taxonomy (which is reserved for FRON wire mappings).
public enum DirectPaymentBrowserError: Error, CustomStringConvertible, Sendable {
    /// The user dismissed the in-app browser without completing the
    /// flow. Equivalent to `ASWebAuthenticationSessionError.canceledLogin`.
    case userCancelled

    /// No deep-link callback scheme was configured. The host product
    /// MUST pass a non-empty `callbackScheme` to
    /// `DirectPaymentBrowser(...)`.
    case missingCallbackScheme

    /// The browser returned a URL on the configured scheme but the
    /// host portion did not match the originally-requested URL — a
    /// possible redirect-chain attack. Surfaced as a typed error so
    /// the host product fails-closed.
    case returnUrlMismatch(expectedHost: String, gotHost: String?)

    /// `ASWebAuthenticationSession` failed to start (typically a
    /// presentation-context anchor mis-config).
    case sessionFailedToStart

    /// Generic underlying failure from the OS-level session.
    case underlying(String)

    public var description: String {
        switch self {
        case .userCancelled:
            return "DirectPaymentBrowserError.userCancelled"
        case .missingCallbackScheme:
            return "DirectPaymentBrowserError.missingCallbackScheme"
        case .returnUrlMismatch(let exp, let got):
            return "DirectPaymentBrowserError.returnUrlMismatch(expected=\(exp), got=\(got ?? "<nil>"))"
        case .sessionFailedToStart:
            return "DirectPaymentBrowserError.sessionFailedToStart"
        case .underlying(let m):
            return "DirectPaymentBrowserError.underlying(\(m))"
        }
    }
}

/// In-app browser façade for opening `CheckoutSession.hostedUrl` /
/// `PortalSession.portalUrl` and awaiting the return-URL callback.
///
/// USAGE:
/// ```swift
/// let browser = DirectPaymentBrowser(callbackScheme: "myapp")
/// let returnUrl = try await browser.openCheckoutUrl(checkout)
/// // returnUrl carries session_id / status query params from the provider
/// let fresh = try await client.refreshAfterPayment(sessionId: checkout.sessionId)
/// ```
///
/// CONCURRENCY: this type is `@MainActor`-bound. ASWebAuthenticationSession
/// MUST be created + started on the main actor (it presents UI). The
/// `open*` methods are `async` so they suspend cleanly while the user
/// drives the in-app browser.
@available(iOS 12.0, macOS 10.15, macCatalyst 13.0, *)
@MainActor
public final class DirectPaymentBrowser: NSObject {

    /// Deep-link scheme the provider redirects to (e.g. "myapp" if the
    /// host's `Info.plist` declares `myapp://payment-return`). The
    /// scheme is forwarded verbatim to ASWebAuthenticationSession,
    /// which gates the OS-level callback on a scheme match.
    public let callbackScheme: String

    /// Whether to use a private (non-persistent) browser session.
    /// Default `true` — payment URLs MUST NOT share cookies with the
    /// host app's tab state.
    public let usesEphemeralSession: Bool

    /// Optional presentation-context provider. iOS/macCatalyst require
    /// one; we fall back to `DefaultPresentationContextProvider` (a
    /// best-effort lookup against the active window scene) when the
    /// host product does not supply one. macOS uses the key window
    /// implicitly.
    public weak var presentationProvider: ASWebAuthenticationPresentationContextProviding?

    /// Live session reference — retained until the callback resolves.
    /// `_session` is `@MainActor`-isolated; the session API itself is
    /// MainActor-bound.
    private var liveSession: ASWebAuthenticationSession?

    public init(
        callbackScheme: String,
        usesEphemeralSession: Bool = true,
        presentationProvider: ASWebAuthenticationPresentationContextProviding? = nil
    ) {
        self.callbackScheme = callbackScheme
        self.usesEphemeralSession = usesEphemeralSession
        self.presentationProvider = presentationProvider
        super.init()
    }

    // ── Public façade — open URLs + await return-URL callback ───────

    /// Opens `checkout.hostedUrl` in the in-app browser and suspends
    /// until the user either completes the flow (lands on the
    /// configured scheme) or cancels.
    ///
    /// Returns the return URL the provider redirected to — the host
    /// product can extract provider-side query params (e.g.
    /// `session_id`) from it before calling
    /// `DirectClient.refreshAfterPayment(sessionId:)`.
    @discardableResult
    public func openCheckoutUrl(
        _ checkout: CheckoutSession
    ) async throws -> URL {
        return try await openUrl(checkout.hostedUrl)
    }

    /// Opens `portal.portalUrl` in the in-app browser. Same return
    /// shape as `openCheckoutUrl(_:)`.
    @discardableResult
    public func openPortalUrl(
        _ portal: PortalSession
    ) async throws -> URL {
        return try await openUrl(portal.portalUrl)
    }

    /// Lower-level entry point — opens any HTTPS URL in the in-app
    /// browser. Used by both `openCheckoutUrl` and `openPortalUrl`.
    /// The URL's hostname is captured for the post-callback host
    /// equality check (defence against redirect-chain attacks).
    ///
    /// FIX S-1 (W6 fix-pass) — REJECT non-https URLs at the SDK layer.
    /// The server-side allowlist on `return_url` already pins this, but
    /// surfacing locally prevents a `http://` / `javascript:` / `file:`
    /// URL from ever reaching ASWebAuthenticationSession (which would
    /// otherwise render the page in a system-level browser, defeating
    /// the response-seal protections). The only exception is the
    /// caller-configured deep-link CALLBACK scheme — that lives on the
    /// post-flow callback URL the provider redirects TO, never on the
    /// hosted URL we OPEN. We surface as `DirectError.badRequest` so
    /// the host product's payment-side `catch let e as DirectError`
    /// handler bins it with every other client-side validation miss.
    public func openUrl(_ url: URL) async throws -> URL {
        // S-Fix 1 — pin https on the URL we hand to ASWebAuthenticationSession.
        // Custom schemes (e.g. `myapp://`) would either fail to load or
        // open in an unexpected handler — neither outcome is safe.
        guard let urlScheme = url.scheme?.lowercased(),
              urlScheme == "https" else {
            throw DirectError.badRequest(reason: "non_https_browser_url")
        }
        // Defensive: empty callback scheme would make
        // ASWebAuthenticationSession's callback predicate always
        // false — the user would be stuck on the hosted page with no
        // way back. Surface as a typed config error.
        if callbackScheme.isEmpty {
            throw DirectPaymentBrowserError.missingCallbackScheme
        }
        // The originally-requested host. We accept a redirect chain
        // INSIDE the provider (the provider can move the user across
        // its own subdomains during checkout) — the callback host
        // equality check below pins on the CALLBACK URL's scheme +
        // path matching, NOT on the provider's intermediate hosts.

        return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<URL, Error>) in
            let scheme = self.callbackScheme
            let session = ASWebAuthenticationSession(
                url: url,
                callbackURLScheme: scheme
            ) { callbackUrl, error in
                // Single-shot teardown — release the strong session
                // ref on the next main-actor tick so the OS can
                // tear down the WKWebView without racing self.
                Task { @MainActor in
                    self.liveSession = nil
                }
                if let e = error {
                    if let asError = e as? ASWebAuthenticationSessionError,
                       asError.code == .canceledLogin {
                        cont.resume(throwing: DirectPaymentBrowserError.userCancelled)
                    } else {
                        cont.resume(throwing:
                            DirectPaymentBrowserError.underlying(String(describing: e)))
                    }
                    return
                }
                guard let cb = callbackUrl else {
                    cont.resume(throwing:
                        DirectPaymentBrowserError.underlying("no callback URL"))
                    return
                }
                // Scheme pin: ASWebAuthenticationSession already gates
                // on `callbackURLScheme` matching, so this should
                // always pass — we double-check as defence-in-depth.
                if (cb.scheme?.lowercased() ?? "") != scheme.lowercased() {
                    cont.resume(throwing:
                        DirectPaymentBrowserError.returnUrlMismatch(
                            expectedHost: scheme, gotHost: cb.scheme))
                    return
                }
                cont.resume(returning: cb)
            }
            if self.usesEphemeralSession {
                session.prefersEphemeralWebBrowserSession = true
            }
            // Wire the presentation provider. iOS + macCatalyst REQUIRE
            // one; macOS infers from the key window.
            #if os(iOS) || targetEnvironment(macCatalyst)
            if let provider = self.presentationProvider {
                session.presentationContextProvider = provider
            } else {
                let fallback = DefaultPresentationContextProvider()
                session.presentationContextProvider = fallback
                // Keep the fallback alive for the session's lifetime
                // — ASWebAuthenticationSession holds a `weak` ref.
                objc_setAssociatedObject(
                    session,
                    &Self.presentationProviderAssocKey,
                    fallback,
                    .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
            }
            #endif
            self.liveSession = session
            if !session.start() {
                self.liveSession = nil
                cont.resume(throwing: DirectPaymentBrowserError.sessionFailedToStart)
            }
        }
    }

    /// Cancel the in-flight session if one is active. The pending
    /// `openUrl(_:)` continuation will resume with `.userCancelled`
    /// via the underlying ASWebAuthenticationSession callback.
    public func cancel() {
        liveSession?.cancel()
        liveSession = nil
    }

    // ── Deep-link return handler (alternative entry point) ──────────

    /// Host-app-side bridge to call from a custom URL-scheme handler
    /// (e.g. `SceneDelegate.scene(_:openURLContexts:)` or the SwiftUI
    /// `.onOpenURL` modifier) when the host product is NOT routing the
    /// callback through `ASWebAuthenticationSession`. The handler MUST
    /// be set BEFORE the user starts the checkout / portal flow.
    ///
    /// USAGE:
    /// ```swift
    /// // In SwiftUI:
    /// .onOpenURL { url in
    ///     DirectPaymentBrowser.deepLinkReturnHandler?(.success(url))
    /// }
    /// ```
    public static var deepLinkReturnHandler: DeepLinkReturnHandler?

    /// One-shot helper for host products that want the handler to
    /// auto-clear after firing (so a second deep-link doesn't trigger
    /// stale wiring). Wires the supplied closure as
    /// `deepLinkReturnHandler` and returns the same closure for
    /// reference equality.
    @discardableResult
    public static func setDeepLinkReturnHandler(
        _ handler: @escaping DeepLinkReturnHandler
    ) -> DeepLinkReturnHandler {
        Self.deepLinkReturnHandler = handler
        return handler
    }

    /// Clears any previously-set deep-link handler.
    public static func clearDeepLinkReturnHandler() {
        Self.deepLinkReturnHandler = nil
    }

    // ── Internals ──────────────────────────────────────────────────

    private static var presentationProviderAssocKey: UInt8 = 0
}

// ── Default presentation context provider ──────────────────────────

#if os(iOS) || targetEnvironment(macCatalyst)
import UIKit

/// Best-effort default presentation provider — walks the active
/// window scene for a key window. The host product SHOULD pass an
/// explicit provider for production use (this fallback is for the
/// 95% case where the host has a single foregrounded scene).
@available(iOS 13.0, *)
@MainActor
final class DefaultPresentationContextProvider: NSObject, ASWebAuthenticationPresentationContextProviding {
    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        // Walk all connected scenes and return the first foreground-
        // active window. Fall back to a fresh empty anchor on miss —
        // ASWebAuthenticationSession will surface a startup failure
        // through its completion handler in that case.
        for scene in UIApplication.shared.connectedScenes {
            guard let windowScene = scene as? UIWindowScene,
                  windowScene.activationState == .foregroundActive else {
                continue
            }
            if let key = windowScene.windows.first(where: { $0.isKeyWindow }) {
                return key
            }
            if let first = windowScene.windows.first {
                return first
            }
        }
        return ASPresentationAnchor()
    }
}
#endif

#endif // canImport(AuthenticationServices)
