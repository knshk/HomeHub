// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

// ─────────────────────────────────────────────────────────────────────
// DirectHeartbeatScheduler — periodic heartbeat with offline-skip +
// resume.
//
// Cadence is server-controlled: the SDK pulls `heartbeat_cadence_ms`
// from the register response (or `nextHeartbeatAfterMs` from the most
// recent heartbeat response) and schedules a one-shot task at that
// interval. Each tick fires `runHeartbeat()` which is supplied by
// `DirectClient` as a closure — keeps this file decoupled from the
// rest of the FRON surface.
//
// Offline-skip strategy: a network error on a heartbeat tick is
// SWALLOWED (logged via the supplied logger but NOT propagated) — the
// heartbeat is best-effort; an offline window shouldn't poison the
// scheduler. The next scheduled tick still runs at the requested
// cadence; if connectivity is back by then, the heartbeat resumes
// naturally.
//
// We do NOT integrate with a system-level connectivity monitor (e.g.
// `NWPathMonitor`) here — the Vanaheim Swift codebase doesn't ship
// one as of Wave 11, and the spec language says "use the existing
// platform connectivity monitor if there is one; otherwise a simple
// periodic timer that catches + logs network errors." We take the
// latter: a periodic Task.sleep loop with try? around the closure.
//
// Concurrency: actor-isolated so start/stop/updateCadence cannot race.
// The scheduling loop runs as a detached Task that observes the
// `running` flag to exit cleanly on stop().
// ─────────────────────────────────────────────────────────────────────

/// Closure type the scheduler invokes on each tick. Throwing is fine —
/// the scheduler catches + logs.
public typealias DirectHeartbeatTick = @Sendable () async throws -> Void

/// Periodic heartbeat scheduler. Construct once per `DirectClient`
/// instance; call `start(...)` after `register()` succeeds.
public actor DirectHeartbeatScheduler {

    /// Current cadence in milliseconds. Updated by `updateCadence(_:)`
    /// after each heartbeat response — the next scheduled tick honours
    /// the new value.
    private var cadenceMs: Int

    /// Closure invoked on each tick. Set in `start(tick:)`.
    private var tick: DirectHeartbeatTick?

    /// `true` while the scheduler is active. The running loop checks
    /// this between ticks and exits when it flips to `false`.
    private var running: Bool = false

    /// Live loop task. Held so `stop()` can cancel + await its exit.
    private var loop: Task<Void, Never>?

    public init(initialCadenceMs: Int) {
        self.cadenceMs = initialCadenceMs
    }

    /// Starts the heartbeat loop. Idempotent — a second call while
    /// `running` is a no-op.
    public func start(tick: @escaping DirectHeartbeatTick) {
        if running { return }
        running = true
        self.tick = tick
        loop = Task { [weak self] in
            await self?.runLoop()
        }
    }

    /// Stops the heartbeat loop. The currently in-flight tick (if any)
    /// runs to completion; the loop exits on its next check.
    public func stop() {
        running = false
        loop?.cancel()
        loop = nil
        tick = nil
    }

    /// Updates the cadence used by subsequent ticks. Honours
    /// `nextHeartbeatAfterMs` from the server's heartbeat response.
    public func updateCadence(_ newCadenceMs: Int) {
        // Defensive bounds: anything < 1s or > 1d is almost certainly a
        // server-side bug; clamp rather than crash.
        let clamped = max(1000, min(newCadenceMs, 24 * 60 * 60 * 1000))
        cadenceMs = clamped
    }

    /// True iff the scheduler is currently running. Useful for
    /// diagnostics.
    public var isRunning: Bool { running }

    /// Snapshot of the cadence the next tick will honour.
    public var currentCadenceMs: Int { cadenceMs }

    // MARK: - Internals

    private func runLoop() async {
        while running {
            let delayNs = UInt64(cadenceMs) * 1_000_000
            do {
                try await Task.sleep(nanoseconds: delayNs)
            } catch is CancellationError {
                return
            } catch {
                return
            }
            if !running { return }
            if let tick = tick {
                do {
                    try await tick()
                } catch {
                    // Best-effort: log + swallow. Offline-skip is the
                    // load-bearing behaviour here; a thrown error from
                    // the closure (typically `DirectError.network` /
                    // .notConnected) MUST NOT kill the scheduler.
                    // The next tick still runs at the same cadence.
                    //
                    // We deliberately do NOT use os_log / Logger here
                    // — the Vanaheim SDK keeps logging behind the
                    // host-product-supplied telemetry surface so the
                    // SDK doesn't unilaterally spam the console. The
                    // host product will observe heartbeat failures
                    // via the `reportError(...)` channel if the
                    // closure surfaces them.
                    _ = error
                }
            }
        }
    }
}
