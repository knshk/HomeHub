// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

// ─────────────────────────────────────────────────────────────────────
// DirectFcmBridge — wires APNS token changes to
// `DirectClient.registerFcmToken`.
//
// On Apple platforms the host product receives an APNs device token in
// `application(_:didRegisterForRemoteNotificationsWithDeviceToken:)`
// (or the SwiftUI `@Environment(\.notificationServiceProxy)` shim).
// The product should pipe that token into the SDK via `submit(token:
// platform:)` whenever it changes — the bridge dedupes against the
// last-sent value and only triggers the server call on real changes.
//
// The spec calls this "FCM" for unified-vocabulary across iOS / Android
// / web; the FRON server's `/notifications/register-fcm` endpoint
// accepts any of those platforms (the `platform` field is the
// discriminator).
//
// The bridge is a thin coordinator: the actual `submit(...)` flow is
// just (1) skip if the new token == last-sent token, (2) call the
// supplied closure which is `DirectClient.registerFcmToken` wrapped in
// a Sendable closure. We do NOT spin up our own token-fetch loop —
// that's the host product's job (APNs delivery is async via
// AppDelegate / NSAppDelegate callbacks; the SDK can't intercept it
// without adding a UIKit / AppKit dependency).
//
// Concurrency: actor-isolated so `lastSentToken` is a stable
// single-writer slot.
// ─────────────────────────────────────────────────────────────────────

/// Closure invoked by the bridge when the host product submits a new
/// token. The bridge's caller (`DirectClient`) wires this to the FRON
/// register-fcm endpoint.
public typealias DirectFcmSubmitCallback =
    @Sendable (String, DirectPushPlatform) async throws -> Void

/// Lightweight FCM/APNs token coordinator. Dedupes on identical
/// re-submissions so a noisy AppDelegate doesn't spam the server.
public actor DirectFcmBridge {
    private var lastSentToken: String?
    private var submitCallback: DirectFcmSubmitCallback?

    public init() {}

    /// Wires the bridge to its server-side submitter. Idempotent; a
    /// second call replaces the prior callback.
    public func attach(_ callback: @escaping DirectFcmSubmitCallback) {
        submitCallback = callback
    }

    /// Drops the callback so subsequent `submit(...)` calls become
    /// no-ops. Useful in `DirectClient.deactivate(...)` so the SDK
    /// stops forwarding tokens once the user signs out.
    public func detach() {
        submitCallback = nil
    }

    /// Host product calls this whenever APNs / FCM / web-push hands
    /// over a token. The bridge dedupes against the last value and
    /// forwards on a real change. Empty / nil tokens are dropped
    /// silently (an empty token means the OS hasn't issued one yet).
    public func submit(
        token: String,
        platform: DirectPushPlatform
    ) async throws {
        let trimmed = token.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return }
        if trimmed == lastSentToken { return }
        guard let callback = submitCallback else {
            // Bridge not yet attached — silently drop. The next
            // submit after `attach(...)` will retry.
            return
        }
        try await callback(trimmed, platform)
        // Only update on a successful server-side accept so a
        // transient failure doesn't suppress the next retry.
        lastSentToken = trimmed
    }

    /// Forces the bridge to forget its last-sent token so the next
    /// `submit(...)` always reaches the server. Use after a
    /// `deactivate(...)` to ensure the post-reactivate first token
    /// goes through.
    public func reset() {
        lastSentToken = nil
    }

    /// Snapshot of the last successfully-forwarded token. Useful for
    /// diagnostics.
    public var currentToken: String? { lastSentToken }
}

/// Convenience helper: convert a raw APNs device-token blob (Data) to
/// the lowercase hex string the host product passes into `submit(...)`.
/// Provided as a stand-alone helper rather than a method so it works
/// off-actor too.
///
/// The FRON server doesn't care about the encoding — it just persists
/// whatever the SDK forwards. We pick hex because it's the historical
/// Apple convention; if a future host product wants to ship the raw
/// base64 instead, that's fine too.
public func directFcmTokenHexFromAPNsDeviceToken(_ token: Data) -> String {
    return token.map { String(format: "%02x", $0) }.joined()
}
