// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

// ─────────────────────────────────────────────────────────────────────
// DirectConfig — knobs specific to the FRON / Direct mode (mode='fron').
//
// Why a separate config struct (rather than extending VanaheimConfig
// in-place):
//   * VanaheimConfig already locks in `l2BaseUrl`, `jweDecryptor`, and
//     `deviceKeypairProvider` as REQUIRED fields. Direct mode does not
//     use L2 at all — its recipient resolver targets Bifrost via the
//     FRON well-known JWKS, and the device keypair is generated +
//     persisted by `DirectKeypairStore` not by the L2-flavoured
//     KeychainDeviceKeypairProvider.
//   * Splitting the config keeps the existing call sites untouched.
//     `LicenseClient.connect(...)` still requires VanaheimConfig with
//     mode='l2' (the default); a host product that wants FRON instead
//     constructs `DirectClient.connect(...)` with `DirectConfig`.
//
// The `VanaheimConfigMode` enum on the L2 surface (see Config.swift
// mod) is the SINGLE switch the host product flips to opt into Direct;
// the rest of the surface (DirectClient construction, DirectConfig
// fields) is opt-in additive.
// ─────────────────────────────────────────────────────────────────────

/// SDK transport mode. `l2` is the legacy path through Alfheim;
/// `fron` is the direct-to-Bifrost path that bypasses the L2 tier
/// entirely. Default is `l2` for backward compat.
public enum VanaheimConfigMode: String, Sendable, Equatable {
    case l2
    case fron
}

/// Configuration for `DirectClient` (FRON mode). All HTTPS calls go to
/// `bifrostBaseUrl`; the SDK pulls the recipient X25519 pubkey from
/// `{bifrostBaseUrl}/direct/v1/.well-known/jwks.json` on `connect()`.
public struct DirectConfig: Sendable {
    /// Project identifier — every FRON request carries this in the
    /// inner JWS claim `project_id`. Cross-checked against the JWS
    /// verifier middleware's notion of the project; mismatches are
    /// treated as a credentials-presentation attack on the server side.
    public let projectId: String

    /// Base URL of the Bifrost deployment (e.g.
    /// `https://us-central1-licenses-prod.cloudfunctions.net/bifrost`).
    /// The SDK appends `/direct/v1/*` to this base for every endpoint.
    public let bifrostBaseUrl: URL

    /// Pinned SPKI SHA-256 hashes for the API server cert. At least one
    /// pin is required in production; pass an empty list only in tests.
    public let pinnedSpkiSha256: [String]

    /// Cache TTL for the JWKS lookup. Default 1 h — matches the server-
    /// side `Cache-Control: public, max-age=3600` on the Direct JWKS
    /// route.
    public let jwksCacheTtl: TimeInterval

    /// HTTP request timeout. Default 15 s.
    public let httpTimeout: TimeInterval

    /// Allowed clock skew when verifying inner-JWS `iat` / `nbf` / `exp`
    /// claims minted by the server (response envelopes). Default 60 s —
    /// matches the FRON server-side allowance.
    public let clockSkew: TimeInterval

    /// Default heartbeat cadence in milliseconds, used until the server
    /// overrides it via `RegisterResult.heartbeatCadenceMs`. Default
    /// 5 min.
    public let defaultHeartbeatCadenceMs: Int

    /// Stats batcher cadence — interval after which the buffer auto-
    /// flushes regardless of fill level. Default 5 min.
    public let statsFlushInterval: TimeInterval

    /// Stats batcher size threshold — when the in-memory ring buffer
    /// reaches this count it flushes immediately. Default 50.
    public let statsFlushBatchSize: Int

    /// Maximum number of events the stats ring buffer retains in memory
    /// before dropping the oldest. Default 500 — generous but bounded
    /// so a long offline window cannot blow memory.
    public let statsBufferCapacity: Int

    /// Lifetime of one Tier-1 / Tier-2 inner JWS (ms). The token's
    /// `exp` is set to `iat + jwsTokenLifetimeMs`. Default 60 s.
    public let jwsTokenLifetimeMs: Int

    public init(
        projectId: String,
        bifrostBaseUrl: URL,
        pinnedSpkiSha256: [String] = [],
        jwksCacheTtl: TimeInterval = 60 * 60,
        httpTimeout: TimeInterval = 15,
        clockSkew: TimeInterval = 60,
        defaultHeartbeatCadenceMs: Int = 5 * 60 * 1000,
        statsFlushInterval: TimeInterval = 5 * 60,
        statsFlushBatchSize: Int = 50,
        statsBufferCapacity: Int = 500,
        jwsTokenLifetimeMs: Int = 60 * 1000
    ) {
        self.projectId = projectId
        self.bifrostBaseUrl = bifrostBaseUrl
        self.pinnedSpkiSha256 = pinnedSpkiSha256
        self.jwksCacheTtl = jwksCacheTtl
        self.httpTimeout = httpTimeout
        self.clockSkew = clockSkew
        self.defaultHeartbeatCadenceMs = defaultHeartbeatCadenceMs
        self.statsFlushInterval = statsFlushInterval
        self.statsFlushBatchSize = statsFlushBatchSize
        self.statsBufferCapacity = statsBufferCapacity
        self.jwsTokenLifetimeMs = jwsTokenLifetimeMs
    }
}
