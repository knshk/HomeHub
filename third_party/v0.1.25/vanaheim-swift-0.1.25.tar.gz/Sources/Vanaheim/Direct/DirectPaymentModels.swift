// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

// ─────────────────────────────────────────────────────────────────────
// DirectPaymentModels — value types returned from the W6 payment
// surface (`DirectClient`'s payment extension in
// `DirectPaymentClient.swift`).
//
// Shape mirrors the Dart twin (sdk/dart/vanaheim/lib/src/direct/
// direct_payment_models.dart) field-for-field so a host product written
// against either SDK can re-skin against the other without reshaping
// the payment-model layer.
//
// Wire-shape source-of-truth lives in
// `bifrost/packages/functions/src/direct/handlers/payment.ts` — every
// field here maps to a snake-cased key on the FRON `sendDirectJweResponse`
// payload. Camel-case at the SDK surface, snake-case on the wire.
//
// None of these types depend on the L2 (`LicenseClient`) surface — the
// payment surface is FRON-only and the L2 path has its own billing
// surface (`SubscriptionAPI` + `OffersAPI`) that is intentionally not
// reused here so the two evolve independently.
// ─────────────────────────────────────────────────────────────────────

// ── Provider + platform discriminators ──────────────────────────────

/// Payment-provider tag accepted on `startCheckout(...)` /
/// `startNativePayment(...)`. The server-side `paymentConfig` gates
/// per-project overrides — passing a provider here when the project has
/// not opted into `allow_provider_override` surfaces as a
/// `DirectError.badRequest`. Pass `nil` (default) to use the project's
/// configured default provider.
public enum DirectPaymentProvider: String, Sendable, Equatable {
    case stripe
    case paddle
    case lemonSqueezy = "lemon_squeezy"
    case razorpay
}

/// Native-payment platform. Drives the server-side adapter selection
/// (Apple Pay vs Google Pay vs Stripe Payment Element) and the
/// `intent.platform` field on the persisted intent_id ↔ device link.
public enum DirectNativePaymentPlatform: String, Sendable, Equatable {
    case ios
    case android
    case web
}

/// IAP receipt-verification platform. Restricted to the two app-store
/// flavours that ship a server-side verify API.
public enum DirectIapPlatform: String, Sendable, Equatable {
    case ios
    case android
}

/// Billing cadence on a checkout / native-payment session.
public enum DirectBillingCycle: String, Sendable, Equatable {
    case monthly
    case yearly
}

// ── Result types ────────────────────────────────────────────────────

/// Result of `DirectClient.startCheckout(...)`. The host product opens
/// `hostedUrl` in an in-app browser (via the
/// `DirectPaymentBrowser` helper on Apple platforms) and awaits the
/// return-URL callback; once the user lands back on the deep-link, the
/// host calls `refreshAfterPayment(sessionId:)` to pull a fresh
/// entitlement.
public struct CheckoutSession: Sendable, Equatable {
    /// Provider-minted session id (Stripe `cs_*`, Paddle / LS / Razorpay
    /// equivalents). The SDK threads this back through
    /// `refreshAfterPayment(sessionId:)`.
    public let sessionId: String

    /// Hosted-checkout URL the user is sent to. The SDK does NOT log
    /// this URL (the wire shape never traces it) — provider URLs can
    /// carry one-shot tokens on the query string.
    public let hostedUrl: URL

    /// Provider-side expiry for the hosted session, in ms-since-epoch.
    /// The SDK's `startCheckout(...)` returns this verbatim so the
    /// host product can render a "session expires in N minutes" UX.
    public let expiresAtMs: Int

    public init(sessionId: String, hostedUrl: URL, expiresAtMs: Int) {
        self.sessionId = sessionId
        self.hostedUrl = hostedUrl
        self.expiresAtMs = expiresAtMs
    }
}

/// Result of `DirectClient.startNativePayment(...)`. The host product
/// passes `clientSecret` into the platform's native payment sheet (e.g.
/// `STPPaymentSheet`, Google Pay's `PaymentDataRequest`); the actual
/// payment capture happens via webhook on the server side.
public struct PaymentIntent: Sendable, Equatable {
    /// Provider intent id (Stripe `pi_*` etc.). The SDK does NOT
    /// drive the payment sheet directly — the host product passes
    /// this back to the platform SDK alongside `clientSecret`.
    public let intentId: String

    /// Provider client-secret used to authorise the platform's
    /// native sheet. Treat as SECRET — the SDK does not persist it
    /// and the host product should not log it.
    public let clientSecret: String

    /// Provider-side expiry for the intent, in ms-since-epoch.
    public let expiresAtMs: Int

    public init(intentId: String, clientSecret: String, expiresAtMs: Int) {
        self.intentId = intentId
        self.clientSecret = clientSecret
        self.expiresAtMs = expiresAtMs
    }
}

/// Result of `DirectClient.openPortal(...)`. The host product opens
/// `portalUrl` in an in-app browser via the `DirectPaymentBrowser`
/// helper.
public struct PortalSession: Sendable, Equatable {
    /// Provider-managed portal URL (Stripe Billing Portal, Paddle
    /// customer portal, etc.).
    public let portalUrl: URL

    /// Provider-side expiry for the portal session, in ms-since-epoch.
    public let expiresAtMs: Int

    public init(portalUrl: URL, expiresAtMs: Int) {
        self.portalUrl = portalUrl
        self.expiresAtMs = expiresAtMs
    }
}

/// One restored purchase row returned from
/// `DirectClient.restorePurchases(...)`. The SDK presents the array
/// verbatim — the host product picks whichever row drives its UX
/// (typically the highest `validUntil`).
public struct RestoredPurchase: Sendable, Equatable {
    /// User-visible license key tied to the restored purchase.
    public let licenseKey: String
    /// Tier slug (matches the catalog tier id).
    public let tier: String
    /// Expiry, in ms-since-epoch. The host product reads this to
    /// decide whether the purchase is still useful (expired
    /// purchases ARE still returned so the user can see them).
    public let validUntil: Int

    public init(licenseKey: String, tier: String, validUntil: Int) {
        self.licenseKey = licenseKey
        self.tier = tier
        self.validUntil = validUntil
    }
}

/// Result of `DirectClient.restorePurchases(...)`. When `restoredCount`
/// is zero the server returns `entitlementJws == nil` — the SDK can
/// branch on the wire shape without parsing the empty array.
///
/// INVARIANT (B-FRON.5.4): `restoredCount > 0` implies
/// `entitlementJws != nil`; the server hard-fails restore on mint
/// errors rather than admitting a contradictory shape.
public struct RestoreResult: Sendable, Equatable {
    public let restored: [RestoredPurchase]
    public let entitlementJws: String?
    public let restoredCount: Int

    public init(
        restored: [RestoredPurchase],
        entitlementJws: String?,
        restoredCount: Int
    ) {
        self.restored = restored
        self.entitlementJws = entitlementJws
        self.restoredCount = restoredCount
    }
}

/// IAP receipt verification narrow reason. Matches the server-side
/// `DirectIapReceiptInvalidReason` taxonomy in
/// `bifrost/.../handlers/_license-helpers.ts`. Mapped from the wire
/// `reason` string by `DirectIapVerifyResult`'s parser; unknown values
/// fall back to `.unknown` so a server-side taxonomy bump doesn't
/// hard-break the SDK.
public enum DirectIapInvalidReason: String, Sendable, Equatable {
    case expired
    case malformed
    case notSubscribed = "not_subscribed"
    case unknown
}

/// Result of `DirectClient.verifyIapReceipt(...)`. On valid: carries
/// the freshly minted entitlement JWS + the bound license_key + tier
/// + expiry. On invalid: carries the narrow `reason` so the host
/// product can pick the right recovery UX (re-purchase / re-auth /
/// contact support).
public struct IapVerifyResult: Sendable, Equatable {
    public let valid: Bool
    public let licenseKey: String?
    public let tier: String?
    public let validUntil: Int?
    public let entitlementJws: String?
    public let reason: DirectIapInvalidReason?

    public init(
        valid: Bool,
        licenseKey: String? = nil,
        tier: String? = nil,
        validUntil: Int? = nil,
        entitlementJws: String? = nil,
        reason: DirectIapInvalidReason? = nil
    ) {
        self.valid = valid
        self.licenseKey = licenseKey
        self.tier = tier
        self.validUntil = validUntil
        self.entitlementJws = entitlementJws
        self.reason = reason
    }
}
