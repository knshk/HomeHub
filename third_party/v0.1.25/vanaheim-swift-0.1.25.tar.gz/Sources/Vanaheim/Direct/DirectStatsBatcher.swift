// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

// ─────────────────────────────────────────────────────────────────────
// DirectStatsBatcher — in-memory ring buffer + persistence to secure
// storage on app background; flushes every N min (configurable) OR on
// N events (configurable). Persists across app restarts.
//
// Behaviour matches the spec:
//
//   - In-memory ring buffer; bounded by `bufferCapacity`. Once full,
//     the OLDEST event is dropped to make room (the SDK favours
//     fresh data over completeness when the app is in a long offline
//     window).
//   - Auto-flushes every `flushInterval` seconds OR when the buffer
//     reaches `flushBatchSize` events, whichever comes first.
//   - On `persist()` (called by the host product from
//     UIApplicationDidEnterBackground / NSApplicationDidEnterBackground),
//     the buffer is serialised to JSON + written to the supplied
//     `SecureCache` under the key `direct_stats_buffer_v1`.
//   - On `rehydrate()` (called from `DirectClient.connect()`), the
//     persisted buffer is loaded back into memory; the cache slot is
//     cleared so a subsequent backgrounding doesn't double-write.
//   - Flush calls go through a caller-supplied closure (`flushTick`) —
//     the actual HTTP send lives in `DirectClient.sendStats(...)`.
//     This keeps the batcher decoupled from the network layer.
//
// Concurrency: actor-isolated. The flush loop runs on a detached Task
// observing `running`.
// ─────────────────────────────────────────────────────────────────────

/// Closure invoked by the batcher's flush loop. Receives the events
/// dequeued for this batch; must `try await` the send and throw on
/// network failure so the batcher can re-enqueue on retry-worthy
/// errors. (The default `DirectClient` wiring DOES NOT re-enqueue —
/// dropped events are dropped — but the closure surface leaves the
/// option open for a future host-product override.)
public typealias DirectStatsFlush =
    @Sendable ([DirectStatEvent]) async throws -> Void

/// Persistence key for the buffer in `SecureCache`.
public let kDirectStatsBufferKey = "direct_stats_buffer_v1"

/// In-memory ring buffer + auto-flush scheduler for `DirectClient`
/// stats reporting.
public actor DirectStatsBatcher {
    private let bufferCapacity: Int
    private let flushBatchSize: Int
    private let flushInterval: TimeInterval
    private let cache: SecureCache

    /// Ring buffer of pending events. Drops oldest on overflow.
    private var buffer: [DirectStatEvent] = []

    /// Closure supplied to `start(...)`. Nil while stopped.
    private var flushTick: DirectStatsFlush?

    /// Lifecycle flag — true while the auto-flush loop is running.
    private var running: Bool = false

    /// Live loop task. Held so `stop()` can cancel + await its exit.
    private var loop: Task<Void, Never>?

    public init(
        bufferCapacity: Int,
        flushBatchSize: Int,
        flushInterval: TimeInterval,
        cache: SecureCache
    ) {
        self.bufferCapacity = max(1, bufferCapacity)
        self.flushBatchSize = max(1, flushBatchSize)
        self.flushInterval = max(1, flushInterval)
        self.cache = cache
    }

    // MARK: - Lifecycle

    /// Starts the auto-flush loop. Idempotent.
    public func start(flush: @escaping DirectStatsFlush) {
        if running { return }
        running = true
        self.flushTick = flush
        loop = Task { [weak self] in
            await self?.runLoop()
        }
    }

    /// Stops the loop. The currently in-flight flush (if any) runs to
    /// completion; the loop exits on its next check.
    public func stop() {
        running = false
        loop?.cancel()
        loop = nil
        flushTick = nil
    }

    // MARK: - Enqueue

    /// Adds an event to the buffer. Triggers an immediate inline flush
    /// when the buffer crosses `flushBatchSize` — keeps the wire-side
    /// latency tight when an app is sending a lot of events quickly.
    public func add(_ event: DirectStatEvent) async {
        if buffer.count >= bufferCapacity {
            buffer.removeFirst() // drop oldest
        }
        buffer.append(event)
        if buffer.count >= flushBatchSize, let flush = flushTick {
            await flushNow(flush: flush)
        }
    }

    /// Bulk-add convenience.
    public func add(_ events: [DirectStatEvent]) async {
        for e in events {
            if buffer.count >= bufferCapacity {
                buffer.removeFirst()
            }
            buffer.append(e)
        }
        if buffer.count >= flushBatchSize, let flush = flushTick {
            await flushNow(flush: flush)
        }
    }

    /// Forces an immediate flush regardless of buffer fill or interval.
    /// Exposed for diagnostics + the host product's "drain before
    /// quit" hook.
    public func flushImmediate() async {
        guard let flush = flushTick else { return }
        await flushNow(flush: flush)
    }

    /// Current buffer depth.
    public var bufferedCount: Int { buffer.count }

    // MARK: - Persistence (app background / foreground hooks)

    /// Serialises the buffer to JSON + persists to `SecureCache`. The
    /// host product calls this from its app-background hook so an OS
    /// kill doesn't lose the buffered events.
    public func persist() async {
        if buffer.isEmpty {
            // Nothing to write — also clear any prior persisted blob
            // so a crash-then-rehydrate doesn't double-count.
            try? await cache.deleteRaw(kDirectStatsBufferKey)
            return
        }
        let array: [[String: Any]] = buffer.map { e in
            var m: [String: Any] = [
                "event_name": e.eventName,
                "occurred_at_ms": e.occurredAtMs,
                "count": e.count,
            ]
            if let d = e.dimensions {
                m["dimensions"] = d
            }
            return m
        }
        do {
            let data = try JSONSerialization.data(withJSONObject: array)
            if let s = String(data: data, encoding: .utf8) {
                try await cache.putRaw(kDirectStatsBufferKey, s)
            }
        } catch {
            // Best-effort. If persistence fails the in-memory buffer
            // is still intact for the rest of this process lifetime.
            _ = error
        }
    }

    /// Loads any persisted buffer back into memory + clears the cache
    /// slot. Called from `DirectClient.connect()`.
    public func rehydrate() async {
        guard let json = try? await cache.getRaw(kDirectStatsBufferKey),
              let data = json.data(using: .utf8) else { return }
        do {
            guard let arr = try JSONSerialization.jsonObject(with: data)
                as? [[String: Any]] else { return }
            for row in arr {
                guard let name = row["event_name"] as? String,
                      let ts = row["occurred_at_ms"] as? Int else { continue }
                let count = row["count"] as? Int ?? 1
                let dims = row["dimensions"] as? [String: Any]
                if buffer.count >= bufferCapacity {
                    buffer.removeFirst()
                }
                buffer.append(DirectStatEvent(
                    eventName: name,
                    occurredAtMs: ts,
                    dimensions: dims,
                    count: count))
            }
            try? await cache.deleteRaw(kDirectStatsBufferKey)
        } catch {
            // Bad blob — drop it so future rehydrates don't keep trying.
            try? await cache.deleteRaw(kDirectStatsBufferKey)
        }
    }

    // MARK: - Internals

    private func runLoop() async {
        while running {
            let delayNs = UInt64(flushInterval * 1_000_000_000)
            do {
                try await Task.sleep(nanoseconds: delayNs)
            } catch {
                return
            }
            if !running { return }
            if let flush = flushTick {
                await flushNow(flush: flush)
            }
        }
    }

    private func flushNow(flush: DirectStatsFlush) async {
        if buffer.isEmpty { return }
        // Snapshot + clear in a single actor-isolated step so a
        // concurrent `add(...)` doesn't slip events into the
        // mid-flight batch.
        let batch = buffer
        buffer.removeAll(keepingCapacity: true)
        do {
            try await flush(batch)
        } catch {
            // Flush failed — re-enqueue best-effort, oldest-first, so
            // the next tick retries. Cap by `bufferCapacity` so a
            // long server outage doesn't unbounded-grow the buffer.
            for e in batch {
                if buffer.count >= bufferCapacity {
                    // Drop the just-failed events from the head if
                    // newer events have arrived in the meantime; the
                    // ring-buffer contract prefers fresh over complete.
                    break
                }
                buffer.insert(e, at: 0)
            }
        }
    }
}
