// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit

#if canImport(Security)
import Security
#endif

// ─────────────────────────────────────────────────────────────────────
// DirectKeypairStore — Keychain-backed Ed25519 keypair management for
// the FRON / Direct mode.
//
// Two distinct keypairs live here:
//
//   1. EPHEMERAL — generated fresh on each `connect()` and used to
//      sign the inner JWS on the Tier 1 `/direct/v1/register` call.
//      The PUBLIC half of the ephemeral keypair is embedded in the
//      JWS header (`device_pub_jwk`) and BECOMES the durable device
//      identity once the server accepts the register response.
//
//   2. DURABLE — the same Ed25519 keypair, but promoted to durable
//      status once `register()` succeeds. Persisted to Keychain
//      against the v1 slot keys; signs every subsequent Tier 2 call's
//      inner JWS (`typ = bifrost-direct+durable+jws`).
//
// The "promotion" is just a Keychain write of the same scalar — the
// ephemeral and durable keys are byte-identical once register lands.
// This matches the server-side expectation (see
// `bifrost/.../jws-verifier.ts` Mode A docblock: "the PUBLIC half of
// that keypair […] IS the durable device identity once accepted").
//
// Keychain slots (separate from the L2-mode slots in
// `DeviceKeypairProvider` so a host product running both modes side-
// by-side doesn't collide):
//
//   service:  io.vanaheim.sdk.direct
//   accounts: vanaheim_direct_device_id          (UTF-8 string)
//             vanaheim_direct_durable_ed25519    (raw 32-byte scalar)
//             vanaheim_direct_server_nonce       (UTF-8 string)
//
// On `clear()` (after `deactivate(reason:)`), every direct-mode slot
// is wiped so the next connect re-issues a fresh ephemeral keypair.
//
// Concurrency: actor-isolated so the ephemeral-load + durable-promote
// + sign paths cannot race. The in-memory caches (`cachedEphemeral`
// / `cachedDurable`) are populated lazily on first use.
// ─────────────────────────────────────────────────────────────────────

/// Keychain service identifier for the persisted direct-mode keypair.
/// Versioned (v1 in the account name) so a future scheme bump can land
/// without colliding with on-disk blobs.
public let kDirectKeychainService = "io.vanaheim.sdk.direct"

/// Account names — match the spec verbatim ("vanaheim:direct:..." but
/// Keychain accounts can't contain `:`, so we use underscore).
public let kDirectDeviceIdAccount = "vanaheim_direct_device_id"
public let kDirectDurableEd25519Account = "vanaheim_direct_durable_ed25519"
public let kDirectServerNonceAccount = "vanaheim_direct_server_nonce"

/// Direct-mode keypair + device-id store. Distinct from the L2-mode
/// `KeychainDeviceKeypairProvider` so the two surfaces don't collide.
public actor DirectKeypairStore {
    private let service: String

    // Ephemeral Ed25519 — generated fresh on connect(), used by
    // /direct/v1/register only. Once register accepts, the SAME
    // scalar becomes the durable key (Keychain-persisted).
    private var cachedEphemeral: Curve25519.Signing.PrivateKey?

    // Durable Ed25519 — loaded from Keychain on first use, cached for
    // the actor's lifetime. nil until register has succeeded at least
    // once on this device.
    private var cachedDurable: Curve25519.Signing.PrivateKey?

    // Cached device id (Keychain string slot). nil pre-register.
    private var cachedDeviceId: String?

    public init(service: String = kDirectKeychainService) {
        self.service = service
    }

    // MARK: - Ephemeral path (registration only)

    /// Generates (or returns the cached) ephemeral Ed25519 keypair.
    /// Called by `DirectRequestBuilder` when assembling the inner JWS
    /// for `/direct/v1/register`.
    ///
    /// The keypair is held in memory only — no Keychain write happens
    /// until `promoteEphemeralToDurable()` runs (which is invoked
    /// from `DirectClient.register(...)` after the server accepts the
    /// response).
    public func ensureEphemeralKey() throws -> Curve25519.Signing.PrivateKey {
        if let k = cachedEphemeral { return k }
        let priv = Curve25519.Signing.PrivateKey()
        cachedEphemeral = priv
        return priv
    }

    /// Persists the ephemeral keypair as the durable identity + writes
    /// the L3-assigned `device_id`. Called from `DirectClient.register`
    /// after the server response lands.
    public func promoteEphemeralToDurable(deviceId: String) throws {
        guard let priv = cachedEphemeral else {
            throw DirectError.network(
                message: "promoteEphemeralToDurable called without an " +
                         "ephemeral keypair — register flow out of order")
        }
        try saveDurableToKeychain(priv: priv)
        try saveDeviceIdToKeychain(deviceId: deviceId)
        cachedDurable = priv
        cachedDeviceId = deviceId
        // The ephemeral cache is now identical to the durable one;
        // keep it around for the rest of this process lifetime so a
        // re-register on the same boot is a no-op.
    }

    // MARK: - Durable path (every other endpoint)

    /// Returns the durable Ed25519 keypair for signing Tier-2 inner
    /// JWSes. Throws `.notConnected` if `register()` hasn't yet
    /// promoted an ephemeral keypair (or rehydrated one from
    /// Keychain).
    public func requireDurableKey() throws -> Curve25519.Signing.PrivateKey {
        if let k = cachedDurable { return k }
        if let k = try loadDurableFromKeychain() {
            cachedDurable = k
            return k
        }
        throw DirectError.notConnected
    }

    /// Returns the durable device id (L3-assigned, written during
    /// register). Throws `.notConnected` pre-register.
    public func requireDeviceId() throws -> String {
        if let id = cachedDeviceId { return id }
        if let id = loadDeviceIdFromKeychain() {
            cachedDeviceId = id
            return id
        }
        throw DirectError.notConnected
    }

    /// Convenience: try to rehydrate the durable identity from
    /// Keychain at connect() time. Silent miss is fine — the device
    /// just hasn't registered yet.
    public func rehydrate() {
        if cachedDurable == nil, let k = try? loadDurableFromKeychain() {
            cachedDurable = k
        }
        if cachedDeviceId == nil, let id = loadDeviceIdFromKeychain() {
            cachedDeviceId = id
        }
    }

    /// True iff register() has already succeeded on this device and
    /// the durable identity is loadable from Keychain.
    public func hasDurableIdentity() -> Bool {
        if cachedDurable != nil { return true }
        return (try? loadDurableFromKeychain()) != nil
    }

    // MARK: - Server nonce

    /// Persists the one-shot server nonce returned by `/register`.
    /// The SDK echoes it on the first state-changing call (`activate`
    /// / `heartbeat`) so the server can bind the register response
    /// to its follow-up.
    public func putServerNonce(_ nonce: String) {
        cachedServerNonce = nonce
        _ = try? writeStringToKeychain(
            account: kDirectServerNonceAccount, value: nonce)
    }

    /// Reads the persisted server nonce (cached or Keychain). nil if
    /// no nonce is currently in flight.
    public func getServerNonce() -> String? {
        if let n = cachedServerNonce { return n }
        let n = readStringFromKeychain(account: kDirectServerNonceAccount)
        cachedServerNonce = n
        return n
    }

    /// Wipes the server nonce after it's been consumed.
    public func clearServerNonce() {
        cachedServerNonce = nil
        _ = try? deleteFromKeychain(account: kDirectServerNonceAccount)
    }

    private var cachedServerNonce: String?

    // MARK: - Reset

    /// Wipes every direct-mode slot (durable keypair + device id +
    /// server nonce + in-memory ephemeral). Called from
    /// `DirectClient.deactivate(reason:)` so the next connect can
    /// re-register cleanly.
    public func clear() {
        cachedEphemeral = nil
        cachedDurable = nil
        cachedDeviceId = nil
        cachedServerNonce = nil
        _ = try? deleteFromKeychain(account: kDirectDurableEd25519Account)
        _ = try? deleteFromKeychain(account: kDirectDeviceIdAccount)
        _ = try? deleteFromKeychain(account: kDirectServerNonceAccount)
    }

    // MARK: - Keychain I/O

    #if canImport(Security)

    private func loadDurableFromKeychain() throws -> Curve25519.Signing.PrivateKey? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: kDirectDurableEd25519Account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        if status == errSecItemNotFound { return nil }
        if status != errSecSuccess {
            throw KeychainError(
                "Direct durable key load failed (OSStatus \(status))")
        }
        guard let data = item as? Data, data.count == 32 else { return nil }
        do {
            return try Curve25519.Signing.PrivateKey(rawRepresentation: data)
        } catch {
            // Corrupted blob — drop it and regenerate on next register.
            _ = try? deleteFromKeychain(account: kDirectDurableEd25519Account)
            return nil
        }
    }

    private func saveDurableToKeychain(priv: Curve25519.Signing.PrivateKey) throws {
        let raw = priv.rawRepresentation
        _ = try? deleteFromKeychain(account: kDirectDurableEd25519Account)
        let attrs: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: kDirectDurableEd25519Account,
            kSecAttrAccessible as String:
                kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
            kSecValueData as String: raw,
        ]
        let status = SecItemAdd(attrs as CFDictionary, nil)
        if status != errSecSuccess {
            throw KeychainError(
                "Direct durable key save failed (OSStatus \(status))")
        }
    }

    private func saveDeviceIdToKeychain(deviceId: String) throws {
        try writeStringToKeychain(
            account: kDirectDeviceIdAccount, value: deviceId)
    }

    private func loadDeviceIdFromKeychain() -> String? {
        readStringFromKeychain(account: kDirectDeviceIdAccount)
    }

    private func writeStringToKeychain(account: String, value: String) throws {
        let data = Data(value.utf8)
        _ = try? deleteFromKeychain(account: account)
        let attrs: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecAttrAccessible as String:
                kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
            kSecValueData as String: data,
        ]
        let status = SecItemAdd(attrs as CFDictionary, nil)
        if status != errSecSuccess {
            throw KeychainError(
                "Direct string write failed (OSStatus \(status), account \(account))")
        }
    }

    private func readStringFromKeychain(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func deleteFromKeychain(account: String) throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
        let status = SecItemDelete(query as CFDictionary)
        if status != errSecSuccess && status != errSecItemNotFound {
            throw KeychainError(
                "Direct delete failed (OSStatus \(status), account \(account))")
        }
    }

    #else
    // Non-Apple platforms — surface a clear error rather than silently
    // succeeding. The SDK is gated to iOS 15+ / macOS 12+ in
    // Package.swift; this branch exists only for tooling that lints
    // the file off-platform.

    private func loadDurableFromKeychain() throws -> Curve25519.Signing.PrivateKey? {
        throw KeychainError("Security framework unavailable on this platform")
    }
    private func saveDurableToKeychain(priv: Curve25519.Signing.PrivateKey) throws {
        throw KeychainError("Security framework unavailable on this platform")
    }
    private func saveDeviceIdToKeychain(deviceId: String) throws {
        throw KeychainError("Security framework unavailable on this platform")
    }
    private func loadDeviceIdFromKeychain() -> String? { nil }
    private func writeStringToKeychain(account: String, value: String) throws {
        throw KeychainError("Security framework unavailable on this platform")
    }
    private func readStringFromKeychain(account: String) -> String? { nil }
    private func deleteFromKeychain(account: String) throws {}

    #endif
}
