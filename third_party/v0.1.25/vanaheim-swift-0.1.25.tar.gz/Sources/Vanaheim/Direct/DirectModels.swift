// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

// ─────────────────────────────────────────────────────────────────────
// DirectModels — value types returned from `DirectClient` methods.
//
// These mirror the Dart twin (sdk/dart/license_store_sdk/lib/src/direct/
// direct_models.dart) field-for-field so a host product written against
// one SDK can be re-skinned over the other without reshaping the model
// layer. The shapes themselves are deliberately small: every entitlement
// JWS, server nonce, and tier-metadata object lives behind a typed
// accessor so a future server bump can add fields without breaking the
// Swift API.
//
// NONE of these types depend on the L2 (`LicenseClient`) surface — the
// FRON / Direct mode is a standalone path; the existing `Entitlements`
// + `LicenseJwtClaims` types in `Models.swift` are NOT reused here so
// the two surfaces can evolve independently.
// ─────────────────────────────────────────────────────────────────────

/// Result of `DirectClient.register(...)`. The server mints the durable
/// `device_id` from the SDK's ephemeral pubkey + supplies the initial
/// entitlement JWS + heartbeat cadence the SDK should schedule against.
///
/// `@unchecked Sendable` — the `tierMetadata` field is `[String: Any]`
/// (the JSON dictionary from the server response). The values are all
/// JSONSerialization-derived POD types (NSString, NSNumber, NSArray,
/// NSDictionary, NSNull) that don't carry mutable identity across actor
/// boundaries; the `@unchecked` claim is sound for this taxonomy.
public struct RegisterResult: @unchecked Sendable, Equatable {
    /// L3-assigned durable device id (e.g. `dev_<base36>`). The SDK
    /// persists this in Keychain under `vanaheim:direct:device_id`.
    public let deviceId: String

    /// Initial entitlement JWS — Ed25519 + EdDSA. The SDK exposes the
    /// parsed feature list / quotas via `hasFeature` / `quota`; the raw
    /// JWS is retained for debug + verify-flow refresh.
    public let entitlementJws: String

    /// Free-form tier metadata blob (display name, marketing color, etc.).
    /// Treated as opaque by the SDK.
    public let tierMetadata: [String: Any]

    /// Feature ids granted on this tier.
    public let featureList: [String]

    /// Quota counters keyed by name (max projects / max seats / …).
    public let quotas: [String: Int]

    /// One-shot server nonce. The SDK echoes this on the first
    /// `activate` / `heartbeat` call to bind the register response to
    /// the subsequent state-changing call without a session table.
    public let serverNonce: String

    /// Heartbeat cadence in milliseconds — the SDK schedules its
    /// periodic heartbeat at this interval (subject to the local
    /// connectivity / offline gate).
    public let heartbeatCadenceMs: Int

    public init(
        deviceId: String,
        entitlementJws: String,
        tierMetadata: [String: Any],
        featureList: [String],
        quotas: [String: Int],
        serverNonce: String,
        heartbeatCadenceMs: Int
    ) {
        self.deviceId = deviceId
        self.entitlementJws = entitlementJws
        self.tierMetadata = tierMetadata
        self.featureList = featureList
        self.quotas = quotas
        self.serverNonce = serverNonce
        self.heartbeatCadenceMs = heartbeatCadenceMs
    }

    public static func == (lhs: RegisterResult, rhs: RegisterResult) -> Bool {
        return lhs.deviceId == rhs.deviceId
            && lhs.entitlementJws == rhs.entitlementJws
            && lhs.featureList == rhs.featureList
            && lhs.quotas == rhs.quotas
            && lhs.serverNonce == rhs.serverNonce
            && lhs.heartbeatCadenceMs == rhs.heartbeatCadenceMs
    }
}

/// Result of `DirectClient.activate(...)`. Re-mints the entitlement
/// bundle for the (project, device) pair against the supplied license
/// key.
///
/// `@unchecked Sendable` — see `RegisterResult`.
public struct ActivateResult: @unchecked Sendable, Equatable {
    public let entitlementJws: String
    public let tierMetadata: [String: Any]
    public let featureList: [String]
    public let quotas: [String: Int]
    /// Server-side timestamp (ms-since-epoch) the response was minted at.
    /// The SDK uses this to schedule the next refresh cycle.
    public let refreshedAtMs: Int

    public init(
        entitlementJws: String,
        tierMetadata: [String: Any],
        featureList: [String],
        quotas: [String: Int],
        refreshedAtMs: Int
    ) {
        self.entitlementJws = entitlementJws
        self.tierMetadata = tierMetadata
        self.featureList = featureList
        self.quotas = quotas
        self.refreshedAtMs = refreshedAtMs
    }

    public static func == (lhs: ActivateResult, rhs: ActivateResult) -> Bool {
        return lhs.entitlementJws == rhs.entitlementJws
            && lhs.featureList == rhs.featureList
            && lhs.quotas == rhs.quotas
            && lhs.refreshedAtMs == rhs.refreshedAtMs
    }
}

/// Result of `DirectClient.verify()`. Same shape as `ActivateResult`
/// plus a `deactivated` flag carried over from the server's revoked-
/// device fast path.
///
/// `@unchecked Sendable` — see `RegisterResult`.
public struct VerifyResult: @unchecked Sendable, Equatable {
    /// Entitlement JWS — `nil` when the device was deactivated server-
    /// side (the SDK then surfaces `deactivated == true` so the host
    /// product can shut down gracefully).
    public let entitlementJws: String?
    public let tierMetadata: [String: Any]
    public let featureList: [String]
    public let quotas: [String: Int]
    public let refreshedAtMs: Int?

    /// `true` when the server reported the device as revoked. The host
    /// product should call `deactivate(reason:)` locally to clear
    /// Keychain state.
    public let deactivated: Bool
    public let deactivatedReason: String?
    public let deactivatedAtMs: Int?

    public init(
        entitlementJws: String?,
        tierMetadata: [String: Any],
        featureList: [String],
        quotas: [String: Int],
        refreshedAtMs: Int?,
        deactivated: Bool = false,
        deactivatedReason: String? = nil,
        deactivatedAtMs: Int? = nil
    ) {
        self.entitlementJws = entitlementJws
        self.tierMetadata = tierMetadata
        self.featureList = featureList
        self.quotas = quotas
        self.refreshedAtMs = refreshedAtMs
        self.deactivated = deactivated
        self.deactivatedReason = deactivatedReason
        self.deactivatedAtMs = deactivatedAtMs
    }

    public static func == (lhs: VerifyResult, rhs: VerifyResult) -> Bool {
        return lhs.entitlementJws == rhs.entitlementJws
            && lhs.featureList == rhs.featureList
            && lhs.quotas == rhs.quotas
            && lhs.refreshedAtMs == rhs.refreshedAtMs
            && lhs.deactivated == rhs.deactivated
            && lhs.deactivatedReason == rhs.deactivatedReason
            && lhs.deactivatedAtMs == rhs.deactivatedAtMs
    }
}

/// Result of `DirectClient.heartbeat()`. Carries the next-call hint
/// from the server (so a project can dial cadence per-deploy without an
/// SDK release) plus the revoked-device fast-path flag.
public struct HeartbeatResult: Sendable, Equatable {
    /// `true` while the bind row is live; `false` after admin-side
    /// revocation.
    public let valid: Bool

    /// When valid == false, the reason the server reports (best-effort —
    /// `"unknown"` on a forensic-doc-read miss).
    public let revokedReason: String?

    /// Server-suggested cooldown before the next heartbeat. The SDK
    /// honours this verbatim (subject to the offline gate).
    public let nextHeartbeatAfterMs: Int

    public init(
        valid: Bool,
        revokedReason: String? = nil,
        nextHeartbeatAfterMs: Int
    ) {
        self.valid = valid
        self.revokedReason = revokedReason
        self.nextHeartbeatAfterMs = nextHeartbeatAfterMs
    }
}

/// Snapshot of `getCatalog()` — opaque tier / feature / pricing-plan
/// rows + an etag the SDK passes back on the next call so the server
/// can short-circuit on no-change.
///
/// `@unchecked Sendable` — see `RegisterResult`.
public struct CatalogSnapshot: @unchecked Sendable, Equatable {
    /// Opaque etag — `nil` on a cold fetch.
    public let catalogEtag: String?

    /// One row per tier. The SDK does not parse these — they are
    /// surfaced to the host product so it can render a marketing
    /// upgrade-tier UI without a separate catalog call.
    public let tiers: [[String: Any]]
    public let features: [[String: Any]]
    public let pricingPlans: [[String: Any]]

    public init(
        catalogEtag: String?,
        tiers: [[String: Any]],
        features: [[String: Any]],
        pricingPlans: [[String: Any]]
    ) {
        self.catalogEtag = catalogEtag
        self.tiers = tiers
        self.features = features
        self.pricingPlans = pricingPlans
    }

    public static func == (lhs: CatalogSnapshot, rhs: CatalogSnapshot) -> Bool {
        return lhs.catalogEtag == rhs.catalogEtag
            && lhs.tiers.count == rhs.tiers.count
            && lhs.features.count == rhs.features.count
            && lhs.pricingPlans.count == rhs.pricingPlans.count
    }
}

/// Single telemetry event for the stats batcher. Shaped per the
/// B-FRON.4.1 contract (`event_name` matches `[a-z0-9_.]{1,64}`).
///
/// `@unchecked Sendable` — see `RegisterResult`.
public struct DirectStatEvent: @unchecked Sendable {
    public let eventName: String
    public let occurredAtMs: Int
    public let dimensions: [String: Any]?
    public let count: Int

    public init(
        eventName: String,
        occurredAtMs: Int,
        dimensions: [String: Any]? = nil,
        count: Int = 1
    ) {
        self.eventName = eventName
        self.occurredAtMs = occurredAtMs
        self.dimensions = dimensions
        self.count = count
    }
}

/// Result of `DirectClient.sendStats(...)`. Per-batch accept/reject
/// counts — the SDK can surface these in diagnostics.
public struct StatsResult: Sendable, Equatable {
    public let acceptedEventCount: Int
    public let rejectedEventCount: Int
    public let rejectionReasons: [String]

    public init(
        acceptedEventCount: Int,
        rejectedEventCount: Int,
        rejectionReasons: [String] = []
    ) {
        self.acceptedEventCount = acceptedEventCount
        self.rejectedEventCount = rejectedEventCount
        self.rejectionReasons = rejectionReasons
    }
}

/// Single error report for `DirectClient.reportError(...)`. The
/// `fingerprint` (caller-side hash) is the cardinality-bounded key the
/// dashboards index on; `message` / `stack` are PII-tagged and never
/// surface on the wire response.
///
/// `@unchecked Sendable` — see `RegisterResult`.
public struct DirectErrorReport: @unchecked Sendable {
    public let errorType: String
    public let occurredAtMs: Int
    public let message: String?
    public let stack: String?
    public let context: [String: Any]?
    public let fingerprint: String?

    public init(
        errorType: String,
        occurredAtMs: Int,
        message: String? = nil,
        stack: String? = nil,
        context: [String: Any]? = nil,
        fingerprint: String? = nil
    ) {
        self.errorType = errorType
        self.occurredAtMs = occurredAtMs
        self.message = message
        self.stack = stack
        self.context = context
        self.fingerprint = fingerprint
    }
}

/// Result of `DirectClient.reportError(...)`. The server mints an
/// `errorId` for cross-system correlation; the SDK echoes it back to
/// the caller so a host product can pin it to a support ticket.
public struct ErrorResult: Sendable, Equatable {
    public let errorId: String

    public init(errorId: String) {
        self.errorId = errorId
    }
}

/// Push-token platform discriminator. The FRON `/notifications/register-
/// fcm` endpoint takes one of these in the `platform` field — the SDK
/// passes whatever the platform actually issued (APNs token on iOS, FCM
/// token on Android, web-push subscription on web).
public enum DirectPushPlatform: String, Sendable, Equatable {
    case ios
    case android
    case web
}
