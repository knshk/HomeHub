// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

// ─────────────────────────────────────────────────────────────────────
// DirectPaymentClient — the six payment methods on `DirectClient`
// (W6 / B-FRON.5.*).
//
// Implemented as a `public extension` on the existing `DirectClient`
// actor so the host product's call-site shape is identical to the
// existing register / activate / verify / heartbeat surface — no new
// top-level type, no second `connect()`, no second keypair store.
//
// Every method here flows through `DirectClient.postDurableJson(...)`
// (W5's Tier-2 envelope path) — same `DirectRequestBuilder` +
// `DirectResponseParser`, same RFC 7519 claim names (aud/iat/nbf/exp/
// jti), same body wrapper. No new crypto path is introduced for the
// payment surface. The W6 contract pins this explicitly:
//
//   - Payment endpoints are Tier 2 (JWE + durable JWS).
//   - No new envelope shape, no fresh keypair (ephemeral_pubkey is
//     `register`-only).
//   - Identical timestamp shape (ms-since-epoch on outbound claims;
//     server-side `iat`/`exp` on the inner response JWS arrives in
//     unix-seconds per `signJws`).
//
// Wire shape (snake-case) for each route is the source-of-truth in
// `bifrost/packages/functions/src/direct/handlers/payment.ts`. The
// camelCase ↔ snake_case translation happens here.
// ─────────────────────────────────────────────────────────────────────

public extension DirectClient {

    // ── B-FRON.5.1 — POST /direct/v1/payment/checkout ────────────────

    /// Mints a provider-side hosted-checkout session. The host product
    /// opens `CheckoutSession.hostedUrl` in an in-app browser (via the
    /// `DirectPaymentBrowser` helper on Apple platforms), waits for
    /// the user to land back on the deep-link, then calls
    /// `refreshAfterPayment(sessionId:)` to pull a fresh entitlement.
    ///
    /// - Parameters:
    ///   - tier: Catalog tier slug (`[a-z0-9_]{1,64}`).
    ///   - billingCycle: Monthly or yearly.
    ///   - currency: ISO-4217 3-letter code (e.g. "USD", "INR").
    ///   - returnUrl: Deep-link the provider redirects to on success.
    ///     MUST be on the project's return-URL allowlist (server-side
    ///     defence against open-redirect attacks).
    ///   - cancelUrl: Optional deep-link the provider redirects to on
    ///     cancel. Also subject to the allowlist.
    ///   - provider: Optional provider override. Gated server-side by
    ///     the project's `allow_provider_override` flag — passing a
    ///     provider here when the project has not opted in surfaces
    ///     as `.badRequest`.
    func startCheckout(
        tier: String,
        billingCycle: DirectBillingCycle,
        currency: String,
        returnUrl: URL,
        cancelUrl: URL? = nil,
        provider: DirectPaymentProvider? = nil
    ) async throws -> CheckoutSession {
        try requireConnected()
        // Client-side return-URL pre-validation. The server-side
        // allowlist is the load-bearing defence (W6 security
        // requirement #1 — open-redirect); the client check below is
        // a cheap fast-fail so a misconfigured host product surfaces
        // a typed `.badRequest` BEFORE the wire round-trip.
        try Self.requireHttpsUrl(returnUrl, fieldName: "return_url")
        if let cancel = cancelUrl {
            try Self.requireHttpsUrl(cancel, fieldName: "cancel_url")
        }
        // Server-side tier validation regex is `^[a-z0-9_]{1,64}$`;
        // we mirror it here so a typo surfaces locally.
        try Self.requireTierSlug(tier)
        try Self.requireCurrencyTag(currency)

        var body: [String: Any] = [
            "project_id": projectId,
            "tier": tier,
            "billing_cycle": billingCycle.rawValue,
            "currency": currency,
            "return_url": returnUrl.absoluteString,
        ]
        if let cancel = cancelUrl {
            body["cancel_url"] = cancel.absoluteString
        }
        if let p = provider {
            body["provider"] = p.rawValue
        }

        let json = try await postDurableJson(
            route: "/direct/v1/payment/checkout",
            audience: "direct:payment.checkout",
            body: body)

        guard let sessionId = json["session_id"] as? String,
              let hostedUrlStr = json["hosted_url"] as? String,
              let hostedUrl = URL(string: hostedUrlStr),
              let expiresAtMs = Self.asInt(json["expires_at_ms"]) else {
            throw DirectError.network(
                message: "checkout response missing required fields")
        }
        return CheckoutSession(
            sessionId: sessionId,
            hostedUrl: hostedUrl,
            expiresAtMs: expiresAtMs)
    }

    // ── B-FRON.5.2 — POST /direct/v1/payment/intent ─────────────────

    /// Mints a native-payment intent (Stripe Payment Sheet / Apple Pay
    /// / Google Pay). The host product passes the returned
    /// `clientSecret` to the platform's native payment-sheet API; the
    /// actual capture event lands via webhook on the server.
    func startNativePayment(
        tier: String,
        billingCycle: DirectBillingCycle,
        currency: String,
        platform: DirectNativePaymentPlatform,
        provider: DirectPaymentProvider? = nil
    ) async throws -> PaymentIntent {
        try requireConnected()
        try Self.requireTierSlug(tier)
        try Self.requireCurrencyTag(currency)

        var body: [String: Any] = [
            "project_id": projectId,
            "tier": tier,
            "billing_cycle": billingCycle.rawValue,
            "currency": currency,
            "platform": platform.rawValue,
        ]
        if let p = provider {
            body["provider"] = p.rawValue
        }

        let json = try await postDurableJson(
            route: "/direct/v1/payment/intent",
            audience: "direct:payment.intent",
            body: body)

        guard let intentId = json["intent_id"] as? String,
              let clientSecret = json["client_secret"] as? String,
              let expiresAtMs = Self.asInt(json["expires_at_ms"]) else {
            throw DirectError.network(
                message: "intent response missing required fields")
        }
        return PaymentIntent(
            intentId: intentId,
            clientSecret: clientSecret,
            expiresAtMs: expiresAtMs)
    }

    // ── B-FRON.5.3 — POST /direct/v1/payment/portal ─────────────────

    /// Mints a provider-side customer-portal session so the user can
    /// manage payment methods + cancel / pause their subscription.
    /// The host product opens `PortalSession.portalUrl` in an in-app
    /// browser via the `DirectPaymentBrowser` helper.
    ///
    /// Surfaces `.noActiveSubscription` when the device has no current
    /// `active` / `trialing` subscription — the host product should
    /// route the user through `startCheckout(...)` in that case.
    func openPortal(returnUrl: URL) async throws -> PortalSession {
        try requireConnected()
        try Self.requireHttpsUrl(returnUrl, fieldName: "return_url")

        let body: [String: Any] = [
            "project_id": projectId,
            "return_url": returnUrl.absoluteString,
        ]

        let json = try await postDurableJson(
            route: "/direct/v1/payment/portal",
            audience: "direct:payment.portal",
            body: body)

        guard let portalUrlStr = json["portal_url"] as? String,
              let portalUrl = URL(string: portalUrlStr),
              let expiresAtMs = Self.asInt(json["expires_at_ms"]) else {
            throw DirectError.network(
                message: "portal response missing required fields")
        }
        return PortalSession(
            portalUrl: portalUrl,
            expiresAtMs: expiresAtMs)
    }

    // ── B-FRON.5.4 — POST /direct/v1/payment/restore ────────────────

    /// Re-binds purchases tied to (project, device) — typically called
    /// on app re-install / sign-in to re-issue an entitlement without
    /// forcing the user through checkout again.
    ///
    /// SECURITY:
    ///   - Server-side: restore only surfaces purchases tied to THIS
    ///     device_id (the port scopes at the persistence layer).
    ///   - Client-side: we cap the returned `restored` array at
    ///     `Self.maxRestoredEntries` so a misbehaving server cannot
    ///     blow the SDK's memory budget. The slot count is generous
    ///     (1000) — production restores are typically <10 rows.
    func restorePurchases(
        platform: DirectIapPlatform
    ) async throws -> RestoreResult {
        try requireConnected()

        let body: [String: Any] = [
            "project_id": projectId,
            "platform": platform.rawValue,
        ]

        let json = try await postDurableJson(
            route: "/direct/v1/payment/restore",
            audience: "direct:payment.restore",
            body: body)

        let rawRestored = (json["restored"] as? [[String: Any]]) ?? []
        // Client-side cap. The server itself bounds the response size
        // at the port layer, but the SDK enforces a defence-in-depth
        // ceiling so a server-side bug cannot ship an arbitrarily-
        // large payload through the entitlement snapshot.
        if rawRestored.count > Self.maxRestoredEntries {
            throw DirectError.network(
                message: "restore response oversized " +
                         "(\(rawRestored.count) > \(Self.maxRestoredEntries))")
        }
        var restored: [RestoredPurchase] = []
        restored.reserveCapacity(rawRestored.count)
        for entry in rawRestored {
            guard let licenseKey = entry["license_key"] as? String,
                  let tier = entry["tier"] as? String,
                  let validUntil = Self.asInt(entry["valid_until"]) else {
                throw DirectError.network(
                    message: "restore row missing required fields")
            }
            restored.append(RestoredPurchase(
                licenseKey: licenseKey,
                tier: tier,
                validUntil: validUntil))
        }
        let entitlementJws = json["entitlement_jws"] as? String
        let restoredCount = Self.asInt(json["restored_count"])
            ?? restored.count

        // INVARIANT mirror (B-FRON.5.4): the server guarantees that
        // `restored_count > 0` implies `entitlement_jws != nil`. We
        // defend against a server-side regression by surfacing a
        // typed network error rather than a contradictory shape — the
        // host product's UX shouldn't try to gate features on a JWS
        // it doesn't have.
        if restoredCount > 0 && entitlementJws == nil {
            throw DirectError.network(
                message: "restore invariant violated: count > 0 but no JWS")
        }
        return RestoreResult(
            restored: restored,
            entitlementJws: entitlementJws,
            restoredCount: restoredCount)
    }

    // ── B-FRON.5.5 — POST /direct/v1/payment/iap-verify ─────────────

    /// Verifies an Apple App Store JWS receipt or a Google Play
    /// purchase token. On valid: returns the freshly-minted
    /// entitlement JWS + the bound license_key + tier + expiry. On
    /// invalid: returns `valid=false` with a narrow `reason` so the
    /// host product can pick the right recovery UX.
    ///
    /// SECURITY:
    ///   - Receipt size cap: rejected client-side before the wire
    ///     round-trip if it exceeds `Self.maxIapReceiptBytes` (16 KB,
    ///     matching the server-side cap in `assertIapVerifyBody`).
    ///     This is a defence-in-depth check — the server enforces the
    ///     same limit — but bouncing early saves a doomed JWE round-
    ///     trip + keeps an oversized payload off the audit log.
    ///   - Server-side per-device rate-limit (5/min default) surfaces
    ///     as `.rateLimited(retryAfterMs:)` via the standard error
    ///     path; the host product should honour the hint.
    func verifyIapReceipt(
        platform: DirectIapPlatform,
        receipt: String
    ) async throws -> IapVerifyResult {
        try requireConnected()
        // Client-side size cap. UTF-8 bytes — Apple's JWS receipts
        // are ~4-8 KB; Google purchase tokens are ~250-500 chars.
        // 16 KB matches the server-side `RETURN_URL_MAX_LEN`-style
        // bound for receipt in `assertIapVerifyBody`.
        if receipt.utf8.count > Self.ipReceiptMaxBytes {
            throw DirectError.badRequest(reason: "iap_receipt_too_large")
        }
        if receipt.isEmpty {
            throw DirectError.badRequest(reason: "receipt_empty")
        }

        let body: [String: Any] = [
            "project_id": projectId,
            "platform": platform.rawValue,
            "receipt": receipt,
        ]

        let json = try await postDurableJson(
            route: "/direct/v1/payment/iap-verify",
            audience: "direct:payment.iap-verify",
            body: body)

        let valid = (json["valid"] as? Bool) ?? false
        if !valid {
            let rawReason = json["reason"] as? String
            let reason = rawReason
                .flatMap { DirectIapInvalidReason(rawValue: $0) }
                ?? .unknown
            return IapVerifyResult(valid: false, reason: reason)
        }
        let licenseKey = json["license_key"] as? String
        let tier = json["tier"] as? String
        let validUntil = Self.asInt(json["valid_until"])
        let entitlementJws = json["entitlement_jws"] as? String
        return IapVerifyResult(
            valid: true,
            licenseKey: licenseKey,
            tier: tier,
            validUntil: validUntil,
            entitlementJws: entitlementJws)
    }

    // ── B-FRON.5.6 — POST /direct/v1/payment/refresh ────────────────

    /// "I just paid — give me a fresh entitlement reflecting the new
    /// tier." Pure-read against the persisted checkout-session link +
    /// catalog. The state mutation already happened on the webhook
    /// side; this call mints a fresh JWS off the current bind row.
    ///
    /// `sessionId` is optional — when omitted the call degrades to
    /// "give me my current entitlement", which is functionally
    /// equivalent to `verify()` but emits a different server-side
    /// audit action (`payment.refresh.no_session`) so dashboards can
    /// split the two flows. Surfaces `.sessionNotFound` /
    /// `.sessionNotComplete` when a non-nil `sessionId` does not
    /// match a completed checkout-session row.
    func refreshAfterPayment(
        sessionId: String? = nil
    ) async throws -> VerifyResult {
        try requireConnected()

        var body: [String: Any] = [
            "project_id": projectId,
        ]
        if let sid = sessionId {
            body["session_id"] = sid
        }

        let json = try await postDurableJson(
            route: "/direct/v1/payment/refresh",
            audience: "direct:payment.refresh",
            body: body)

        // Wire shape mirrors `/verify` (deliberate — the SDK has ONE
        // parser regardless of which path freshened the entitlement),
        // minus the `deactivated` fast-path (`/refresh` is never the
        // revocation channel — that lives on `/verify` + `/heartbeat`).
        guard let jws = json["entitlement_jws"] as? String else {
            throw DirectError.network(
                message: "refresh response missing entitlement_jws")
        }
        let tierMeta = json["tier_metadata"] as? [String: Any] ?? [:]
        let features = (json["feature_list"] as? [String]) ?? []
        let quotas = Self.decodeIntMap(json["quotas"])
        let refreshedAtMs = Self.asInt(json["refreshed_at_ms"])

        // Push the fresh entitlement into the actor's in-memory
        // snapshot so subsequent `hasFeature(...)` / `quota(...)`
        // reads reflect the post-payment state immediately — the host
        // product does NOT need a separate `verify()` call to refresh
        // the local cache.
        applyEntitlementSnapshot(features: features, quotas: quotas)

        return VerifyResult(
            entitlementJws: jws,
            tierMetadata: tierMeta,
            featureList: features,
            quotas: quotas,
            refreshedAtMs: refreshedAtMs,
            deactivated: false,
            deactivatedReason: nil,
            deactivatedAtMs: nil)
    }

    // ── Internal helpers — actor-isolated state access ──────────────

    /// Exposes the actor's `config.projectId` to the extension methods
    /// without round-tripping through the actor's external surface.
    /// `nonisolated` is safe here because `DirectConfig` is `Sendable`
    /// and the actor never mutates it post-init.
    private var projectId: String { config.projectId }

    // ── Wire-shape validation helpers ───────────────────────────────

    /// Client-side return-URL pre-validation. The server-side allow-
    /// list is the load-bearing defence; this is a fast-fail so an
    /// obviously malformed URL surfaces locally before the round-trip.
    /// HTTPS-only (the SDK does not admit plaintext payment URLs at
    /// any layer, regardless of project allowlist).
    fileprivate static func requireHttpsUrl(
        _ url: URL,
        fieldName: String
    ) throws {
        guard let scheme = url.scheme?.lowercased(),
              scheme == "https" else {
            throw DirectError.badRequest(reason: "\(fieldName)_not_https")
        }
        guard url.host?.isEmpty == false else {
            throw DirectError.badRequest(reason: "\(fieldName)_no_host")
        }
        if url.absoluteString.count > Self.maxReturnUrlLength {
            throw DirectError.badRequest(reason: "\(fieldName)_too_long")
        }
    }

    /// Mirror of the server-side `TIER_SLUG_RE = /^[a-z0-9_]{1,64}$/`.
    fileprivate static func requireTierSlug(_ tier: String) throws {
        if tier.isEmpty || tier.count > 64 {
            throw DirectError.badRequest(reason: "tier_invalid")
        }
        for s in tier.unicodeScalars {
            let v = s.value
            let isLower = (v >= 0x61 && v <= 0x7a)        // a-z
            let isDigit = (v >= 0x30 && v <= 0x39)        // 0-9
            let isUnderscore = (v == 0x5f)                // _
            if !(isLower || isDigit || isUnderscore) {
                throw DirectError.badRequest(reason: "tier_invalid")
            }
        }
    }

    /// Mirror of the server-side `/^[A-Z]{3}$/` ISO-4217 check.
    fileprivate static func requireCurrencyTag(_ currency: String) throws {
        if currency.count != 3 {
            throw DirectError.badRequest(reason: "currency_invalid")
        }
        for s in currency.unicodeScalars {
            let v = s.value
            if !(v >= 0x41 && v <= 0x5a) { // A-Z
                throw DirectError.badRequest(reason: "currency_invalid")
            }
        }
    }

    /// Coerce a JSON number (Int / NSNumber / Double) to Int.
    fileprivate static func asInt(_ raw: Any?) -> Int? {
        if let n = raw as? Int { return n }
        if let n = raw as? NSNumber { return n.intValue }
        if let n = raw as? Double { return Int(n) }
        return nil
    }

    /// Convert a JSON map's number values to `Int` — sibling to
    /// `DirectClient.decodeIntMap` (which is `private`, hence
    /// duplicated here rather than exposed).
    fileprivate static func decodeIntMap(_ raw: Any?) -> [String: Int] {
        guard let m = raw as? [String: Any] else { return [:] }
        var out: [String: Int] = [:]
        for (k, v) in m {
            if let n = v as? Int { out[k] = n }
            else if let n = v as? NSNumber { out[k] = n.intValue }
            else if let n = v as? Double { out[k] = Int(n) }
        }
        return out
    }

    // ── Defence-in-depth bounds (mirror server caps) ────────────────

    /// Maximum length of a hosted return-URL the SDK will emit. Mirrors
    /// `RETURN_URL_MAX_LEN = 2048` in the server-side checkout handler.
    fileprivate static var maxReturnUrlLength: Int { 2048 }

    /// Maximum bytes accepted for an IAP receipt. 24 KB matches the
    /// Dart twin's `kIapReceiptMaxBytes` after the W6 fix-pass — Apple's
    /// signed JWS receipts run ~4-8 KB and Google purchase tokens run
    /// ~250-500 chars, so 24 KB leaves headroom for size growth without
    /// admitting obviously-malformed payloads. The server enforces the
    /// same hard cap in `assertIapVerifyBody`; this client-side check
    /// is defence-in-depth so an oversized receipt fails fast (no JWE
    /// round-trip, no audit-log row).
    ///
    /// FIX S-Fix 3 — renamed `maxIapReceiptBytes` → `ipReceiptMaxBytes`
    /// to match the Dart constant identifier exactly so a grep across
    /// both twins surfaces a single source of truth.
    fileprivate static var ipReceiptMaxBytes: Int { 24576 }

    /// Maximum number of restored-purchase rows we accept from the
    /// server. Defence-in-depth — the server bounds the response size
    /// at the port layer, but we cap on the SDK side too so a
    /// server-side bug cannot ship an arbitrarily-large payload.
    fileprivate static var maxRestoredEntries: Int { 1000 }
}
