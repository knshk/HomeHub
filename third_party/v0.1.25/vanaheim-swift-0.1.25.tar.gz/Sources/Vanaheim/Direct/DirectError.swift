// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

// ─────────────────────────────────────────────────────────────────────
// DirectError — Swift-native enum mirroring the FRON server-side error
// taxonomy (`src/direct/errors.ts`). Each case carries the structured
// associated data the host product needs to make a UX decision (e.g.
// `.rateLimited(retryAfterMs:)`).
//
// Why a Swift enum (rather than a `LicenseStoreError` subclass tree
// like the L2 surface):
//   * Swift enums with associated values pattern-match more naturally
//     for callers that want to branch on case (the L2 surface uses
//     `catch let e as SeatCapExceededError` which is more verbose).
//   * The FRON server collapses every middleware failure to a small
//     set of coarse wire codes (see `_license-helpers.ts` + `errors.ts`)
//     — the SDK's job is to map those wire codes into a discriminated
//     Swift type so the host product can write a clean `switch error`.
//
// `LicenseStoreError` is still the conformance root so a host product
// that catches generically (`catch let e as LicenseStoreError`) sees
// FRON errors land in the same bucket as the L2 surface.
// ─────────────────────────────────────────────────────────────────────

/// FRON / Direct-mode error taxonomy. Every method on `DirectClient`
/// throws cases from this enum (or a wrapping `NetworkError` /
/// `LicenseStoreError` for transport-layer failures).
public enum DirectError: Error, CustomStringConvertible, Sendable {

    // ── License + entitlement (B-FRON.2.*) ──────────────────────────

    /// License key is unknown / malformed / mismatched against the
    /// project. Coarse — the server collapses several subcases to this
    /// single wire code so a probe can't enumerate which dimension
    /// tripped.
    case licenseInvalid(reason: String? = nil)

    /// License has reached its seat cap. Surfaces from `register` and
    /// `activate`.
    case licenseSeatExceeded

    /// License has expired (past `expires_at_ms`). Terminal — the host
    /// product should prompt for a fresh key rather than retrying.
    case licenseExpired

    /// `register()` only — the supplied fingerprint is already bound to
    /// a different device on this project.
    case fingerprintAlreadyRegistered

    // ── Notifications (B-FRON.3.*) ──────────────────────────────────

    /// `registerFcmToken()` — the supplied token is already bound to a
    /// DIFFERENT device. The host product should re-acquire a fresh
    /// token from the platform and retry.
    case fcmTokenReused

    // ── Cross-cutting middleware (B-FRON.1.*) ───────────────────────

    /// Per-device or per-project rate-limit tripped. `retryAfterMs`
    /// hints how long to back off; honour it before retrying.
    case rateLimited(retryAfterMs: Int)

    /// Project is not opted in to Direct mode on this Bifrost deploy.
    /// The host product should fall back to the L2 path or surface a
    /// configuration error.
    case projectDisabled

    /// Server rejected the JWE envelope (decrypt failure). The wire
    /// body collapses every reason to a single coarse code — usually
    /// indicates a stale recipient kid or a backend rotation in flight.
    /// The SDK auto-retries once after a force JWKS refresh.
    case jweDecryptFailed

    /// Server rejected the inner JWS (signature / claims). Indicates
    /// either a clock-skew issue, a device-id mismatch, or a malformed
    /// payload from the SDK. Terminal.
    case jwsInvalid

    /// Server detected an ephemeral-pubkey replay. The SDK regenerates
    /// the ephemeral keypair on every request, so this almost never
    /// fires in practice — when it does, the wire body indicates the
    /// SDK's request was held in flight long enough for the server to
    /// time-window the keypair out.
    case replayDetected

    // ── Server keys + JWKS (B-FRON.2.1 / B-FRON.2.8) ────────────────

    /// `acknowledgeKidRotation(kid:)` — the supplied kid is not
    /// currently published in the server's JWKS. Either the SDK is
    /// racing a rotation or the kid was mistyped.
    case kidNotPublished

    // ── Telemetry (B-FRON.4.*) ──────────────────────────────────────

    /// `reportError()` — the server-side error-ingest port is unwired
    /// on this deploy (HTTP 503). Coarse signal that the host product
    /// should NOT retry; the SDK already logged the drop.
    case telemetryNotWired

    // ── Generic / catch-all ─────────────────────────────────────────

    /// HTTP 4xx/5xx that didn't map to a more specific taxonomy code.
    /// `statusCode` is the raw HTTP status; `wireCode` is the server's
    /// `error.code` field (e.g. `DIRECT_BAD_REQUEST`).
    case server(statusCode: Int, wireCode: String?, message: String?)

    /// Wire / connection / TLS error — wraps the underlying `Error`.
    case network(message: String, cause: String? = nil)

    /// Caller used `DirectClient` before `connect()` finished.
    case notConnected

    /// The Bifrost JWKS did not publish any usable X25519 enc key.
    /// Either the deployment is in a key-rotation gap or the SDK's
    /// pinned algorithm allowlist doesn't intersect with what the
    /// server publishes. The SDK does NOT auto-retry — the host
    /// product should surface this as a configuration failure.
    case noRecipientKey

    /// Certificate pin check failed during the TLS handshake. Wraps
    /// the URLSessionDelegate `cancelAuthenticationChallenge` outcome
    /// (S-2). The SDK does NOT retry — a pin mismatch is a hard
    /// signal that either the deploy's leaf-cert rotated without the
    /// SDK getting a fresh pin list, or a man-in-the-middle box is
    /// between the device and Bifrost. Either way the only safe
    /// posture is fail-closed: surface to the host product so it can
    /// re-fetch its pin list or alert the user.
    case certPinFailed

    /// Server returned `DIRECT_DEVICE_REVOKED` (S-5). The SDK has
    /// already wiped the durable Ed25519 keypair + device id + cached
    /// entitlements; the host product MUST drive the user through
    /// re-registration (call `register(...)` again with a fresh
    /// license key). Terminal for the current device identity —
    /// retrying the same Tier-2 call without re-registering will keep
    /// failing the same way.
    case deviceRevoked(reason: String? = nil)

    // ── Payments (B-FRON.5.*) ───────────────────────────────────────

    /// Generic bad-request wrapper for the payment surface (W6).
    /// Mirrors the DIRECT_BAD_REQUEST wire code the payment handlers
    /// throw for return-URL allowlist misses, malformed currency tags,
    /// unknown tier slugs, and the like. The server collapses several
    /// 400-class shapes into this code so a probe cannot enumerate
    /// which dimension tripped — the `reason` field is the sanitised
    /// message the server logs alongside.
    case badRequest(reason: String? = nil)

    /// Server returned `DIRECT_PAYMENT_PROVIDER_FAILED` (HTTP 502 —
    /// downstream provider blip). The SDK should retry with backoff;
    /// the wire body never carries provider-side internals.
    case paymentProviderFailed(provider: String? = nil)

    /// Server returned `DIRECT_NO_PROVIDER_CONFIGURED` (HTTP 503 — the
    /// project has no payment provider wired). Distinct from
    /// `paymentProviderFailed` because the recovery is admin-side
    /// (provision a Stripe / Paddle / Razorpay account) rather than
    /// retry. Terminal until the deploy is reconfigured.
    case noProviderConfigured

    /// Server returned `DIRECT_NO_ACTIVE_SUBSCRIPTION` (HTTP 409 —
    /// the device asked to manage a subscription that doesn't exist
    /// or has been canceled). The host product should route the user
    /// through `startCheckout(...)` instead of `openPortal(...)`.
    case noActiveSubscription

    /// Server returned `DIRECT_SESSION_NOT_FOUND` (HTTP 404 — the
    /// supplied checkout session_id has no persisted FRON-leg
    /// correlation row). Coarse — the server also surfaces this when
    /// the row exists under a different project_id (cross-project
    /// probe defence).
    case sessionNotFound

    /// Server returned `DIRECT_SESSION_NOT_COMPLETE` (HTTP 409 —
    /// the row exists but the provider webhook has not flipped
    /// `completed=true` yet). The host product should retry with
    /// backoff; webhook delivery is usually sub-second but can lag
    /// under provider load.
    case sessionNotComplete

    /// Server returned `DIRECT_IAP_RECEIPT_INVALID` (HTTP 400 — Apple
    /// / Google's verify API rejected the supplied receipt). The
    /// narrow `reason` (expired / malformed / not_subscribed /
    /// unknown) drives the host product's recovery UX.
    case iapReceiptInvalid(reason: String? = nil)

    public var description: String {
        switch self {
        case .licenseInvalid(let reason):
            return "DirectError.licenseInvalid\(reason.map { " (\($0))" } ?? "")"
        case .licenseSeatExceeded: return "DirectError.licenseSeatExceeded"
        case .licenseExpired: return "DirectError.licenseExpired"
        case .fingerprintAlreadyRegistered: return "DirectError.fingerprintAlreadyRegistered"
        case .fcmTokenReused: return "DirectError.fcmTokenReused"
        case .rateLimited(let ms): return "DirectError.rateLimited(retryAfterMs=\(ms))"
        case .projectDisabled: return "DirectError.projectDisabled"
        case .jweDecryptFailed: return "DirectError.jweDecryptFailed"
        case .jwsInvalid: return "DirectError.jwsInvalid"
        case .replayDetected: return "DirectError.replayDetected"
        case .kidNotPublished: return "DirectError.kidNotPublished"
        case .telemetryNotWired: return "DirectError.telemetryNotWired"
        case .server(let s, let w, let m):
            return "DirectError.server(status=\(s) code=\(w ?? "?") message=\(m ?? "?"))"
        case .network(let m, let c):
            return "DirectError.network(\(m)\(c.map { " — \($0)" } ?? ""))"
        case .notConnected: return "DirectError.notConnected"
        case .noRecipientKey: return "DirectError.noRecipientKey"
        case .certPinFailed: return "DirectError.certPinFailed"
        case .deviceRevoked(let r):
            return "DirectError.deviceRevoked\(r.map { " (\($0))" } ?? "")"
        case .badRequest(let r):
            return "DirectError.badRequest\(r.map { " (\($0))" } ?? "")"
        case .paymentProviderFailed(let p):
            return "DirectError.paymentProviderFailed\(p.map { " (\($0))" } ?? "")"
        case .noProviderConfigured:
            return "DirectError.noProviderConfigured"
        case .noActiveSubscription:
            return "DirectError.noActiveSubscription"
        case .sessionNotFound:
            return "DirectError.sessionNotFound"
        case .sessionNotComplete:
            return "DirectError.sessionNotComplete"
        case .iapReceiptInvalid(let r):
            return "DirectError.iapReceiptInvalid\(r.map { " (\($0))" } ?? "")"
        }
    }
}

/// Bridges a server-side wire code + HTTP status to a `DirectError`
/// case. Centralised so the request builder + every response parser
/// surface a consistent taxonomy.
public enum DirectErrorMapper {
    /// Map a server response envelope into the appropriate `DirectError`
    /// case.
    ///
    /// - `wireCode`: the JSON `error.code` field on the sealed-error
    ///   envelope (post-W6 fix-pass-2 → `claims.error.code`).
    /// - `message`: legacy fallback for the human-readable
    ///   `error.message` field. Some routes still emit this on the
    ///   plaintext error path.
    /// - `retryAfterMs`: parsed from the sealed `retry_after_ms` claim
    ///   (or the plaintext `Retry-After` header on the legacy path).
    /// - `reason`: structured narrow-reason hint (e.g.
    ///   `DIRECT_IAP_RECEIPT_INVALID` carries `expired`/`malformed`/
    ///   `not_subscribed`/`unknown`; `DIRECT_DEVICE_REVOKED` carries
    ///   `key_rotation` etc.). Preferred over `message` when both are
    ///   present.
    /// - `provider`: provider tag on `DIRECT_PAYMENT_PROVIDER_FAILED`
    ///   (sanitised by the server to one of stripe/paddle/lemon_squeezy/
    ///   razorpay/apple_iap/google_iap/restore).
    public static func map(
        statusCode: Int,
        wireCode: String?,
        message: String?,
        retryAfterMs: Int? = nil,
        reason: String? = nil,
        provider: String? = nil
    ) -> DirectError {
        // Prefer structured `reason` over `message`; the W6 sealed-error
        // envelope splits the human message off into its own field so
        // the SDK can fork UX on the narrow reason taxonomy without
        // string-matching free-form messages.
        let effectiveReason = reason ?? message
        // Coarse wire codes shipped by the FRON middleware chain — see
        // `bifrost/packages/functions/src/direct/handlers/_license-helpers.ts`
        // and `direct/errors.ts` for the source of truth.
        switch (wireCode ?? "").uppercased() {
        case "DIRECT_LICENSE_INVALID":
            return .licenseInvalid(reason: effectiveReason)
        case "DIRECT_LICENSE_SEAT_EXCEEDED":
            return .licenseSeatExceeded
        case "DIRECT_LICENSE_EXPIRED":
            return .licenseExpired
        case "DIRECT_FINGERPRINT_ALREADY_REGISTERED",
             "DIRECT_REGISTER_FINGERPRINT_ALREADY_REGISTERED":
            return .fingerprintAlreadyRegistered
        case "DIRECT_FCM_TOKEN_REUSED":
            return .fcmTokenReused
        case "DIRECT_RATE_LIMIT", "DIRECT_RATE_LIMITED":
            return .rateLimited(retryAfterMs: retryAfterMs ?? 0)
        case "DIRECT_PROJECT_DISABLED":
            return .projectDisabled
        case "DIRECT_JWE_DECRYPT_FAILED":
            return .jweDecryptFailed
        case "DIRECT_JWS_INVALID":
            return .jwsInvalid
        case "DIRECT_REPLAY_DETECTED":
            return .replayDetected
        case "DIRECT_KID_NOT_PUBLISHED":
            return .kidNotPublished
        case "DIRECT_TELEMETRY_NOT_WIRED":
            return .telemetryNotWired
        case "DIRECT_DEVICE_REVOKED":
            return .deviceRevoked(reason: effectiveReason)
        case "DIRECT_BAD_REQUEST":
            return .badRequest(reason: effectiveReason)
        case "DIRECT_PAYMENT_PROVIDER_FAILED":
            // Server `provider` claim carries the sanitised provider tag
            // ("stripe" / "paddle" / "lemon_squeezy" / "razorpay" /
            // "apple_iap" / "google_iap" / "restore"). The pre-sealed-
            // envelope legacy path folded the same tag into `message`;
            // honour both shapes so a server that hasn't migrated yet
            // still surfaces the provider tag verbatim.
            return .paymentProviderFailed(provider: provider ?? message)
        case "DIRECT_NO_PROVIDER_CONFIGURED":
            return .noProviderConfigured
        case "DIRECT_NO_ACTIVE_SUBSCRIPTION":
            return .noActiveSubscription
        case "DIRECT_SESSION_NOT_FOUND":
            return .sessionNotFound
        case "DIRECT_SESSION_NOT_COMPLETE":
            return .sessionNotComplete
        case "DIRECT_IAP_RECEIPT_INVALID":
            // The IAP narrow reason rides the sealed-error envelope's
            // `reason` field (per W6 fix-pass-2 fixture sample
            // `DIRECT_IAP_RECEIPT_INVALID_expired`): one of
            // expired/malformed/not_subscribed/unknown. Legacy 400-class
            // adapter rejections still arrive via `message`; both shapes
            // route here through `effectiveReason`.
            return .iapReceiptInvalid(reason: effectiveReason)
        default:
            return .server(statusCode: statusCode, wireCode: wireCode, message: message)
        }
    }
}
