// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2B.6 Account portability — license transfer + account merge requests.
public actor AccountAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    public func transferRequest(targetEmail: String, reason: String) async throws -> AccountRequest {
        try capabilities.require("preferences")
        let url = await endpoint().appendingPathComponent("v1/account/transfer-request")
        let raw = try await http.postJson(url: url, body: ["target_email": targetEmail, "reason": reason])
        return try NotificationsAPI.decode(raw, AccountRequest.self)
    }

    public func mergeRequest(targetEmail: String, reason: String) async throws -> AccountRequest {
        try capabilities.require("preferences")
        let url = await endpoint().appendingPathComponent("v1/account/merge-request")
        let raw = try await http.postJson(url: url, body: ["target_email": targetEmail, "reason": reason])
        return try NotificationsAPI.decode(raw, AccountRequest.self)
    }

    public func getRequest(_ id: String) async throws -> AccountRequest {
        try capabilities.require("preferences")
        let url = await endpoint().appendingPathComponent("v1/account/requests/\(id)")
        let raw = try await http.postJson(url: url, body: [:])
        return try NotificationsAPI.decode(raw, AccountRequest.self)
    }
}
