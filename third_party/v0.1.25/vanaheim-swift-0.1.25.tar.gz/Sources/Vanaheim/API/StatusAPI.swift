// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2B.5 Status page consumer surface — current snapshot + AsyncStream
/// of changes via polling.
public actor StatusAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities
    private var pollTask: Task<Void, Never>?

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    public func current() async throws -> SystemStatus {
        try capabilities.require("status")
        let url = await endpoint().appendingPathComponent("v1/status/current")
        let raw = try await http.postJson(url: url, body: [:])
        return try NotificationsAPI.decode(raw, SystemStatus.self)
    }

    /// Returns an `AsyncStream` of status snapshots. Polls every
    /// `pollIntervalSeconds` (default 60); de-dups on `overall` + `updatedAt`.
    public func subscribe(pollIntervalSeconds: Int = 60) async throws -> AsyncStream<SystemStatus> {
        try capabilities.require("status")
        pollTask?.cancel()
        let http = self.http
        let endpoint = self.endpoint
        let interval = pollIntervalSeconds
        return AsyncStream { continuation in
            let task = Task { [weak self] in
                guard self != nil else { return }
                var last: SystemStatus? = nil
                while !Task.isCancelled {
                    do {
                        let url = await endpoint().appendingPathComponent("v1/status/current")
                        let raw = try await http.postJson(url: url, body: [:])
                        let s = try NotificationsAPI.decode(raw, SystemStatus.self)
                        if last == nil || last?.overall != s.overall || last?.updatedAt != s.updatedAt {
                            continuation.yield(s)
                            last = s
                        }
                    } catch {
                        // Transient — drop tick; the subscriber sees stale state,
                        // never an error.
                    }
                    try? await Task.sleep(nanoseconds: UInt64(interval) * 1_000_000_000)
                }
                continuation.finish()
            }
            Task { await self.setPollTask(task) }
            continuation.onTermination = { _ in task.cancel() }
        }
    }

    private func setPollTask(_ task: Task<Void, Never>) {
        pollTask = task
    }

    public func dispose() {
        pollTask?.cancel()
        pollTask = nil
    }
}
