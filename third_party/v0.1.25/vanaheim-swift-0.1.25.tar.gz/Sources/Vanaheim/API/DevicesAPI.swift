// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2A.5 / v2-Vanaheim device enrollment.
///
/// In v2 the SDK no longer talks to Bifrost directly for device records —
/// enrollment, heartbeat, and revocation are all owned by L2 (Alfheim). On
/// first boot the SDK auto-registers its X25519 device pubkey via `register`;
/// subsequent boots skip enrollment by checking the `device_registered_v1`
/// SecureCache marker that `LicenseClient` writes after a successful
/// `register` call.
///
/// All three endpoints live under `{l2BaseUrl}/v1/devices/...`. The SDK
/// passes its `SignedHttpClient` in so the HMAC + auth + AppCheck headers
/// + JWE envelope are applied uniformly with the rest of the data-plane API
/// surface.
///
/// Mirror of `sdk/dart/license_store_sdk/lib/src/api/devices_api.dart`.
public final class DevicesAPI: Sendable {
    private let http: SignedHttpClient
    private let l2BaseUrl: URL

    public init(http: SignedHttpClient, l2BaseUrl: URL) {
        self.http = http
        self.l2BaseUrl = l2BaseUrl
    }

    /// Enrolls this device's X25519 public key with L2. Idempotent on
    /// `(project_id, device_fingerprint)`; safe to retry on transient
    /// failures. Returns the server-assigned `device_id` (string) which the
    /// caller persists in SecureCache for the heartbeat / revoke endpoints
    /// and for the `X-LS-Device-Id` header on JWE-required calls.
    ///
    /// The route is JWE-required per the hard-coded policy in
    /// `RoutePolicy.swift` (forthcoming) — the underlying `SignedHttpClient`
    /// wraps the body in a JWE envelope automatically. Callers do NOT need
    /// to do anything special here.
    public func register(devicePubKey: Data) async throws -> DeviceEnrollment {
        guard !devicePubKey.isEmpty else {
            throw LicenseStoreError("DevicesAPI.register: device public key must not be empty")
        }
        let url = l2BaseUrl.appendingPathComponent("v1/devices/enroll")
        let res = try await http.postJson(url: url, body: [
            // Base64url, no padding — JWE/JWS canonical form. The server
            // uses this directly as the X25519 recipient pubkey for
            // JWE-to-device and never re-encodes.
            "device_pubkey": devicePubKey.base64URLEncodedString(),
        ])
        guard let deviceId = res["device_id"] as? String, !deviceId.isEmpty else {
            throw NetworkError("L2 enroll returned no device_id")
        }
        return DeviceEnrollment(
            deviceId: deviceId,
            enrolledAt: Self.parseTimeOrNow(res["enrolled_at"]))
    }

    /// Marks this device as online with L2. Cheap call — used to keep the
    /// device's `last_seen_at` fresh so L2 can prune stale records on its own
    /// schedule. Idempotent. No body parameters; the device identity is
    /// pulled from the request headers (`X-LS-Device-Id` + HMAC).
    public func heartbeat() async throws {
        let url = l2BaseUrl.appendingPathComponent("v1/devices/heartbeat")
        _ = try await http.postJson(url: url, body: [:])
    }

    /// Revokes a specific device by id. Most products will call this for
    /// "sign out everywhere" / "lost my phone" flows. The current device can
    /// revoke itself by passing its own `deviceId` — the SDK's normal
    /// `deactivate()` flow does NOT call this (it only frees the seat); use
    /// this when you mean "delete the device record + invalidate its
    /// pubkey on L2 permanently".
    ///
    /// Surfaces `DeviceRevokedError` if the server reports the device was
    /// already revoked.
    public func revoke(deviceId: String) async throws {
        guard !deviceId.isEmpty else {
            throw LicenseStoreError("DevicesAPI.revoke: deviceId must not be empty")
        }
        let url = l2BaseUrl.appendingPathComponent("v1/devices/\(deviceId)/revoke")
        _ = try await http.postJson(url: url, body: [:])
    }

    private static func parseTimeOrNow(_ raw: Any?) -> Date {
        if let s = raw as? String {
            let fmt = ISO8601DateFormatter()
            fmt.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let d = fmt.date(from: s) {
                return d
            }
            let fallback = ISO8601DateFormatter()
            if let d = fallback.date(from: s) {
                return d
            }
        }
        return Date()
    }
}

/// Result of a successful `DevicesAPI.register` call. Held briefly by the
/// SDK's connect()-time enrollment flow; the `deviceId` is persisted into
/// SecureCache for subsequent boots.
public struct DeviceEnrollment: Sendable {
    /// L2-assigned, opaque device identifier. Used as `X-LS-Device-Id` on
    /// JWE-required calls + as the path segment in `DevicesAPI.revoke`.
    public let deviceId: String

    /// Server-reported enrollment timestamp (UTC). Diagnostics only.
    public let enrolledAt: Date

    public init(deviceId: String, enrolledAt: Date) {
        self.deviceId = deviceId
        self.enrolledAt = enrolledAt
    }
}
