// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Privacy + consent center: GDPR Art. 20 data export, Art. 17 erasure,
/// per-scope consent management. Access via `LicenseClient.privacy`.
public actor PrivacyAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    /// Initiates an async data export (GDPR Art. 20).
    public func exportData() async throws -> PrivacyJob {
        try capabilities.require("privacy")
        let url = await endpoint().appendingPathComponent("v1/privacy/export")
        let raw = try await http.postJson(url: url, body: [:])
        return try NotificationsAPI.decode(raw, PrivacyJob.self)
    }

    /// Requests account erasure (GDPR Art. 17). Backend crypto-shreds PII
    /// while retaining encrypted aggregate financial data per tax retention.
    /// [confirmation] must be the exact account email.
    public func requestErasure(confirmation: String) async throws -> PrivacyJob {
        try capabilities.require("privacy")
        let url = await endpoint().appendingPathComponent("v1/privacy/erase")
        let raw = try await http.postJson(url: url, body: ["confirmation": confirmation])
        return try NotificationsAPI.decode(raw, PrivacyJob.self)
    }

    /// Polls a privacy job.
    public func getJob(_ id: String) async throws -> PrivacyJob {
        try capabilities.require("privacy")
        let url = await endpoint().appendingPathComponent("v1/privacy/jobs/\(id)")
        let raw = try await http.postJson(url: url, body: [:])
        return try NotificationsAPI.decode(raw, PrivacyJob.self)
    }

    /// Fetches the user's current per-scope consent state.
    public func getConsents() async throws -> ConsentState {
        try capabilities.require("privacy")
        let url = await endpoint().appendingPathComponent("v1/privacy/consents/get")
        let raw = try await http.postJson(url: url, body: [:])
        return try NotificationsAPI.decode(raw, ConsentState.self)
    }

    /// Updates per-scope consents. Server records timestamp + IP + UA +
    /// exact text version into the consent ledger for GDPR Art. 7 proof.
    public func updateConsents(_ state: ConsentState, consentTextVersion: String? = nil) async throws -> ConsentState {
        try capabilities.require("privacy")
        var body: [String: Any] = ["scopes": state.scopes]
        if let v = consentTextVersion { body["consent_text_version"] = v }
        let url = await endpoint().appendingPathComponent("v1/privacy/consents/update")
        let raw = try await http.postJson(url: url, body: body)
        return try NotificationsAPI.decode(raw, ConsentState.self)
    }
}
