// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Feedback / NPS / CSAT / exit-survey submission. Access via
/// `LicenseClient.feedback`. Device context auto-attached server-side.
public actor FeedbackAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    private var maxAttachmentBytes: Int { capabilities.feedbackMaxAttachmentMb * 1024 * 1024 }

    /// Structured feedback submission. Body text is envelope-encrypted server-side.
    public func submit(
        category: String,
        rating: Int? = nil,
        text: String? = nil,
        attachments: [FeedbackAttachment] = []
    ) async throws -> FeedbackReceipt {
        try capabilities.require("feedback")
        var body: [String: Any] = ["category": category]
        if let rating = rating { body["rating"] = rating }
        if let text = text { body["text"] = text }
        let encodedAttachments = attachments
            .filter { $0.bytes.count <= maxAttachmentBytes }
            .map { att -> [String: Any] in
                [
                    "filename": att.filename,
                    "content_type": att.contentType,
                    "bytes_b64": att.bytes.base64EncodedString()
                ]
            }
        if !encodedAttachments.isEmpty {
            body["attachments"] = encodedAttachments
        }
        let url = await endpoint().appendingPathComponent("v1/feedback")
        let raw = try await http.postJson(url: url, body: body)
        return try NotificationsAPI.decode(raw, FeedbackReceipt.self)
    }

    /// NPS score 0-10 with optional comment.
    public func nps(score: Int, comment: String? = nil) async throws -> FeedbackReceipt {
        try capabilities.require("feedback")
        guard (0...10).contains(score) else {
            throw FeedbackError("NPS score must be 0-10")
        }
        var body: [String: Any] = ["score": score]
        if let comment = comment { body["comment"] = comment }
        let url = await endpoint().appendingPathComponent("v1/feedback/nps")
        let raw = try await http.postJson(url: url, body: body)
        return try NotificationsAPI.decode(raw, FeedbackReceipt.self)
    }

    /// CSAT score 1-5.
    public func csat(score: Int, comment: String? = nil, ticketId: String? = nil) async throws -> FeedbackReceipt {
        try capabilities.require("feedback")
        guard (1...5).contains(score) else {
            throw FeedbackError("CSAT score must be 1-5")
        }
        var body: [String: Any] = ["score": score]
        if let comment = comment { body["comment"] = comment }
        if let ticketId = ticketId { body["ticket_id"] = ticketId }
        let url = await endpoint().appendingPathComponent("v1/feedback/csat")
        let raw = try await http.postJson(url: url, body: body)
        return try NotificationsAPI.decode(raw, FeedbackReceipt.self)
    }

    /// Records that a survey prompt was shown so the orchestrator can dedup.
    public func markPromptShown(_ surveyId: String) async throws {
        try capabilities.require("feedback")
        let url = await endpoint().appendingPathComponent("v1/feedback/prompt-shown")
        _ = try await http.postJson(url: url, body: ["survey_id": surveyId])
    }
}

/// Argument-validation error for feedback API (e.g. NPS out of range).
public final class FeedbackError: LicenseStoreError {
    public override init(_ message: String, cause: Error? = nil) {
        super.init(message, cause: cause)
    }
}
