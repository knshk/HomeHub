// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2B.7 Organization / B2B SSO surface.
public actor OrganizationAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    public func members() async throws -> [OrgMember] {
        try capabilities.require("organization")
        let url = await endpoint().appendingPathComponent("v1/organization/members")
        let raw = try await http.postJson(url: url, body: [:])
        guard let arr = raw["members"] as? [[String: Any]] else { return [] }
        let data = try JSONSerialization.data(withJSONObject: arr)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode([OrgMember].self, from: data)
    }

    public func invite(email: String, role: String = "member") async throws -> OrgInvite {
        try capabilities.require("organization")
        let url = await endpoint().appendingPathComponent("v1/organization/invites")
        let raw = try await http.postJson(url: url, body: ["email": email, "role": role])
        return try NotificationsAPI.decode(raw, OrgInvite.self)
    }

    public func listInvites() async throws -> [OrgInvite] {
        try capabilities.require("organization")
        let url = await endpoint().appendingPathComponent("v1/organization/invites/list")
        let raw = try await http.postJson(url: url, body: [:])
        guard let arr = raw["invites"] as? [[String: Any]] else { return [] }
        let data = try JSONSerialization.data(withJSONObject: arr)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode([OrgInvite].self, from: data)
    }

    public func revokeInvite(_ inviteId: String) async throws {
        try capabilities.require("organization")
        let url = await endpoint().appendingPathComponent("v1/organization/invites/\(inviteId)/revoke")
        _ = try await http.postJson(url: url, body: [:])
    }

    public func ssoStartUrl(orgSlug: String, returnUrl: URL? = nil) async throws -> URL {
        try capabilities.require("organization")
        var body: [String: Any] = ["org_slug": orgSlug]
        if let returnUrl = returnUrl { body["return_url"] = returnUrl.absoluteString }
        let url = await endpoint().appendingPathComponent("v1/organization/sso/start")
        let raw = try await http.postJson(url: url, body: body)
        guard let str = raw["url"] as? String, !str.isEmpty, let parsed = URL(string: str) else {
            throw NetworkError("sso/start returned no URL")
        }
        return parsed
    }
}
