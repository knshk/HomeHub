// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2B.3 AI customer assistant.
public actor AssistantAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    public func ask(prompt: String, conversationId: String? = nil) async throws -> AssistantMessage {
        try capabilities.require("assistant")
        var body: [String: Any] = ["prompt": prompt]
        if let conversationId = conversationId { body["conversation_id"] = conversationId }
        let url = await endpoint().appendingPathComponent("v1/assistant/ask")
        let raw = try await http.postJson(url: url, body: body)
        guard let msg = raw["message"] as? [String: Any] else {
            throw NetworkError("assistant/ask returned no message")
        }
        return try NotificationsAPI.decode(msg, AssistantMessage.self)
    }

    public func conversations(limit: Int = 20) async throws -> [AssistantConversation] {
        try capabilities.require("assistant")
        let url = await endpoint().appendingPathComponent("v1/assistant/conversations")
        let raw = try await http.postJson(url: url, body: ["limit": limit])
        guard let arr = raw["conversations"] as? [[String: Any]] else { return [] }
        let data = try JSONSerialization.data(withJSONObject: arr)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode([AssistantConversation].self, from: data)
    }

    public func conversation(_ id: String) async throws -> AssistantConversationDetail {
        try capabilities.require("assistant")
        let url = await endpoint().appendingPathComponent("v1/assistant/conversations/\(id)")
        let raw = try await http.postJson(url: url, body: [:])
        guard let convoRaw = raw["conversation"] as? [String: Any] else {
            throw NetworkError("assistant returned no conversation")
        }
        let messagesRaw = raw["messages"] as? [[String: Any]] ?? []
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let convo = try NotificationsAPI.decode(convoRaw, AssistantConversation.self)
        let messages = try decoder.decode(
            [AssistantMessage].self,
            from: JSONSerialization.data(withJSONObject: messagesRaw))
        return AssistantConversationDetail(conversation: convo, messages: messages)
    }
}
