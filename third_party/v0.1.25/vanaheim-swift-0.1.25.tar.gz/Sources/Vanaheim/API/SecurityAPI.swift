// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2A.8 — MFA + session management.
///
/// Day-1 contract covers TOTP, recovery codes, sessions, step-up grants.
/// WebAuthn registration ceremony is platform-native and deferred to the
/// consuming app — backend exposes the challenge endpoint when that lands.
///
/// Gated by `capabilities.mfa`.
public actor SecurityAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    public func status() async throws -> MfaStatus {
        try capabilities.require("mfa")
        let url = await endpoint().appendingPathComponent("v1/security/mfa/status")
        let raw = try await http.postJson(url: url, body: [:])
        return try NotificationsAPI.decode(raw, MfaStatus.self)
    }

    public func enrollTotp(accountEmail: String, label: String? = nil) async throws -> TotpEnrollment {
        try capabilities.require("mfa")
        var body: [String: Any] = ["account_email": accountEmail]
        if let label = label { body["label"] = label }
        let url = await endpoint().appendingPathComponent("v1/security/mfa/totp/enroll")
        let raw = try await http.postJson(url: url, body: body)
        return try NotificationsAPI.decode(raw, TotpEnrollment.self)
    }

    public func verifyTotp(factorId: String, code: String) async throws {
        try capabilities.require("mfa")
        let url = await endpoint().appendingPathComponent("v1/security/mfa/totp/verify")
        _ = try await http.postJson(url: url, body: ["factor_id": factorId, "code": code])
    }

    public func regenerateRecoveryCodes() async throws -> [String] {
        try capabilities.require("mfa")
        let url = await endpoint().appendingPathComponent("v1/security/mfa/recovery-codes/regenerate")
        let raw = try await http.postJson(url: url, body: [:])
        return raw["codes"] as? [String] ?? []
    }

    public func verifyRecoveryCode(_ code: String) async throws {
        try capabilities.require("mfa")
        let url = await endpoint().appendingPathComponent("v1/security/mfa/recovery-codes/verify")
        _ = try await http.postJson(url: url, body: ["code": code])
    }

    public func listSessions() async throws -> [MfaSession] {
        try capabilities.require("mfa")
        let url = await endpoint().appendingPathComponent("v1/security/sessions")
        let raw = try await http.postJson(url: url, body: [:])
        guard let arr = raw["sessions"] as? [[String: Any]] else { return [] }
        let data = try JSONSerialization.data(withJSONObject: arr)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode([MfaSession].self, from: data)
    }

    public func revokeSession(_ id: String) async throws {
        try capabilities.require("mfa")
        let url = await endpoint().appendingPathComponent("v1/security/sessions/\(id)/revoke")
        _ = try await http.postJson(url: url, body: [:])
    }

    public func revokeAllSessions() async throws {
        try capabilities.require("mfa")
        let url = await endpoint().appendingPathComponent("v1/security/sessions/revoke-all")
        _ = try await http.postJson(url: url, body: [:])
    }

    public func mintStepUp(scope: String, ttlSeconds: Int = 300) async throws -> StepUpGrant {
        try capabilities.require("mfa")
        let url = await endpoint().appendingPathComponent("v1/security/step-up/mint")
        let raw = try await http.postJson(url: url, body: ["scope": scope, "ttl_secs": ttlSeconds])
        return try NotificationsAPI.decode(raw, StepUpGrant.self)
    }
}

// MARK: - Models

public struct MfaFactor: Sendable, Codable {
    public let id: String
    public let type: String
    public let label: String
    public let confirmedAt: Date?
    public let lastUsedAt: Date?
    public let createdAt: Date

    enum CodingKeys: String, CodingKey {
        case id = "ID"
        case type = "Type"
        case label = "Label"
        case confirmedAt = "ConfirmedAt"
        case lastUsedAt = "LastUsedAt"
        case createdAt = "CreatedAt"
    }
}

public struct MfaStatus: Sendable, Codable {
    public let enabled: Bool
    public let factors: [MfaFactor]
    public let recoveryCodesLeft: Int

    enum CodingKeys: String, CodingKey {
        case enabled
        case factors
        case recoveryCodesLeft = "recovery_codes_left"
    }
}

public struct TotpEnrollment: Sendable, Codable {
    public let factorId: String
    public let type: String
    public let otpAuthUri: String
    public let base32Secret: String

    enum CodingKeys: String, CodingKey {
        case factorId = "factor_id"
        case type
        case otpAuthUri = "otpauth_uri"
        case base32Secret = "base32_secret"
    }
}

public struct MfaSession: Sendable, Codable {
    public let id: String
    public let deviceFingerprint: String
    public let deviceName: String?
    public let os: String?
    public let mfaVerifiedAt: Date?
    public let lastSeenAt: Date
    public let expiresAt: Date
    public let revokedAt: Date?
    public let revokedReason: String?
    public let createdAt: Date

    public var isRevoked: Bool { revokedAt != nil }

    enum CodingKeys: String, CodingKey {
        case id = "ID"
        case deviceFingerprint = "DeviceFingerprint"
        case deviceName = "DeviceName"
        case os = "OS"
        case mfaVerifiedAt = "MfaVerifiedAt"
        case lastSeenAt = "LastSeenAt"
        case expiresAt = "ExpiresAt"
        case revokedAt = "RevokedAt"
        case revokedReason = "RevokedReason"
        case createdAt = "CreatedAt"
    }
}

public struct StepUpGrant: Sendable, Codable {
    public let id: String
    public let scope: String
    public let expiresAt: Date

    enum CodingKeys: String, CodingKey {
        case id = "ID"
        case scope = "Scope"
        case expiresAt = "ExpiresAt"
    }
}
