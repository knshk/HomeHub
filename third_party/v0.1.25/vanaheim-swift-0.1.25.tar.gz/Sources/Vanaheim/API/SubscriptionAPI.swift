// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Self-serve subscription management: list tiers, upgrade, schedule
/// downgrade, cancel, reactivate, list invoices, generate Stripe Customer
/// Portal URL.
///
/// Tier-change semantics match server-side policy:
///   * upgrade  → immediate (prorated)
///   * downgrade → ALWAYS scheduled to period end (defense-in-depth)
///   * cancel    → at period end, no grace
///   * reactivate → only within renewal-failure grace
public actor SubscriptionAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    /// Fetches the user's current plan as a structured snapshot — slug +
    /// display name + amount + currency + interval + entitlements. Combines
    /// what `client.tier` (slug only) and `tiers()` (catalog list) provide,
    /// with one authoritative round-trip server-side.
    ///
    /// Returns nil when the account has no active subscription.
    public func currentPlan() async throws -> SubscriptionTier? {
        try capabilities.require("subscription")
        let url = await endpoint().appendingPathComponent("v1/subscription/current-plan")
        let raw = try await http.postJson(url: url, body: [:])
        guard let planRaw = raw["plan"] as? [String: Any] else { return nil }
        return try NotificationsAPI.decode(planRaw, SubscriptionTier.self)
    }

    /// Lists tiers + pricing for current product / region / currency.
    public func tiers(currency: String? = nil) async throws -> [SubscriptionTier] {
        try capabilities.require("subscription")
        var body: [String: Any] = [:]
        if let currency = currency { body["currency"] = currency }
        let url = await endpoint().appendingPathComponent("v1/subscription/tiers")
        let raw = try await http.postJson(url: url, body: body)
        guard let tiersRaw = raw["tiers"] as? [[String: Any]] else { return [] }
        let data = try JSONSerialization.data(withJSONObject: tiersRaw)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode([SubscriptionTier].self, from: data)
    }

    /// Immediately switches to [tier]. Server rejects downgrades here.
    public func upgradeTo(_ tier: String) async throws {
        try capabilities.require("subscription")
        let url = await endpoint().appendingPathComponent("v1/subscription/upgrade")
        _ = try await http.postJson(url: url, body: ["tier": tier])
    }

    /// Schedules a downgrade to [tier] effective at period end.
    public func scheduleDowngrade(_ tier: String) async throws {
        try capabilities.require("subscription")
        let url = await endpoint().appendingPathComponent("v1/subscription/schedule-downgrade")
        _ = try await http.postJson(url: url, body: ["tier": tier])
    }

    /// Cancels at period end (no grace). [reason] captured for exit survey.
    public func cancel(reason: String? = nil) async throws {
        try capabilities.require("subscription")
        var body: [String: Any] = [:]
        if let reason = reason { body["reason"] = reason }
        let url = await endpoint().appendingPathComponent("v1/subscription/cancel")
        _ = try await http.postJson(url: url, body: body)
    }

    /// Reactivates a cancelled subscription within the grace window.
    public func reactivate() async throws {
        try capabilities.require("subscription")
        let url = await endpoint().appendingPathComponent("v1/subscription/reactivate")
        _ = try await http.postJson(url: url, body: [:])
    }

    /// Lists prior invoices, newest first.
    public func invoices(limit: Int = 25, cursor: String? = nil) async throws -> InvoicePage {
        try capabilities.require("subscription")
        var body: [String: Any] = ["limit": limit]
        if let cursor = cursor, !cursor.isEmpty { body["cursor"] = cursor }
        let url = await endpoint().appendingPathComponent("v1/subscription/invoices")
        let raw = try await http.postJson(url: url, body: body)
        return try NotificationsAPI.decode(raw, InvoicePage.self)
    }

    /// Generates a short-lived Stripe Customer Portal session URL.
    public func portalSessionUrl(returnUrl: URL? = nil) async throws -> URL {
        try capabilities.require("subscription")
        var body: [String: Any] = [:]
        if let returnUrl = returnUrl { body["return_url"] = returnUrl.absoluteString }
        let url = await endpoint().appendingPathComponent("v1/subscription/portal-session")
        let raw = try await http.postJson(url: url, body: body)
        guard let str = raw["url"] as? String, !str.isEmpty, let parsed = URL(string: str) else {
            throw NetworkError("portal-session returned no URL")
        }
        return parsed
    }
}
