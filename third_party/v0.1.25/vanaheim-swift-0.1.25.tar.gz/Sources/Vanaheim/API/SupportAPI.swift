// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Support / tickets / KB search. Access via `LicenseClient.support`.
///
/// Tickets auto-attach license + tier + payment + recent telemetry context
/// server-side from the authenticated JWT.
public actor SupportAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    private var maxAttachmentBytes: Int { capabilities.feedbackMaxAttachmentMb * 1024 * 1024 }

    /// Opens a new ticket.
    public func openTicket(
        subject: String,
        body: String,
        category: String? = nil,
        priority: String? = nil,
        attachments: [FeedbackAttachment] = []
    ) async throws -> SupportTicket {
        try capabilities.require("support")
        var reqBody: [String: Any] = ["subject": subject, "body": body]
        if let category = category { reqBody["category"] = category }
        if let priority = priority { reqBody["priority"] = priority }
        let encodedAttachments = attachments
            .filter { $0.bytes.count <= maxAttachmentBytes }
            .map { att -> [String: Any] in
                [
                    "filename": att.filename,
                    "content_type": att.contentType,
                    "bytes_b64": att.bytes.base64EncodedString()
                ]
            }
        if !encodedAttachments.isEmpty {
            reqBody["attachments"] = encodedAttachments
        }
        let url = await endpoint().appendingPathComponent("v1/support/tickets")
        let raw = try await http.postJson(url: url, body: reqBody)
        guard let ticketRaw = raw["ticket"] as? [String: Any] else {
            throw NetworkError("openTicket returned no ticket")
        }
        return try NotificationsAPI.decode(ticketRaw, SupportTicket.self)
    }

    /// Lists this user's tickets, newest first.
    public func listTickets(status: String? = nil) async throws -> [SupportTicket] {
        try capabilities.require("support")
        var body: [String: Any] = [:]
        if let status = status { body["status"] = status }
        let url = await endpoint().appendingPathComponent("v1/support/tickets/list")
        let raw = try await http.postJson(url: url, body: body)
        guard let arr = raw["tickets"] as? [[String: Any]] else { return [] }
        let data = try JSONSerialization.data(withJSONObject: arr)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode([SupportTicket].self, from: data)
    }

    /// Fetches one ticket plus its full message thread.
    public func getTicket(_ id: String) async throws -> SupportTicketDetail {
        try capabilities.require("support")
        let url = await endpoint().appendingPathComponent("v1/support/tickets/\(id)")
        let raw = try await http.postJson(url: url, body: [:])
        guard let ticketRaw = raw["ticket"] as? [String: Any] else {
            throw NetworkError("getTicket returned no ticket")
        }
        let messagesRaw = raw["messages"] as? [[String: Any]] ?? []
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let ticket = try NotificationsAPI.decode(ticketRaw, SupportTicket.self)
        let messages = try decoder.decode(
            [SupportMessage].self,
            from: JSONSerialization.data(withJSONObject: messagesRaw))
        return SupportTicketDetail(ticket: ticket, messages: messages)
    }

    /// Posts a reply on an open ticket.
    public func replyTo(ticketId: String, message: String) async throws -> SupportMessage {
        try capabilities.require("support")
        let url = await endpoint().appendingPathComponent("v1/support/tickets/\(ticketId)/reply")
        let raw = try await http.postJson(url: url, body: ["message": message])
        guard let msgRaw = raw["message"] as? [String: Any] else {
            throw NetworkError("replyTo returned no message")
        }
        return try NotificationsAPI.decode(msgRaw, SupportMessage.self)
    }
}
