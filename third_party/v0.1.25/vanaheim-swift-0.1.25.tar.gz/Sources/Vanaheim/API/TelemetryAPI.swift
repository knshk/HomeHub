// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2B.1 Telemetry / metering / analytics — buffered, batched, retries.
/// Survives app restarts via SecureCache. Day-1 SDK contract is stable so
/// adding the real backend ingestion later requires no SDK release.
public actor TelemetryAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let cache: SecureCache
    private let capabilities: SdkCapabilities
    private let productSlug: String

    private static let eventsKey = "telemetry_buffer_v1"
    private static let meteringKey = "metering_buffer_v1"

    private var events: [_TelemetryEvent] = []
    private var metering: [_MeteringRecord] = []
    private var samplingRates: [String: Double] = [:]
    private var flushTask: Task<Void, Never>?
    private var disposed = false

    init(http: SignedHttpClient,
         endpoint: @escaping @Sendable () async -> URL,
         cache: SecureCache,
         capabilities: SdkCapabilities,
         productSlug: String) {
        self.http = http
        self.endpoint = endpoint
        self.cache = cache
        self.capabilities = capabilities
        self.productSlug = productSlug
    }

    // MARK: - public surface

    public func track(_ eventName: String, props: [String: Any] = [:]) async throws {
        try capabilities.require("telemetry")
        if disposed { return }
        let rate = samplingRates[eventName] ?? 1.0
        if rate < 1.0 && Double.random(in: 0..<1) > rate { return }
        events.append(_TelemetryEvent(
            name: eventName,
            props: stripPii(props),
            occurredAt: Date()))
        trimEvents()
    }

    public func identify(traits: [String: Any]) async throws {
        try capabilities.require("telemetry")
        try await track("__identify", props: stripPii(traits))
    }

    public func recordMetering(key: String, count: Int = 1, metadata: [String: Any] = [:]) async throws {
        try capabilities.require("telemetry")
        if disposed { return }
        if count <= 0 { return }
        metering.append(_MeteringRecord(
            key: key,
            count: count,
            metadata: stripPii(metadata),
            occurredAt: Date()))
        trimMetering()
    }

    public func setSampleRate(eventName: String, rate: Double) {
        samplingRates[eventName] = min(max(rate, 0.0), 1.0)
    }

    public func flush() async throws {
        if disposed { return }
        if events.isEmpty && metering.isEmpty { return }
        try await doFlush()
    }

    /// Restore the offline queue. Called from LicenseClient.connect.
    public func restore() async {
        if let json = try? await cache.getRaw(Self.eventsKey),
           let data = json.data(using: .utf8),
           let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            events = arr.compactMap(_TelemetryEvent.fromJson)
            trimEvents()
        }
        if let json = try? await cache.getRaw(Self.meteringKey),
           let data = json.data(using: .utf8),
           let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            metering = arr.compactMap(_MeteringRecord.fromJson)
            trimMetering()
        }
    }

    public func start() {
        if disposed { return }
        flushTask?.cancel()
        let interval = UInt64(capabilities.telemetryFlushIntervalSeconds) * 1_000_000_000
        flushTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: interval)
                guard let self = self else { return }
                await self.silentFlush()
            }
        }
    }

    public func dispose() async {
        if disposed { return }
        disposed = true
        flushTask?.cancel()
        flushTask = nil
        await persistQueues()
    }

    // MARK: - internals

    private func doFlush() async throws {
        let batchSize = capabilities.telemetryBatchSize
        var eventsBatch: [_TelemetryEvent] = []
        while !events.isEmpty && eventsBatch.count < batchSize {
            eventsBatch.append(events.removeFirst())
        }
        var meteringBatch: [_MeteringRecord] = []
        while !metering.isEmpty && meteringBatch.count < batchSize {
            meteringBatch.append(metering.removeFirst())
        }
        if eventsBatch.isEmpty && meteringBatch.isEmpty { return }
        do {
            if !eventsBatch.isEmpty {
                let url = await endpoint().appendingPathComponent("v1/analytics/events")
                _ = try await http.postJson(url: url, body: [
                    "product_slug": productSlug,
                    "events": eventsBatch.map { $0.toJson() }
                ])
            }
            if !meteringBatch.isEmpty {
                let url = await endpoint().appendingPathComponent("v1/metering/record")
                _ = try await http.postJson(url: url, body: [
                    "product_slug": productSlug,
                    "records": meteringBatch.map { $0.toJson() }
                ])
            }
        } catch {
            events.insert(contentsOf: eventsBatch, at: 0)
            metering.insert(contentsOf: meteringBatch, at: 0)
            trimEvents()
            trimMetering()
            throw error
        }
    }

    private func silentFlush() async {
        do {
            try await doFlush()
        } catch {
            // Periodic flushes never escape; persisted queue survives restart.
        }
        await persistQueues()
    }

    private func persistQueues() async {
        let eventsArr = events.map { $0.toJson() }
        let meteringArr = metering.map { $0.toJson() }
        if let data = try? JSONSerialization.data(withJSONObject: eventsArr),
           let json = String(data: data, encoding: .utf8) {
            try? await cache.putRaw(Self.eventsKey, json)
        }
        if let data = try? JSONSerialization.data(withJSONObject: meteringArr),
           let json = String(data: data, encoding: .utf8) {
            try? await cache.putRaw(Self.meteringKey, json)
        }
    }

    private func trimEvents() {
        let max = capabilities.telemetryMaxBuffer
        while events.count > max { events.removeFirst() }
    }

    private func trimMetering() {
        let max = capabilities.telemetryMaxBuffer
        while metering.count > max { metering.removeFirst() }
    }

    // PII patterns — strip emails, US-style 10+ digit numbers, card-like seqs.
    private static let emailRe = try! NSRegularExpression(pattern: "[A-Z0-9._%+\\-]+@[A-Z0-9.\\-]+\\.[A-Z]{2,}", options: [.caseInsensitive])
    private static let phoneRe = try! NSRegularExpression(pattern: "\\b\\d{10,15}\\b", options: [])
    private static let cardRe = try! NSRegularExpression(pattern: "\\b(?:\\d[ \\-]?){13,19}\\b", options: [])

    private func stripPii(_ input: [String: Any]) -> [String: Any] {
        var out: [String: Any] = [:]
        for (k, v) in input {
            if let s = v as? String {
                let range = NSRange(s.startIndex..<s.endIndex, in: s)
                if Self.emailRe.firstMatch(in: s, options: [], range: range) != nil ||
                   Self.phoneRe.firstMatch(in: s, options: [], range: range) != nil ||
                   Self.cardRe.firstMatch(in: s, options: [], range: range) != nil {
                    continue
                }
                out[k] = s
            } else if let dict = v as? [String: Any] {
                out[k] = stripPii(dict)
            } else {
                out[k] = v
            }
        }
        return out
    }
}

// `props` is a JSON-derived [String: Any] (NSNull / Bool / Int / Double /
// String / Array / Dictionary) — all safe to share across actors. Compiler
// can't prove this through `Any`, so we vouch for it the same way
// `AnyCodable` does.
struct _TelemetryEvent: @unchecked Sendable {
    let name: String
    let props: [String: Any]
    let occurredAt: Date

    func toJson() -> [String: Any] {
        [
            "name": name,
            "props": props,
            "occurred_at": ISO8601DateFormatter().string(from: occurredAt)
        ]
    }

    static func fromJson(_ j: [String: Any]) -> _TelemetryEvent? {
        guard let name = j["name"] as? String,
              let props = j["props"] as? [String: Any] else { return nil }
        let occurredAtStr = j["occurred_at"] as? String ?? ""
        let occurredAt = ISO8601DateFormatter().date(from: occurredAtStr) ?? Date()
        return _TelemetryEvent(name: name, props: props, occurredAt: occurredAt)
    }
}

struct _MeteringRecord: @unchecked Sendable {
    let key: String
    let count: Int
    let metadata: [String: Any]
    let occurredAt: Date

    func toJson() -> [String: Any] {
        [
            "key": key,
            "count": count,
            "metadata": metadata,
            "occurred_at": ISO8601DateFormatter().string(from: occurredAt)
        ]
    }

    static func fromJson(_ j: [String: Any]) -> _MeteringRecord? {
        guard let key = j["key"] as? String,
              let count = (j["count"] as? Int) ?? ((j["count"] as? NSNumber)?.intValue),
              let metadata = j["metadata"] as? [String: Any] else { return nil }
        let occurredAtStr = j["occurred_at"] as? String ?? ""
        let occurredAt = ISO8601DateFormatter().date(from: occurredAtStr) ?? Date()
        return _MeteringRecord(key: key, count: count, metadata: metadata, occurredAt: occurredAt)
    }
}

// getRaw / putRaw / deleteRaw are now first-class SecureCache protocol
// methods — see Storage/SecureCache.swift.
