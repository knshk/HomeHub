// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2B.4 Referrals — 1:1 user-driven "give a month, get a month".
public actor ReferralsAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    public func code() async throws -> ReferralCode {
        try capabilities.require("referrals")
        let url = await endpoint().appendingPathComponent("v1/referrals/code")
        let raw = try await http.postJson(url: url, body: [:])
        return try NotificationsAPI.decode(raw, ReferralCode.self)
    }

    public func invites() async throws -> [ReferralInvite] {
        try capabilities.require("referrals")
        let url = await endpoint().appendingPathComponent("v1/referrals/invites")
        let raw = try await http.postJson(url: url, body: [:])
        guard let arr = raw["invites"] as? [[String: Any]] else { return [] }
        let data = try JSONSerialization.data(withJSONObject: arr)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode([ReferralInvite].self, from: data)
    }

    public func shareLink(channel: String) async throws -> URL {
        try capabilities.require("referrals")
        let url = await endpoint().appendingPathComponent("v1/referrals/share-link")
        let raw = try await http.postJson(url: url, body: ["channel": channel])
        guard let str = raw["url"] as? String, !str.isEmpty, let parsed = URL(string: str) else {
            throw NetworkError("share-link returned no URL")
        }
        return parsed
    }
}
