// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2B.8 Offer code redemption.
public actor OffersAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    public func redeem(token: String? = nil, code: String? = nil) async throws -> OfferRedemption {
        try capabilities.require("offers")
        if (token == nil || token!.isEmpty) && (code == nil || code!.isEmpty) {
            throw NetworkError("Either token or code must be provided")
        }
        var body: [String: Any] = [:]
        if let token = token, !token.isEmpty { body["token"] = token }
        if let code = code, !code.isEmpty { body["code"] = code }
        let url = await endpoint().appendingPathComponent("v1/offers/redeem")
        let raw = try await http.postJson(url: url, body: body)
        return try NotificationsAPI.decode(raw, OfferRedemption.self)
    }

    public func history() async throws -> [OfferRedemption] {
        try capabilities.require("offers")
        let url = await endpoint().appendingPathComponent("v1/offers/history")
        let raw = try await http.postJson(url: url, body: [:])
        guard let arr = raw["redemptions"] as? [[String: Any]] else { return [] }
        let data = try JSONSerialization.data(withJSONObject: arr)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode([OfferRedemption].self, from: data)
    }
}
