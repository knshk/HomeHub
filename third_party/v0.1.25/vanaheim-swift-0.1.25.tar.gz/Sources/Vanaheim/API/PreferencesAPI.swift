// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Cross-product user preferences: locale, timezone, theme, accessibility
/// flags, communication frequency. Server-side `account_preferences` table.
///
/// SYNC read path: products call `cachedValue(_:)` to read from the
/// JWT-embedded snapshot without a round-trip. Use [refresh] / [update]
/// for write / explicit-refresh paths.
public actor PreferencesAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities
    private var snapshot: [String: Any] = [:]

    // Standard preference keys (products may add custom)
    public static let localeKey = "locale"
    public static let timezoneKey = "timezone"
    public static let themeKey = "theme"
    public static let accessibilityHighContrastKey = "accessibility.high_contrast"
    public static let accessibilityReduceMotionKey = "accessibility.reduce_motion"
    public static let communicationSummaryFrequencyKey = "communication.summary_frequency"

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    /// Async read of any key.
    public func value(_ key: String) -> Any? {
        snapshot[key]
    }

    /// Typed cached read. Async because the actor owns the snapshot.
    public func cachedValue<T>(_ key: String, as: T.Type = T.self) -> T? {
        let v = snapshot[key]
        if let typed = v as? T { return typed }
        if T.self == Int.self, let n = v as? NSNumber { return n.intValue as? T }
        if T.self == Double.self, let n = v as? NSNumber { return n.doubleValue as? T }
        return nil
    }

    /// Replaces in-memory snapshot. Called internally by LicenseClient when
    /// a fresh JWT carries a prefs payload, and by [refresh] / [update].
    public func primeSnapshot(_ values: [String: Any]) {
        snapshot = values
    }

    /// Fetches current preferences from server.
    @discardableResult
    public func refresh() async throws -> [String: Any] {
        try capabilities.require("preferences")
        let url = await endpoint().appendingPathComponent("v1/preferences/get")
        let raw = try await http.postJson(url: url, body: [:])
        let values = (raw["values"] as? [String: Any]) ?? [:]
        snapshot = values
        return snapshot
    }

    /// Writes one key/value. Returns merged snapshot.
    @discardableResult
    public func update(_ key: String, _ value: Any) async throws -> [String: Any] {
        try capabilities.require("preferences")
        let url = await endpoint().appendingPathComponent("v1/preferences/update")
        let raw = try await http.postJson(url: url, body: ["key": key, "value": value])
        let values = (raw["values"] as? [String: Any]) ?? [:]
        snapshot = values
        return snapshot
    }

    /// Writes multiple keys atomically.
    @discardableResult
    public func updateMany(_ updates: [String: Any]) async throws -> [String: Any] {
        try capabilities.require("preferences")
        let url = await endpoint().appendingPathComponent("v1/preferences/update-many")
        let raw = try await http.postJson(url: url, body: ["updates": updates])
        let values = (raw["values"] as? [String: Any]) ?? [:]
        snapshot = values
        return snapshot
    }
}
