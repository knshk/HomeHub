// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Notification inbox + preferences. Access via `LicenseClient.notifications`.
///
/// All calls use the existing HMAC + Firebase + App Check signed POST scheme.
/// Backend may stub these endpoints initially (Project_Plan.md §3A.3) — the
/// SDK contract is stable from day-1.
public actor NotificationsAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    /// One page of inbox messages, newest first.
    public func inbox(limit: Int? = nil, cursor: String? = nil) async throws -> NotificationInboxPage {
        try capabilities.require("notifications")
        var body: [String: Any] = ["limit": limit ?? capabilities.notificationInboxPageSize]
        if let cursor = cursor, !cursor.isEmpty { body["cursor"] = cursor }
        let url = await endpoint().appendingPathComponent("v1/notifications/inbox")
        let raw = try await http.postJson(url: url, body: body)
        return try Self.decode(raw, NotificationInboxPage.self)
    }

    /// Marks one message read. Idempotent.
    public func markRead(_ id: String) async throws {
        try capabilities.require("notifications")
        let url = await endpoint().appendingPathComponent("v1/notifications/\(id)/mark-read")
        _ = try await http.postJson(url: url, body: [:])
    }

    /// Fetches the user's current per-channel × per-template preferences.
    public func getPreferences() async throws -> NotificationPreferences {
        try capabilities.require("notifications")
        let url = await endpoint().appendingPathComponent("v1/notifications/preferences/get")
        let raw = try await http.postJson(url: url, body: [:])
        return try Self.decode(raw, NotificationPreferences.self)
    }

    /// Updates preferences. Server merges with stored state.
    public func updatePreferences(_ prefs: NotificationPreferences) async throws -> NotificationPreferences {
        try capabilities.require("notifications")
        let url = await endpoint().appendingPathComponent("v1/notifications/preferences/update")
        let body: [String: Any] = [
            "channels": prefs.channels,
            "per_template": prefs.perTemplate.mapValues { $0 as Any }
        ]
        let raw = try await http.postJson(url: url, body: body)
        return try Self.decode(raw, NotificationPreferences.self)
    }

    static func decode<T: Decodable>(_ raw: [String: Any], _ type: T.Type) throws -> T {
        let data = try JSONSerialization.data(withJSONObject: raw)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(T.self, from: data)
    }
}
