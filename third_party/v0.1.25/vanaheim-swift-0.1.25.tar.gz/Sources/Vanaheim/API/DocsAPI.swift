// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2B.2 KB / docs search.
public actor DocsAPI {
    private let http: SignedHttpClient
    private let endpoint: @Sendable () async -> URL
    private let capabilities: SdkCapabilities

    init(http: SignedHttpClient, endpoint: @escaping @Sendable () async -> URL, capabilities: SdkCapabilities) {
        self.http = http
        self.endpoint = endpoint
        self.capabilities = capabilities
    }

    public func search(_ query: String, limit: Int = 10) async throws -> [DocsHit] {
        try capabilities.require("docs")
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return [] }
        let url = await endpoint().appendingPathComponent("v1/docs/search")
        let raw = try await http.postJson(url: url, body: ["query": trimmed, "limit": limit])
        guard let arr = raw["hits"] as? [[String: Any]] else { return [] }
        let data = try JSONSerialization.data(withJSONObject: arr)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode([DocsHit].self, from: data)
    }
}
