// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

// MARK: - ActivationResult

/// Result of a successful activation. `kickedDevice` is non-nil only for
/// floating-tier bumps.
public struct ActivationResult: Sendable {
    public let activationId: String
    public let expiresAt: Date
    public let entitlements: Entitlements
    public let kickedDevice: KickedDevice?
}

// MARK: - KickedDevice

/// Sanitized record of a session deactivated to make room for a new
/// floating activation. Device fingerprint intentionally omitted — surface
/// only the human-friendly fields.
public struct KickedDevice: Sendable, Codable {
    public let activationId: String
    public let deviceName: String?
    public let os: String?
    public let lastSeenAt: Date

    enum CodingKeys: String, CodingKey {
        case activationId = "activation_id"
        case deviceName = "device_name"
        case os
        case lastSeenAt = "last_seen_at"
    }
}

// MARK: - Entitlements

/// Tier + per-feature entitlements. Read via the convenience methods on
/// `LicenseClient`; `values` is exposed for diagnostics.
public struct Entitlements: Sendable {
    public let tier: String
    public let version: Int
    public let values: [String: AnyCodable]

    /// True if the named entitlement is present and truthy.
    public func has(_ key: String) -> Bool {
        guard let v = values[key]?.value else { return false }
        if let b = v as? Bool { return b }
        if let arr = v as? [Any] { return !arr.isEmpty }
        return true
    }

    /// Returns the entitlement coerced to the requested numeric/string type.
    public func quota<T>(_ key: String, as: T.Type = T.self) -> T? {
        let v = values[key]?.value
        if let typed = v as? T { return typed }
        if T.self == Int.self, let n = v as? NSNumber { return n.intValue as? T }
        if T.self == Double.self, let n = v as? NSNumber { return n.doubleValue as? T }
        return nil
    }
}

// MARK: - LicenseStateChange

/// Emitted via `LicenseClient.stateChanges` (AsyncStream) when something
/// the product UI may care about happens.
public struct LicenseStateChange: Sendable {
    public let kind: LicenseStateChangeKind
    public let entitlements: Entitlements?
    public let kickedDevice: KickedDevice?
    public let error: LicenseStoreError?
    /// Optional inbox notification payload for `.notificationReceived`.
    public let notification: NotificationMessage?

    public init(
        kind: LicenseStateChangeKind,
        entitlements: Entitlements? = nil,
        kickedDevice: KickedDevice? = nil,
        error: LicenseStoreError? = nil,
        notification: NotificationMessage? = nil
    ) {
        self.kind = kind
        self.entitlements = entitlements
        self.kickedDevice = kickedDevice
        self.error = error
        self.notification = notification
    }
}

public enum LicenseStateChangeKind: Sendable {
    /// First successful activation after connect().
    case activated
    /// Server bumped entitlements_version — re-render gated UI.
    case entitlementsUpdated
    /// Server bumped cfg_v (runtime config override). Re-read config<T>.
    case configUpdated
    /// Server bumped prefs_v (cross-product preferences).
    case preferencesUpdated
    /// A new inbox notification arrived via push wake-trigger.
    case notificationReceived
    /// This device was bumped by another login (floating tier) or admin revoked.
    case sessionRevoked
    /// JWT expired and refresh failed.
    case expired
    /// Persistent error after retries (network / auth / pinning).
    case error
}

// MARK: - LicenseJwtClaims

/// Decoded JWT claims relevant to the SDK. Other claims are ignored.
///
/// Forward-compat: new optional claims may appear server-side without an SDK
/// bump. Unknown claims are silently ignored.
public struct LicenseJwtClaims: Sendable {
    public let issuer: String
    public let licenseId: String
    public let productId: String
    public let accountId: String
    public let tier: String
    public let entitlements: [String: AnyCodable]
    public let entitlementsVersion: Int

    /// Merged runtime-config overlay from the backend (global → region →
    /// country → product → tier → license). Read via `client.config(_:)`.
    public let config: [String: AnyCodable]
    /// Bumped server-side on every config-override write affecting this license.
    public let configVersion: Int

    /// Multi-valued roles (e.g. `["customer", "partner"]`). Empty when not yet emitted.
    public let roles: [String]
    /// Organization context if acting on behalf of a B2B account.
    public let orgId: String?
    /// Per-org role (owner / admin / member) when `orgId` set.
    public let orgRole: String?

    /// Bumped server-side on every cross-product preferences write.
    public let preferencesVersion: Int
    /// Resolved user locale (e.g. "en-US"). Nil when not server-side; SDK falls
    /// back to system locale.
    public let locale: String?

    public let issuedAt: Date
    public let notBefore: Date
    public let expiresAt: Date
    public let kid: String

    public init(
        issuer: String,
        licenseId: String,
        productId: String,
        accountId: String,
        tier: String,
        entitlements: [String: AnyCodable],
        entitlementsVersion: Int,
        issuedAt: Date,
        notBefore: Date,
        expiresAt: Date,
        kid: String,
        config: [String: AnyCodable] = [:],
        configVersion: Int = 0,
        roles: [String] = [],
        orgId: String? = nil,
        orgRole: String? = nil,
        preferencesVersion: Int = 0,
        locale: String? = nil
    ) {
        self.issuer = issuer
        self.licenseId = licenseId
        self.productId = productId
        self.accountId = accountId
        self.tier = tier
        self.entitlements = entitlements
        self.entitlementsVersion = entitlementsVersion
        self.issuedAt = issuedAt
        self.notBefore = notBefore
        self.expiresAt = expiresAt
        self.kid = kid
        self.config = config
        self.configVersion = configVersion
        self.roles = roles
        self.orgId = orgId
        self.orgRole = orgRole
        self.preferencesVersion = preferencesVersion
        self.locale = locale
    }
}

// ===========================================================================
// 2A.3 Notification SDK surface
// ===========================================================================

/// One inbox row delivered by License Store. Persistent record of a
/// notification (cross-channel) viewable in the product's bell icon.
public struct NotificationMessage: Sendable, Codable {
    public let id: String
    public let productId: String
    public let kind: String
    public let title: String?
    public let body: String?
    public let deepLink: String?
    public let createdAt: Date
    public let readAt: Date?

    public var isUnread: Bool { readAt == nil }

    enum CodingKeys: String, CodingKey {
        case id
        case productId = "product_id"
        case kind, title, body
        case deepLink = "deep_link"
        case createdAt = "created_at"
        case readAt = "read_at"
    }
}

/// Paged inbox fetch result.
public struct NotificationInboxPage: Sendable, Codable {
    public let messages: [NotificationMessage]
    public let nextCursor: String?

    enum CodingKeys: String, CodingKey {
        case messages
        case nextCursor = "next_cursor"
    }
}

/// Per-channel × per-template preferences.
public struct NotificationPreferences: Sendable, Codable {
    public var channels: [String: Bool]
    public var perTemplate: [String: [String: Bool]]

    public init(channels: [String: Bool] = [:], perTemplate: [String: [String: Bool]] = [:]) {
        self.channels = channels
        self.perTemplate = perTemplate
    }

    enum CodingKeys: String, CodingKey {
        case channels
        case perTemplate = "per_template"
    }
}

// ===========================================================================
// 2A.4 Feedback SDK surface
// ===========================================================================

/// Standard feedback categories; products may pass custom strings.
public enum FeedbackCategory {
    public static let bug = "bug"
    public static let feature = "feature"
    public static let uxComplaint = "ux"
    public static let pricing = "pricing"
    public static let praise = "praise"
    public static let other = "other"
}

/// In-memory attachment for feedback / support.
public struct FeedbackAttachment: Sendable {
    public let filename: String
    public let contentType: String
    public let bytes: Data
    public init(filename: String, contentType: String, bytes: Data) {
        self.filename = filename
        self.contentType = contentType
        self.bytes = bytes
    }
}

/// Server-assigned id + acknowledgement timestamp.
public struct FeedbackReceipt: Sendable, Codable {
    public let id: String
    public let receivedAt: Date

    enum CodingKeys: String, CodingKey {
        case id
        case receivedAt = "received_at"
    }
}

// ===========================================================================
// 2A.7 Subscription self-serve SDK surface
// ===========================================================================

/// A tier description returned by `subscription.tiers()`.
public struct SubscriptionTier: Sendable, Codable {
    public let slug: String
    public let displayName: String
    public let description: String?
    public let amountCents: Int
    public let currency: String
    public let interval: String
    public let entitlements: [String: AnyCodable]

    enum CodingKeys: String, CodingKey {
        case slug
        case displayName = "display_name"
        case description
        case amountCents = "amount_cents"
        case currency, interval, entitlements
    }
}

/// Invoice summary returned by `subscription.invoices()`.
public struct InvoiceSummary: Sendable, Codable {
    public let id: String
    public let number: String
    public let amountCents: Int
    public let currency: String
    public let status: String
    public let issuedAt: Date
    public let paidAt: Date?
    public let pdfUrl: URL?

    enum CodingKeys: String, CodingKey {
        case id, number
        case amountCents = "amount_cents"
        case currency, status
        case issuedAt = "issued_at"
        case paidAt = "paid_at"
        case pdfUrl = "pdf_url"
    }
}

/// Paged invoice listing.
public struct InvoicePage: Sendable, Codable {
    public let invoices: [InvoiceSummary]
    public let nextCursor: String?

    enum CodingKeys: String, CodingKey {
        case invoices
        case nextCursor = "next_cursor"
    }
}

// ===========================================================================
// 2A.6 Roles & multi-context
// ===========================================================================

/// Snapshot of partner-specific fields exposed when JWT carries `partner` role.
public struct PartnerProfile: Sendable, Codable {
    public let accountId: String
    public let marginTier: String
    public let commissionRateBps: Int?
    public let applicationStatus: String
    public let resellerTaxId: String?

    enum CodingKeys: String, CodingKey {
        case accountId = "account_id"
        case marginTier = "margin_tier"
        case commissionRateBps = "commission_rate_bps"
        case applicationStatus = "application_status"
        case resellerTaxId = "reseller_tax_id"
    }
}

/// Snapshot of org context exposed when JWT carries `org_id`.
public struct OrganizationContext: Sendable {
    public let orgId: String
    public let orgRole: String
}

// ===========================================================================
// 2A.9 Privacy + consent SDK surface
// ===========================================================================

/// Standard consent scopes — products may pass custom keys.
public enum ConsentScope {
    public static let essential = "essential"
    public static let analytics = "analytics"
    public static let marketing = "marketing"
    public static let advertising = "advertising"
    public static let shareWithPartners = "share_with_partners"
}

public struct ConsentState: Sendable, Codable {
    public var scopes: [String: Bool]
    public let capturedAt: Date?

    public init(scopes: [String: Bool], capturedAt: Date? = nil) {
        self.scopes = scopes
        self.capturedAt = capturedAt
    }

    enum CodingKeys: String, CodingKey {
        case scopes
        case capturedAt = "captured_at"
    }
}

public struct PrivacyJob: Sendable, Codable {
    public let id: String
    public let status: String
    public let downloadUrl: URL?

    enum CodingKeys: String, CodingKey {
        case id, status
        case downloadUrl = "download_url"
    }
}

// ===========================================================================
// 2A.11 Support SDK surface
// ===========================================================================

public struct SupportTicket: Sendable, Codable {
    public let id: String
    public let subject: String
    public let status: String
    public let priority: String?
    public let openedAt: Date
    public let resolvedAt: Date?

    enum CodingKeys: String, CodingKey {
        case id, subject, status, priority
        case openedAt = "opened_at"
        case resolvedAt = "resolved_at"
    }
}

public struct SupportMessage: Sendable, Codable {
    public let id: String
    public let role: String
    public let body: String
    public let sentAt: Date

    enum CodingKeys: String, CodingKey {
        case id, role, body
        case sentAt = "sent_at"
    }
}

public struct SupportTicketDetail: Sendable, Codable {
    public let ticket: SupportTicket
    public let messages: [SupportMessage]
}

// ===========================================================================
// 2B.3 AI assistant
// ===========================================================================

public struct AssistantMessage: Sendable, Codable {
    public let id: String
    public let role: String
    public let content: String
    public let sentAt: Date
    public let citations: [String]

    enum CodingKeys: String, CodingKey {
        case id, role, content
        case sentAt = "sent_at"
        case citations
    }
}

public struct AssistantConversation: Sendable, Codable {
    public let id: String
    public let title: String?
    public let createdAt: Date
    public let updatedAt: Date

    enum CodingKeys: String, CodingKey {
        case id, title
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
}

public struct AssistantConversationDetail: Sendable, Codable {
    public let conversation: AssistantConversation
    public let messages: [AssistantMessage]
}

// ===========================================================================
// 2B.4 Referrals
// ===========================================================================

public struct ReferralCode: Sendable, Codable {
    public let code: String
    public let shareUrl: URL?

    enum CodingKeys: String, CodingKey {
        case code
        case shareUrl = "share_url"
    }
}

public struct ReferralInvite: Sendable, Codable {
    public let id: String
    public let status: String
    public let invitedAt: Date
    public let convertedAt: Date?
    public let rewardAmountCents: Int?
    public let rewardCurrency: String?

    enum CodingKeys: String, CodingKey {
        case id, status
        case invitedAt = "invited_at"
        case convertedAt = "converted_at"
        case rewardAmountCents = "reward_amount_cents"
        case rewardCurrency = "reward_currency"
    }
}

// ===========================================================================
// 2B.5 Status page
// ===========================================================================

public enum SystemStatusLevel: String, Sendable, Codable {
    case operational
    case degradedPerformance = "degraded_performance"
    case partialOutage = "partial_outage"
    case majorOutage = "major_outage"
    case underMaintenance = "under_maintenance"
}

public struct SystemComponent: Sendable, Codable {
    public let name: String
    public let status: SystemStatusLevel
}

public struct IncidentSummary: Sendable, Codable {
    public let id: String
    public let title: String
    public let severity: String
    public let status: String
    public let startedAt: Date

    enum CodingKeys: String, CodingKey {
        case id, title, severity, status
        case startedAt = "started_at"
    }
}

public struct SystemStatus: Sendable, Codable {
    public let overall: SystemStatusLevel
    public let components: [SystemComponent]
    public let activeIncidents: [IncidentSummary]
    public let updatedAt: Date

    enum CodingKeys: String, CodingKey {
        case overall, components
        case activeIncidents = "active_incidents"
        case updatedAt = "updated_at"
    }
}

// ===========================================================================
// 2B.6 Account portability
// ===========================================================================

public struct AccountRequest: Sendable, Codable {
    public let id: String
    public let kind: String
    public let status: String
    public let requestedAt: Date

    enum CodingKeys: String, CodingKey {
        case id, kind, status
        case requestedAt = "requested_at"
    }
}

// ===========================================================================
// 2B.7 Organization / B2B
// ===========================================================================

public struct OrgMember: Sendable, Codable {
    public let accountId: String
    public let email: String
    public let role: String
    public let joinedAt: Date

    enum CodingKeys: String, CodingKey {
        case accountId = "account_id"
        case email, role
        case joinedAt = "joined_at"
    }
}

public struct OrgInvite: Sendable, Codable {
    public let id: String
    public let email: String
    public let role: String
    public let status: String
    public let createdAt: Date

    enum CodingKeys: String, CodingKey {
        case id, email, role, status
        case createdAt = "created_at"
    }
}

// ===========================================================================
// 2B.8 Offer redemption
// ===========================================================================

public struct OfferRedemption: Sendable, Codable {
    public let code: String
    public let discountPct: Int?
    public let discountAmountCents: Int?
    public let currency: String?
    public let appliedAt: Date

    enum CodingKeys: String, CodingKey {
        case code
        case discountPct = "discount_pct"
        case discountAmountCents = "discount_amount_cents"
        case currency
        case appliedAt = "applied_at"
    }
}

// ===========================================================================
// 2B.2 Docs / KB search
// ===========================================================================

public struct DocsHit: Sendable, Codable {
    public let title: String
    public let snippet: String
    public let url: URL
    public let score: Double
}

// MARK: - AnyCodable shim

/// Tiny type-erased Codable that lets us round-trip arbitrary JSON values
/// in the entitlements blob. Swift Foundation has no built-in equivalent.
///
/// Marked `@unchecked Sendable` because `value: Any` wraps a JSON-derived
/// immutable type (NSNull, Bool, Int, Double, String, Array, Dictionary) —
/// all safe to share across actors. The compiler can't prove this through
/// `Any`, so we vouch for it.
public struct AnyCodable: @unchecked Sendable, Codable {
    public let value: Any

    public init(_ value: Any) { self.value = value }

    public init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if c.decodeNil() { value = NSNull() }
        else if let b = try? c.decode(Bool.self) { value = b }
        else if let i = try? c.decode(Int.self) { value = i }
        else if let d = try? c.decode(Double.self) { value = d }
        else if let s = try? c.decode(String.self) { value = s }
        else if let a = try? c.decode([AnyCodable].self) { value = a.map(\.value) }
        else if let o = try? c.decode([String: AnyCodable].self) {
            value = o.mapValues(\.value)
        } else {
            throw DecodingError.dataCorruptedError(
                in: c, debugDescription: "Unsupported JSON type")
        }
    }

    public func encode(to encoder: Encoder) throws {
        var c = encoder.singleValueContainer()
        switch value {
        case is NSNull: try c.encodeNil()
        case let b as Bool: try c.encode(b)
        case let i as Int: try c.encode(i)
        case let d as Double: try c.encode(d)
        case let s as String: try c.encode(s)
        case let a as [Any]: try c.encode(a.map(AnyCodable.init))
        case let o as [String: Any]: try c.encode(o.mapValues(AnyCodable.init))
        default:
            throw EncodingError.invalidValue(value, .init(
                codingPath: encoder.codingPath,
                debugDescription: "Cannot encode \(type(of: value))"))
        }
    }
}

// (Sendable conformance is declared on the struct itself above with
// @unchecked Sendable — no separate extension needed. The previous
// extension's `where Self: Codable` clause was invalid Swift syntax
// for a non-generic type.)
