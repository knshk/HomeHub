// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import CryptoKit
import Foundation

/// SecureCache key the SDK uses to remember a successful device enrollment.
/// Cleared on 410 `DEVICE_REVOKED` / `DEVICE_UNENROLLED` so the next
/// `LicenseClient.connect()` re-enrols. Mirrors the v1→v2 rollout doc.
public let kDeviceRegisteredMarker = "device_registered_v1"

// Concrete types live in:
//   * `Crypto/RoutePolicy.swift` — `enum RouteConfidentiality` +
//     `enum RoutePolicy` (static `classify(_:)`),
//   * `Crypto/JweCodec.swift`    — `struct JweCodec`, `JweAadContext`.
// The transport composes those directly. Only the abstract seams below
// (`DeviceJwsSigner`, `InnerJwsVerifier`, `ProjectIdProvider`) live here —
// they're the contracts the device-enrollment + JWKS-verifier layers fulfil
// and we keep them as protocols so tests can inject deterministic doubles.

/// Signs the inner device JWS (Ed25519). Implemented by the device-keypair
/// provider — the transport keeps it abstract so tests can inject
/// deterministic signatures.
public protocol DeviceJwsSigner: Sendable {
    /// The device id (as written to `X-LS-Device-Id`) the SDK enrolled under.
    /// Empty string if not yet enrolled (transport will short-circuit
    /// JWE-required routes pending enrollment).
    var deviceId: String { get }

    /// Current `kid` of the device's Ed25519 signing key — copied into the
    /// inner JWS header so L3 can resolve it in the device registry.
    var sigKid: String { get }

    /// Produces a compact-JWS (3 dot-separated base64url segments) over
    /// `claims` signed with the device private key. Header MUST include
    /// `alg: EdDSA`, `kid: sigKid`, `typ: device+jws`.
    func signClaims(_ claims: [String: Any]) async throws -> String
}

/// Verifies the inner JWS embedded inside a JWE response. Returns the
/// parsed claims map. Throws `JwtVerificationError` on signature / kid /
/// expiry failure; throws `JweRouteMismatchError` on path mismatch.
public protocol InnerJwsVerifier: Sendable {
    func verify(
        compactJws: String,
        expectedRoute: String,
        expectedRequestId: String
    ) async throws -> [String: Any]
}

/// Project id surfaced into JWE AAD. Vended by `LicenseClient` which knows
/// it from `LicenseStoreConfig`. Held as a protocol so tests can vary it
/// without rebuilding the transport.
public protocol ProjectIdProvider: Sendable {
    /// Numeric tenant identifier — required as Int by `JweAadContext`.
    var projectId: Int { get }
}

/// HTTP client for v2 (Vanaheim). On every request it:
///   * generates a UUIDv7 request_id and a 16-byte nonce,
///   * classifies the route via `RoutePolicy`,
///   * for JWE-required routes: signs an inner device JWS (Ed25519),
///     encrypts to L2's current X25519 recipient key via `JweCodec`, and
///     sends `application/jose+json` with `X-LS-Recipient-Kid`,
///     `X-LS-Device-Id`, `X-LS-Request-Id`, `X-LS-KEK-V`,
///   * for JWS-allowed routes: passes plain JSON through (legacy HMAC
///     headers still attached for the regional API layer),
///   * on response:
///       - if `X-LS-Confidentiality: jwe`, decrypts and verifies the inner
///         JWS, raising `JweRouteMismatchError` on path mismatch,
///       - if the route was JWE-required but the server returned plain
///         JSON (no `X-LS-Confidentiality: jwe` header), raises
///         `JweRequiredButGotJwsError` (fail-closed, no downgrade),
///   * on 412 `pek_stale` / `X-LS-KEK-V` mismatch: refreshes
///     `L2KeysClient` and retries once. Second failure → `PekStaleError`,
///   * on 410 `DEVICE_REVOKED` / `DEVICE_UNENROLLED`: clears the
///     `device_registered_v1` SecureCache marker and raises
///     `DeviceRevokedError`.
///
/// HMAC signing + Bearer auth + App Check headers are preserved on every
/// request — the JWE envelope is added on TOP of (not in place of) them.
public final class SignedHttpClient: @unchecked Sendable {
    private let signer: HmacSigner
    private let auth: AuthTokenProvider
    private let appCheck: AppCheckTokenProvider
    private let session: URLSession
    private let timeout: TimeInterval

    // v2 / Vanaheim wiring. All optional so existing tests that don't need
    // JWE-required behaviour can construct with the legacy three providers +
    // pinner only. When `useRoutePolicy` is false (default), every call
    // routes through the legacy plain-JSON path regardless of `RoutePolicy`.
    private let useRoutePolicy: Bool
    private let jweCodec: JweCodec?
    private let deviceSigner: DeviceJwsSigner?
    // Held as the PROTOCOL so test doubles + alternative secure backings can
    // substitute their own impl without being forced through Keychain. The
    // concrete `KeychainDeviceKeypairProvider` still conforms — production
    // wiring passes it through unchanged.
    private let deviceKeypair: DeviceKeypairProvider?
    private let innerVerifier: InnerJwsVerifier?
    private let l2Keys: L2KeysClient?
    private let projectIdProvider: ProjectIdProvider?
    private let secureCache: SecureCache?

    public init(
        signer: HmacSigner,
        auth: AuthTokenProvider,
        appCheck: AppCheckTokenProvider,
        pinner: CertificatePinner,
        timeout: TimeInterval = 15,
        useRoutePolicy: Bool = false,
        jweCodec: JweCodec? = nil,
        deviceSigner: DeviceJwsSigner? = nil,
        deviceKeypair: DeviceKeypairProvider? = nil,
        innerVerifier: InnerJwsVerifier? = nil,
        l2Keys: L2KeysClient? = nil,
        projectIdProvider: ProjectIdProvider? = nil,
        secureCache: SecureCache? = nil
    ) {
        self.signer = signer
        self.auth = auth
        self.appCheck = appCheck
        self.timeout = timeout
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = timeout
        cfg.timeoutIntervalForResource = timeout * 2
        // The pinner is the delegate for the SESSION (handles TLS challenges
        // on every request). Pass nil delegateQueue → default operation queue.
        self.session = URLSession(configuration: cfg, delegate: pinner, delegateQueue: nil)
        self.useRoutePolicy = useRoutePolicy
        self.jweCodec = jweCodec
        self.deviceSigner = deviceSigner
        self.deviceKeypair = deviceKeypair
        self.innerVerifier = innerVerifier
        self.l2Keys = l2Keys
        self.projectIdProvider = projectIdProvider
        self.secureCache = secureCache
    }

    /// Sends a POST and returns the parsed JSON response. JWE wrapping is
    /// applied per `RoutePolicy.classify` (default-deny → JWE-required) when
    /// `useRoutePolicy` is true. Otherwise every call falls back to plain
    /// JSON (legacy v0.1 behaviour) so the pre-JWE products keep working.
    public func postJson(url: URL, body: [String: Any], requireAuth: Bool = true) async throws -> [String: Any] {
        let classification: RouteConfidentiality = useRoutePolicy
            ? RoutePolicy.classify(url.path)
            : .jwsAllowed
        switch classification {
        case .jweRequired:
            return try await postJwe(url: url, body: body, requireAuth: requireAuth)
        case .jwsAllowed:
            return try await postPlain(url: url, body: body, requireAuth: requireAuth, expectJweResponse: false)
        }
    }

    /// GET — used for unauthenticated reads (JWKS).
    public func getJson(url: URL) async throws -> [String: Any] {
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        return try await sendAndDecode(req)
    }

    // ------------------------------------------------------------- plain post

    private func postPlain(
        url: URL,
        body: [String: Any],
        requireAuth: Bool,
        expectJweResponse: Bool
    ) async throws -> [String: Any] {
        let bodyData = try JSONSerialization.data(withJSONObject: body, options: [.sortedKeys])
        let bodyStr = String(data: bodyData, encoding: .utf8) ?? "{}"
        let sig = signer.sign(bodyStr)
        let requestId = Self.uuidV7()

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue(LsHeaders.json, forHTTPHeaderField: "Content-Type")
        req.setValue(LsHeaders.json, forHTTPHeaderField: "Accept")
        req.setValue(signer.productSlug, forHTTPHeaderField: "X-LS-Product")
        req.setValue(sig.timestamp, forHTTPHeaderField: "X-LS-Timestamp")
        req.setValue(sig.signature, forHTTPHeaderField: "X-LS-Signature")
        req.setValue(requestId, forHTTPHeaderField: LsHeaders.XLSRequestId)
        if requireAuth {
            let tok = try await auth.getIdToken()
            req.setValue("Bearer \(tok)", forHTTPHeaderField: "Authorization")
        }
        if let appCheckTok = try await appCheck.getToken(), !appCheckTok.isEmpty {
            req.setValue(appCheckTok, forHTTPHeaderField: "X-Firebase-AppCheck")
        }
        req.httpBody = bodyData

        return try await sendAndDecode(req, expectJweResponse: expectJweResponse, routePath: url.path)
    }

    // --------------------------------------------------------------- JWE post

    private func postJwe(
        url: URL,
        body: [String: Any],
        requireAuth: Bool
    ) async throws -> [String: Any] {
        guard let codec = jweCodec,
              let dSigner = deviceSigner,
              let l2Keys = l2Keys,
              let projectIdProvider = projectIdProvider
        else {
            throw LicenseStoreError(
                "Route \(url.path) requires JWE but the SDK was not configured " +
                "with a JweCodec / DeviceJwsSigner / L2KeysClient / projectId. " +
                "See LicenseStoreConfig wiring (TODO-V2-S-04..S-09).")
        }

        // First attempt with the currently-cached recipient key. Retry once
        // on pek_stale after forcing a /.well-known/lcs-keys refresh.
        let firstKey = try await l2Keys.fetch()
        do {
            return try await doJweRoundTrip(
                url: url,
                body: body,
                requireAuth: requireAuth,
                codec: codec,
                deviceSigner: dSigner,
                recipient: firstKey,
                projectId: projectIdProvider.projectId
            )
        } catch is PekStaleError {
            // Single PEK-refresh retry: re-fetch L2 keys and try once more.
            // If it fails again the second exception propagates unchanged.
            let refreshedKey = try await l2Keys.fetch(forceRefresh: true)
            return try await doJweRoundTrip(
                url: url,
                body: body,
                requireAuth: requireAuth,
                codec: codec,
                deviceSigner: dSigner,
                recipient: refreshedKey,
                projectId: projectIdProvider.projectId
            )
        }
    }

    private func doJweRoundTrip(
        url: URL,
        body: [String: Any],
        requireAuth: Bool,
        codec: JweCodec,
        deviceSigner dSigner: DeviceJwsSigner,
        recipient: L2RecipientKey,
        projectId: Int
    ) async throws -> [String: Any] {
        let routePath = url.path
        let requestId = Self.uuidV7()
        let nonce = Self.nonce16()
        let tsMs = Int(Date().timeIntervalSince1970 * 1000)
        let deviceId = dSigner.deviceId

        // 1) Inner device JWS over the body. Claims bind the envelope to the
        //    physical route and nonce so L3 cannot be replayed across paths.
        let innerClaims: [String: Any] = [
            "iat": tsMs / 1000,
            "nonce": nonce.base64URLEncodedString(),
            "request_id": requestId,
            "route_path": routePath,
            "device_id": deviceId,
            "project_id": projectId,
            "body": body,
        ]
        let innerJws = try await dSigner.signClaims(innerClaims)
        guard let innerJwsBytes = innerJws.data(using: .utf8) else {
            throw LicenseStoreError("inner JWS not UTF-8 encodable")
        }

        // 2) Resolve the recipient X25519 pubkey into the CryptoKit type the
        //    `JweCodec` accepts. `L2RecipientKey.x25519Pub` is the raw 32-byte
        //    scalar form; CryptoKit constructs the PublicKey directly from it.
        let recipientPubKey: Curve25519.KeyAgreement.PublicKey
        do {
            recipientPubKey = try Curve25519.KeyAgreement.PublicKey(
                rawRepresentation: recipient.x25519Pub
            )
        } catch {
            throw JweDecryptionFailedError(
                "L2 recipient X25519 pub not valid: \(error)", cause: error)
        }

        // 3) JWE envelope. The protected header (built by `JweCodec`) binds
        //    project_id / route_path / request_id into the AAD per RFC 7516
        //    §5.1 — the server cross-checks them in alfheim middleware.
        //    `senderId` / `recipientId` go into `apu` / `apv`.
        //
        //    `apu` MUST be the SHA-256 thumbprint of the device's X25519
        //    pubkey (b64url, no padding) per `JweCodec.swift` docstring and
        //    the JWE migration spec. Passing the opaque device id string
        //    here drifts from the Dart twin and breaks server-side AAD
        //    cross-check. Compute from the device keypair on every request
        //    (it's a single SHA-256 over an already-cached 32-byte pub).
        guard let keypair = deviceKeypair else {
            throw LicenseStoreError(
                "JWE-required route \(routePath) needs a DeviceKeypairProvider " +
                "to compute the `apu` thumbprint; SDK was not configured with one. " +
                "See VanaheimConfig wiring.")
        }
        let apu = try await deviceX25519PubThumbprint(keypair)
        let aadCtx = JweAadContext(
            senderId: apu,
            recipientId: recipient.kid,
            projectId: projectId,
            routePath: routePath,
            requestId: requestId
        )
        let compactJwe: String
        do {
            compactJwe = try codec.encryptForRecipient(
                innerJwsBytes: innerJwsBytes,
                recipientPub: recipientPubKey,
                recipientKid: recipient.kid,
                aad: aadCtx
            )
        } catch let e as LicenseStoreError {
            throw e
        } catch {
            throw JweDecryptionFailedError("request encrypt failed: \(error)", cause: error)
        }

        // 4) Legacy HMAC over the JWE body (server still computes HMAC over
        //    the wire-form body before the alfheim middleware decrypts).
        let sig = self.signer.sign(compactJwe)

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue(LsHeaders.joseJson, forHTTPHeaderField: "Content-Type")
        req.setValue("\(LsHeaders.joseJson), \(LsHeaders.json)", forHTTPHeaderField: "Accept")
        req.setValue(self.signer.productSlug, forHTTPHeaderField: "X-LS-Product")
        req.setValue(sig.timestamp, forHTTPHeaderField: "X-LS-Timestamp")
        req.setValue(sig.signature, forHTTPHeaderField: "X-LS-Signature")
        req.setValue(requestId, forHTTPHeaderField: LsHeaders.XLSRequestId)
        req.setValue(deviceId, forHTTPHeaderField: LsHeaders.XLSDeviceId)
        req.setValue(recipient.kid, forHTTPHeaderField: LsHeaders.XLSRecipientKid)
        req.setValue(String(recipient.kekVersion), forHTTPHeaderField: LsHeaders.XLSKekV)
        if requireAuth {
            let tok = try await auth.getIdToken()
            req.setValue("Bearer \(tok)", forHTTPHeaderField: "Authorization")
        }
        if let appCheckTok = try await appCheck.getToken(), !appCheckTok.isEmpty {
            req.setValue(appCheckTok, forHTTPHeaderField: "X-Firebase-AppCheck")
        }
        req.httpBody = compactJwe.data(using: .utf8)

        let (data, response) = try await rawSend(req)
        guard let http = response as? HTTPURLResponse else {
            throw NetworkError("Non-HTTP response", statusCode: nil)
        }

        // 5) Status-driven exception path (412 pek_stale, 410 device_revoked,
        //    415 jwe_required) BEFORE attempting to decode the body, so we
        //    don't try to JSON-parse a problem+json body.
        try await maybeThrowJweStatus(
            data: data,
            http: http,
            routePath: routePath,
            deviceId: deviceId
        )

        // 6) Confidentiality check. JWE-required routes MUST come back with
        //    X-LS-Confidentiality: jwe. A plaintext body on success is a
        //    fail-closed condition (mis-deployed L2 or MITM).
        let conf = http.value(forHTTPHeaderField: LsHeaders.XLSConfidentiality)
        if conf != LsHeaders.confidentialityJwe {
            throw JweRequiredButGotJwsError(routePath: routePath)
        }

        // 7) Decrypt the response envelope and verify the inner JWS bound to
        //    this exact route + request_id.
        guard let responseJwe = String(data: data, encoding: .utf8) else {
            throw JweDecryptionFailedError("response body not UTF-8")
        }
        guard let keypair = deviceKeypair else {
            throw LicenseStoreError(
                "JWE response requires a DeviceKeypairProvider to decrypt; " +
                "SDK was not configured with one. See VanaheimConfig wiring.")
        }
        let devicePriv = try await keypair.getPrivateKey()
        let plaintext: Data
        do {
            let result = try codec.decryptCompact(
                jwe: responseJwe,
                devicePriv: devicePriv
            )
            plaintext = result.plaintext
            // Defense in depth: verify the response header binds to the same
            // route_path we sent. The server already enforces this in egress,
            // but a misrouted JWE that slipped past surfaces here.
            if let observed = result.header.routePath, observed != routePath {
                throw JweRouteMismatchError(
                    expectedRoute: routePath, observedRoute: observed)
            }
        } catch let e as LicenseStoreError {
            throw e
        } catch {
            throw JweDecryptionFailedError("response decrypt failed: \(error)", cause: error)
        }
        guard let innerJwsResponse = String(data: plaintext, encoding: .utf8) else {
            throw JweDecryptionFailedError("response inner JWS not UTF-8")
        }

        let claims: [String: Any]
        if let verifier = innerVerifier {
            claims = try await verifier.verify(
                compactJws: innerJwsResponse,
                expectedRoute: routePath,
                expectedRequestId: requestId
            )
        } else {
            // TODO(wave-10e): InnerJwsVerifier wiring; peekJwsPayload bypass MUST land before production
            //
            // No verifier injected (tests / staged rollout): trust the
            // decoded JWS payload but still parse it. The compact JWS is
            // header.payload.signature — payload is segment 1.
            //
            // Release builds fail closed — peekJwsPayload does NOT verify the
            // Ed25519 signature on the inner JWS, so any production binary
            // reaching this branch would silently accept unauthenticated
            // claims. Force the wiring to land before ship.
            #if !DEBUG
            throw JweInnerVerifierRequiredError()
            #else
            claims = try Self.peekJwsPayload(innerJwsResponse)
            #endif
        }

        // 8) Map decoded claims/body into the SDK's existing { ... } response.
        if let payload = claims["body"] as? [String: Any] {
            return payload
        }
        return claims
    }

    // ------------------------------------------------------------- response

    /// Status-code dispatch for JWE-leg failure modes. Returns normally if
    /// the response is a regular 2xx OR a non-JWE-specific error (those are
    /// re-mapped by the legacy decoder below).
    private func maybeThrowJweStatus(
        data: Data,
        http: HTTPURLResponse,
        routePath: String,
        deviceId: String
    ) async throws {
        if (200...299).contains(http.statusCode) { return }
        let body = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]
        let code = body["error"] as? String
        let reason = body["reason_code"] as? String

        // 412 pek_stale: L2 rotated the KEK between cache and request.
        if http.statusCode == 412 && (code == "pek_stale" || reason == "KEK_V_STALE") {
            let sentV = (body["sent_kek_v"] as? Int)
                ?? (body["sent_kek_v"] as? NSNumber)?.intValue
            let expV = (body["expected_kek_v"] as? Int)
                ?? (body["expected_kek_v"] as? NSNumber)?.intValue
            throw PekStaleError(sentKekV: sentV, serverKekV: expV)
        }
        // 410 device revoked / unenrolled.
        if http.statusCode == 410 && (reason == "DEVICE_REVOKED" || reason == "DEVICE_UNENROLLED") {
            await clearDeviceRegistrationMarker()
            throw DeviceRevokedError(deviceId: deviceId)
        }
        // 415 jwe_required: L2 reported the body wasn't a JWE (we don't
        // expect this — the SDK always sends JWE on this path — but cover it).
        if http.statusCode == 415 && code == "jwe_required" {
            throw JweRequiredButGotJwsError(routePath: routePath)
        }
        // Fall through to the legacy error mapper so existing error codes
        // (seat_cap_exceeded, auth, etc.) still produce typed exceptions.
        try throwLegacy(http: http, body: body)
    }

    private func clearDeviceRegistrationMarker() async {
        guard let cache = secureCache else { return }
        // SecureCache deletion best-effort; surfacing the DeviceRevoked
        // signal takes priority. The next connect() will retry the delete.
        try? await cache.deleteRaw(kDeviceRegisteredMarker)
    }

    private func rawSend(_ req: URLRequest) async throws -> (Data, URLResponse) {
        do {
            return try await session.data(for: req)
        } catch let e as URLError where e.code == .serverCertificateUntrusted ||
                                         e.code == .secureConnectionFailed {
            throw CertificatePinError("TLS handshake rejected by pinner", cause: e)
        } catch {
            throw NetworkError("HTTP failure: \(error.localizedDescription)", cause: error)
        }
    }

    /// Generic send + decode path used by `getJson` and the plain-JSON POST
    /// path. JWE-required routes route through `doJweRoundTrip` instead.
    private func sendAndDecode(
        _ req: URLRequest,
        expectJweResponse: Bool = false,
        routePath: String? = nil
    ) async throws -> [String: Any] {
        let (data, response) = try await rawSend(req)
        guard let http = response as? HTTPURLResponse else {
            throw NetworkError("Non-HTTP response", statusCode: nil)
        }

        // Fail-closed: caller expected JWE but server sent plaintext.
        if expectJweResponse {
            let conf = http.value(forHTTPHeaderField: LsHeaders.XLSConfidentiality)
            if conf != LsHeaders.confidentialityJwe {
                throw JweRequiredButGotJwsError(routePath: routePath)
            }
        }

        let body = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]
        if (200...299).contains(http.statusCode) {
            return body
        }
        try throwLegacy(http: http, body: body)
    }

    /// Legacy error-code → typed-exception mapper. Server reference:
    /// `internal/platform/server.WriteError`.
    private func throwLegacy(http: HTTPURLResponse, body: [String: Any]) throws -> Never {
        let code = body["error"] as? String
        let msg = (body["message"] as? String)
            ?? HTTPURLResponse.localizedString(forStatusCode: http.statusCode)

        switch code {
        case "seat_cap_exceeded":
            throw SeatCapExceededError(msg)
        case "session_revoked":
            throw SessionRevokedError(msg)
        case "transfer_cooldown_active":
            let available = (body["available_at"] as? String).flatMap(ISO8601DateFormatter().date)
                ?? Date()
            throw TransferCooldownError(availableAt: available)
        case "hmac", "auth", "firebase":
            throw AuthError("\(code ?? "auth"): \(msg)")
        case "app_check":
            throw AppCheckFailedError(msg)
        default:
            break
        }
        if http.statusCode == 401 || http.statusCode == 403 {
            throw AuthError(msg)
        }
        throw NetworkError(msg, statusCode: http.statusCode)
    }

    // ---------------------------------------------------------------- helpers

    /// Best-effort UUIDv7. Format per draft-ietf-uuidrev-rfc4122bis:
    /// 48-bit unix-ms timestamp || 4-bit version (0x7) || 12 bits random ||
    /// 2-bit variant (10) || 62 bits random.
    static func uuidV7() -> String {
        let tsMs = UInt64(Date().timeIntervalSince1970 * 1000)
        var bytes = [UInt8](repeating: 0, count: 16)
        bytes[0] = UInt8((tsMs >> 40) & 0xff)
        bytes[1] = UInt8((tsMs >> 32) & 0xff)
        bytes[2] = UInt8((tsMs >> 24) & 0xff)
        bytes[3] = UInt8((tsMs >> 16) & 0xff)
        bytes[4] = UInt8((tsMs >> 8) & 0xff)
        bytes[5] = UInt8(tsMs & 0xff)
        var rng = SystemRandomNumberGenerator()
        for i in 6..<16 {
            bytes[i] = UInt8.random(in: 0...255, using: &rng)
        }
        // version 7 in bits 4..7 of byte 6
        bytes[6] = (bytes[6] & 0x0f) | 0x70
        // variant 10 in bits 6..7 of byte 8
        bytes[8] = (bytes[8] & 0x3f) | 0x80
        return Self.formatUuid(bytes)
    }

    static func nonce16() -> Data {
        var bytes = [UInt8](repeating: 0, count: 16)
        var rng = SystemRandomNumberGenerator()
        for i in 0..<16 {
            bytes[i] = UInt8.random(in: 0...255, using: &rng)
        }
        return Data(bytes)
    }

    private static func formatUuid(_ b: [UInt8]) -> String {
        func h(_ i: Int) -> String { String(format: "%02x", b[i]) }
        return "\(h(0))\(h(1))\(h(2))\(h(3))-\(h(4))\(h(5))-\(h(6))\(h(7))-\(h(8))\(h(9))-\(h(10))\(h(11))\(h(12))\(h(13))\(h(14))\(h(15))"
    }

    /// Lightweight no-verify peek at a compact JWS payload — used only when
    /// the SDK is constructed without an `InnerJwsVerifier` (early-rollout
    /// + tests). In production the verifier is always wired.
    private static func peekJwsPayload(_ compactJws: String) throws -> [String: Any] {
        let parts = compactJws.split(separator: ".", omittingEmptySubsequences: false)
        if parts.count != 3 {
            throw JwtVerificationError("inner JWS shape invalid (\(parts.count) segments)")
        }
        let payload = String(parts[1])
        guard let bytes = Data(base64URLEncoded: payload) else {
            throw JwtVerificationError("inner JWS payload base64url decode failed")
        }
        guard let obj = try? JSONSerialization.jsonObject(with: bytes) as? [String: Any] else {
            throw JwtVerificationError("inner JWS payload is not a JSON object")
        }
        return obj
    }
}

