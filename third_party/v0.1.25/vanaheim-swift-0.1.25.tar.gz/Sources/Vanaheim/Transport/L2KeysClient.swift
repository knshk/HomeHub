// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// One L2 (Alfheim) recipient key bundle as published by
/// `GET {l2BaseUrl}/.well-known/lcs-keys`.
///
/// v2 collapses v1's two-recipient envelope (Bifrost + L2) to a single
/// recipient (L2 only). L2 forwards the inner device JWS to Bifrost over
/// the L2↔L3 leg — the device never wraps to Bifrost directly.
///
/// Wire shape (single recipient at a time; overlap pair only during rotation):
/// ```json
/// {
///   "kek_version": 7,
///   "x25519": { "kid": "l2-enc-7", "crv": "X25519", "x": "<b64url 32B>" },
///   "ed25519": { "kid": "l2-sig-7", "crv": "Ed25519", "x": "<b64url 32B>" }
/// }
/// ```
public struct L2RecipientKey: Sendable, Equatable {
    /// L2's encryption-key id (goes into `X-LS-Recipient-Kid`, the JWE
    /// header `kid`, and the AAD).
    public let kid: String

    /// L2's X25519 public key — 32 raw bytes, the recipient key the device
    /// performs ECDH-ES against. The JWE codec wraps the CEK to this.
    public let x25519Pub: Data

    /// L2's Ed25519 signing-key id used to verify the `LCS-L2-Sig` header
    /// on L2-originated material-change responses (the SDK does NOT verify
    /// inner JWSes with this key — those use the JWKS Bifrost keys).
    public let sigKid: String

    /// L2's Ed25519 verifying key — 32 raw bytes.
    public let ed25519Pub: Data

    /// KEK version published alongside the keys. Mirrored into `X-LS-KEK-V`
    /// on every outbound JWE so L2 can detect stale envelopes.
    public let kekVersion: Int

    public init(
        kid: String,
        x25519Pub: Data,
        sigKid: String,
        ed25519Pub: Data,
        kekVersion: Int
    ) {
        self.kid = kid
        self.x25519Pub = x25519Pub
        self.sigKid = sigKid
        self.ed25519Pub = ed25519Pub
        self.kekVersion = kekVersion
    }
}

/// Fetches and caches L2's `/.well-known/lcs-keys` endpoint.
///
/// Cache policy:
///   * 1 h TTL by default (mirrors L2's `Cache-Control: max-age=3600`).
///   * ETag-aware: a refresh after TTL sends `If-None-Match`; a `304`
///     response just extends the freshness window without replacing the
///     in-memory key.
///   * On `pek_stale` from [SignedHttpClient], the transport calls
///     [forceRefresh] to repoll before the retry.
///   * Single-flight: concurrent callers share one in-flight Task.
public actor L2KeysClient {
    /// `{l2BaseUrl}/.well-known/lcs-keys`. The SDK never talks to Bifrost
    /// directly for recipient keys in v2 — L2 owns its own well-known.
    public let url: URL

    private let session: URLSession
    private let ttl: TimeInterval
    private let timeout: TimeInterval

    private var cached: L2RecipientKey?
    private var etag: String?
    private var fetchedAt: Date = .distantPast
    private var inFlight: Task<L2RecipientKey, Error>?

    public init(
        l2BaseUrl: URL,
        session: URLSession = .shared,
        ttl: TimeInterval = 60 * 60,
        timeout: TimeInterval = 15
    ) {
        // Defensively normalize: strip any trailing slash so appending paths
        // doesn't double the separator.
        var base = l2BaseUrl.absoluteString
        if base.hasSuffix("/") {
            base.removeLast()
        }
        self.url = URL(string: "\(base)/.well-known/lcs-keys") ?? l2BaseUrl
        self.session = session
        self.ttl = ttl
        self.timeout = timeout
    }

    /// Returns the current recipient key, fetching if cold or stale.
    ///
    /// Mirrors Dart `L2KeysClient.get()` — the canonical SDK-surface read.
    /// Production code should use this; tests that need to bypass the TTL
    /// reach for [forceRefresh].
    public func get() async throws -> L2RecipientKey {
        try await fetch(forceRefresh: false)
    }

    /// Forces a network refresh, bypassing the TTL cache. Called by
    /// `SignedHttpClient` on `PekStaleError` (412 `pek_stale` /
    /// `X-LS-KEK-V` mismatch). Mirrors Dart `L2KeysClient.forceRefresh()`.
    public func forceRefresh() async throws -> L2RecipientKey {
        try await fetch(forceRefresh: true)
    }

    /// Internal implementation shared by [get] / [forceRefresh]. Kept
    /// public for backwards-compat with existing call sites in this module
    /// (`SignedHttpClient.postJwe` and `LicenseClient.connect`) but new code
    /// should prefer the named wrappers above for Dart-parity.
    public func fetch(forceRefresh: Bool = false) async throws -> L2RecipientKey {
        if forceRefresh {
            // Reset the freshness window so single-flight does a real network
            // round-trip rather than returning the in-memory cache.
            fetchedAt = .distantPast
        }
        if let c = cached, !isStale(), !forceRefresh {
            return c
        }
        return try await refresh()
    }

    /// Drops the cached key. Used in tests and on explicit `clear()`.
    public func invalidate() {
        cached = nil
        etag = nil
        fetchedAt = .distantPast
    }

    private func isStale() -> Bool {
        Date().timeIntervalSince(fetchedAt) > ttl
    }

    private func refresh() async throws -> L2RecipientKey {
        if let inFlight = inFlight {
            return try await inFlight.value
        }
        let task = Task<L2RecipientKey, Error> { [weak self] in
            guard let self else {
                throw NetworkError("l2_keys: client deallocated")
            }
            return try await self.doFetch()
        }
        inFlight = task
        defer { inFlight = nil }
        return try await task.value
    }

    private func doFetch() async throws -> L2RecipientKey {
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.timeoutInterval = timeout
        if let etag = etag {
            req.setValue(etag, forHTTPHeaderField: "If-None-Match")
        }

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: req)
        } catch let e as URLError where e.code == .timedOut {
            throw NetworkError("l2_keys: timeout", cause: e)
        } catch {
            throw NetworkError("l2_keys: \(error.localizedDescription)", cause: error)
        }

        guard let http = response as? HTTPURLResponse else {
            throw NetworkError("l2_keys: non-HTTP response")
        }

        if http.statusCode == 304 {
            guard let c = cached else {
                // Server claimed Not-Modified but we have nothing — treat as
                // a protocol error and force a clean refetch next call.
                invalidate()
                throw NetworkError("l2_keys: 304 without cached body",
                                   statusCode: 304)
            }
            fetchedAt = Date()
            return c
        }
        if !(200...299).contains(http.statusCode) {
            throw NetworkError(
                "l2_keys: \(http.statusCode) " +
                HTTPURLResponse.localizedString(forStatusCode: http.statusCode),
                statusCode: http.statusCode)
        }

        let body: [String: Any]
        do {
            guard let parsed = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                throw NetworkError("l2_keys: body is not a JSON object")
            }
            body = parsed
        } catch let e as LicenseStoreError {
            throw e
        } catch {
            throw NetworkError("l2_keys: malformed body: \(error)", cause: error)
        }

        let key = try Self.parse(body)
        cached = key
        if let newEtag = http.value(forHTTPHeaderField: "Etag")
            ?? http.value(forHTTPHeaderField: "ETag") {
            etag = newEtag
        }
        fetchedAt = Date()
        return key
    }

    // ----------------------------------------------------------------- parse

    private static func parse(_ body: [String: Any]) throws -> L2RecipientKey {
        let kekVersion: Int
        if let n = body["kek_version"] as? Int {
            kekVersion = n
        } else if let n = body["kek_version"] as? NSNumber {
            kekVersion = n.intValue
        } else {
            throw NetworkError("l2_keys: missing kek_version")
        }
        guard let x = body["x25519"] as? [String: Any] else {
            throw NetworkError("l2_keys: missing x25519")
        }
        guard let s = body["ed25519"] as? [String: Any] else {
            throw NetworkError("l2_keys: missing ed25519")
        }
        guard let xKid = x["kid"] as? String,
              let xPub = decodeRaw32(x, expectedCrv: "X25519"),
              let sKid = s["kid"] as? String,
              let sPub = decodeRaw32(s, expectedCrv: "Ed25519")
        else {
            throw NetworkError("l2_keys: invalid key fields")
        }
        return L2RecipientKey(
            kid: xKid,
            x25519Pub: xPub,
            sigKid: sKid,
            ed25519Pub: sPub,
            kekVersion: kekVersion
        )
    }

    /// JWK-style OKP key: `{ "kty":"OKP", "crv":"<expectedCrv>", "x":"<b64url 32B>" }`.
    /// Returns nil on any decode/shape error so the caller can produce a
    /// single uniform NetworkError.
    private static func decodeRaw32(_ jwk: [String: Any], expectedCrv: String) -> Data? {
        guard (jwk["crv"] as? String) == expectedCrv else { return nil }
        guard let x = jwk["x"] as? String, !x.isEmpty else { return nil }
        guard let bytes = base64UrlDecode(x), bytes.count == 32 else { return nil }
        return bytes
    }

    private static func base64UrlDecode(_ s: String) -> Data? {
        var str = s
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let pad = (4 - str.count % 4) % 4
        if pad > 0 { str.append(String(repeating: "=", count: pad)) }
        return Data(base64Encoded: str)
    }
}
