// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import CryptoKit
import Foundation

/// Computes the HMAC signature the server expects.
/// Server reference: `internal/auth/hmac.go` — verifies
///   HMAC-SHA256(secret, timestamp || "\n" || product || "\n" || body)
public struct HmacSigner: Sendable {
    public let productSlug: String
    public let sdkSecret: String

    public init(productSlug: String, sdkSecret: String) {
        self.productSlug = productSlug
        self.sdkSecret = sdkSecret
    }

    /// Returns (timestamp string, hex signature). Caller attaches as
    /// X-LS-Timestamp and X-LS-Signature headers.
    public func sign(_ body: String, now: Date = Date()) -> (timestamp: String, signature: String) {
        let ts = String(Int(now.timeIntervalSince1970))
        let input = "\(ts)\n\(productSlug)\n\(body)".data(using: .utf8)!
        let key = SymmetricKey(data: Data(sdkSecret.utf8))
        let mac = HMAC<SHA256>.authenticationCode(for: input, using: key)
        let hex = mac.map { String(format: "%02x", $0) }.joined()
        return (ts, hex)
    }
}
