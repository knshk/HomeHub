// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// HTTP header constants used by the Vanaheim transport layer (v2).
///
/// Source of truth: `JWE_migration.md` line 175. Mirrors the analogous
/// `headers.ts` / `headers.dart` constants across the Bifrost / Alfheim /
/// Vanaheim trio so a header rename never silently drifts between SDKs.
///
/// All constants are canonical-case (HTTP headers are case-insensitive on
/// the wire but the server's structured logging keys on these exact spellings).
public enum LsHeaders {
    // ---------------------------------------------------------------- request

    /// Per-device stable id assigned at `POST /v1/devices/enroll`. REQUIRED on
    /// every JWE request (hot-path or material-change). Missing → L3 returns
    /// 422 `DEVICE_SIG_INVALID`.
    public static let XLSDeviceId = "X-LS-Device-Id"

    /// UUIDv7 generated client-side, one per HTTP request. Used for:
    ///   * idempotency / replay protection at L1 + L2 + L3,
    ///   * AAD binding (must equal the inner-JWS `request_id` claim),
    ///   * cross-tier log correlation.
    public static let XLSRequestId = "X-LS-Request-Id"

    /// L2 X25519 encryption key id the device wrapped the CEK to (the value
    /// from `L2RecipientKey.kid`). **Singular** — v1's plural
    /// `X-LS-Recipient-Kids` is gone (single recipient only in v2).
    public static let XLSRecipientKid = "X-LS-Recipient-Kid"

    /// KEK version the device based its envelope on. L2 compares to its
    /// current version; mismatch → 412 `pek_stale` → SDK refreshes
    /// `/.well-known/lcs-keys` and retries exactly once.
    public static let XLSKekV = "X-LS-KEK-V"

    // --------------------------------------------------------------- response

    /// L2 sets this to `jwe` when the response body is a single-recipient
    /// compact JWE wrapping an inner JWS. Absence means plaintext JSON (only
    /// legal for routes in the JWS-allowed carve-out).
    public static let XLSConfidentiality = "X-LS-Confidentiality"

    // ----------------------------------------------------------- well-formed

    /// `application/jose+json` — Content-Type the SDK sends for JWE bodies.
    /// Plain JWS-allowed routes keep `application/json`.
    public static let joseJson = "application/jose+json"

    /// `application/json` — Content-Type for the JWS-allowed carve-out.
    public static let json = "application/json"

    /// Value of [XLSConfidentiality] when the body is a JWE.
    public static let confidentialityJwe = "jwe"
}
