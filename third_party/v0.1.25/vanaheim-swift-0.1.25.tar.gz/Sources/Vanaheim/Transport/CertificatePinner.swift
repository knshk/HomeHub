// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import CryptoKit
import Foundation

/// Pins the server's leaf-cert SPKI SHA-256 hash. Implemented as a
/// URLSessionDelegate so pinning is enforced INSIDE the TLS handshake on
/// every request — there's no MITM window between pin-check and connect.
///
/// Pin format: base64(SHA-256(SubjectPublicKeyInfo)).
///
/// On platforms without raw cert access (none for Swift on Apple platforms;
/// this matters only when the library is ported to web/Linux later), the
/// pinner short-circuits to a no-op like the Flutter SDK's kIsWeb guard.
public final class CertificatePinner: NSObject, URLSessionDelegate, @unchecked Sendable {
    public let pinnedSpkiSha256: Set<String>

    public init(pinnedSpkiSha256: [String]) {
        self.pinnedSpkiSha256 = Set(pinnedSpkiSha256)
    }

    public var isEnabled: Bool { !pinnedSpkiSha256.isEmpty }

    public func urlSession(
        _ session: URLSession,
        didReceive challenge: URLAuthenticationChallenge,
        completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void
    ) {
        guard challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
              let trust = challenge.protectionSpace.serverTrust
        else {
            completionHandler(.performDefaultHandling, nil)
            return
        }
        // No pins configured = trust the system chain.
        if pinnedSpkiSha256.isEmpty {
            completionHandler(.useCredential, URLCredential(trust: trust))
            return
        }
        // Pull the leaf cert (chain index 0) and hash its SPKI.
        // SecTrustCopyCertificateChain is the iOS 15+/macOS 12+ replacement
        // for the deprecated SecTrustGetCertificateAtIndex. Our Package.swift
        // platform floors are iOS 15 / macOS 12, so this is always available.
        guard let chain = SecTrustCopyCertificateChain(trust) as? [SecCertificate],
              let cert = chain.first,
              let spkiHash = Self.spkiSha256Base64(of: cert)
        else {
            completionHandler(.cancelAuthenticationChallenge, nil)
            return
        }
        if pinnedSpkiSha256.contains(spkiHash) {
            completionHandler(.useCredential, URLCredential(trust: trust))
        } else {
            completionHandler(.cancelAuthenticationChallenge, nil)
        }
    }

    /// Extracts the leaf certificate's SubjectPublicKeyInfo (SPKI) and
    /// returns SHA-256 in base64 — the same value `openssl` and other
    /// pinning tools compute:
    ///
    ///     openssl x509 -in cert.pem -pubkey -noout \
    ///       | openssl pkey -pubin -outform DER \
    ///       | openssl dgst -sha256 -binary \
    ///       | openssl enc -base64
    ///
    /// Apple's `SecKeyCopyExternalRepresentation` returns the *raw key
    /// bytes* (RSA modulus / EC point), NOT the full SPKI DER. To produce
    /// the SPKI hash, we prepend the algorithm-specific ASN.1 DER header
    /// before SHA-256. References: RFC 5480 (EC), RFC 8017 (RSA), and
    /// Apple Tech Note 2232 "Pinning Public Keys".
    ///
    /// Returns nil if the key algorithm/size isn't in our known-prefix
    /// table — then the integrator either adds the missing prefix or
    /// switches to cert-hash pinning. Refusing to emit a wrong hash is
    /// the safer default vs silently producing a never-matching value.
    static func spkiSha256Base64(of cert: SecCertificate) -> String? {
        guard let publicKey = SecCertificateCopyKey(cert) else { return nil }
        guard let attrs = SecKeyCopyAttributes(publicKey) as? [String: Any] else { return nil }
        let keyType = attrs[kSecAttrKeyType as String] as? String
        let keySize = attrs[kSecAttrKeySizeInBits as String] as? Int
        guard let prefix = spkiAsn1Prefix(keyType: keyType, keySize: keySize) else {
            return nil
        }
        guard let pubKeyBytes = SecKeyCopyExternalRepresentation(publicKey, nil) as Data? else {
            return nil
        }
        var spki = Data(prefix)
        spki.append(pubKeyBytes)
        let hash = SHA256.hash(data: spki)
        return Data(hash).base64EncodedString()
    }

    /// ASN.1 SPKI header bytes to prepend to the raw key bytes that
    /// `SecKeyCopyExternalRepresentation` emits. Covers the algorithms
    /// real TLS certs use today (RSA 2048/4096, EC P-256/P-384). Add
    /// entries here as new key types appear in your cert rotation plan.
    ///
    /// Implementation note: we use if/else against runtime-resolved
    /// `kSecAttrKeyTypeRSA as String` constants because Swift does NOT
    /// allow CFString constants inside switch tuple patterns —
    /// `case (kSecAttrKeyTypeRSA as String, 2048):` fails to compile.
    static func spkiAsn1Prefix(keyType: String?, keySize: Int?) -> [UInt8]? {
        guard let keyType = keyType, let keySize = keySize else { return nil }
        let rsaType = kSecAttrKeyTypeRSA as String
        let ecType = kSecAttrKeyTypeECSECPrimeRandom as String

        if keyType == rsaType && keySize == 2048 {
            return [
                0x30, 0x82, 0x01, 0x22, 0x30, 0x0d, 0x06, 0x09,
                0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01,
                0x01, 0x05, 0x00, 0x03, 0x82, 0x01, 0x0f, 0x00,
            ]
        }
        if keyType == rsaType && keySize == 4096 {
            return [
                0x30, 0x82, 0x02, 0x22, 0x30, 0x0d, 0x06, 0x09,
                0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01,
                0x01, 0x05, 0x00, 0x03, 0x82, 0x02, 0x0f, 0x00,
            ]
        }
        if keyType == ecType && keySize == 256 {
            return [
                0x30, 0x59, 0x30, 0x13, 0x06, 0x07, 0x2a, 0x86,
                0x48, 0xce, 0x3d, 0x02, 0x01, 0x06, 0x08, 0x2a,
                0x86, 0x48, 0xce, 0x3d, 0x03, 0x01, 0x07, 0x03,
                0x42, 0x00,
            ]
        }
        if keyType == ecType && keySize == 384 {
            return [
                0x30, 0x76, 0x30, 0x10, 0x06, 0x07, 0x2a, 0x86,
                0x48, 0xce, 0x3d, 0x02, 0x01, 0x06, 0x05, 0x2b,
                0x81, 0x04, 0x00, 0x22, 0x03, 0x62, 0x00,
            ]
        }
        return nil
    }
}
