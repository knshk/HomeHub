// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Pure-function decision logic for "is the cached JWT good, do I need to
/// refresh, am I past the cliff?" No I/O, trivially unit-testable.
public struct GraceStateMachine: Sendable {
    public let refreshBefore: TimeInterval
    public let clockSkew: TimeInterval

    public init(refreshBefore: TimeInterval = 24 * 60 * 60,
                clockSkew: TimeInterval = 5 * 60) {
        self.refreshBefore = refreshBefore
        self.clockSkew = clockSkew
    }

    public func evaluate(jwtExpiresAt: Date?, now: Date = Date()) -> GraceDecision {
        guard let exp = jwtExpiresAt else {
            return GraceDecision(state: .noJwt)
        }
        let remaining = exp.timeIntervalSince(now)
        if remaining <= -clockSkew {
            return GraceDecision(state: .expired, sinceExpiry: -remaining)
        }
        if remaining <= refreshBefore {
            return GraceDecision(state: .refreshNeeded, timeUntilExpiry: remaining)
        }
        return GraceDecision(state: .fresh, timeUntilExpiry: remaining)
    }
}

public enum GraceState: Sendable {
    case noJwt          // No cached JWT — must activate or hit verify
    case fresh          // JWT valid, far from expiry — no network needed
    case refreshNeeded  // JWT valid but close to expiry — use AND refresh in background
    case expired        // Past clock-skew tolerance — must refresh; offline = fail
}

public struct GraceDecision: Sendable {
    public let state: GraceState
    public let timeUntilExpiry: TimeInterval?
    public let sinceExpiry: TimeInterval?

    public init(state: GraceState, timeUntilExpiry: TimeInterval? = nil, sinceExpiry: TimeInterval? = nil) {
        self.state = state
        self.timeUntilExpiry = timeUntilExpiry
        self.sinceExpiry = sinceExpiry
    }
}
