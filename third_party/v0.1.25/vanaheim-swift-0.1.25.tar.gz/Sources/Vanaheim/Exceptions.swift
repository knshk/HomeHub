// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

// Mirror of sdk/dart/license_store_sdk/lib/src/exceptions.dart — same
// semantics, Swift idioms. Catch LicenseStoreError to handle SDK failures
// generically; switch on subclasses for UX branching.
public class LicenseStoreError: Error, CustomStringConvertible {
    public let message: String
    public let cause: Error?

    public init(_ message: String, cause: Error? = nil) {
        self.message = message
        self.cause = cause
    }

    public var description: String {
        let causeStr = cause.map { " (cause: \($0))" } ?? ""
        return "\(type(of: self)): \(message)\(causeStr)"
    }
}

/// Activation refused because the license has reached its seat cap.
public final class SeatCapExceededError: LicenseStoreError {
    public override init(_ message: String = "License seat cap exceeded", cause: Error? = nil) {
        super.init(message, cause: cause)
    }
}

/// Floating-tier bump — another device claimed the session.
public final class SessionRevokedError: LicenseStoreError {
    public override init(_ message: String = "Session revoked on another device", cause: Error? = nil) {
        super.init(message, cause: cause)
    }
}

/// Hard-lock transfer attempted before cooldown elapsed.
public final class TransferCooldownError: LicenseStoreError {
    public let availableAt: Date
    public init(availableAt: Date) {
        self.availableAt = availableAt
        super.init("Transfer cooldown active until \(ISO8601DateFormatter().string(from: availableAt))")
    }
}

/// JWT expired and the SDK could not refresh (offline beyond grace).
public final class LicenseExpiredError: LicenseStoreError {
    public override init(_ message: String = "License expired and could not refresh", cause: Error? = nil) {
        super.init(message, cause: cause)
    }
}

/// Transport / network failure (timeout, 5xx, TLS, DNS).
public final class NetworkError: LicenseStoreError {
    public let statusCode: Int?
    public init(_ message: String, statusCode: Int? = nil, cause: Error? = nil) {
        self.statusCode = statusCode
        super.init(message, cause: cause)
    }
}

/// Cert chain leaf SPKI did not match a pinned hash. Treat as MITM.
public final class CertificatePinError: LicenseStoreError {
    public override init(_ message: String = "Server certificate failed pinning check", cause: Error? = nil) {
        super.init(message, cause: cause)
    }
}

/// Firebase App Check token unavailable or rejected by the server.
public final class AppCheckFailedError: LicenseStoreError {
    public override init(_ message: String = "App Check verification failed", cause: Error? = nil) {
        super.init(message, cause: cause)
    }
}

/// JWT failed structure / signature checks. Caller MUST discard the JWT.
/// Distinct from LicenseExpiredError so callers can branch (compromised vs
/// just-stale).
public final class JwtVerificationError: LicenseStoreError {}

/// Server returned 401/403 with auth-level failure: HMAC mismatch, Firebase
/// token rejected, account/license mismatch.
public final class AuthError: LicenseStoreError {}

/// Caller used the SDK before connect() completed.
public final class NotConnectedError: LicenseStoreError {
    public init() {
        super.init("Call LicenseClient.connect(...) before using this method")
    }
}

// ---------------------------------------------------------------------------
// v2 / Vanaheim JWE-migration errors.
//
// These cover the new failure modes introduced by the JWE-required-by-default
// route policy + L2 device enrollment model. Distinct from JwtVerificationError
// so product UX can branch precisely (retry / reauth / clear-cache / surface).
// Mirrors sdk/dart/license_store_sdk/lib/src/exceptions.dart §v2 section.
// ---------------------------------------------------------------------------

/// Thrown when the server returned a plaintext (JWS / unencrypted JSON)
/// response on a route the SDK's route policy classifies as JWE-required.
///
/// SECURITY signal, not transient — the SDK MUST refuse the response. The
/// likely root causes (in order of likelihood): L2 misconfiguration (route
/// policy disagreement between SDK + server), MITM stripping the JWE
/// envelope, or a backend regression that bypassed the encrypt-on-egress
/// middleware. Product UX: surface as "secure connection failed" — do NOT
/// auto-retry, do NOT silently fall back to JWS.
public final class JweRequiredButGotJwsError: LicenseStoreError {
    /// The route path that should have been JWE-wrapped (diagnostics only).
    public let routePath: String?
    public init(routePath: String? = nil, cause: Error? = nil) {
        self.routePath = routePath
        let base = "Server returned plaintext on a JWE-required route"
        let msg = routePath.map { "\(base) (route: \($0))" } ?? base
        super.init(msg, cause: cause)
    }
}

/// Thrown when an outgoing JWE was rejected because its `kek_v` doesn't
/// match the current L2 recipient-key version. Normal operational signal
/// during L2 recipient-key rotation. The SDK retries exactly once after
/// force-refreshing the L2KeysClient cache; if the second attempt also
/// fails with PekStale, this is surfaced to the caller.
public final class PekStaleError: LicenseStoreError {
    /// `kek_v` the SDK sent (what we believed was current).
    public let sentKekV: Int?
    /// `kek_v` the server reports as current (what L2 actually rotated to).
    /// Spelled `serverKekV` per the v2 spec; the equivalent Dart field is
    /// `expectedKekV` but the wire-level header (`X-LS-KEK-V` on the
    /// response) is server-authoritative so the Swift name uses the
    /// server-facing terminology.
    public let serverKekV: Int?
    public init(sentKekV: Int? = nil, serverKekV: Int? = nil, cause: Error? = nil) {
        self.sentKekV = sentKekV
        self.serverKekV = serverKekV
        let base = "Recipient-key epoch (kek_v) is stale; refresh L2 keys"
        let msg: String
        if sentKekV == nil && serverKekV == nil {
            msg = base
        } else {
            msg = "\(base) (sent=\(sentKekV.map(String.init) ?? "nil"), expected=\(serverKekV.map(String.init) ?? "nil"))"
        }
        super.init(msg, cause: cause)
    }
}

/// Thrown when L2 returns HTTP 410 Gone for this device's enrollment.
/// The caller (`LicenseClient` plumbing) MUST clear the
/// `device_registered_v1` SecureCache marker so the next boot re-enrols
/// with a fresh keypair. Product UX: prompt the user to re-activate.
public final class DeviceRevokedError: LicenseStoreError {
    /// The device id L2 reported as revoked (diagnostics only — the SDK has
    /// already cleared it from local storage by the time this surfaces).
    public let deviceId: String?
    public init(deviceId: String? = nil, cause: Error? = nil) {
        self.deviceId = deviceId
        let base = "Device was revoked by the server; re-enrollment required"
        let msg = deviceId.map { "\(base) (device: \($0))" } ?? base
        super.init(msg, cause: cause)
    }
}

/// Thrown in release builds when `SignedHttpClient` would otherwise fall
/// back to `peekJwsPayload` because no `InnerJwsVerifier` was injected.
///
/// The peek path parses the inner JWS payload WITHOUT verifying the Ed25519
/// signature — acceptable for tests and the staged rollout while
/// `InnerJwsVerifier` wiring is in flight (TODO(wave-10e)), but a hard
/// fail-closed in release builds so no production binary can ship that
/// silently trusts an unverified payload. Once the verifier is wired into
/// `LicenseClient.connect()`, this error type becomes unreachable in normal
/// operation.
public final class JweInnerVerifierRequiredError: LicenseStoreError {
    public override init(
        _ message: String =
            "InnerJwsVerifier is required for production builds; SDK was " +
            "constructed without one. Wire one via LicenseClient.connect(...) " +
            "before shipping (TODO(wave-10e)).",
        cause: Error? = nil
    ) {
        super.init(message, cause: cause)
    }
}

/// Thrown when the inner JWS inside a decrypted JWE carries a `route_path`
/// header that doesn't match the path the request was actually served on.
/// In practice rare — the server rejects such mismatches in L2's
/// verify-egress middleware before they ever reach the client. The
/// exception type exists so the SDK can fail closed on the unlikely case
/// where a misrouted JWE slips past server-side checks (defense in depth).
public final class JweRouteMismatchError: LicenseStoreError {
    /// The route the SDK called.
    public let expectedRoute: String?
    /// The `route_path` inside the inner-JWS header.
    public let observedRoute: String?
    public init(expectedRoute: String? = nil, observedRoute: String? = nil, cause: Error? = nil) {
        self.expectedRoute = expectedRoute
        self.observedRoute = observedRoute
        let base = "Inner JWS route_path does not match served path"
        let msg: String
        if expectedRoute == nil && observedRoute == nil {
            msg = base
        } else {
            msg = "\(base) (expected=\(expectedRoute ?? "nil"), observed=\(observedRoute ?? "nil"))"
        }
        super.init(msg, cause: cause)
    }
}
