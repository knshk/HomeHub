// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// The single product-facing object. Construct via
/// `LicenseClient.connect(...)`; then call `activate`, `verify`, read
/// entitlements via `hasFeature` / `quota`, and observe state changes via
/// `stateChanges`.
public actor LicenseClient {
    public static let issuer = "licenses.example.com" // ci-allow: sdk-legacy-issuer-string — JWT `iss` claim, not a URL

    private let config: VanaheimConfig
    private let productSlug: String
    private let http: SignedHttpClient
    private let jwks: JwksClient
    private let cache: SecureCache
    private let fp: DeviceFingerprintGenerator
    private let grace: GraceStateMachine
    private let telemetry: ErrorTelemetry
    private nonisolated let l2Keys: L2KeysClient
    private nonisolated let devices: DevicesAPI

    private var regionEndpoint: URL
    private var licenseId: String?
    private var activationId: String?
    private var cachedJwt: String?
    private var claims: LicenseJwtClaims?
    private var knownEntitlementsVersion: Int = 0
    private var knownConfigVersion: Int = 0
    private var knownPreferencesVersion: Int = 0
    private var lastSentPushToken: String?
    private var refreshTask: Task<Void, Never>?
    private var pushTokenTask: Task<Void, Never>?
    private var pushMessageTask: Task<Void, Never>?
    private var disposed = false

    private let capabilities_: SdkCapabilities
    private let push: PushTokenProvider
    private let formatter_: MessageFormatter
    private var _telemetryAPI: TelemetryAPI?

    // Lazily-constructed sub-API namespaces. All hang off the same
    // SignedHttpClient + regional endpoint.
    private var _notifications: NotificationsAPI?
    private var _feedback: FeedbackAPI?
    private var _subscription: SubscriptionAPI?
    private var _privacy: PrivacyAPI?
    private var _preferences: PreferencesAPI?
    private var _support: SupportAPI?
    private var _assistant: AssistantAPI?
    private var _referrals: ReferralsAPI?
    private var _status: StatusAPI?
    private var _account: AccountAPI?
    private var _organization: OrganizationAPI?
    private var _offers: OffersAPI?
    private var _docs: DocsAPI?
    private var _security: SecurityAPI?

    // Nonisolated snapshot for SYNC reads (hasFeature, quota, tier,
    // expiresAt, entitlementsVersion). Restores call-site parity with
    // Flutter's sync getters. Updated by the actor on every claims change
    // via updateSnapshot(); read by nonisolated methods under snapshotLock.
    //
    // GraceStateMachine is a Sendable value type, so its config is safe
    // to capture nonisolated; sync readers re-evaluate the grace state
    // inline using this captured config without needing actor isolation.
    private nonisolated let snapshotLock = NSLock()
    private nonisolated(unsafe) var _snapshot: ClaimsSnapshot?
    private nonisolated(unsafe) var _snapshotExpiredEmitted = false
    private nonisolated let graceForSync: GraceStateMachine

    private nonisolated let stateContinuation: AsyncStream<LicenseStateChange>.Continuation
    public nonisolated let stateChanges: AsyncStream<LicenseStateChange>

    private init(
        config: VanaheimConfig,
        capabilities: SdkCapabilities,
        productSlug: String,
        http: SignedHttpClient,
        jwks: JwksClient,
        cache: SecureCache,
        fp: DeviceFingerprintGenerator,
        grace: GraceStateMachine,
        telemetry: ErrorTelemetry,
        regionEndpoint: URL,
        push: PushTokenProvider,
        formatter: MessageFormatter,
        l2Keys: L2KeysClient,
        devices: DevicesAPI
    ) {
        self.config = config
        self.capabilities_ = capabilities
        self.productSlug = productSlug
        self.http = http
        self.jwks = jwks
        self.cache = cache
        self.fp = fp
        self.grace = grace
        self.telemetry = telemetry
        self.push = push
        self.formatter_ = formatter
        self.regionEndpoint = regionEndpoint
        self.graceForSync = grace
        self.l2Keys = l2Keys
        self.devices = devices

        var cont: AsyncStream<LicenseStateChange>.Continuation!
        self.stateChanges = AsyncStream { cont = $0 }
        self.stateContinuation = cont
    }

    /// Immutable snapshot read by nonisolated sync getters.
    private struct ClaimsSnapshot: Sendable {
        let claims: LicenseJwtClaims
        let entitlementsVersion: Int
    }

    /// Atomically updates the nonisolated snapshot. Called from the actor
    /// every time `claims` changes (activate, verify, rehydrate, clear).
    /// Pass nil to invalidate (post-sign-out, post-revoke, etc.).
    private func updateSnapshot(_ claims: LicenseJwtClaims?) {
        snapshotLock.lock()
        defer { snapshotLock.unlock() }
        if let c = claims {
            _snapshot = ClaimsSnapshot(claims: c, entitlementsVersion: c.entitlementsVersion)
        } else {
            _snapshot = nil
        }
        // Fresh JWT clears the one-shot expired guard.
        _snapshotExpiredEmitted = false
    }

    // MARK: - Construction

    /// Connects: resolves the regional API endpoint from the control plane,
    /// restores any cached JWT, and starts the background refresh loop.
    ///
    /// v2 / Vanaheim: `config` is now REQUIRED — it carries the per-product
    /// `l2BaseUrl`, `projectId`, JWE decryptor, and device-keypair provider.
    /// On first boot (no `device_registered_v1` cache marker) the SDK also
    /// enrolls the device's X25519 pubkey with L2 before returning — so the
    /// caller can immediately `activate()` without an extra round-trip.
    public static func connect(
        controlPlaneUrl: URL,
        productSlug: String,
        sdkSecret: String,
        config: VanaheimConfig,
        capabilities: SdkCapabilities = .defaults,
        // Defaults to UnconfiguredAuthTokenProvider() — throws on first use
        // with a clear "pass FirebaseAuthTokenProvider or DevAuthTokenProvider"
        // message. Restores Flutter SDK call-site parity (auth is optional).
        // Swift cannot construct a Firebase default itself because we don't
        // bundle the firebase-ios-sdk; consuming app injects it.
        auth: AuthTokenProvider = UnconfiguredAuthTokenProvider(),
        appCheck: AppCheckTokenProvider = NoAppCheckProvider(),
        cache: SecureCache? = nil,
        fingerprint: DeviceFingerprintGenerator = DeviceFingerprintGenerator(),
        pushTokenProvider: PushTokenProvider = NoPushTokenProvider(),
        i18nCatalog: [String: String] = [:]
    ) async throws -> LicenseClient {

        let signer = HmacSigner(productSlug: productSlug, sdkSecret: sdkSecret)
        let pinner = CertificatePinner(pinnedSpkiSha256: config.pinnedSpkiSha256)

        let storage = cache ?? KeychainSecureCache()
        let telemetry = ErrorTelemetry(cache: storage)
        await telemetry.restore()

        // v2 / Vanaheim: pre-build the JWE machinery BEFORE SignedHttpClient
        // so every outbound call — including DevicesAPI.maybeEnrollDevice on
        // the JWE-required POST /v1/devices/enroll — routes through the JWE
        // leg. Prior to this wave the transport was constructed with only
        // the legacy 5 params, so postJson silently fell back to postPlain
        // on JWE-required routes (Wave 10d CRIT-1).
        let l2Keys = L2KeysClient(
            l2BaseUrl: config.l2BaseUrl,
            ttl: config.jwksCacheTtl,
            timeout: config.httpTimeout)
        do {
            _ = try await l2Keys.fetch()
        } catch {
            await telemetry.capture(
                source: "connect.l2KeysClient.initialFetch",
                error: error,
                severity: .warn)
            // Continue — transport will retry on demand.
        }

        // The keypair provider lives on the config so the host product can
        // back it with whatever secure storage they prefer (Secure Enclave,
        // hardware key, in-memory test double). Production wires
        // `KeychainDeviceKeypairProvider()` — same concrete type the
        // transport asks `getPrivateKey()` on inside the JWE response path.
        let deviceKeypair = config.deviceKeypairProvider
        let jweCodec = JweCodec()
        // Default Ed25519 inner-JWS signer + project-id provider. The signer
        // pulls the L2-assigned device id from `SecureCache.getRaw('device_id_v1')`
        // — set by `maybeEnrollDevice()` post-enrollment. Empty string before
        // first enrollment.
        let deviceJwsSigner = KeychainDeviceJwsSigner(cache: storage)
        let projectIdProvider = StaticProjectIdProvider(projectId: config.projectId)

        // v2: SignedHttpClient is the single egress; routePolicy + jweCodec +
        // deviceSigner + deviceKeypair + l2Keys + projectIdProvider drive
        // JWE-required wrapping. `innerVerifier: nil` for the staged rollout
        // — Wave 10e (MED-2) wires the production Ed25519 inner-JWS verifier;
        // release builds fail closed via `JweInnerVerifierRequiredError` in
        // the transport meanwhile.
        let http = SignedHttpClient(
            signer: signer,
            auth: auth,
            appCheck: appCheck,
            pinner: pinner,
            timeout: config.httpTimeout,
            useRoutePolicy: true,
            jweCodec: jweCodec,
            deviceSigner: deviceJwsSigner,
            deviceKeypair: deviceKeypair,
            // TODO(wave-10e) MED-2: wire the production InnerJwsVerifier
            // (Ed25519 + device-registry kid lookup) once it lands.
            innerVerifier: nil,
            l2Keys: l2Keys,
            projectIdProvider: projectIdProvider,
            secureCache: storage)

        let jwksUrl = controlPlaneUrl.appendingPathComponent("v1/.well-known/jwks.json")
        let jwks = JwksClient(jwksUrl: jwksUrl, http: http, defaultTtl: config.jwksCacheTtl)

        let region: URL
        if let cachedEndpoint = try await storage.getRegionEndpoint(),
           let u = URL(string: cachedEndpoint) {
            region = u
        } else {
            do {
                region = try await resolveRegion(http: http, controlPlane: controlPlaneUrl, productSlug: productSlug)
                try await storage.putRegionEndpoint(region.absoluteString)
            } catch {
                await telemetry.capture(source: "connect.resolveRegion", error: error, context: [
                    "control_plane": controlPlaneUrl.absoluteString,
                ])
                await telemetry.flush()
                throw error
            }
        }

        let devices = DevicesAPI(http: http, l2BaseUrl: config.l2BaseUrl)
        let client = LicenseClient(
            config: config,
            capabilities: capabilities,
            productSlug: productSlug, http: http, jwks: jwks,
            cache: storage, fp: fingerprint,
            grace: GraceStateMachine(refreshBefore: config.refreshBefore, clockSkew: config.clockSkew),
            telemetry: telemetry,
            regionEndpoint: region,
            push: pushTokenProvider,
            formatter: MessageFormatter(catalog: i18nCatalog),
            l2Keys: l2Keys,
            devices: devices)

        // v2: first-boot device enrollment. The marker key
        // `device_registered_v1` lives in SecureCache; cleared by
        // DeviceRevokedError handling so a revoked device naturally
        // re-enrolls on next connect. We do this BEFORE rehydrate so the
        // cached JWT path can rely on a device being registered with L2.
        try await client.maybeEnrollDevice()

        await client.rehydrate()
        if !(pushTokenProvider is NoPushTokenProvider) {
            await client.wirePush()
        }
        if capabilities.telemetry {
            await client.startTelemetry()
        }
        return client
    }

    /// v2 / Vanaheim first-boot device enrollment.
    ///
    /// Idempotent via the `device_registered_v1` SecureCache marker:
    ///   * If marker is set, skip — device is already enrolled with L2.
    ///   * Else, ask the configured `deviceKeypairProvider` for the X25519
    ///     pubkey, POST to L2 `/v1/devices/enroll`, persist the assigned
    ///     `device_id`, and write the marker.
    ///
    /// Enrollment failures bubble up — without an L2 device record the SDK
    /// can't run JWE-required calls, so failing fast is correct.
    private func maybeEnrollDevice() async throws {
        let marker = try? await cache.getRaw(kDeviceRegisteredMarker)
        if marker == "true" { return }
        let pubKey = try await config.deviceKeypairProvider.getPublicKey()
        guard !pubKey.isEmpty else {
            throw LicenseStoreError(
                "VanaheimConfig.deviceKeypairProvider returned an empty pubkey; " +
                "v2 SDK requires a real X25519 keypair for L2 device enrollment.")
        }
        do {
            let enrollment = try await devices.register(devicePubKey: pubKey)
            try? await cache.putRaw("device_id_v1", enrollment.deviceId)
            try? await cache.putRaw(kDeviceRegisteredMarker, "true")
        } catch let e as DeviceRevokedError {
            // Server claims this fingerprint is permanently revoked. Clear
            // any stale marker so a fresh keypair-rotation flow can re-enrol
            // on the next connect attempt (host product decides whether to
            // rotate).
            try? await cache.deleteRaw(kDeviceRegisteredMarker)
            try? await cache.deleteRaw("device_id_v1")
            throw e
        } catch {
            await telemetry.capture(source: "connect.devices.register", error: error)
            throw error
        }
    }

    /// Idempotent: starts/replays telemetry restore + flush timer.
    private func startTelemetry() async {
        let api = TelemetryAPI(
            http: http,
            endpoint: { [weak self] in
                await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
            },
            cache: cache,
            capabilities: capabilities_,
            productSlug: productSlug)
        _telemetryAPI = api
        await api.restore()
        await api.start()
    }

    /// §3A.3 push wake-trigger: incoming `license.changed` /
    /// `license.config_changed` messages immediately trigger verify() so the
    /// SDK observes any cfg_v / ev / prefs_v bump within seconds.
    private func wirePush() {
        pushTokenTask?.cancel()
        pushMessageTask?.cancel()
        let push = self.push
        pushTokenTask = Task { [weak self] in
            for await _ in push.tokenChanges {
                guard let self = self else { return }
                await self.clearLastSentToken()
            }
        }
        pushMessageTask = Task { [weak self] in
            for await msg in push.incomingMessages {
                guard let self = self else { return }
                let kind = msg["kind"] as? String ?? ""
                if kind == "license.changed" ||
                   kind == "license.config_changed" ||
                   kind == "license.notification" {
                    try? await self.verify()
                }
            }
        }
    }

    private func clearLastSentToken() {
        lastSentPushToken = nil
    }

    private static func resolveRegion(http: SignedHttpClient, controlPlane: URL, productSlug: String) async throws -> URL {
        let url = controlPlane.appendingPathComponent("v1/accounts")
        let body = try await http.postJson(url: url, body: ["product_slug": productSlug])
        guard let endpoint = body["suggested_endpoint"] as? String, let url = URL(string: endpoint) else {
            throw NetworkError("Control plane returned no region endpoint")
        }
        return url
    }

    private func rehydrate() async {
        licenseId = try? await cache.getLicenseId()
        activationId = try? await cache.getActivationId()
        guard let jwt = try? await cache.getJwt() else { return }
        do {
            let c = try await verifyCachedJwt(jwt)
            cachedJwt = jwt
            claims = c
            knownEntitlementsVersion = c.entitlementsVersion
            knownConfigVersion = c.configVersion
            knownPreferencesVersion = c.preferencesVersion
            updateSnapshot(c)
            scheduleRefresh(at: c.expiresAt)
        } catch is JwtVerificationError {
            try? await cache.clear()
            try? await cache.putRegionEndpoint(regionEndpoint.absoluteString)
        } catch is LicenseExpiredError {
            try? await cache.clear()
            try? await cache.putRegionEndpoint(regionEndpoint.absoluteString)
        } catch {
            // Other errors (network, etc.) — leave cache alone, caller's verify() will re-attempt
        }
    }

    // MARK: - Public surface

    /// Binds this device to the license and returns the signed JWT.
    /// Idempotent on (license, device). If the tier is floating and the new
    /// activation bumped an older session, `ActivationResult.kickedDevice` is set.
    public func activate(deviceName: String? = nil, os: String? = nil) async throws -> ActivationResult {
        try checkAlive()
        let fpHex = await fp.generate(productSlug: productSlug)
        // `??` doesn't compose with `try await` — its right-hand operand is
        // a non-async, non-throwing autoclosure. Spell out the fallback.
        let lid: String
        if let existing = licenseId {
            lid = existing
        } else {
            lid = try await ensureLicense()
        }

        var body: [String: Any] = ["device_fingerprint": fpHex]
        if let deviceName = deviceName { body["device_name"] = deviceName }
        if let os = os { body["os"] = os }

        // v2 / Vanaheim: the `device_pubkey` field that v1 sent in the
        // activate body is GONE. Device enrollment now happens up-front
        // during connect() via DevicesAPI.register — by the time we get
        // here, L2 already knows this device's recipient pubkey. The
        // activate response can be JWE-wrapped immediately; verifyCachedJwt
        // handles JWE detection.

        // §2A.1 / §3A.3: attach push token if the product wired up FCM/APNs.
        // Empty token = product hasn't requested permission yet — backend
        // stays pull-only for this device. We cache the last-sent token so
        // we don't re-emit unchanged tokens.
        if !(push is NoPushTokenProvider) {
            if let t = try? await push.getToken(), !t.isEmpty, t != lastSentPushToken {
                body["push_token"] = t
                lastSentPushToken = t
            }
        }

        let url = regionEndpoint.appendingPathComponent("v1/licenses/\(lid)/activate")
        let res = try await http.postJson(url: url, body: body)

        guard let jwt = res["jwt"] as? String else {
            throw NetworkError("Server returned no jwt")
        }
        let c = try await verifyCachedJwt(jwt)

        var kicked: KickedDevice? = nil
        if let kRaw = res["kicked_device"] as? [String: Any] {
            kicked = parseKickedDevice(kRaw)
        }

        activationId = res["activation_id"] as? String
        cachedJwt = jwt
        claims = c
        knownEntitlementsVersion = c.entitlementsVersion
        knownConfigVersion = c.configVersion
        knownPreferencesVersion = c.preferencesVersion
        updateSnapshot(c) // includes resetting _snapshotExpiredEmitted

        try? await cache.putJwt(jwt)
        if let aid = activationId { try? await cache.putActivationId(aid) }
        try? await cache.putLicenseId(lid)

        scheduleRefresh(at: c.expiresAt)
        emit(.activated, claims: c, kicked: kicked)

        return ActivationResult(
            activationId: activationId ?? "",
            expiresAt: c.expiresAt,
            entitlements: entitlements(from: c),
            kickedDevice: kicked)
    }

    /// Refreshes the JWT and re-verifies. Throws on failure; the SDK does
    /// NOT silently fall back to a stale JWT on auth errors.
    public func verify() async throws {
        try checkAlive()
        guard let lid = licenseId else { throw NotConnectedError() }
        let fpHex = await fp.generate(productSlug: productSlug)

        let preGrace = grace.evaluate(jwtExpiresAt: claims?.expiresAt)
        let url = regionEndpoint.appendingPathComponent("v1/licenses/verify")
        let body: [String: Any] = ["license_id": lid, "device_fingerprint": fpHex]

        do {
            let res = try await http.postJson(url: url, body: body)
            guard let jwt = res["jwt"] as? String else {
                throw NetworkError("Server returned no jwt")
            }
            let c = try await verifyCachedJwt(jwt)
            cachedJwt = jwt
            claims = c
            updateSnapshot(c) // includes resetting _snapshotExpiredEmitted
            try? await cache.putJwt(jwt)
            if c.entitlementsVersion > knownEntitlementsVersion {
                knownEntitlementsVersion = c.entitlementsVersion
                emit(.entitlementsUpdated, claims: c)
            }
            if c.configVersion > knownConfigVersion {
                knownConfigVersion = c.configVersion
                emit(.configUpdated, claims: c)
            }
            if c.preferencesVersion > knownPreferencesVersion {
                knownPreferencesVersion = c.preferencesVersion
                emit(.preferencesUpdated, claims: c)
            }
            scheduleRefresh(at: c.expiresAt)
        } catch let e as SessionRevokedError {
            await telemetry.capture(source: "verify", error: e)
            try? await cache.clear()
            claims = nil
            cachedJwt = nil
            updateSnapshot(nil)
            emit(.sessionRevoked, error: e)
            throw e
        } catch let e as LicenseExpiredError {
            await telemetry.capture(source: "verify", error: e)
            emit(.expired, claims: claims, error: e)
            throw e
        } catch let e as NetworkError {
            if preGrace.state == .expired, let c = claims {
                let err = LicenseExpiredError("Cached JWT expired and refresh failed: \(e.message)", cause: e)
                markExpiredOnce(c)
                emit(.expired, claims: c, error: err)
                await telemetry.capture(source: "verify.offline_expired", error: err)
                throw err
            }
            await telemetry.capture(source: "verify", error: e, severity: .warn)
            throw e
        }
    }

    /// Hard-lock transfer: deactivate this binding so the user can activate
    /// on a new device. Honors the tier's cooldown.
    public func transferToNewDevice() async throws {
        try checkAlive()
        guard let lid = licenseId, let aid = activationId else { throw NotConnectedError() }
        let url = regionEndpoint.appendingPathComponent("v1/licenses/\(lid)/transfer")
        _ = try await http.postJson(url: url, body: ["activation_id": aid])
        try? await cache.clear()
        claims = nil
        cachedJwt = nil
        activationId = nil
        updateSnapshot(nil)
    }

    /// Frees this device's seat. Use for "sign out" or app uninstall hooks.
    /// Error contract: matches Dart's `Future<void> deactivate()` semantics
    /// exactly — both propagate transport / auth / network errors to the
    /// caller (Dart via Future-rejection, Swift via `throws`). Neither
    /// swallows errors; callers should `try await` (Swift) or `await /
    /// catch` (Dart) accordingly. Local-state cleanup (cache.clear, claims
    /// nil, etc.) only runs after a successful POST.
    public func deactivate() async throws {
        try checkAlive()
        guard let lid = licenseId, let aid = activationId else { return }
        let url = regionEndpoint.appendingPathComponent("v1/licenses/\(lid)/deactivate")
        _ = try await http.postJson(url: url, body: ["activation_id": aid])
        try? await cache.clear()
        claims = nil
        cachedJwt = nil
        activationId = nil
        updateSnapshot(nil)
    }

    // MARK: - Sync nonisolated reads (Flutter-parity sync API)
    //
    // These match Dart's sync `bool hasFeature(...)`, `T? quota<T>(...)`,
    // `String? tier`, `DateTime? expiresAt`, `int entitlementsVersion`.
    // They read from the nonisolated snapshot updated by the actor on
    // every claims change. No `await` required at the call site.
    //
    // Concurrency safety: NSLock around snapshot get/set. The captured
    // GraceStateMachine is a Sendable value type, so inline grace
    // evaluation is safe without actor isolation.

    /// Pure offline read. Returns false (fail-closed) if no cached JWT or
    /// the cached JWT is expired per the grace state machine.
    public nonisolated func hasFeature(_ key: String) -> Bool {
        let (snapshot, _) = readSnapshot()
        guard let c = snapshot?.claims else { return false }
        if isExpiredNonisolated(c) {
            markExpiredOnce(c)
            return false
        }
        return entitlementsNonisolated(from: c).has(key)
    }

    /// Pure offline read. Returns nil (fail-closed) when no JWT or expired.
    public nonisolated func quota<T>(_ key: String, as: T.Type = T.self) -> T? {
        let (snapshot, _) = readSnapshot()
        guard let c = snapshot?.claims else { return nil }
        if isExpiredNonisolated(c) {
            markExpiredOnce(c)
            return nil
        }
        return entitlementsNonisolated(from: c).quota(key, as: T.self)
    }

    /// Current tier slug ("pro", "plus", …) or nil if not activated.
    public nonisolated var tier: String? {
        readSnapshot().0?.claims.tier
    }

    /// JWT expiry. SDK refreshes ~1 day before this by default.
    public nonisolated var expiresAt: Date? {
        readSnapshot().0?.claims.expiresAt
    }

    /// entitlements_version from the most recent JWT. Bumped server-side
    /// on every tier change; the SDK fires `entitlementsUpdated` when it
    /// observes a higher value after refresh.
    public nonisolated var entitlementsVersion: Int {
        readSnapshot().0?.entitlementsVersion ?? 0
    }

    /// cfg_v from the most recent JWT. Bumped on every runtime-config
    /// override write affecting this license. SDK fires `.configUpdated`
    /// when observed bump.
    public nonisolated var configVersion: Int {
        readSnapshot().0?.claims.configVersion ?? 0
    }

    /// prefs_v from the most recent JWT. Bumped on cross-product preferences
    /// change. SDK fires `.preferencesUpdated` when observed bump.
    public nonisolated var preferencesVersion: Int {
        readSnapshot().0?.claims.preferencesVersion ?? 0
    }

    // MARK: - 2A.1 Runtime config sync read

    /// Reads a runtime-config value. Fail-closed: returns `defaultValue` when
    /// no cached JWT, missing key, wrong type, or expired JWT.
    public nonisolated func config<T>(_ key: String, default defaultValue: T) -> T {
        let (snapshot, _) = readSnapshot()
        guard let c = snapshot?.claims else { return defaultValue }
        if isExpiredNonisolated(c) {
            markExpiredOnce(c)
            return defaultValue
        }
        let v = c.config[key]?.value
        if let typed = v as? T { return typed }
        if T.self == Int.self, let n = v as? NSNumber { return n.intValue as? T ?? defaultValue }
        if T.self == Double.self, let n = v as? NSNumber { return n.doubleValue as? T ?? defaultValue }
        return defaultValue
    }

    // MARK: - 2A.2 Feature-flag convenience

    /// Returns true if runtime-config flag `feature.<key>.enabled` is true.
    /// Default false — fail-closed.
    public nonisolated func featureEnabled(_ key: String) -> Bool {
        config("feature.\(key).enabled", default: false)
    }

    // MARK: - 2A.6 Roles + multi-context getters

    /// Multi-valued roles from JWT (`["customer", "partner", ...]`). Empty
    /// when backend hasn't started emitting the claim.
    public nonisolated var roles: [String] {
        readSnapshot().0?.claims.roles ?? []
    }

    /// True if the JWT carries [role].
    public nonisolated func hasRole(_ role: String) -> Bool {
        roles.contains(role)
    }

    /// True if `'partner' ∈ roles`.
    public nonisolated var isPartner: Bool { hasRole("partner") }

    /// Organization context if the JWT carries `org_id`. Nil for consumer
    /// accounts.
    public nonisolated var organization: OrganizationContext? {
        guard let c = readSnapshot().0?.claims,
              let id = c.orgId, let role = c.orgRole else { return nil }
        return OrganizationContext(orgId: id, orgRole: role)
    }

    // MARK: - 2A.12 Locale

    /// Resolved user locale from JWT (e.g. "en-US"). Nil when not server-side;
    /// products should fall back to platform system locale.
    public nonisolated var locale: String? {
        readSnapshot().0?.claims.locale
    }

    // MARK: - 2A.3 / 2A.4 / 2A.7 / 2A.9 / 2A.10 / 2A.11 sub-API accessors

    /// Notification inbox + preferences (§2A.3).
    public func notifications() -> NotificationsAPI {
        if let api = _notifications { return api }
        let api = NotificationsAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _notifications = api
        return api
    }

    /// Feedback / NPS / CSAT (§2A.4).
    public func feedback() -> FeedbackAPI {
        if let api = _feedback { return api }
        let api = FeedbackAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _feedback = api
        return api
    }

    /// Self-serve subscription management (§2A.7).
    public func subscription() -> SubscriptionAPI {
        if let api = _subscription { return api }
        let api = SubscriptionAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _subscription = api
        return api
    }

    /// Privacy + consent (§2A.9).
    public func privacy() -> PrivacyAPI {
        if let api = _privacy { return api }
        let api = PrivacyAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _privacy = api
        return api
    }

    /// Cross-product preferences (§2A.10).
    public func preferences() -> PreferencesAPI {
        if let api = _preferences { return api }
        let api = PreferencesAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _preferences = api
        return api
    }

    /// Support / tickets / KB (§2A.11).
    public func support() -> SupportAPI {
        if let api = _support { return api }
        let api = SupportAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _support = api
        return api
    }

    /// AI customer assistant (§2B.3).
    public func assistant() -> AssistantAPI {
        if let api = _assistant { return api }
        let api = AssistantAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _assistant = api
        return api
    }

    /// Referrals (§2B.4).
    public func referrals() -> ReferralsAPI {
        if let api = _referrals { return api }
        let api = ReferralsAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _referrals = api
        return api
    }

    /// System status (§2B.5).
    public func status() -> StatusAPI {
        if let api = _status { return api }
        let api = StatusAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _status = api
        return api
    }

    /// Account portability (§2B.6).
    public func account() -> AccountAPI {
        if let api = _account { return api }
        let api = AccountAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _account = api
        return api
    }

    /// Organization / B2B (§2B.7).
    public func organizationApi() -> OrganizationAPI {
        if let api = _organization { return api }
        let api = OrganizationAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _organization = api
        return api
    }

    /// Offer redemption (§2B.8).
    public func offers() -> OffersAPI {
        if let api = _offers { return api }
        let api = OffersAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _offers = api
        return api
    }

    /// Docs / KB search (§2B.2).
    public func docs() -> DocsAPI {
        if let api = _docs { return api }
        let api = DocsAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _docs = api
        return api
    }

    /// v2 / Vanaheim device enrollment / heartbeat / revoke (§2A.5). First-boot
    /// enrollment happens automatically during `connect()` via the
    /// `device_registered_v1` SecureCache marker; this accessor is for
    /// products that want to call `heartbeat` or `revoke(deviceId:)` on
    /// demand.
    public nonisolated var deviceApi: DevicesAPI { devices }

    /// v2 / Vanaheim L2 recipient-key client. Exposed mainly for diagnostics
    /// and for tests that want to force-refresh the cached key. Production
    /// code should not need to call this directly — the transport wraps
    /// `forceRefresh()` automatically on `PekStaleError`.
    public nonisolated var l2KeysClient: L2KeysClient { l2Keys }

    /// MFA + session management (§2A.8). TOTP enrollment + verify, recovery
    /// code rotation + verify, sessions list + revoke (single + all), step-up
    /// grant minting. Gated by `capabilities.mfa`.
    public func security() -> SecurityAPI {
        if let api = _security { return api }
        let api = SecurityAPI(http: http, endpoint: { [weak self] in
            await self?.currentRegionEndpoint() ?? URL(string: "https://invalid.invalid")!
        }, capabilities: capabilities_)
        _security = api
        return api
    }

    // MARK: - §2B.1 Telemetry + §2A.12 i18n format

    /// Records an analytics event (§2B.1). No-op when `capabilities.telemetry`
    /// is disabled. Returns immediately — never blocks the caller.
    public func track(_ eventName: String, props: [String: Any] = [:]) async {
        guard capabilities_.telemetry, let api = _telemetryAPI else { return }
        try? await api.track(eventName, props: props)
    }

    /// Records a metering counter (§2B.1).
    public func recordMetering(key: String, count: Int = 1, metadata: [String: Any] = [:]) async {
        guard capabilities_.telemetry, let api = _telemetryAPI else { return }
        try? await api.recordMetering(key: key, count: count, metadata: metadata)
    }

    /// Associates user traits.
    public func identify(traits: [String: Any]) async {
        guard capabilities_.telemetry, let api = _telemetryAPI else { return }
        try? await api.identify(traits: traits)
    }

    /// Forces an immediate telemetry flush. Throws on network failure;
    /// caller may retry.
    public func flushTelemetry() async throws {
        guard let api = _telemetryAPI else { return }
        try await api.flush()
    }

    /// Formats an i18n message by key (§2A.12).
    public nonisolated func format(_ key: String, vars: [String: Any] = [:]) -> String {
        formatter_.format(key, vars: vars)
    }

    /// Currently-loaded capability config (read-only).
    public nonisolated var capabilities: SdkCapabilities { capabilities_ }

    /// Internal: current regional endpoint. Sub-APIs capture this as a
    /// closure so any future region migration is picked up automatically.
    private func currentRegionEndpoint() -> URL {
        regionEndpoint
    }

    private nonisolated func readSnapshot() -> (ClaimsSnapshot?, Bool) {
        snapshotLock.lock()
        defer { snapshotLock.unlock() }
        return (_snapshot, _snapshotExpiredEmitted)
    }

    private nonisolated func isExpiredNonisolated(_ c: LicenseJwtClaims) -> Bool {
        graceForSync.evaluate(jwtExpiresAt: c.expiresAt).state == .expired
    }

    private nonisolated func entitlementsNonisolated(from c: LicenseJwtClaims) -> Entitlements {
        Entitlements(tier: c.tier, version: c.entitlementsVersion, values: c.entitlements)
    }

    /// One-shot emit of LicenseStateChangeKind.expired when a sync read
    /// observes a past-exp JWT. Uses the snapshotLock to atomically flip
    /// the flag so concurrent hasFeature/quota calls don't double-emit.
    private nonisolated func markExpiredOnce(_ c: LicenseJwtClaims) {
        snapshotLock.lock()
        if _snapshotExpiredEmitted {
            snapshotLock.unlock()
            return
        }
        _snapshotExpiredEmitted = true
        snapshotLock.unlock()
        // stateContinuation is nonisolated; yield is thread-safe.
        let ent = entitlementsNonisolated(from: c)
        stateContinuation.yield(LicenseStateChange(
            kind: .expired,
            entitlements: ent,
            kickedDevice: nil,
            error: LicenseExpiredError("Cached JWT past exp")))
    }

    /// Diagnostics bundle for support flows. SDK never auto-uploads.
    public func diagnostics(limit: Int? = nil) async -> [String: Any] {
        await telemetry.exportForDiagnostics(limit: limit)
    }

    // MARK: - v0.1.19 · reportCapability (Bifrost B-9.19 apps surface)

    /// Publishes a per-project boolean capability presence signal to
    /// Bifrost. See `CapabilityReportValidation` (in `Capabilities.swift`)
    /// for the shared wire regex + `ReportCapabilityWire` for the pinned
    /// wire constants used across Dart / Swift / TS parity fixtures.
    ///
    /// - Parameters:
    ///   - key: Boolean-flag identifier matching
    ///     `^has_[a-z0-9_]{2,64}$` (e.g. `"has_offline_export"`).
    ///     Client-side validation throws `CapabilityKeyInvalidError`
    ///     on mismatch; the server also fails closed with
    ///     `CAPABILITY_KEY_INVALID` for defence in depth.
    ///   - value: Boolean presence signal. v0.1.19 admits booleans
    ///     only (scalar expansion deferred).
    ///
    /// Idempotent by `(project_id, key)` — replay with the same value
    /// is a 200 no-op server-side.
    ///
    /// Retries on HTTP 429 with capped exponential backoff (100ms →
    /// 200ms → 400ms; max 3 total attempts). Other non-2xx statuses
    /// propagate as the underlying `NetworkError`.
    ///
    /// Wire: `POST /v1/apps/capabilities` with body
    /// `{"key":"<key>","value":<bool>}`. Auth flows through the
    /// existing per-project transport — the server edge is PAK-JWE
    /// authed (per-project scope from the PAK claim); the SDK's
    /// existing `SignedHttpClient` JWE envelope binds `project_id`
    /// into the AAD so the server-side cross-check passes.
    public func reportCapability(_ key: String, _ value: Bool) async throws {
        try checkAlive()
        // Client-side validation FIRST — fail fast, no wire round-trip
        // on a typo. Server also enforces (fail-closed) so a stale
        // SDK that skipped this check would still surface a typed
        // NetworkError. Uses the shared helper in `Capabilities.swift`
        // so Dart / Swift / TS regex stays byte-identical.
        try CapabilityReportValidation.requireValidKey(key)

        let url = regionEndpoint.appendingPathComponent(
            String(ReportCapabilityWire.routePath.drop(while: { $0 == "/" })))
        let body: [String: Any] = [
            ReportCapabilityWire.bodyKeyKey: key,
            ReportCapabilityWire.bodyKeyValue: value,
        ]

        // Retry-on-429 loop. Capped exponential backoff — matches the
        // Dart twin's `_reportCapabilityRetryBackoffMs` schedule
        // (100ms → 200ms → 400ms). We keep the ladder short because the
        // server-side bucket is 10 req/min per (project_id, PAK) — a
        // long client-side backoff would just move the pressure to the
        // next tick without changing the throughput ceiling.
        var attempt = 0
        var backoffMs: UInt64 = 100
        while true {
            do {
                _ = try await http.postJson(url: url, body: body)
                return
            } catch let e as NetworkError where e.statusCode == 429 {
                attempt += 1
                if attempt >= ReportCapabilityWire.maxAttempts { throw e }
                try? await Task.sleep(
                    nanoseconds: backoffMs * 1_000_000)
                backoffMs *= 2
                continue
            }
        }
    }

    public func clearDiagnostics() async {
        await telemetry.clear()
    }

    /// Releases timers, flushes telemetry, closes the stream.
    public func dispose() async {
        if disposed { return }
        disposed = true
        refreshTask?.cancel()
        refreshTask = nil
        pushTokenTask?.cancel()
        pushTokenTask = nil
        pushMessageTask?.cancel()
        pushMessageTask = nil
        if let tel = _telemetryAPI {
            await tel.dispose()
        }
        if let st = _status {
            await st.dispose()
        }
        await telemetry.flush()
        stateContinuation.finish()
    }

    // MARK: - Internals

    private func checkAlive() throws {
        if disposed { throw NotConnectedError() }
    }

    private func ensureLicense() async throws -> String {
        let url = regionEndpoint.appendingPathComponent("v1/licenses")
        let res = try await http.postJson(url: url, body: [
            "product_slug": productSlug,
            "intent": "trial_if_none",
        ])
        guard let id = res["id"] as? String else {
            throw NetworkError("Server returned no license id")
        }
        licenseId = id
        try? await cache.putLicenseId(id)
        return id
    }

    private func verifyCachedJwt(_ token: String) async throws -> LicenseJwtClaims {
        // §2A.5 JWE detection: if the token is a 5-segment JWE, hand it to
        // the configured decryptor first; the inner JWS is verified normally
        // below. Backend can roll out JWE per-product without an SDK update
        // — JWS-only deployments keep working with zero config.
        var jwt = token
        if detectTokenFormat(token) == .jwe {
            // v2 / Vanaheim: config.jweDecryptor is required (non-optional)
            // — every product wires one. The old "no decryptor configured"
            // branch is dead; we keep JweDecryptionRequiredError in the
            // taxonomy so a future opt-out path can throw it without an SDK
            // bump.
            jwt = try await config.jweDecryptor.decrypt(token)
        }
        let parts = jwt.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 3 else { throw JwtVerificationError("malformed JWT") }
        let (kid, expectedAud) = try peekHeaderAndAud(headerB64: String(parts[0]), claimsB64: String(parts[1]))

        var pub = try await jwks.getKey(kid)
        if pub == nil {
            try await jwks.refresh()
            pub = try await jwks.getKey(kid)
        }
        guard let publicKey = pub else {
            throw JwtVerificationError("Unknown kid: \(kid)")
        }
        return try JwtVerifier.verifyAndDecode(
            jwt: jwt,
            publicKey: publicKey,
            expectedIssuer: LicenseClient.issuer,
            expectedAudience: expectedAud,
            clockSkew: config.clockSkew)
    }

    private func peekHeaderAndAud(headerB64: String, claimsB64: String) throws -> (String, String) {
        guard let hd = JwtVerifier.base64UrlDecode(headerB64),
              let cd = JwtVerifier.base64UrlDecode(claimsB64) else {
            throw JwtVerificationError("invalid JWT base64 segments")
        }
        let header = try JwtVerifier.decodeJson(hd, kind: "header")
        let claims = try JwtVerifier.decodeJson(cd, kind: "claims")
        guard let kid = header["kid"] as? String, !kid.isEmpty else {
            throw JwtVerificationError("JWT header missing kid")
        }
        guard let aud = claims["aud"] as? String, !aud.isEmpty else {
            throw JwtVerificationError("JWT claims missing aud")
        }
        return (kid, aud)
    }

    private func entitlements(from c: LicenseJwtClaims) -> Entitlements {
        entitlementsNonisolated(from: c)
    }

    private nonisolated func emit(
        _ kind: LicenseStateChangeKind,
        claims: LicenseJwtClaims? = nil,
        kicked: KickedDevice? = nil,
        error: LicenseStoreError? = nil
    ) {
        let ent = claims.map(entitlementsNonisolated(from:))
        stateContinuation.yield(LicenseStateChange(
            kind: kind, entitlements: ent, kickedDevice: kicked, error: error))
    }

    private func scheduleRefresh(at expiresAt: Date) {
        refreshTask?.cancel()
        let when = expiresAt.addingTimeInterval(-config.refreshBefore)
        let delay = max(0, when.timeIntervalSinceNow)
        refreshTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            guard let self = self else { return }
            do {
                try await self.verify()
            } catch {
                await self.handleRefreshError(error)
            }
        }
    }

    private func handleRefreshError(_ error: Error) async {
        emit(.error, claims: claims, error: error as? LicenseStoreError)
        // Retry in 10 min — async closure means errors actually surface.
        refreshTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 600_000_000_000)
            guard let self = self else { return }
            try? await self.verify()
        }
    }

    private nonisolated func parseKickedDevice(_ raw: [String: Any]) -> KickedDevice? {
        guard let aid = raw["activation_id"] as? String,
              let lsStr = raw["last_seen_at"] as? String,
              let ls = ISO8601DateFormatter().date(from: lsStr) else {
            return nil
        }
        return KickedDevice(
            activationId: aid,
            deviceName: raw["device_name"] as? String,
            os: raw["os"] as? String,
            lastSeenAt: ls)
    }
}

// ─────────────────────────────────────────────────────────────────────
// Mode-discriminated factory (W5 / Agent B).
//
// Returned union type. Host products that want to switch transparently
// between L2 and FRON without per-mode branching consume the values
// via `if case .l2(let c)` / `if case .fron(let c)`. Each variant
// carries the same surface conceptually but the concrete types differ
// (LicenseClient — actor-isolated, L2-flavoured public API;
//  DirectClient — actor-isolated, FRON-flavoured public API). The
// shared subset (hasFeature / quota) is reachable on both without
// type erasure; we intentionally do NOT collapse the two clients
// behind a single protocol because their per-call shapes (activate
// returning ActivationResult vs ActivateResult, etc.) are
// deliberately distinct on the wire.
public enum VanaheimClient {
    case l2(LicenseClient)
    case fron(DirectClient)
}

extension LicenseClient {
    /// Mode-aware factory. Returns a `DirectClient` when
    /// `config.mode == .fron`; otherwise constructs the existing
    /// `LicenseClient` exactly as `connect(controlPlaneUrl:...)` does
    /// today.
    ///
    /// For the `.fron` branch, callers MUST supply `directConfig`
    /// (the FRON-specific knobs that don't live on `VanaheimConfig`
    /// itself). `controlPlaneUrl` / `sdkSecret` / `auth` / `appCheck`
    /// are ignored on the FRON path — FRON has no control-plane region
    /// resolution + uses inner-JWS Ed25519 auth instead of HMAC.
    ///
    /// This factory keeps the existing single-mode L2 callsites
    /// untouched: a product on L2 keeps calling
    /// `LicenseClient.connect(controlPlaneUrl:productSlug:sdkSecret:
    /// config:)` directly. Only products flipping to FRON need to use
    /// the factory.
    public static func connectAutoMode(
        controlPlaneUrl: URL,
        productSlug: String,
        sdkSecret: String,
        config: VanaheimConfig,
        directConfig: DirectConfig? = nil,
        capabilities: SdkCapabilities = .defaults,
        auth: AuthTokenProvider = UnconfiguredAuthTokenProvider(),
        appCheck: AppCheckTokenProvider = NoAppCheckProvider(),
        cache: SecureCache? = nil,
        fingerprint: DeviceFingerprintGenerator = DeviceFingerprintGenerator(),
        pushTokenProvider: PushTokenProvider = NoPushTokenProvider(),
        i18nCatalog: [String: String] = [:]
    ) async throws -> VanaheimClient {
        switch config.mode {
        case .l2:
            let c = try await LicenseClient.connect(
                controlPlaneUrl: controlPlaneUrl,
                productSlug: productSlug,
                sdkSecret: sdkSecret,
                config: config,
                capabilities: capabilities,
                auth: auth,
                appCheck: appCheck,
                cache: cache,
                fingerprint: fingerprint,
                pushTokenProvider: pushTokenProvider,
                i18nCatalog: i18nCatalog)
            return .l2(c)
        case .fron:
            guard let dc = directConfig else {
                throw LicenseStoreError(
                    "VanaheimConfig.mode == .fron but no DirectConfig was " +
                    "supplied. Pass `directConfig:` to connectAutoMode.")
            }
            let direct = try DirectClient(config: dc, secureCache: cache)
            try await direct.connect()
            return .fron(direct)
        }
    }
}
