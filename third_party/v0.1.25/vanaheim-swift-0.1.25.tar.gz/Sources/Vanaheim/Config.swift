// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Configuration knobs for `LicenseClient`. Sensible defaults; override only
/// when you have a concrete reason.
///
/// v2 / Vanaheim: renamed from `LicenseStoreConfig`. Adds `l2BaseUrl` +
/// `projectId` (required, no defaults — host product must wire these), and
/// flips `jweDecryptor` / `deviceKeypairProvider` from optional to required
/// since v2 routes are JWE-by-default with a hard-coded JWS-allowed list.
/// The v1 `bifrostBaseUrl` is gone — the SDK no longer talks to Bifrost
/// directly; device enrollment goes through L2 instead.
///
/// Mirror of `sdk/dart/license_store_sdk/lib/src/config.dart`.
public struct VanaheimConfig: Sendable {
    /// Project identifier — used as part of the JWE AAD
    /// (`<project_id>|<route_path>|<request_id>`) and the X-LS-Project-Id
    /// header on outgoing requests. Required.
    ///
    /// Was previously passed positionally to `LicenseClient.connect()` in v1;
    /// moved into the config so the AAD-construction helper inside
    /// `SignedHttpClient` can read it without an extra parameter hop.
    public let projectId: Int

    /// Base URL of the L2 (Alfheim) tier this product is bound to.
    /// All v2 JWE-required calls + device enrollment hit `{l2BaseUrl}/...`.
    /// Required — there is no default; the host product must provide one.
    ///
    /// Replaces v1's `bifrostBaseUrl` (deleted). The L2 tier owns recipient
    /// keys and device records now; Bifrost is no longer an SDK dependency.
    public let l2BaseUrl: URL

    /// JWE confidentiality wrapper (§2A.5). v2 makes this required because
    /// the JWE-required vs JWS-allowed route table is hard-coded and most
    /// data-plane calls are encrypted. Host products should pass
    /// `CryptoKitJweDecryptor(keypair)` (once available) or any
    /// implementation conforming to `JwePayloadDecryptor`.
    public let jweDecryptor: JwePayloadDecryptor

    /// Per-device X25519 keypair provider (§2A.5). v2 makes this required
    /// because every device must enroll a pubkey with L2 on first boot (see
    /// `DevicesAPI.register`). Host products should pass
    /// `KeychainDeviceKeypairProvider()` (once available) or any
    /// implementation conforming to `DeviceKeypairProvider` that persists the
    /// private key in platform-level secure storage.
    public let deviceKeypairProvider: DeviceKeypairProvider

    /// How close to JWT expiry the SDK proactively refreshes. Default 1 day.
    /// With the server's default 7-day exp, this means at-most-once-a-week
    /// network call from a logged-in active user.
    public let refreshBefore: TimeInterval

    /// Maximum offline grace. If the cached JWT's exp is past now + this,
    /// the SDK behaves as if there is no JWT (forces network). nil = trust
    /// the server-set exp (default).
    public let hardOfflineGrace: TimeInterval?

    /// Pinned SPKI SHA-256 hashes (base64) for the API server cert. Provide
    /// at least one (current); add the next pin before rotation. Empty list
    /// disables pinning — only safe in dev.
    public let pinnedSpkiSha256: [String]

    /// JWKS cache TTL when the server response carries no Cache-Control.
    /// Default 1 h.
    public let jwksCacheTtl: TimeInterval

    /// HTTP timeout per request. Default 15 s.
    public let httpTimeout: TimeInterval

    /// Allowed client/server clock skew. Default 5 min — matches the server's
    /// HMAC replay-window tolerance.
    public let clockSkew: TimeInterval

    /// Dev-only: accept a `dev:<uid>:<email>` Firebase ID-token stand-in
    /// when Firebase isn't configured. Never true in production builds.
    public let allowDevAuthBypass: Bool

    /// Transport mode discriminator. `l2` (default) uses the existing
    /// L2 (Alfheim) tier; `fron` bypasses L2 and talks directly to
    /// Bifrost via the FRON envelope. When set to `.fron`, the host
    /// product should construct `DirectClient` (instead of
    /// `LicenseClient`) at the top of its boot path — the existing
    /// `LicenseClient.connect(...)` path keeps behaving exactly as
    /// before regardless of this value (it never reads `mode`).
    ///
    /// See `Direct/DirectConfig.swift` for the FRON-mode-specific
    /// knobs; this field is here so a single VanaheimConfig instance
    /// can carry both halves on host products that want to flip modes
    /// at runtime.
    public let mode: VanaheimConfigMode

    public init(
        projectId: Int,
        l2BaseUrl: URL,
        jweDecryptor: JwePayloadDecryptor,
        deviceKeypairProvider: DeviceKeypairProvider,
        refreshBefore: TimeInterval = 24 * 60 * 60,
        hardOfflineGrace: TimeInterval? = nil,
        pinnedSpkiSha256: [String] = [],
        jwksCacheTtl: TimeInterval = 60 * 60,
        httpTimeout: TimeInterval = 15,
        clockSkew: TimeInterval = 5 * 60,
        allowDevAuthBypass: Bool = false,
        mode: VanaheimConfigMode = .l2
    ) {
        self.projectId = projectId
        self.l2BaseUrl = l2BaseUrl
        self.jweDecryptor = jweDecryptor
        self.deviceKeypairProvider = deviceKeypairProvider
        self.refreshBefore = refreshBefore
        self.hardOfflineGrace = hardOfflineGrace
        self.pinnedSpkiSha256 = pinnedSpkiSha256
        self.jwksCacheTtl = jwksCacheTtl
        self.httpTimeout = httpTimeout
        self.clockSkew = clockSkew
        self.allowDevAuthBypass = allowDevAuthBypass
        self.mode = mode
    }
}
