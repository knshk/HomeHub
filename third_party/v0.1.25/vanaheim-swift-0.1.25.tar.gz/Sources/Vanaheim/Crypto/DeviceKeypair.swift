// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit

#if canImport(Security)
import Security
#endif

/// Device X25519 keypair provider — generates once, persists the raw 32-byte
/// scalar to the system Keychain, exposes only the 32-byte public key + a
/// scoped accessor that hands the `Curve25519.KeyAgreement.PrivateKey` back
/// to `JweCodec.decryptCompact`.
///
/// v2 / Vanaheim collapsed the v1 plural-provider zoo into a single concrete
/// class. `NoDeviceKeypairProvider` (the no-op stub used in v1 tests +
/// products that didn't enable JWE) is gone — v2 makes the keypair required
/// because every device must enroll with L2 on first boot.
///
/// Storage tier selection:
///   * iOS / macOS  → Keychain, `kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly`.
///     Secure Enclave is preferred where available BUT the SE only stores
///     P256 (secp256r1) private keys — there is no SE backing for X25519
///     today (as of iOS 17 / macOS 14). We therefore always fall back to the
///     plain Keychain tier here. If a future CryptoKit ships
///     `SecureEnclave.Curve25519.KeyAgreement` we will swap to it without
///     a public API change (the protocol exposes only `getPublicKey()`).
///
/// Idempotency: `getPublicKey()` and `getPrivateKey()` may be called
/// concurrently — the provider guards generation with an actor-isolated
/// in-memory cache so only one keypair is ever written to the Keychain.

/// Keychain service identifier for the persisted X25519 scalar. Versioned so
/// a future algorithm rotation can ship without colliding with the v1 blob.
public let kDeviceX25519KeychainService = "io.licensestore.sdk.device.x25519"

/// Keychain account identifier for the v1 scalar slot.
public let kDeviceX25519KeychainAccount = "device_x25519_priv_v1"

/// Production `DeviceKeypairProvider` backed by CryptoKit X25519 + the
/// system Keychain. Pure Swift; no third-party deps.
public actor KeychainDeviceKeypairProvider: DeviceKeypairProvider {
    private let service: String
    private let account: String

    // In-memory cache: the loaded private key + its derived public bytes.
    // CryptoKit re-derives the public key from the raw scalar on every
    // `Curve25519.KeyAgreement.PrivateKey(rawRepresentation:)` call, so we
    // pin them once at load time.
    private var cachedPriv: Curve25519.KeyAgreement.PrivateKey?
    private var cachedPub: Data?

    public init(
        service: String = kDeviceX25519KeychainService,
        account: String = kDeviceX25519KeychainAccount
    ) {
        self.service = service
        self.account = account
    }

    /// Returns the 32-byte X25519 public key. Triggers a one-shot
    /// read-or-generate against the Keychain on first call.
    public func getPublicKey() async throws -> Data {
        try ensureLoaded()
        return cachedPub!
    }

    /// Returns the live `Curve25519.KeyAgreement.PrivateKey`. Required by
    /// `JweCodec.decryptCompact` so it can run `sharedSecretFromKeyAgreement`
    /// against the ephemeral peer key.
    ///
    /// Products should NEVER call this directly — it's the wire the
    /// `CryptoKitJweDecryptor` uses to bridge the keypair into the codec.
    public func getPrivateKey() async throws -> Curve25519.KeyAgreement.PrivateKey {
        try ensureLoaded()
        return cachedPriv!
    }

    private func ensureLoaded() throws {
        if cachedPriv != nil && cachedPub != nil { return }
        // Try to read an existing scalar from Keychain.
        if let priv = try loadFromKeychain() {
            cachedPriv = priv
            cachedPub = priv.publicKey.rawRepresentation
            return
        }
        // Generate fresh + persist.
        let priv = Curve25519.KeyAgreement.PrivateKey()
        try saveToKeychain(priv: priv)
        cachedPriv = priv
        cachedPub = priv.publicKey.rawRepresentation
    }

    // MARK: - Keychain I/O

    #if canImport(Security)

    private func loadFromKeychain() throws -> Curve25519.KeyAgreement.PrivateKey? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        if status == errSecItemNotFound {
            return nil
        }
        if status != errSecSuccess {
            throw KeychainError("SecItemCopyMatching failed (OSStatus \(status))")
        }
        guard let data = item as? Data else {
            return nil
        }
        // Some platforms return the data trimmed to 32 bytes; reject anything else.
        if data.count != 32 {
            // Corrupted blob — drop it and regenerate on the next call.
            _ = try? deleteFromKeychain()
            return nil
        }
        do {
            return try Curve25519.KeyAgreement.PrivateKey(rawRepresentation: data)
        } catch {
            // Bad scalar (extraordinarily rare for X25519 since any 32-byte
            // string is a valid scalar after CryptoKit clamps it, but be
            // defensive). Wipe + regenerate.
            _ = try? deleteFromKeychain()
            return nil
        }
    }

    private func saveToKeychain(priv: Curve25519.KeyAgreement.PrivateKey) throws {
        let raw = priv.rawRepresentation
        // Delete any stale entry first so we don't fight a duplicate.
        _ = try? deleteFromKeychain()
        let attrs: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
            kSecValueData as String: raw,
        ]
        let status = SecItemAdd(attrs as CFDictionary, nil)
        if status != errSecSuccess {
            throw KeychainError("SecItemAdd failed (OSStatus \(status))")
        }
    }

    private func deleteFromKeychain() throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
        let status = SecItemDelete(query as CFDictionary)
        if status != errSecSuccess && status != errSecItemNotFound {
            throw KeychainError("SecItemDelete failed (OSStatus \(status))")
        }
    }

    #else

    private func loadFromKeychain() throws -> Curve25519.KeyAgreement.PrivateKey? {
        throw KeychainError("Security framework unavailable on this platform")
    }
    private func saveToKeychain(priv: Curve25519.KeyAgreement.PrivateKey) throws {
        throw KeychainError("Security framework unavailable on this platform")
    }
    private func deleteFromKeychain() throws {}

    #endif
}

/// Thrown when the Keychain rejects a load/store/delete of the device scalar.
public final class KeychainError: LicenseStoreError {}
