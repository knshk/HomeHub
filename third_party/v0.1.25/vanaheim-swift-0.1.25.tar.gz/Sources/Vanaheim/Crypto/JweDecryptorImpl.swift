// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit

/// Concrete `JwePayloadDecryptor` used by v2 / Vanaheim. Thin adapter that
/// pulls the device X25519 private key out of a `KeychainDeviceKeypairProvider`
/// and hands it to `JweCodec.decryptCompact` with the strict alg/enc
/// allowlist enforced.
///
/// There is exactly one production decryptor in v2. v1 shipped a no-op stub
/// plus an interface for products to plug their own; v2 ships the concrete
/// impl and makes it required via `LicenseStoreConfig.jweDecryptor`.
/// Products that don't want JWE pick a JWS-allowed route from
/// `RoutePolicy.swift` and never see this class.
///
/// The allowlist is hard-coded to `ECDH-ES` / `A256GCM` and enforced
/// BEFORE any crypto runs. Anything else — including a downgrade to v1's
/// `ECDH-ES+A256KW` — surfaces as `JweDecryptionFailedError` without
/// exposing oracle behaviour.
public struct CryptoKitJweDecryptor: JwePayloadDecryptor {
    private let keypair: KeychainDeviceKeypairProvider
    private let codec: JweCodec
    private let allowlist: AlgAllowlist

    public init(
        keypair: KeychainDeviceKeypairProvider,
        codec: JweCodec = JweCodec(),
        allowlist: AlgAllowlist = .default
    ) {
        self.keypair = keypair
        self.codec = codec
        self.allowlist = allowlist
    }

    public func decrypt(_ jwe: String) async throws -> String {
        let priv = try await keypair.getPrivateKey()
        let result = try codec.decryptCompact(
            jwe: jwe,
            devicePriv: priv,
            expectedAlgs: allowlist
        )
        // The plaintext is the inner JWS (UTF-8 ASCII string per RFC 7519).
        // `JwtVerifier` re-parses it; we don't validate the signature here.
        guard let inner = String(data: result.plaintext, encoding: .utf8) else {
            throw JweDecryptionFailedError("inner JWS plaintext is not valid UTF-8")
        }
        return inner
    }
}
