// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit

/// Token format detected from the wire.
///
/// JWS is the day-1 shape (3 segments, signed-but-readable). JWE is the
/// Phase 5 / 2A.5 confidentiality shape (5 segments) — backend can flip to
/// it per-product without an SDK bump as long as the consuming product has
/// wired up a `JwePayloadDecryptor` and `DeviceKeypairProvider`.
public enum LicenseTokenFormat: Sendable {
    /// `header.claims.signature` — Ed25519 signed JWS. Default today.
    case jws

    /// `header.encrypted_key.iv.ciphertext.tag` — JWE wrapping inner JWS.
    /// SDK decrypts the wrapper, then verifies the inner JWS normally.
    case jwe
}

/// Inspects a compact JWT and returns its format. Does NOT verify anything
/// — purely structural.
public func detectTokenFormat(_ token: String) -> LicenseTokenFormat {
    let dotCount = token.reduce(0) { $1 == "." ? $0 + 1 : $0 }
    return dotCount == 4 ? .jwe : .jws
}

/// Pluggable decryptor invoked when the SDK receives a JWE-wrapped token.
/// Returns the inner JWS to be verified by the normal JwtVerifier.
///
/// Day-1 contract: the SDK does NOT ship a default implementation. Products
/// that need JWE wire up a concrete decryptor (e.g. backed by CryptoKit's
/// `Curve25519.KeyAgreement` + `AES.GCM`) and pass it via
/// `LicenseStoreConfig.jweDecryptor`. Backend may stay on JWS indefinitely
/// for products that don't need it.
public protocol JwePayloadDecryptor: Sendable {
    /// Given a JWE compact-serialization string, decrypts and returns the
    /// inner JWS string. Implementations MUST:
    ///   * verify JWE header `enc` and `alg` are in an allowlist
    ///     (default policy: `ECDH-ES+A256GCM` only)
    ///   * use the device private key from a `DeviceKeypairProvider`
    ///   * throw `JweDecryptionFailedError` on failure
    func decrypt(_ jwe: String) async throws -> String
}

/// Generates / accesses a per-device X25519 keypair used as the JWE recipient
/// key. v2 / Vanaheim makes this REQUIRED — every device must enroll an
/// X25519 pubkey with L2 on first boot, and JWE responses can only be
/// decrypted by handing the private key into `JweCodec.decryptCompact`.
///
/// Implementations should:
///   * generate the keypair once and persist the PRIVATE key in Keychain
///     with `kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly` and (where
///     available) Secure Enclave protection on iOS / macOS
///   * expose only the raw 32-byte PUBLIC key via `getPublicKey()`
///   * surface the `Curve25519.KeyAgreement.PrivateKey` via `getPrivateKey()`
///     so the transport can decrypt JWE responses
///   * be idempotent — concurrent calls share the same keypair
///
/// Revocation contract: `getPrivateKey()` MAY throw (or eventually return a
/// sentinel from a future async-throwing accessor) when the host product has
/// rotated/cleared the device key after the server flagged the device as
/// revoked. Throwing surfaces to the transport which then raises a typed
/// `DeviceRevokedError` so the host product can prompt re-enrollment. The
/// SDK never silently downgrades to plaintext if a private key is missing.
public protocol DeviceKeypairProvider: Sendable {
    /// Returns the X25519 public key as 32 raw bytes. The SDK includes this
    /// in the L2 enrollment payload as base64url-encoded `device_pubkey` and
    /// uses its SHA-256 thumbprint as the JWE `apu` header.
    func getPublicKey() async throws -> Data

    /// Returns the live `Curve25519.KeyAgreement.PrivateKey` used by
    /// `JweCodec.decryptCompact` to derive the CEK from the ephemeral peer
    /// key. Implementations MUST NOT expose the raw scalar — only the
    /// CryptoKit type itself, which keeps the bytes inside the framework's
    /// secure region.
    func getPrivateKey() async throws -> Curve25519.KeyAgreement.PrivateKey
}

// v2 / Vanaheim: `NoDeviceKeypairProvider` (a no-op stub from v1 used as a
// "no JWE wanted" sentinel) is deleted. The JWE-required vs JWS-allowed
// route table is hard-coded now (see RoutePolicy.swift) and JWE-required is
// the default — every device MUST enroll an X25519 pubkey with L2 on first
// boot. Products use `KeychainDeviceKeypairProvider` from
// `DeviceKeypair.swift`. The protocol above stays so tests and alternate
// secure backings can substitute their own impl.

/// Thrown when the SDK receives a JWE-wrapped token but no
/// `JwePayloadDecryptor` is configured.
public final class JweDecryptionRequiredError: LicenseStoreError {
    public override init(_ message: String = "Server returned a JWE-wrapped token but no JwePayloadDecryptor is configured. Set LicenseStoreConfig.jweDecryptor or have your backend disable JWE for this product.", cause: Error? = nil) {
        super.init(message, cause: cause)
    }
}

/// Thrown when decryption fails (wrong key, wrong alg, malformed JWE, etc.).
public final class JweDecryptionFailedError: LicenseStoreError {}

extension Data {
    /// Base64URL (no padding) — used to encode the X25519 public key in the
    /// activate payload, matching JWE / JWS section 5 encoding rules.
    public func base64URLEncodedString() -> String {
        base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
}
