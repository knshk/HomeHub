// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit

/// Computes the stable device-pubkey thumbprint used as JWE `apu`
/// (PartyUInfo) per the v2 envelope spec — SHA-256 of the raw 32-byte
/// X25519 pubkey, base64url-encoded with no padding.
///
/// Lives at the module-level so both the transport (which needs it inside
/// `JweAadContext.senderId` on every outbound JWE) and `DevicesAPI` (which
/// could surface it for diagnostics / heartbeat) can call into a single
/// implementation. Mirrors Dart's `devicePubThumbprint()` in
/// `sdk/dart/license_store_sdk/lib/src/crypto/thumbprint.dart` — both SDKs
/// MUST produce byte-for-byte identical output for the same X25519 pubkey
/// so the AAD bound into the JWE matches what the server cross-checks.
///
/// Pure CryptoKit; no third-party deps. The X25519 keypair provider is
/// already an async surface so this helper inherits the same shape.
public func deviceX25519PubThumbprint(
    _ provider: DeviceKeypairProvider
) async throws -> String {
    let pub = try await provider.getPublicKey()
    return deviceX25519PubThumbprint(pubKey: pub)
}

/// Synchronous overload that operates directly on the raw 32-byte X25519
/// pubkey. Useful in unit tests + regression fixtures where the caller
/// already has the bytes in hand (e.g. cross-SDK lock-in vectors).
///
/// Implementation detail: delegates to `pubKeyThumbprint(_:)` so the math
/// lives in exactly one place and the Curve25519-ECDH-flavoured name doesn't
/// imply the math itself is X25519-specific (it isn't — it's
/// `b64url(sha256(rawBytes))` for any 32-byte input).
public func deviceX25519PubThumbprint(pubKey: Data) -> String {
    return pubKeyThumbprint(pubKey)
}

/// Curve-agnostic thumbprint helper: `b64url(sha256(rawPubBytes))`.
///
/// The spec defines the device-pub thumbprint as the SHA-256 of the RAW
/// public-key bytes, base64url-encoded without padding — regardless of
/// which Curve25519 family the caller is hashing. Callers may pass:
///   * an X25519 ECDH pubkey (32 bytes) — used for JWE `apu`
///   * an Ed25519 signing pubkey (32 bytes) — used for JWS `kid`
/// or in principle any opaque byte buffer. The math is identical.
///
/// `deviceX25519PubThumbprint(pubKey:)` is the legacy entry point retained
/// for source compatibility on the JWE path; new call sites (e.g. the
/// Ed25519 `sigKid` derivation in `DeviceJwsSignerImpl.swift`) should call
/// this Curve-neutral helper directly. Both names route through the SAME
/// SHA-256 + base64url-no-pad pipeline — `ThumbprintTests.swift` pins this
/// equivalence so a future refactor can't silently fork the two paths.
public func pubKeyThumbprint(_ pubBytes: Data) -> String {
    let digest = SHA256.hash(data: pubBytes)
    return Data(digest).base64URLEncodedString()
}
