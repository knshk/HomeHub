// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit
import os

#if canImport(Security)
import Security
#endif

/// Keychain service identifier for the persisted Ed25519 signing scalar.
/// Separate from the X25519 ECDH scalar (`kDeviceX25519KeychainService`)
/// because JWS-sign and JWE-recipient keys are distinct — rotating one
/// without the other is allowed.
public let kDeviceEd25519KeychainService = "io.licensestore.sdk.device.ed25519"

/// Keychain account identifier for the v1 Ed25519 scalar slot.
public let kDeviceEd25519KeychainAccount = "device_ed25519_priv_v1"

/// Production `DeviceJwsSigner` backed by an Ed25519 signing key persisted in
/// the system Keychain, plus a `SecureCache`-backed lookup for the
/// L2-assigned `device_id` (written by `LicenseClient.maybeEnrollDevice()`
/// under the `device_id_v1` key).
///
/// Why a separate signer (not bolted onto `KeychainDeviceKeypairProvider`):
///   * The X25519 keypair is used for ECDH/JWE recipient material; the
///     Ed25519 keypair is used for inner-JWS signing. CryptoKit models
///     these as distinct families (`Curve25519.KeyAgreement` vs
///     `Curve25519.Signing`) and the protocols separate cleanly.
///   * Tests can inject a deterministic `DeviceJwsSigner` double without
///     touching the keypair provider.
///
/// `sigKid` derivation: SHA-256 of the raw 32-byte Ed25519 public key,
/// base64url-encoded (no padding). Symmetric with the X25519 pub
/// thumbprint helper in `Thumbprint.swift` so L3 can resolve the kid
/// directly from the device registry without an extra round trip.
///
/// `deviceId` derivation: read from `SecureCache.getRaw("device_id_v1")`
/// at construction (and on every `signClaims` call so a freshly-enrolled
/// device picks up its id without a SignedHttpClient rebuild). Empty
/// string until enrollment lands — matches the protocol contract.
public actor KeychainDeviceJwsSigner: DeviceJwsSigner {
    private let service: String
    private let account: String
    private let cache: SecureCache

    private var cachedPriv: Curve25519.Signing.PrivateKey?
    private var cachedPub: Data?
    private var cachedSigKid: String?
    // Polled fresh on each signClaims so post-enrollment IDs propagate.
    private var cachedDeviceId: String = ""

    /// Shared lock-backed storage for the nonisolated snapshot getters.
    /// Allocated once at init and retained for the actor's lifetime so the
    /// lock identity is stable across reads + writes.
    ///
    /// ISSUE 3 fix (Wave 10d residual): the previous implementation used
    /// `nonisolated(unsafe) private var deviceIdSnapshot/sigKidSnapshot`,
    /// which formally allows a data race — actor-isolated writes inside
    /// `ensureLoaded()` / `refreshDeviceIdFromCache()` could be torn against
    /// concurrent nonisolated reads from the transport's
    /// `X-LS-Device-Id` / JWS `kid` header builders. Swift Concurrency 6's
    /// strict-checking mode flags this. Switching to an `os_unfair_lock`-
    /// guarded `SnapshotBox` makes both sides explicit-locked, which is
    /// safe regardless of concurrency mode and adds no measurable overhead
    /// (an uncontended unfair-lock acquire is a single atomic op).
    private let snapshot = SnapshotBox()

    public init(
        cache: SecureCache,
        service: String = kDeviceEd25519KeychainService,
        account: String = kDeviceEd25519KeychainAccount
    ) {
        self.cache = cache
        self.service = service
        self.account = account
    }

    // MARK: - DeviceJwsSigner

    /// Snapshot of the L2-assigned device id. Empty when the device has not
    /// yet enrolled (first-boot pre-`maybeEnrollDevice`).
    ///
    /// The actor-isolated `signClaims` path refreshes both snapshots on
    /// every call (see `refreshDeviceIdFromCache()` / `ensureLoaded()`),
    /// so a nonisolated read returns the LAST committed value. Reads + writes
    /// are serialised through `snapshot`'s `os_unfair_lock`, so there is no
    /// torn-read window — the worst case is staleness of one sign cycle,
    /// which is fine: the transport calls `signClaims` first and only then
    /// reads `deviceId`/`sigKid` to populate `X-LS-Device-Id` / JWS `kid`.
    nonisolated public var deviceId: String {
        snapshot.deviceId
    }

    nonisolated public var sigKid: String {
        snapshot.sigKid
    }

    public func signClaims(_ claims: [String: Any]) async throws -> String {
        try ensureLoaded()
        try await refreshDeviceIdFromCache()
        guard let priv = cachedPriv else {
            throw LicenseStoreError("device Ed25519 key not loaded")
        }
        // Header: alg=EdDSA, kid=<sigKid>, typ=device+jws.
        let header: [String: Any] = [
            "alg": "EdDSA",
            "kid": cachedSigKid ?? "",
            "typ": "device+jws",
        ]
        let headerJson = try JSONSerialization.data(
            withJSONObject: header, options: [.sortedKeys])
        let headerB64 = headerJson.base64URLEncodedString()

        let claimsJson = try JSONSerialization.data(
            withJSONObject: claims, options: [.sortedKeys])
        let claimsB64 = claimsJson.base64URLEncodedString()

        let signingInput = "\(headerB64).\(claimsB64)"
        guard let signingBytes = signingInput.data(using: .ascii) else {
            throw LicenseStoreError("signing input not ASCII-encodable")
        }
        let signature = try priv.signature(for: signingBytes)
        return "\(signingInput).\(signature.base64URLEncodedString())"
    }

    // MARK: - Load + persist

    private func ensureLoaded() throws {
        if cachedPriv != nil && cachedPub != nil && cachedSigKid != nil {
            return
        }
        if let priv = try loadFromKeychain() {
            cachedPriv = priv
            cachedPub = priv.publicKey.rawRepresentation
            // ISSUE 2 fix (Wave 10d residual): use the Curve-neutral helper
            // `pubKeyThumbprint(_:)` for an Ed25519 signing pubkey rather
            // than the X25519-named overload. The math is identical
            // (b64url(sha256(rawPubBytes))) but the name now matches the
            // input curve so future readers don't get misled.
            cachedSigKid = pubKeyThumbprint(priv.publicKey.rawRepresentation)
            snapshot.setSigKid(cachedSigKid ?? "")
            return
        }
        let priv = Curve25519.Signing.PrivateKey()
        try saveToKeychain(priv: priv)
        cachedPriv = priv
        cachedPub = priv.publicKey.rawRepresentation
        cachedSigKid = pubKeyThumbprint(priv.publicKey.rawRepresentation)
        snapshot.setSigKid(cachedSigKid ?? "")
    }

    private func refreshDeviceIdFromCache() async throws {
        let raw = (try? await cache.getRaw("device_id_v1")) ?? ""
        cachedDeviceId = raw ?? ""
        snapshot.setDeviceId(cachedDeviceId)
    }

    // MARK: - Keychain I/O

    #if canImport(Security)

    private func loadFromKeychain() throws -> Curve25519.Signing.PrivateKey? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        if status == errSecItemNotFound { return nil }
        if status != errSecSuccess {
            throw KeychainError("SecItemCopyMatching failed (OSStatus \(status))")
        }
        guard let data = item as? Data, data.count == 32 else { return nil }
        do {
            return try Curve25519.Signing.PrivateKey(rawRepresentation: data)
        } catch {
            _ = try? deleteFromKeychain()
            return nil
        }
    }

    private func saveToKeychain(priv: Curve25519.Signing.PrivateKey) throws {
        let raw = priv.rawRepresentation
        _ = try? deleteFromKeychain()
        let attrs: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
            kSecValueData as String: raw,
        ]
        let status = SecItemAdd(attrs as CFDictionary, nil)
        if status != errSecSuccess {
            throw KeychainError("SecItemAdd failed (OSStatus \(status))")
        }
    }

    private func deleteFromKeychain() throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
        let status = SecItemDelete(query as CFDictionary)
        if status != errSecSuccess && status != errSecItemNotFound {
            throw KeychainError("SecItemDelete failed (OSStatus \(status))")
        }
    }

    #else

    private func loadFromKeychain() throws -> Curve25519.Signing.PrivateKey? {
        throw KeychainError("Security framework unavailable on this platform")
    }
    private func saveToKeychain(priv: Curve25519.Signing.PrivateKey) throws {
        throw KeychainError("Security framework unavailable on this platform")
    }
    private func deleteFromKeychain() throws {}

    #endif
}

/// Adapter that exposes a `VanaheimConfig.projectId` Int as the transport's
/// `ProjectIdProvider`. Held as a value type so wiring is cheap and
/// `Sendable` falls out for free.
public struct StaticProjectIdProvider: ProjectIdProvider, Sendable {
    public let projectId: Int
    public init(projectId: Int) {
        self.projectId = projectId
    }
}

/// Thread-safe snapshot of the last-committed `deviceId` + `sigKid` strings.
///
/// Wraps an `os_unfair_lock` so the actor-isolated load/refresh path and the
/// nonisolated protocol getters (`KeychainDeviceJwsSigner.deviceId` /
/// `.sigKid`) can read + write without a data race. This is the ISSUE 3 fix
/// from the Wave 10d review: the previous implementation used
/// `nonisolated(unsafe) var`, which the Swift 6 concurrency checker flags as
/// a torn-read hazard.
///
/// Why a class (not a struct): we need a stable lock identity that's pinned
/// to a single heap address — `os_unfair_lock_t` is a pointer to mutable
/// memory and copying it via value semantics would split the lock.
///
/// Why `os_unfair_lock` (not `NSLock` or `DispatchQueue`):
///   * Lower overhead — uncontended acquire is a single atomic CAS.
///   * Apple-platform-native; no thread-priority-inversion issues vs. spin
///     locks (the kernel donates priority to the holder).
///   * Matches existing usage patterns in CryptoKit's own internals.
///
/// `@unchecked Sendable`: the only mutable state (`_deviceId`, `_sigKid`)
/// is guarded by `_lock`; both getters + setters lock before touching the
/// underlying strings, so the unchecked claim is sound.
final class SnapshotBox: @unchecked Sendable {
    private var _lock = os_unfair_lock_s()
    private var _deviceId: String = ""
    private var _sigKid: String = ""

    var deviceId: String {
        os_unfair_lock_lock(&_lock)
        defer { os_unfair_lock_unlock(&_lock) }
        return _deviceId
    }

    var sigKid: String {
        os_unfair_lock_lock(&_lock)
        defer { os_unfair_lock_unlock(&_lock) }
        return _sigKid
    }

    func setDeviceId(_ value: String) {
        os_unfair_lock_lock(&_lock)
        defer { os_unfair_lock_unlock(&_lock) }
        _deviceId = value
    }

    func setSigKid(_ value: String) {
        os_unfair_lock_lock(&_lock)
        defer { os_unfair_lock_unlock(&_lock) }
        _sigKid = value
    }
}
