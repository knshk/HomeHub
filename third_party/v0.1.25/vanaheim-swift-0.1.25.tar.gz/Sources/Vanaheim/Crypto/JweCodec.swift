// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation
import CryptoKit

/// Single-recipient compact JWE codec (RFC 7516 §5 + RFC 7518 §4.6).
///
/// v2 / Vanaheim — there is exactly **one** code path:
///
///   * alg = `ECDH-ES`      (direct ECDH-ES; no AES key wrap)
///   * enc = `A256GCM`      (256-bit AES-GCM with 12-byte IV / 16-byte tag)
///   * curve = X25519       (Curve25519, 32 raw bytes per key)
///   * kdf  = ConcatKDF     (NIST SP 800-56A §5.8.1) — derives the CEK
///                          directly from the X25519 shared secret. No A256KW.
///
/// The two-recipient General-JSON encoder that lived in v1 (`encryptForRecipients`)
/// is gone. There is no shared CEK across recipients. There is no AES key wrap.
/// There is no fallback to JWS. Callers that need plaintext must pick a
/// JWS-allowed route from `RouteConfidentiality` / `RoutePolicy.swift`.
///
/// This file owns only the crypto primitives: header construction, ConcatKDF,
/// X25519 shared-secret derivation, AES-GCM encrypt/decrypt, compact
/// serialization. AAD construction (`<project_id>|<route_path>|<request_id>`)
/// is delegated to `JweAadContext` which produces both the header fields and
/// the AAD bytes per RFC 7516 §5.1 — i.e. ASCII(b64url(protected_header)).
///
/// Pure CryptoKit — no third-party crypto deps. Mirrors the Dart twin in
/// `sdk/dart/license_store_sdk/lib/src/crypto/jwe_codec.dart`.

// MARK: - AAD context

/// Inputs that go into the JWE protected header AND into the AAD chain.
///
/// Per RFC 7516 §5.1, `aad = ASCII(b64url(protected_header))`. So as long as
/// the custom claims (`project_id`, `route_path`, `request_id`, `apu`, `apv`)
/// are inside the protected header, they're cryptographically bound to the
/// ciphertext for free — the AAD is just the b64url-encoded header bytes.
public struct JweAadContext: Sendable {
    /// Stable identifier for the sender — for L1→L2 this is the device pubkey
    /// thumbprint (SHA-256 of the raw 32-byte X25519 pub, b64url-encoded). Goes
    /// into the JWE `apu` header (RFC 7518 §4.6.1.2).
    public let senderId: String

    /// Stable identifier for the recipient — for L1→L2 this is the L2 enc-key
    /// kid (from `/.well-known/lcs-keys`). Goes into `apv` (§4.6.1.3).
    public let recipientId: String

    /// Tenant / product project identifier. Mirrors `X-LS-Project-Id` header.
    public let projectId: Int

    /// Logical HTTP route (e.g. `/v1/account/me`). Mirrors the request line.
    public let routePath: String

    /// UUIDv7 the client emitted in `X-LS-Request-Id`. Single-use; required.
    public let requestId: String

    public init(
        senderId: String,
        recipientId: String,
        projectId: Int,
        routePath: String,
        requestId: String
    ) {
        self.senderId = senderId
        self.recipientId = recipientId
        self.projectId = projectId
        self.routePath = routePath
        self.requestId = requestId
    }
}

// MARK: - Allowlist

/// Allowlist enforced before any crypto runs.
///
/// v2 is strict: `alg` must be `ECDH-ES`, `enc` must be `A256GCM`. Anything
/// else — including `ECDH-ES+A256KW` from v1, or `RSA-OAEP` from a malicious
/// downgrade — surfaces as `JweDecryptionFailedError` BEFORE the codec
/// touches the ciphertext.
public struct AlgAllowlist: Sendable {
    public let algs: Set<String>
    public let encs: Set<String>

    public init(algs: Set<String> = ["ECDH-ES"], encs: Set<String> = ["A256GCM"]) {
        self.algs = algs
        self.encs = encs
    }

    public static let `default` = AlgAllowlist()
}

// MARK: - Decoded header

/// Decoded JWE protected header surfaced to callers of `decryptCompact` so
/// they can cross-check `apu` / `apv` / `project_id` / `request_id` against
/// their own expectations.
///
/// Not `Sendable` — the `raw` dictionary holds `Any` from `JSONSerialization`,
/// which would defeat strict concurrency. Callers should consume the typed
/// fields they need on the actor that ran `decryptCompact`.
public struct JweProtectedHeader {
    public let alg: String
    public let enc: String
    public let kid: String?
    public let apu: String?
    public let apv: String?
    public let projectId: Int?
    public let routePath: String?
    public let requestId: String?
    public let typ: String?
    public let lcsVersion: Int?
    /// The raw decoded JSON object — for fields the typed accessors above
    /// don't surface.
    public let raw: [String: Any]
}

// MARK: - Codec

/// Stateless codec. There is no init step, no key cache — every call
/// generates a fresh ephemeral X25519 keypair. Recipients never see `epk`
/// for more than the lifetime of one HTTP request.
public struct JweCodec: Sendable {
    // Curve / alg constants. Tied to the v2 envelope shape; if any of these
    // change the recipients' service-side allowlist must change in lockstep.
    private static let kCurve = "X25519"
    private static let kKty = "OKP"
    private static let kAlg = "ECDH-ES"
    private static let kEnc = "A256GCM"
    private static let kTyp = "lcs+jwe"
    private static let kLcsVersion = 2

    public init() {}

    /// Encrypts `innerJwsBytes` (the device-signed inner JWS, as raw UTF-8
    /// bytes — typically `header.claims.signature` ASCII) for a single
    /// recipient, returning a 5-segment compact JWE string.
    ///
    /// `recipientPub` must be a Curve25519.KeyAgreement.PublicKey. `recipientKid`
    /// is the L2 enc-key kid from `/.well-known/lcs-keys`. `aad` supplies the
    /// custom header claims (`project_id` / `route_path` / `request_id`)
    /// plus `apu`/`apv` — all bound to the ciphertext automatically via the
    /// b64url-encoded header AAD per RFC 7516 §5.1.
    ///
    /// Throws `JweDecryptionFailedError` (reused as the codec's only
    /// runtime exception) if the underlying CryptoKit stack rejects the inputs.
    public func encryptForRecipient(
        innerJwsBytes: Data,
        recipientPub: Curve25519.KeyAgreement.PublicKey,
        recipientKid: String,
        aad: JweAadContext
    ) throws -> String {
        // 1. Fresh ephemeral X25519 keypair — NEVER cached, NEVER reused.
        let epk = Curve25519.KeyAgreement.PrivateKey()
        let epkPubBytes = epk.publicKey.rawRepresentation

        // 2. Build the protected header. Order matters only insofar as the
        // recipient must decode it as JSON — we don't pin canonical key
        // order because the AAD is the b64url of whatever bytes we emit
        // here, and the recipient re-uses those bytes verbatim.
        let headerMap: [String: Any] = [
            "alg": Self.kAlg,
            "enc": Self.kEnc,
            "kid": recipientKid,
            "epk": [
                "kty": Self.kKty,
                "crv": Self.kCurve,
                "x": epkPubBytes.base64URLEncodedString(),
            ],
            "apu": aad.senderId,
            "apv": aad.recipientId,
            "project_id": aad.projectId,
            "route_path": aad.routePath,
            "request_id": aad.requestId,
            "typ": Self.kTyp,
            "lcs_v": Self.kLcsVersion,
        ]
        let headerJsonBytes: Data
        do {
            headerJsonBytes = try JSONSerialization.data(withJSONObject: headerMap, options: [.sortedKeys])
        } catch {
            throw JweDecryptionFailedError("failed to serialize JWE protected header: \(error)", cause: error)
        }
        let protectedB64 = headerJsonBytes.base64URLEncodedString()

        // 3. Derive the CEK via direct ECDH-ES → ConcatKDF (RFC 7518 §4.6).
        let cekBytes = try Self.deriveCek(
            myPriv: epk,
            peerPub: recipientPub,
            apu: aad.senderId,
            apv: aad.recipientId
        )

        // 4. AES-GCM encrypt. AAD = ASCII bytes of the b64url-encoded header.
        let cek = SymmetricKey(data: cekBytes)
        guard let aadBytes = protectedB64.data(using: .ascii) else {
            throw JweDecryptionFailedError("protected header b64url is not ASCII")
        }
        let sealed: AES.GCM.SealedBox
        do {
            sealed = try AES.GCM.seal(innerJwsBytes, using: cek, authenticating: aadBytes)
        } catch {
            throw JweDecryptionFailedError("AES-GCM seal failed: \(error)", cause: error)
        }

        guard let nonceBytes = sealed.nonce.withUnsafeBytes({ Data($0) }) as Data? else {
            throw JweDecryptionFailedError("could not extract AES-GCM nonce")
        }

        // 5. Compact serialization: 5 segments.
        //    The "encrypted_key" segment is the empty string for ECDH-ES direct.
        let parts = [
            protectedB64,
            "", // encrypted_key — empty per RFC 7518 §4.6 for direct ECDH-ES.
            nonceBytes.base64URLEncodedString(),
            sealed.ciphertext.base64URLEncodedString(),
            sealed.tag.base64URLEncodedString(),
        ]
        return parts.joined(separator: ".")
    }

    /// Decrypts a compact JWE string with the device's X25519 private key.
    ///
    /// `devicePriv` is the device-side `Curve25519.KeyAgreement.PrivateKey`,
    /// typically owned by `KeychainDeviceKeypairProvider`. The codec uses it
    /// directly with `sharedSecretFromKeyAgreement`.
    ///
    /// `expectedAlgs` enforces alg/enc BEFORE any crypto runs. Throws
    /// `JweDecryptionFailedError` on anything off-allowlist, malformed
    /// segments, or MAC mismatch.
    public func decryptCompact(
        jwe: String,
        devicePriv: Curve25519.KeyAgreement.PrivateKey,
        expectedAlgs: AlgAllowlist = .default
    ) throws -> (plaintext: Data, header: JweProtectedHeader) {
        let parts = jwe.split(separator: ".", omittingEmptySubsequences: false).map(String.init)
        if parts.count != 5 {
            throw JweDecryptionFailedError("malformed JWE: expected 5 segments, got \(parts.count)")
        }

        guard let headerBytes = Data(base64URLEncoded: parts[0]) else {
            throw JweDecryptionFailedError("invalid base64url in protected header")
        }
        let encryptedKey = parts[1] // must be empty for ECDH-ES direct
        guard let iv = Data(base64URLEncoded: parts[2]) else {
            throw JweDecryptionFailedError("invalid base64url in iv")
        }
        guard let ciphertext = Data(base64URLEncoded: parts[3]) else {
            throw JweDecryptionFailedError("invalid base64url in ciphertext")
        }
        guard let tag = Data(base64URLEncoded: parts[4]) else {
            throw JweDecryptionFailedError("invalid base64url in tag")
        }

        let headerObj: Any
        do {
            headerObj = try JSONSerialization.jsonObject(with: headerBytes, options: [])
        } catch {
            throw JweDecryptionFailedError("invalid JWE header JSON: \(error)", cause: error)
        }
        guard let header = headerObj as? [String: Any] else {
            throw JweDecryptionFailedError("JWE header is not a JSON object")
        }

        // Allowlist FIRST. Cheap rejection before we touch the asymmetric path.
        guard let alg = header["alg"] as? String, expectedAlgs.algs.contains(alg) else {
            throw JweDecryptionFailedError("disallowed alg: \(header["alg"] ?? "nil")")
        }
        guard let enc = header["enc"] as? String, expectedAlgs.encs.contains(enc) else {
            throw JweDecryptionFailedError("disallowed enc: \(header["enc"] ?? "nil")")
        }
        if !encryptedKey.isEmpty {
            // ECDH-ES direct: encrypted_key MUST be empty (RFC 7518 §4.6).
            throw JweDecryptionFailedError("encrypted_key must be empty for ECDH-ES direct")
        }

        // Extract epk → Curve25519.KeyAgreement.PublicKey.
        guard let epkMap = header["epk"] as? [String: Any],
              (epkMap["kty"] as? String) == Self.kKty,
              (epkMap["crv"] as? String) == Self.kCurve,
              let epkX = epkMap["x"] as? String else {
            throw JweDecryptionFailedError("invalid or missing epk header (need OKP/X25519/x)")
        }
        guard let epkPubBytes = Data(base64URLEncoded: epkX) else {
            throw JweDecryptionFailedError("invalid base64url in epk.x")
        }
        if epkPubBytes.count != 32 {
            throw JweDecryptionFailedError("epk.x must be 32 bytes, got \(epkPubBytes.count)")
        }
        let epkPub: Curve25519.KeyAgreement.PublicKey
        do {
            epkPub = try Curve25519.KeyAgreement.PublicKey(rawRepresentation: epkPubBytes)
        } catch {
            throw JweDecryptionFailedError("epk.x is not a valid X25519 public key: \(error)", cause: error)
        }

        let apu = (header["apu"] as? String) ?? ""
        let apv = (header["apv"] as? String) ?? ""

        let cekBytes = try Self.deriveCek(
            myPriv: devicePriv,
            peerPub: epkPub,
            apu: apu,
            apv: apv
        )
        let cek = SymmetricKey(data: cekBytes)

        guard let aadBytes = parts[0].data(using: .ascii) else {
            throw JweDecryptionFailedError("protected header b64url is not ASCII")
        }

        let nonce: AES.GCM.Nonce
        do {
            nonce = try AES.GCM.Nonce(data: iv)
        } catch {
            throw JweDecryptionFailedError("invalid AES-GCM nonce: \(error)", cause: error)
        }

        let sealed: AES.GCM.SealedBox
        do {
            sealed = try AES.GCM.SealedBox(nonce: nonce, ciphertext: ciphertext, tag: tag)
        } catch {
            throw JweDecryptionFailedError("failed to assemble AES-GCM sealed box: \(error)", cause: error)
        }

        let clear: Data
        do {
            clear = try AES.GCM.open(sealed, using: cek, authenticating: aadBytes)
        } catch CryptoKitError.authenticationFailure {
            throw JweDecryptionFailedError(
                "AES-GCM tag mismatch (wrong key, tampered ciphertext, or AAD mismatch)")
        } catch {
            throw JweDecryptionFailedError("AES-GCM open failed: \(error)", cause: error)
        }

        let parsedHeader = JweProtectedHeader(
            alg: alg,
            enc: enc,
            kid: header["kid"] as? String,
            apu: header["apu"] as? String,
            apv: header["apv"] as? String,
            projectId: header["project_id"] as? Int,
            routePath: header["route_path"] as? String,
            requestId: header["request_id"] as? String,
            typ: header["typ"] as? String,
            lcsVersion: header["lcs_v"] as? Int,
            raw: header
        )
        return (plaintext: clear, header: parsedHeader)
    }

    // MARK: - ConcatKDF (RFC 7518 §4.6.2 / NIST SP 800-56A §5.8.1)

    /// Direct ECDH-ES → ConcatKDF (NIST SP 800-56A §5.8.1, mapped per
    /// RFC 7518 §4.6.2). Produces a 256-bit CEK suitable for A256GCM.
    ///
    /// The "AlgorithmID" is `A256GCM` (the `enc` value, NOT the `alg`, because
    /// for direct ECDH-ES the CEK is the agreed-upon symmetric key — §4.6.2).
    /// PartyUInfo / PartyVInfo are the raw UTF-8 bytes of `apu` / `apv` per
    /// §4.6.1.2/3 — already base64url-safe in our envelope, so no further
    /// re-encoding.
    private static func deriveCek(
        myPriv: Curve25519.KeyAgreement.PrivateKey,
        peerPub: Curve25519.KeyAgreement.PublicKey,
        apu: String,
        apv: String
    ) throws -> Data {
        let shared: SharedSecret
        do {
            shared = try myPriv.sharedSecretFromKeyAgreement(with: peerPub)
        } catch {
            throw JweDecryptionFailedError("X25519 sharedSecretFromKeyAgreement failed: \(error)", cause: error)
        }
        let z = shared.withUnsafeBytes { Data($0) }
        if z.count != 32 {
            throw JweDecryptionFailedError("X25519 shared secret must be 32 bytes, got \(z.count)")
        }

        // ConcatKDF input: counter(32-bit BE) || Z || OtherInfo
        //   OtherInfo = AlgorithmID || PartyUInfo || PartyVInfo || SuppPubInfo
        //   each prefixed with a big-endian 32-bit length.
        //   SuppPubInfo = keyDataLen in BITS (256), big-endian 32-bit.
        let algId = Array(kEnc.utf8) // 'A256GCM'
        let apuBytes = Array(apu.utf8)
        let apvBytes = Array(apv.utf8)

        var otherInfo = Data()
        otherInfo.append(uint32BE(algId.count))
        otherInfo.append(contentsOf: algId)
        otherInfo.append(uint32BE(apuBytes.count))
        otherInfo.append(contentsOf: apuBytes)
        otherInfo.append(uint32BE(apvBytes.count))
        otherInfo.append(contentsOf: apvBytes)
        otherInfo.append(uint32BE(256)) // keyDataLen in BITS

        // For a 256-bit CEK we need exactly one SHA-256 block → counter = 1.
        var hashInput = Data()
        hashInput.append(uint32BE(1))
        hashInput.append(z)
        hashInput.append(otherInfo)

        let digest = SHA256.hash(data: hashInput)
        let cek = Data(digest)
        if cek.count != 32 {
            throw JweDecryptionFailedError("ConcatKDF produced \(cek.count) bytes, expected 32")
        }
        return cek
    }

    private static func uint32BE(_ v: Int) -> Data {
        var out = Data(count: 4)
        let u = UInt32(v).bigEndian
        withUnsafeBytes(of: u) { ptr in
            out.replaceSubrange(0..<4, with: ptr)
        }
        return out
    }
}

// MARK: - Base64URL helpers

extension Data {
    /// Decodes a base64url string (no padding required). Returns nil on
    /// malformed input.
    public init?(base64URLEncoded s: String) {
        var b64 = s
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        // Re-pad to a multiple of 4.
        let pad = (4 - b64.count % 4) % 4
        if pad > 0 {
            b64.append(String(repeating: "=", count: pad))
        }
        guard let data = Data(base64Encoded: b64) else { return nil }
        self = data
    }
}
