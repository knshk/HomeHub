// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// In-memory JWKS cache backed by the control plane's
/// `/v1/.well-known/jwks.json`. Respects `Cache-Control: max-age` from the
/// response; falls back to `LicenseStoreConfig.jwksCacheTtl`.
public actor JwksClient {
    private let jwksUrl: URL
    private let http: SignedHttpClient
    private let defaultTtl: TimeInterval

    private var byKid: [String: Data] = [:]
    private var revokedKids: Set<String> = []
    private var fetchedAt: Date = .distantPast
    private var currentTtl: TimeInterval = 0
    private var inFlight: Task<Void, Error>?

    public init(jwksUrl: URL, http: SignedHttpClient, defaultTtl: TimeInterval = 60 * 60) {
        self.jwksUrl = jwksUrl
        self.http = http
        self.defaultTtl = defaultTtl
    }

    /// Returns the Ed25519 public key bytes for `kid`, fetching JWKS if the
    /// cache is empty or stale. Returns nil if the kid is not present
    /// (caller rejects the JWT).
    public func getKey(_ kid: String) async throws -> Data? {
        if revokedKids.contains(kid) { return nil }
        if let cached = byKid[kid], !isStale() { return cached }
        try await refreshIfNeeded()
        if revokedKids.contains(kid) { return nil }
        return byKid[kid]
    }

    /// Forces a refresh from the server. Safe to call concurrently — only
    /// one network request is in flight at a time.
    public func refresh() async throws {
        try await refreshIfNeeded(force: true)
    }

    private func isStale() -> Bool {
        Date().timeIntervalSince(fetchedAt) > currentTtl
    }

    private func refreshIfNeeded(force: Bool = false) async throws {
        if let inFlight = inFlight {
            try await inFlight.value
            return
        }
        if !force && !isStale() && !byKid.isEmpty { return }
        let task = Task<Void, Error> { try await self.doFetch() }
        inFlight = task
        defer { inFlight = nil }
        try await task.value
    }

    private func doFetch() async throws {
        do {
            let body = try await http.getJson(url: jwksUrl)
            let keys = (body["keys"] as? [[String: Any]]) ?? []
            var next: [String: Data] = [:]
            var revoked: Set<String> = []
            for jwk in keys {
                guard let kid = jwk["kid"] as? String else { continue }
                if (jwk["status"] as? String) == "revoked" {
                    revoked.insert(kid)
                    continue
                }
                if let bytes = Self.decodeEd25519PublicKey(jwk) {
                    next[kid] = bytes
                }
            }
            byKid = next
            revokedKids = revoked
            fetchedAt = Date()
            currentTtl = defaultTtl
        } catch let e as LicenseStoreError {
            throw e
        } catch {
            throw NetworkError("JWKS fetch failed: \(error)", cause: error)
        }
    }

    /// RFC 8037 OKP key: { "kty":"OKP", "crv":"Ed25519", "x":"<b64url 32 bytes>" }
    static func decodeEd25519PublicKey(_ jwk: [String: Any]) -> Data? {
        guard jwk["kty"] as? String == "OKP",
              jwk["crv"] as? String == "Ed25519",
              let x = jwk["x"] as? String,
              !x.isEmpty,
              let bytes = JwtVerifier.base64UrlDecode(x),
              bytes.count == 32
        else { return nil }
        return bytes
    }
}
