// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Hard-coded confidentiality policy. JWE-required is the **default-deny**;
/// JWS-or-plaintext is allowed only on the narrow carve-out below. Both lists
/// live in source — never server-driven — so a backend compromise cannot
/// downgrade a JWE-required route to JWS.
///
/// Must stay in lockstep with the Dart twin in
/// `sdk/dart/license_store_sdk/lib/src/crypto/route_policy.dart` and the L2
/// ingress allowlist. CI runs a parity check; if it fails, the failing side
/// ships first and then the other side ratchets to match.
///
/// `isMaterialChangeHint(path)` is BEST-EFFORT TELEMETRY ONLY. The
/// authoritative material-change classification lives server-side in
/// Alfheim's poll of `material_change_registry/current`; the SDK only
/// needs a coarse hint so it can label outgoing telemetry events for
/// dev-time debugging. Do NOT use the hint as a gating signal.

/// Confidentiality category the SDK MUST apply to a request before
/// transmitting. Material change vs hot-path lives orthogonally to this —
/// every confidentiality tier supports both.
public enum RouteConfidentiality: Sendable, Equatable {
    /// Default. Wrap the body in a single-recipient compact JWE (`ECDH-ES`
    /// + `A256GCM`) to the L2 enc-kid. Device Ed25519 signature on the
    /// inner JWS is also required.
    case jweRequired

    /// Narrow carve-out. Send plain JSON (no JWE wrap). Device signature
    /// not required.
    case jwsAllowed
}

/// Static utility — never instantiated. Methods are `static` and pure.
public enum RoutePolicy {
    /// The complete JWS-allowed carve-out. Every other route is JWE-required
    /// by default-deny. Keep this list short and audited; adding to it is a
    /// security review.
    ///
    /// Each entry is a literal-prefix string. The classifier matches case-sensitive
    /// against the request path (no query string). Trailing slashes are
    /// normalized out of `classify(_:)` before the comparison.
    public static let jwsAllowedRoutes: [String] = [
        // Public splash & catalog hooks (limited fields only — full catalog is JWE).
        "/v1/explore/splash",
        "/v1/catalog/explore",
        // Service metadata.
        "/v1/meta",
        "/healthz",
        "/readyz",
        // Public verifier keys.
        "/v1/.well-known/jwks.json",
        // Status / docs / marketing — all read-only public content.
        "/v1/status/",
        "/v1/docs/",
        "/v1/marketing/",
    ]

    /// Coarse list of route PREFIXES that LIKELY produce material-change events
    /// (license issue / tier upgrade / KYC milestone / payment settlement /
    /// org membership flips, etc.). Used purely as a telemetry tag — the SDK
    /// labels outbound events with `material_change_hint: true|false` so the
    /// dev dashboard can pivot. Server-side classification is authoritative.
    public static let materialChangeHintPrefixes: [String] = [
        "/v1/license/issue",
        "/v1/license/upgrade",
        "/v1/license/downgrade",
        "/v1/license/revoke",
        "/v1/license/transfer",
        "/v1/checkout",
        "/v1/payments/",
        "/v1/kyc/",
        "/v1/accreditation/",
        "/v1/esign/",
        "/v1/bank-deposit/",
        "/v1/cap-table/",
        "/v1/org/membership",
        "/v1/account/me/email-change",
        "/v1/security/mfa/",
    ]

    /// Returns the confidentiality tier for `path`. Default-deny → if no
    /// JWS-allowed prefix matches, the call MUST be wrapped in JWE.
    ///
    /// Matching is prefix-based but path-segment-aware: `/v1/meta` matches
    /// `/v1/meta` and `/v1/meta/something` but NOT `/v1/metadata`. This avoids
    /// surprise downgrades from a route that happens to share a leading
    /// substring with a JWS-allowed entry.
    public static func classify(_ path: String) -> RouteConfidentiality {
        let normalized = normalize(path)
        for prefix in jwsAllowedRoutes {
            if matchesPrefix(normalized, prefix: prefix) {
                return .jwsAllowed
            }
        }
        return .jweRequired
    }

    /// Best-effort dev-time tag. NOT a security control.
    public static func isMaterialChangeHint(_ path: String) -> Bool {
        let normalized = normalize(path)
        for prefix in materialChangeHintPrefixes {
            if matchesPrefix(normalized, prefix: prefix) { return true }
        }
        return false
    }

    private static func normalize(_ path: String) -> String {
        if path.isEmpty { return "/" }
        // Strip query / fragment defensively — callers should pass path only,
        // but the classifier is robust to a stray `?` slipping through.
        var end = path.endIndex
        if let q = path.firstIndex(of: "?"), q < end { end = q }
        if let f = path.firstIndex(of: "#"), f < end { end = f }
        var p = String(path[path.startIndex..<end])
        if p.count > 1 && p.hasSuffix("/") {
            p.removeLast()
        }
        return p
    }

    private static func matchesPrefix(_ path: String, prefix: String) -> Bool {
        // Treat the prefix as a trailing-slash-permissive equality:
        //   prefix='/v1/meta'    → matches '/v1/meta' OR '/v1/meta/...'
        //   prefix='/v1/docs/'   → matches '/v1/docs' OR '/v1/docs/...'
        let p = prefix.hasSuffix("/") ? String(prefix.dropLast()) : prefix
        if path == p { return true }
        return path.hasPrefix(p + "/")
    }
}
