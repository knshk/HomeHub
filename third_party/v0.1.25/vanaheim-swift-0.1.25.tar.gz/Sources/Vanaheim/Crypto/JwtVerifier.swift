// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import CryptoKit
import Foundation

/// Verifies an Ed25519-signed JWT and returns the decoded claims.
///
/// Throws exactly one of:
///   * `LicenseExpiredError` — signature valid, but `exp` is past
///     (with clock-skew tolerance). Caller may go offline-grace or
///     trigger a refresh.
///   * `JwtVerificationError` — anything else: malformed JWT, wrong alg,
///     missing/wrong-typed claim, signature mismatch, future-dated `nbf`,
///     issuer/audience mismatch. Cached JWT must be discarded.
///
/// NEVER returns silently with an unverified token.
public enum JwtVerifier {

    public static func verifyAndDecode(
        jwt: String,
        publicKey: Data,
        expectedIssuer: String,
        expectedAudience: String,
        clockSkew: TimeInterval = 300,
        now: Date = Date()
    ) throws -> LicenseJwtClaims {

        let parts = jwt.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 3 else {
            throw JwtVerificationError("Malformed JWT (expected 3 parts)")
        }
        let headerB64 = String(parts[0])
        let claimsB64 = String(parts[1])
        let sigB64    = String(parts[2])

        guard let headerData = base64UrlDecode(headerB64),
              let claimsData = base64UrlDecode(claimsB64),
              let sigData    = base64UrlDecode(sigB64)
        else {
            throw JwtVerificationError("JWT contains invalid base64url segments")
        }

        let header = try decodeJson(headerData, kind: "header")
        let claimsMap = try decodeJson(claimsData, kind: "claims")

        guard (header["alg"] as? String) == "EdDSA" else {
            throw JwtVerificationError("Unsupported alg: \(header["alg"] ?? "?")")
        }
        guard let kid = header["kid"] as? String, !kid.isEmpty else {
            throw JwtVerificationError("JWT header missing kid")
        }

        let signingInput = "\(headerB64).\(claimsB64)".data(using: .utf8)!

        guard publicKey.count == 32, sigData.count == 64 else {
            throw JwtVerificationError("Unexpected key/sig length")
        }
        let pub: Curve25519.Signing.PublicKey
        do {
            pub = try Curve25519.Signing.PublicKey(rawRepresentation: publicKey)
        } catch {
            throw JwtVerificationError("Invalid Ed25519 public key", cause: error)
        }
        guard pub.isValidSignature(sigData, for: signingInput) else {
            throw JwtVerificationError("Ed25519 signature verification failed")
        }

        // Strict claim extraction — every required field surfaces as
        // JwtVerificationError, never a raw type-mismatch crash.
        let iss = try requireString(claimsMap, "iss")
        let aud = try requireString(claimsMap, "aud")
        if iss != expectedIssuer {
            throw JwtVerificationError("Unexpected iss: \(iss) (want \(expectedIssuer))")
        }
        if aud != expectedAudience {
            throw JwtVerificationError("Unexpected aud: \(aud) (want \(expectedAudience))")
        }

        let exp = try requireInt(claimsMap, "exp")
        let nbf = optInt(claimsMap, "nbf")
        let iat = optInt(claimsMap, "iat")

        let nowSec = Int(now.timeIntervalSince1970)
        let skew = Int(clockSkew)

        // Expiry is a DISTINCT category from structural/signature failure.
        if nowSec > exp + skew {
            throw LicenseExpiredError("Token expired")
        }
        if nbf > 0 && nowSec + skew < nbf {
            throw JwtVerificationError("Token not yet valid")
        }

        let entitlements: [String: AnyCodable]
        if let entRaw = claimsMap["ent"] as? [String: Any] {
            entitlements = entRaw.mapValues { AnyCodable($0) }
        } else {
            entitlements = [:]
        }
        let ev = optInt(claimsMap, "ev")

        // Forward-compat claim extraction: cfg, cfg_v, roles, org_id,
        // org_role, prefs_v, locale. ALL optional — missing or wrong-typed
        // values surface as safe defaults. Day-1 SDK contract: backend can
        // roll out claims without an SDK bump.
        let config: [String: AnyCodable]
        if let cfgRaw = claimsMap["cfg"] as? [String: Any] {
            config = cfgRaw.mapValues { AnyCodable($0) }
        } else {
            config = [:]
        }
        let cfgV = optInt(claimsMap, "cfg_v")

        let roles: [String]
        if let rolesRaw = claimsMap["roles"] as? [Any] {
            roles = rolesRaw.compactMap { ($0 as? String).flatMap { $0.isEmpty ? nil : $0 } }
        } else {
            roles = []
        }
        let orgId = optString(claimsMap, "org_id")
        let orgRole = optString(claimsMap, "org_role")
        let prefsV = optInt(claimsMap, "prefs_v")
        let locale = optString(claimsMap, "locale")

        return LicenseJwtClaims(
            issuer: iss,
            licenseId: try requireString(claimsMap, "sub"),
            productId: aud,
            accountId: try requireString(claimsMap, "acc"),
            tier: try requireString(claimsMap, "tier"),
            entitlements: entitlements,
            entitlementsVersion: ev,
            issuedAt: Date(timeIntervalSince1970: TimeInterval(iat)),
            notBefore: Date(timeIntervalSince1970: TimeInterval(nbf)),
            expiresAt: Date(timeIntervalSince1970: TimeInterval(exp)),
            kid: kid,
            config: config,
            configVersion: cfgV,
            roles: roles,
            orgId: orgId,
            orgRole: orgRole,
            preferencesVersion: prefsV,
            locale: locale
        )
    }

    /// Returns the non-empty string at [key], or nil. Wrong-typed values
    /// silently become nil (forward-compat: future claim shape changes
    /// won't break the verifier).
    static func optString(_ m: [String: Any], _ k: String) -> String? {
        guard let s = m[k] as? String, !s.isEmpty else { return nil }
        return s
    }

    // MARK: - helpers

    static func base64UrlDecode(_ s: String) -> Data? {
        var t = s.replacingOccurrences(of: "-", with: "+")
                 .replacingOccurrences(of: "_", with: "/")
        let pad = (4 - t.count % 4) % 4
        t += String(repeating: "=", count: pad)
        return Data(base64Encoded: t)
    }

    static func decodeJson(_ data: Data, kind: String) throws -> [String: Any] {
        do {
            guard let m = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                throw JwtVerificationError("JWT \(kind) is not a JSON object")
            }
            return m
        } catch let e as LicenseStoreError {
            throw e
        } catch {
            throw JwtVerificationError("Invalid JSON in JWT \(kind): \(error)")
        }
    }

    static func requireString(_ m: [String: Any], _ k: String) throws -> String {
        guard let v = m[k] as? String, !v.isEmpty else {
            throw JwtVerificationError("JWT claim \"\(k)\" missing or not a non-empty string")
        }
        return v
    }

    static func requireInt(_ m: [String: Any], _ k: String) throws -> Int {
        if let n = m[k] as? Int { return n }
        if let n = m[k] as? Double { return Int(n) }
        if let n = m[k] as? NSNumber { return n.intValue }
        throw JwtVerificationError("JWT claim \"\(k)\" missing or not a number")
    }

    static func optInt(_ m: [String: Any], _ k: String) -> Int {
        if let n = m[k] as? Int { return n }
        if let n = m[k] as? Double { return Int(n) }
        if let n = m[k] as? NSNumber { return n.intValue }
        return 0
    }
}
