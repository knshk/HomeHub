// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2A.12 i18n message formatting.
///
/// Day-1 contract: in-process catalog + ICU-style variable interpolation
/// (`Hello, {name}!`) + simple plural form
/// (`{count, plural, one {1 item} other {{count} items}}`).
public struct MessageFormatter: Sendable {
    public let locale: String?
    private let catalog: [String: String]

    public init(locale: String? = nil, catalog: [String: String] = [:]) {
        self.locale = locale
        self.catalog = catalog
    }

    public func withCatalog(_ overrides: [String: String]) -> MessageFormatter {
        var merged = catalog
        for (k, v) in overrides { merged[k] = v }
        return MessageFormatter(locale: locale, catalog: merged)
    }

    /// Format a message by key. Returns the key itself when missing —
    /// useful for dev to spot untranslated strings.
    public func format(_ key: String, vars: [String: Any] = [:]) -> String {
        let template = catalog[key] ?? key
        return interpolate(template, vars: vars)
    }

    private func interpolate(_ template: String, vars: [String: Any]) -> String {
        var out = ""
        var i = template.startIndex
        while i < template.endIndex {
            let c = template[i]
            if c == "{" {
                if let close = findMatchingBrace(template, openAt: i) {
                    let innerStart = template.index(after: i)
                    let inner = String(template[innerStart..<close])
                    out += resolveExpr(inner, vars: vars)
                    i = template.index(after: close)
                    continue
                } else {
                    out += String(template[i...])
                    break
                }
            }
            out += String(c)
            i = template.index(after: i)
        }
        return out
    }

    private func findMatchingBrace(_ s: String, openAt: String.Index) -> String.Index? {
        var depth = 0
        var i = openAt
        while i < s.endIndex {
            let c = s[i]
            if c == "{" { depth += 1 }
            else if c == "}" {
                depth -= 1
                if depth == 0 { return i }
            }
            i = s.index(after: i)
        }
        return nil
    }

    private func resolveExpr(_ inner: String, vars: [String: Any]) -> String {
        // Plural: "name, plural, one {…} other {…}"
        if let m = inner.range(of: "^\\s*(\\w+)\\s*,\\s*plural\\s*,\\s*",
                                options: [.regularExpression]),
           m.lowerBound == inner.startIndex {
            let prefix = inner[inner.startIndex..<m.upperBound]
            let varName = String(prefix.split(separator: ",")[0]).trimmingCharacters(in: .whitespaces)
            let spec = String(inner[m.upperBound...])
            let n = intFromVar(vars[varName])
            let branches = parseBranches(spec)
            let category = pluralCategory(n)
            let branch = branches[category] ?? branches["other"] ?? ""
            var nextVars = vars
            nextVars[varName] = n
            return interpolate(branch, vars: nextVars)
        }
        // Select: "name, select, female {…} male {…} other {…}"
        // Selector-based branching for categorical values: gender, role,
        // partner-tier — any string the catalog wants to switch on.
        if let m = inner.range(of: "^\\s*(\\w+)\\s*,\\s*select\\s*,\\s*",
                                options: [.regularExpression]),
           m.lowerBound == inner.startIndex {
            let prefix = inner[inner.startIndex..<m.upperBound]
            let varName = String(prefix.split(separator: ",")[0]).trimmingCharacters(in: .whitespaces)
            let spec = String(inner[m.upperBound...])
            let key = (vars[varName].map { "\($0)" }) ?? "other"
            let branches = parseBranches(spec)
            let branch = branches[key] ?? branches["other"] ?? ""
            return interpolate(branch, vars: vars)
        }
        // Simple var: "{name}"
        let trimmed = inner.trimmingCharacters(in: .whitespaces)
        if let v = vars[trimmed] {
            return "\(v)"
        }
        return "{\(inner)}"
    }

    private func parseBranches(_ spec: String) -> [String: String] {
        var out: [String: String] = [:]
        var i = spec.startIndex
        while i < spec.endIndex {
            while i < spec.endIndex && spec[i].isWhitespace { i = spec.index(after: i) }
            let keyStart = i
            while i < spec.endIndex && !spec[i].isWhitespace && spec[i] != "{" {
                i = spec.index(after: i)
            }
            let keyword = String(spec[keyStart..<i]).trimmingCharacters(in: .whitespaces)
            while i < spec.endIndex && spec[i].isWhitespace { i = spec.index(after: i) }
            guard i < spec.endIndex && spec[i] == "{" else { break }
            guard let close = findMatchingBrace(spec, openAt: i) else { break }
            let innerStart = spec.index(after: i)
            out[keyword] = String(spec[innerStart..<close])
            i = spec.index(after: close)
        }
        return out
    }

    private func intFromVar(_ v: Any?) -> Int {
        if let i = v as? Int { return i }
        if let n = v as? NSNumber { return n.intValue }
        if let s = v as? String, let i = Int(s) { return i }
        return 0
    }

    private func pluralCategory(_ n: Int) -> String {
        switch n {
        case 0: return "zero"
        case 1: return "one"
        case 2: return "two"
        case 3...10: return "few"
        default: return "other"
        }
    }
}
