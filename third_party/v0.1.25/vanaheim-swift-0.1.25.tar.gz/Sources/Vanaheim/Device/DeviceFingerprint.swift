// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import CryptoKit
import Foundation
#if canImport(UIKit)
import UIKit
#endif
#if canImport(IOKit)
import IOKit
#endif

/// Generates a stable, opaque device fingerprint per platform. Raw OS IDs
/// (IDFV, IOPlatformUUID, ANDROID_ID, etc.) are NEVER sent to the server —
/// we HKDF them with the productSlug to get an opaque 32-byte hex value.
///
/// See DEVICE_BINDING.md §3 for the design.
public struct DeviceFingerprintGenerator: Sendable {
    public init() {}

    /// Returns the hex fingerprint (64 chars). `productSlug` is mixed in so
    /// the same device gets a different fingerprint per product (no
    /// cross-product correlation).
    public func generate(productSlug: String) async -> String {
        let stable = rawPlatformIdentifier()
        let ikm = SHA256.hash(data: Data(stable.utf8))
        let info = "license-store-fp-v1|\(productSlug)".data(using: .utf8)!
        let salt = "license-store/v1".data(using: .utf8)!
        let prk = HMAC<SHA256>.authenticationCode(for: Data(ikm), using: SymmetricKey(data: salt))
        let okm = expandHKDF(prk: Data(prk), info: info, length: 32)
        return okm.map { String(format: "%02x", $0) }.joined()
    }

    /// HKDF-Expand (RFC 5869). Length is capped at 32 here since we only
    /// emit a SHA-256-sized output; the full algorithm allows multiples.
    private func expandHKDF(prk: Data, info: Data, length: Int) -> Data {
        var out = Data()
        var prev = Data()
        var counter: UInt8 = 1
        while out.count < length {
            var input = Data()
            input.append(prev)
            input.append(info)
            input.append(counter)
            let block = HMAC<SHA256>.authenticationCode(for: input, using: SymmetricKey(data: prk))
            prev = Data(block)
            out.append(prev)
            counter += 1
        }
        return out.prefix(length)
    }

    private func rawPlatformIdentifier() -> String {
        #if os(iOS) || os(tvOS) || targetEnvironment(macCatalyst)
        if let idfv = UIDevice.current.identifierForVendor?.uuidString { return idfv }
        return "ios-unknown"
        #elseif os(macOS)
        // IOPlatformUUID via IOKit
        if let uuid = macOSPlatformUUID() { return uuid }
        return "macos-unknown"
        #elseif os(watchOS)
        if let idfv = WKInterfaceDevice.current().identifierForVendor?.uuidString { return idfv }
        return "watchos-unknown"
        #else
        return "unknown-platform"
        #endif
    }

    #if os(macOS)
    private func macOSPlatformUUID() -> String? {
        let entry = IOServiceGetMatchingService(
            kIOMainPortDefault,
            IOServiceMatching("IOPlatformExpertDevice"))
        guard entry != IO_OBJECT_NULL else { return nil }
        defer { IOObjectRelease(entry) }
        let key = "IOPlatformUUID" as CFString
        if let prop = IORegistryEntryCreateCFProperty(entry, key, kCFAllocatorDefault, 0) {
            return (prop.takeRetainedValue() as? String)
        }
        return nil
    }
    #endif
}
