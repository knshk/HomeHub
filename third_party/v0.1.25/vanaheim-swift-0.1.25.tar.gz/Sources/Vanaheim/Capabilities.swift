// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// Per-app capability switches.
///
/// Each consuming product configures an instance (programmatically or by
/// deserializing from JSON/YAML) and passes it to `LicenseClient.connect`.
/// Every sub-API gates calls at runtime: calling a disabled capability
/// throws `CapabilityDisabledError`.
///
/// All capability flags default to `true` if not overridden — products
/// must explicitly disable. This avoids silent disablement when a config
/// is missing a key.
public struct SdkCapabilities: Sendable, Codable {
    public var notifications: Bool
    public var feedback: Bool
    public var support: Bool
    public var subscription: Bool
    public var privacy: Bool
    public var preferences: Bool
    public var telemetry: Bool
    public var assistant: Bool
    public var referrals: Bool
    public var status: Bool
    public var organization: Bool
    public var offers: Bool
    public var docs: Bool
    public var mfa: Bool

    // Tunable defaults
    public var feedbackMaxAttachmentMb: Int
    public var notificationInboxPageSize: Int
    public var telemetryBatchSize: Int
    public var telemetryFlushIntervalSeconds: Int
    public var telemetryMaxBuffer: Int

    public init(
        notifications: Bool = true,
        feedback: Bool = true,
        support: Bool = true,
        subscription: Bool = true,
        privacy: Bool = true,
        preferences: Bool = true,
        telemetry: Bool = true,
        assistant: Bool = true,
        referrals: Bool = true,
        status: Bool = true,
        organization: Bool = true,
        offers: Bool = true,
        docs: Bool = true,
        mfa: Bool = true,
        feedbackMaxAttachmentMb: Int = 5,
        notificationInboxPageSize: Int = 50,
        telemetryBatchSize: Int = 20,
        telemetryFlushIntervalSeconds: Int = 30,
        telemetryMaxBuffer: Int = 500
    ) {
        self.notifications = notifications
        self.feedback = feedback
        self.support = support
        self.subscription = subscription
        self.privacy = privacy
        self.preferences = preferences
        self.telemetry = telemetry
        self.assistant = assistant
        self.referrals = referrals
        self.status = status
        self.organization = organization
        self.offers = offers
        self.docs = docs
        self.mfa = mfa
        self.feedbackMaxAttachmentMb = feedbackMaxAttachmentMb
        self.notificationInboxPageSize = notificationInboxPageSize
        self.telemetryBatchSize = telemetryBatchSize
        self.telemetryFlushIntervalSeconds = telemetryFlushIntervalSeconds
        self.telemetryMaxBuffer = telemetryMaxBuffer
    }

    public static let `defaults` = SdkCapabilities()

    /// Convenience: load from a JSON Data blob with the schema mirrored from
    /// capabilities.yaml. Tools like `yams` or `Yaml.swift` can convert
    /// YAML to JSON before calling this. Missing keys default to `true`.
    public static func fromJson(_ data: Data) throws -> SdkCapabilities {
        let decoder = JSONDecoder()
        // Allow extra fields & missing fields.
        let raw = try JSONSerialization.jsonObject(with: data) as? [String: Any] ?? [:]
        let root = (raw["license_store_sdk"] as? [String: Any]) ?? raw
        let caps = (root["capabilities"] as? [String: Any]) ?? [:]
        let defs = (root["defaults"] as? [String: Any]) ?? [:]

        func boolOf(_ key: String, _ fallback: Bool) -> Bool {
            (caps[key] as? Bool) ?? fallback
        }
        func intOf(_ key: String, _ fallback: Int) -> Int {
            (defs[key] as? Int) ?? ((defs[key] as? NSNumber)?.intValue) ?? fallback
        }
        _ = decoder
        return SdkCapabilities(
            notifications: boolOf("notifications", true),
            feedback: boolOf("feedback", true),
            support: boolOf("support", true),
            subscription: boolOf("subscription", true),
            privacy: boolOf("privacy", true),
            preferences: boolOf("preferences", true),
            telemetry: boolOf("telemetry", true),
            assistant: boolOf("assistant", true),
            referrals: boolOf("referrals", true),
            status: boolOf("status", true),
            organization: boolOf("organization", true),
            offers: boolOf("offers", true),
            docs: boolOf("docs", true),
            mfa: boolOf("mfa", true),
            feedbackMaxAttachmentMb: intOf("feedback_max_attachment_mb", 5),
            notificationInboxPageSize: intOf("notification_inbox_page_size", 50),
            telemetryBatchSize: intOf("telemetry_batch_size", 20),
            telemetryFlushIntervalSeconds: intOf("telemetry_flush_interval_seconds", 30),
            telemetryMaxBuffer: intOf("telemetry_max_buffer", 500)
        )
    }

    public func isEnabled(_ name: String) -> Bool {
        switch name {
        case "notifications": return notifications
        case "feedback":      return feedback
        case "support":       return support
        case "subscription":  return subscription
        case "privacy":       return privacy
        case "preferences":   return preferences
        case "telemetry":     return telemetry
        case "assistant":     return assistant
        case "referrals":     return referrals
        case "status":        return status
        case "organization":  return organization
        case "offers":        return offers
        case "docs":          return docs
        case "mfa":           return mfa
        default:              return true
        }
    }

    /// Throws `CapabilityDisabledError` when the named capability is disabled.
    public func require(_ name: String) throws {
        if !isEnabled(name) {
            throw CapabilityDisabledError(capability: name)
        }
    }
}

/// Thrown when a product calls into an SDK capability that is disabled.
public final class CapabilityDisabledError: LicenseStoreError {
    public let capability: String
    public init(capability: String) {
        self.capability = capability
        super.init("SDK capability \"\(capability)\" is disabled by the product's "
            + "capability config. Enable it in capabilities.yaml or pass an "
            + "SdkCapabilities() with the relevant flag set to true.")
    }
}

// ─────────────────────────────────────────────────────────────────────
// v0.1.19 — reportCapability wire path (Bifrost B-9.19).
//
// A separate concept from the client-side `SdkCapabilities` above:
//   * `SdkCapabilities` gates which sub-APIs a product's SDK exposes
//     (feedback / support / etc). Purely local, product-owned config.
//   * `reportCapability(_:_:)` PUBLISHES a per-project boolean flag
//     ("does this app support offline export?") to Bifrost so the
//     MS catalog can surface the presence signal in aggregate reports
//     WITHOUT any PII crossing the trust boundary.
//
// Wire contract (mirrored across Dart / Swift / TS SDKs — see
// bifrost/packages/api-types/src/fron-parity-fixtures.json §apps):
//   POST /v1/apps/capabilities
//   auth: PAK-JWE (per-project scope from PAK claim)
//   body: { "key": "<has_[a-z0-9_]{2,64}>", "value": <bool> }
//   response 200: { "key", "value", "updated_at_ms" }
//   idempotent by (project_id, key); replay with same value = no-op.
//
// Client-side validation is fail-fast + defence-in-depth (server also
// rejects with CAPABILITY_KEY_INVALID / CAPABILITY_VALUE_TYPE_INVALID).
// ─────────────────────────────────────────────────────────────────────

/// Argument-validation error for `LicenseClient.reportCapability`.
///
/// Thrown BEFORE any wire round-trip when the caller supplies a key
/// that doesn't match `^has_[a-z0-9_]{2,64}$`. The server rejects the
/// same shape with `CAPABILITY_KEY_INVALID` — the client-side check
/// is a fast-fail so a typo surfaces immediately.
public final class CapabilityKeyInvalidError: LicenseStoreError {
    /// The offending key the caller passed (echoed for diagnostics).
    public let key: String
    public init(key: String, cause: Error? = nil) {
        self.key = key
        super.init(
            "Capability key \"\(key)\" is invalid — must match " +
            "^has_[a-z0-9_]{2,64}$ (server rejects with " +
            "CAPABILITY_KEY_INVALID otherwise).",
            cause: cause)
    }
}

/// Namespace for capability-report validation shared across the Swift
/// SDK. Public so host products can validate keys before calling
/// `reportCapability` (e.g. to gate a UI toggle).
public enum CapabilityReportValidation {
    /// The exact regex the server enforces on the wire — mirrored here
    /// byte-for-byte so client-side rejects are identical to server-side.
    public static let keyPattern: String = "^has_[a-z0-9_]{2,64}$"

    /// Validates a capability key. Throws `CapabilityKeyInvalidError`
    /// on any mismatch. Uses NSRegularExpression for anchored full-
    /// string match (no partial matches admitted).
    public static func requireValidKey(_ key: String) throws {
        // Compile once per call — NSRegularExpression is cheap and
        // keeps this pure (no cross-call cache state to reason about
        // for concurrent access from the actor).
        let regex: NSRegularExpression
        do {
            regex = try NSRegularExpression(
                pattern: keyPattern,
                options: [])
        } catch {
            // Compile-time constant pattern — should never fail. If it
            // does, surface a clean typed error rather than crashing.
            throw CapabilityKeyInvalidError(key: key, cause: error)
        }
        let range = NSRange(key.startIndex..., in: key)
        let match = regex.firstMatch(in: key, options: [], range: range)
        guard let m = match, m.range == range else {
            throw CapabilityKeyInvalidError(key: key)
        }
    }
}

// See `LicenseClient.reportCapability(_:_:)` for the public wire method.
// The implementation lives inside `LicenseClient.swift` so it can reach
// the actor's private `http` + `regionEndpoint` + `checkAlive` state
// without leaking those to a wider access level.

// ─────────────────────────────────────────────────────────────────────
// Client-info identifiers used by the reportCapability wire shape.
// Exposed as consts (not lifted from a live wire spec at runtime) so
// the parity fixture can pin them byte-for-byte across the three SDKs.
// ─────────────────────────────────────────────────────────────────────

/// Canonical wire keys for the reportCapability body — pinned so the
/// cross-language parity fixture can assert on them without
/// re-declaring string literals.
public enum ReportCapabilityWire {
    /// Endpoint path — mirrored in the Dart + TS SDKs.
    public static let routePath: String = "/v1/apps/capabilities"
    /// Body key for the capability identifier.
    public static let bodyKeyKey: String = "key"
    /// Body key for the boolean value.
    public static let bodyKeyValue: String = "value"
    /// Retry policy — maximum attempts including the initial call.
    public static let maxAttempts: Int = 3
}
