// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

public enum TelemetrySeverity: String, Sendable, Codable {
    case warn, error, panic
}

/// Captured error event. Immutable. JSON-serializable for support bundles.
public struct TelemetryEvent: Sendable, Codable {
    public let timestamp: Date
    public let severity: TelemetrySeverity
    public let source: String
    public let errorClass: String
    public let message: String
    public let stack: String?
    public let context: [String: AnyCodable]

    enum CodingKeys: String, CodingKey {
        case timestamp = "ts"
        case severity, source, message, stack, context
        case errorClass = "error_class"
    }
}

/// Captures errors locally in a bounded ring buffer, persists to secure
/// storage with a small debounce, and exposes a public diagnostic API so
/// users can attach `client.diagnostics().jsonValue` to a support email.
///
/// Properties guaranteed:
///   * `capture()` is non-throwing.
///   * Ring-buffer is bounded (default 50); oldest events drop first.
///   * Persistence is debounced (default 2 s).
///   * Never includes JWT / SDK secret — only typed-exception messages.
public actor ErrorTelemetry {
    public let maxBuffer: Int
    public let persistDebounce: TimeInterval
    public let cache: SecureCache?

    private var ring: [TelemetryEvent] = []
    private var pendingFlush: Task<Void, Never>?
    private var restored = false

    public init(cache: SecureCache? = nil, maxBuffer: Int = 50, persistDebounce: TimeInterval = 2) {
        self.cache = cache
        self.maxBuffer = maxBuffer
        self.persistDebounce = persistDebounce
    }

    /// Loads any prior-session persisted events. Call once during connect().
    public func restore() async {
        if restored { return }
        restored = true
        guard let cache = cache else { return }
        do {
            guard let raw = try await cache.getTelemetry(),
                  let data = raw.data(using: .utf8) else { return }
            // Per-entry decode so ONE malformed event doesn't drop the
            // whole history. Mirrors Dart restore() (error_telemetry.dart
            // lines 100-104): decode as a top-level array of opaque JSON,
            // then try each element individually.
            guard let arr = (try? JSONSerialization.jsonObject(with: data)) as? [Any] else {
                // Top-level is not even an array — corrupt blob, start clean.
                return
            }
            let dec = JSONDecoder()
            dec.dateDecodingStrategy = .iso8601
            var recovered: [TelemetryEvent] = []
            for entry in arr {
                guard let dict = entry as? [String: Any],
                      let entryData = try? JSONSerialization.data(withJSONObject: dict),
                      let ev = try? dec.decode(TelemetryEvent.self, from: entryData)
                else {
                    continue // skip just this entry
                }
                recovered.append(ev)
            }
            ring = recovered
            trimToMaxBuffer()
        } catch {
            // Defensive: any unexpected failure leaves us with an empty
            // ring (already true). restore() must never fail connect().
        }
    }

    public func capture(
        source: String,
        error: Error,
        stack: String? = nil,
        context: [String: Any] = [:],
        severity: TelemetrySeverity = .error
    ) {
        // SAFETY CONTRACT: capture() must never throw. Any internal failure
        // (a weird mapValues interaction, ring mutation under contention,
        // anything) is silently dropped — the caller already has the
        // original error to deal with. Mirrors Dart's outer try/catch in
        // error_telemetry.dart::capture().
        //
        // The current body has no throwing call sites, but wrapping in
        // Result/try? future-proofs against changes (e.g. if AnyCodable
        // becomes throwing) so the contract holds by construction.
        let snapshot = (Date(), severity, source, error, stack, context)
        let ev: TelemetryEvent? = {
            let (ts, sev, src, err, stk, ctx) = snapshot
            return TelemetryEvent(
                timestamp: ts,
                severity: sev,
                source: src,
                errorClass: String(describing: type(of: err)),
                message: Self.truncate(String(describing: err), max: 2000),
                stack: stk.map { Self.truncate($0, max: 4000) },
                context: ctx.mapValues { AnyCodable($0) }
            )
        }()
        guard let ev = ev else { return }
        ring.append(ev)
        trimToMaxBuffer()
        schedulePersist()
    }

    /// Returns a copy of recent events (newest last).
    public func recent(limit: Int? = nil) -> [TelemetryEvent] {
        if let limit = limit, limit < ring.count {
            return Array(ring.suffix(limit))
        }
        return ring
    }

    /// JSON-serializable bundle for diagnostics. The SDK never auto-uploads.
    public func exportForDiagnostics(limit: Int? = nil) -> [String: Any] {
        let events = recent(limit: limit)
        let enc = JSONEncoder()
        enc.dateEncodingStrategy = .iso8601
        let eventsArray: [[String: Any]]
        if let data = try? enc.encode(events),
           let arr = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] {
            eventsArray = arr
        } else {
            eventsArray = []
        }
        let fmt = ISO8601DateFormatter()
        return [
            "generated_at": fmt.string(from: Date()),
            "events": eventsArray,
        ]
    }

    /// Clears the in-memory buffer and the persisted blob.
    public func clear() async {
        ring.removeAll()
        pendingFlush?.cancel()
        pendingFlush = nil
        if let cache = cache {
            try? await cache.putTelemetry("[]")
        }
    }

    /// Force-flush to storage; called on dispose so events captured since
    /// the last debounce tick aren't lost.
    public func flush() async {
        pendingFlush?.cancel()
        pendingFlush = nil
        await persistNow()
    }

    // MARK: - Internals

    private func trimToMaxBuffer() {
        while ring.count > maxBuffer { ring.removeFirst() }
    }

    private func schedulePersist() {
        guard cache != nil else { return }
        pendingFlush?.cancel()
        pendingFlush = Task { [persistDebounce] in
            try? await Task.sleep(nanoseconds: UInt64(persistDebounce * 1_000_000_000))
            if Task.isCancelled { return }
            await self.persistNow()
        }
    }

    private func persistNow() async {
        guard let cache = cache else { return }
        let snapshot = ring
        let enc = JSONEncoder()
        enc.dateEncodingStrategy = .iso8601
        do {
            let data = try enc.encode(snapshot)
            let s = String(data: data, encoding: .utf8) ?? "[]"
            try await cache.putTelemetry(s)
        } catch {
            // Persist failure is non-fatal; in-memory buffer still has them.
        }
    }

    private static func truncate(_ s: String, max: Int) -> String {
        s.count <= max ? s : "\(s.prefix(max))…[truncated]"
    }
}
