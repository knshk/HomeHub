// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import Foundation

/// §2A.1 / §3A.3 push token provider — the contract the SDK uses to acquire
/// an FCM/APNs registration token + receive incoming push notifications.
///
/// Day-1 SDK ships the protocol so backend FCM rollout doesn't require a
/// future SDK release. Products inject a concrete implementation backed by
/// `FirebaseMessaging` / `UserNotifications`.
///
/// The SDK only ever calls `getToken()` and listens to the two streams; it
/// never touches platform notification permissions directly.
public protocol PushTokenProvider: Sendable {
    /// Returns the current FCM/APNs registration token. May be empty when
    /// the platform has not issued one (permission denied, simulator, etc.)
    /// — SDK treats empty as "no token available".
    func getToken() async throws -> String

    /// Stream of token rotations. SDK re-sends the new token to the backend
    /// during the next activate/verify cycle.
    var tokenChanges: AsyncStream<String> { get }

    /// Stream of incoming push notification payloads. SDK triggers an
    /// immediate `verify()` on `kind == "license.changed"` /
    /// `"license.config_changed"`, and emits `notificationReceived` on
    /// inbox arrivals.
    var incomingMessages: AsyncStream<[String: Any]> { get }
}

/// No-op provider used in tests + as the default when products don't need
/// push notifications. Empty token, never-firing streams.
public struct NoPushTokenProvider: PushTokenProvider, Sendable {
    public init() {}
    public func getToken() async throws -> String { "" }
    public var tokenChanges: AsyncStream<String> {
        AsyncStream { _ in /* never yields */ }
    }
    public var incomingMessages: AsyncStream<[String: Any]> {
        AsyncStream { _ in /* never yields */ }
    }
}
