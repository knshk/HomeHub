# Vanaheim — Webview Quickstart

Browser- / webview-friendly subpath of the `vanaheim` npm package.

```ts
import { createVanaheimClient } from 'vanaheim/webview';
```

The webview entry runs in any modern browser, Electron renderer, React
Native WebView, Capacitor WebView, Tauri webview, or service-worker
context that ships `globalThis.crypto.subtle` (Web Crypto), `globalThis.fetch`,
and `globalThis.atob` / `globalThis.btoa`. It deliberately does NOT import
any `node:*` module, never references `process.*`, and never pulls in
`undici`. The FRON wire format is byte-identical to the Node entry — the
webview client is a thin facade over the shared `DirectClient`.

> Introduced in **v0.1.15** (TS-package-only minor release).

---

## 60-second happy path

```ts
import { createVanaheimClient } from 'vanaheim/webview';

const client = createVanaheimClient({
  mode: 'fron',
  bifrostBaseUrl: 'https://bifrost.example.com',
  productSlug: 'acme-photo-studio',
  sdkSecret: import.meta.env.VITE_VANAHEIM_SDK_SECRET,
  storage,        // see "Wiring the ports" below — REQUIRED
  attestation,    // optional
});

await client.connect();
await client.activate({ licenseKey: 'LCN-XXXX-XXXX-XXXX' });

if (client.hasFeature('export-csv')) showExportButton();

const off = client.onChange((ent) => rerenderPaywall(ent));
// ...
off();
client.dispose();
```

That is the entire surface most apps will touch. The rest of this
document covers the platform-specific port wiring you supply once at
boot.

---

## `VanaheimWebConfig`

| Field            | Type                  | Required | Notes                                                                                              |
|------------------|-----------------------|----------|----------------------------------------------------------------------------------------------------|
| `mode`           | `'fron'`              | yes      | Pinned to `'fron'` for now. `'l2'` is reserved for a future Alfheim-backed webview transport.      |
| `bifrostBaseUrl` | `string`              | yes      | HTTPS base URL of the customer's Bifrost deployment. SDK appends `/direct/v1/*` paths.             |
| `productSlug`    | `string`              | yes      | The slug you assigned to the product in the Vanaheim catalog. Maps to FRON's `projectId` on the wire. |
| `sdkSecret`      | `string`              | yes      | Long-lived build-time secret minted in the Vanaheim catalog. Sent verbatim under `X-Vanaheim-SDK-Secret`. |
| `storage`        | `SecureStoragePort`   | yes      | Host-supplied secure storage. **No default** — there is no generally-safe in-memory fallback for a browser. |
| `attestation`    | `AttestationPort`     | no       | When set, the SDK calls `getToken()` per request and forwards under `X-Vanaheim-Attestation`.      |
| `http`           | `HttpFetch`           | no       | Override the platform `fetch` (e.g. service-worker proxy, host-side telemetry wrapper, test stub). |

---

## Wiring the ports

The webview entry asks the host to implement three small ports.

### Capacitor (iOS / Android WebView)

```ts
import { SecureStoragePlugin } from '@capacitor-community/secure-storage';
import { PlayIntegrity } from '@capacitor-firebase/app-check';
import type { SecureStoragePort, AttestationPort } from 'vanaheim/webview';

const storage: SecureStoragePort = {
  async get(key)    { return (await SecureStoragePlugin.get({ key })).value ?? null; },
  async set(key, v) { await SecureStoragePlugin.set({ key, value: v }); },
  async remove(key) { await SecureStoragePlugin.remove({ key }); },
};

const attestation: AttestationPort = {
  kind: 'play-integrity', // or 'app-attest' on iOS
  async getToken() {
    const { token } = await PlayIntegrity.getToken({ nonce: '' });
    return token;
  },
};

// `http` is unset — Capacitor's bridged fetch is fine.
```

### Tauri (desktop)

```ts
import { Stronghold, Location } from '@tauri-apps/plugin-stronghold';
import { fetch as tauriFetch } from '@tauri-apps/plugin-http';
import type { SecureStoragePort, AttestationPort, HttpFetch } from 'vanaheim/webview';

const stronghold = await Stronghold.load('vanaheim.hold', PASSPHRASE);
const store = stronghold.loadClient('vanaheim').getStore();

const storage: SecureStoragePort = {
  async get(key)    { const b = await store.get(key); return b ? new TextDecoder().decode(new Uint8Array(b)) : null; },
  async set(key, v) { await store.insert(key, Array.from(new TextEncoder().encode(v))); await stronghold.save(); },
  async remove(key) { await store.remove(key); await stronghold.save(); },
};

// Desktop has no first-class attestation provider — leave undefined or
// stub to a constant 'none' token. Bifrost treats a missing header as
// "attestation not supplied".
const attestation: AttestationPort = {
  kind: 'none',
  async getToken() { return null; },
};

const http: HttpFetch = (url, init) => tauriFetch(url, init as Parameters<typeof tauriFetch>[1]);
```

### Pure web (browser, no native shell)

```ts
import type { SecureStoragePort, AttestationPort } from 'vanaheim/webview';

// IndexedDB + a non-extractable AES-GCM key kept in IDB.
// In production wrap the IDB key under WebAuthn-gated unlock.
const storage: SecureStoragePort = await buildIndexedDbAesGcmPort();

// reCAPTCHA Enterprise as the attestation source.
declare const grecaptcha: { execute(siteKey: string, opts: { action: string }): Promise<string> };
const attestation: AttestationPort = {
  kind: 'recaptcha',
  async getToken() {
    return grecaptcha.execute(RECAPTCHA_SITE_KEY, { action: 'vanaheim' });
  },
};
```

> **Do NOT ship `localStorage` as the storage port in production.** Plain
> `localStorage` is cleartext and readable by any JS on the page (including
> any XSS payload). The acceptable pure-web option is IndexedDB +
> Web Crypto with a non-extractable key (optionally WebAuthn-gated).

---

## End-to-end lifecycle

```ts
const client = createVanaheimClient(cfg);

// 1. Connect — boots the underlying DirectClient, loads any durable
//    identity from storage, primes the JWKS cache.
await client.connect();

// 2. Activate.
//    First-time:  pass the license key the user typed in.
//    Subsequent:  call with no args — the durable identity is on disk.
const ent = client.getEntitlements() === null
  ? await client.activate({ licenseKey: 'LCN-XXXX-XXXX-XXXX' })
  : await client.activate();

// 3. Synchronous gates (read from the in-memory entitlement snapshot).
if (client.hasFeature('export-csv')) showExportButton();
const monthlyRenders = client.quotaFor('monthly-renders'); // number | null
const tier = client.tier(); // 'free' | 'pro' | ...

// 4. React to entitlement changes (refresh / activate / deactivate /
//    heartbeat all fire the emitter). Callbacks are NOT replayed on
//    subscribe — you get the next mutation, not the current snapshot.
const off = client.onChange((ent) => {
  rerenderPaywall(ent);
});

// 5. Force a server round trip (e.g. after a portal-side tier change).
await client.refresh();

// 6. Tear down.
off();
client.dispose();
```

---

## Build-time `sdkSecret` injection

The `sdkSecret` is a build-time constant minted in the Vanaheim catalog.
Wire it into your bundler's define / env plugin so it lands as an inlined
string literal in the bundle.

| Bundler  | Snippet                                                                                  |
|----------|------------------------------------------------------------------------------------------|
| Vite     | `define: { 'import.meta.env.VITE_VANAHEIM_SDK_SECRET': JSON.stringify(process.env.VANAHEIM_SDK_SECRET) }` |
| esbuild  | `define: { 'process.env.VANAHEIM_SDK_SECRET': JSON.stringify(process.env.VANAHEIM_SDK_SECRET) }` |
| webpack  | `new webpack.DefinePlugin({ 'process.env.VANAHEIM_SDK_SECRET': JSON.stringify(process.env.VANAHEIM_SDK_SECRET) })` |
| Rollup   | `@rollup/plugin-replace`, `{ 'process.env.VANAHEIM_SDK_SECRET': JSON.stringify(...) }`   |

The SDK never logs the secret, never echoes it in error messages, and
never embeds it in URLs — it only ever flows into the
`X-Vanaheim-SDK-Secret` request header.

---

## Differences vs the Node entry (`import { DirectClient } from 'vanaheim'`)

| Concern                  | Node entry                                    | Webview entry                                                       |
|--------------------------|-----------------------------------------------|---------------------------------------------------------------------|
| Storage                  | Optional — `InMemorySecureStorage` default    | **Required** — no in-memory default (browser process is too volatile) |
| SPKI cert pinning        | Supported via `undici.Agent`                  | Not available — the host's platform owns TLS                        |
| HTTP client              | `undici` (optional dep)                       | Platform `fetch`                                                    |
| Attestation              | Off by default                                | Optional via `AttestationPort`                                      |
| Payment                  | `DirectPaymentDeepLinkHandler`                | **Deferred** — `createPaymentClient` throws (see below)             |
| Bundle topology          | Single ESM, `node:*` permitted                | Curated import closure; CSP-safe, no `node:*`, no `process.*`       |

---

## Multi-product hosts (footgun)

`SecureStoragePort` keys are NOT scoped by `productSlug`. If a single
process wires multiple `createVanaheimClient()` instances against the
**same** `SecureStoragePort` for different products, their durable
identities will collide (last-writer-wins on the device keypair, etc).

If you ship multi-product, partition the port externally — prefix every
key the port observes with the product slug:

```ts
function partitioned(slug: string, base: SecureStoragePort): SecureStoragePort {
  const ns = (k: string) => `${slug}:${k}`;
  return {
    get:    (k) => base.get(ns(k)),
    set:    (k, v) => base.set(ns(k), v),
    remove: (k) => base.remove(ns(k)),
  };
}
```

---

## What's deferred

`createPaymentClient()` is scaffolded — the `PaymentClient` interface
ships (so host code can type against it today) but the **factory throws**
when called. Browser deep-link return-trip plumbing differs structurally
from the Node entry's `DirectPaymentDeepLinkHandler` (popup / redirect /
hash-fragment vs. OS-level URL handler); the dedicated webview-shaped
implementation lands in a follow-up release. The interface is final;
the factory is not.

---

## Protocol details

For wire-level detail — the FRON envelope (X25519 + AES-GCM JWE wrapping
an Ed25519 JWS), per-route `aud` pinning, JWKS rotation, sealed-error
shapes, and the three security tiers (T0 JWKS / T1 register-with-ephemeral-JWS
/ T2 durable-JWS) — see
[`bifrost/docs/FRON_IMPL.md`](../../../bifrost/docs/FRON_IMPL.md).

The webview entry reuses the exact same JWE/JWS modules the Node entry
uses, so any FRON_IMPL.md spec text about the wire format applies
verbatim to webview hosts.

---

## License

Apache-2.0. © 2026 AJTEK.IO (OPC) Private Limited.
