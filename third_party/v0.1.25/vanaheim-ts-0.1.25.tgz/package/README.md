# Vanaheim — TypeScript SDK (Node + Browser/WebView)

TypeScript SDK for the AJTEK.IO License Store. The TS half of Vanaheim
mirrors the Dart (Flutter) and Swift (Apple platforms) SDKs in the same
[`vanaheim/`](../../) repo.

The package ships **two entry points** under one `vanaheim` install:

| Entry                                                | Use from                                            | Import                                                  |
|------------------------------------------------------|-----------------------------------------------------|---------------------------------------------------------|
| Node (default)                                       | Electron main, SSR, CLI tools, Node 20+ runtimes    | `import { DirectClient } from 'vanaheim'`              |
| Browser / WebView (added in **v0.1.15**)             | Pure web, Capacitor, Tauri, Electron renderer, RN WebView | `import { createVanaheimClient } from 'vanaheim/webview'` |

Pick by where the code runs — the wire format is identical, the bundles
are different (the webview bundle is CSP-safe with no `node:*` / `process.*`
/ `undici` references). Both can coexist in a single repo.

## Browser / WebView entry

Added in **v0.1.15**. The `vanaheim/webview` subpath ships a curated
browser-safe bundle: no `node:*` imports, no `process.*` references, no
`undici`. It exposes `createVanaheimClient()`, the `VanaheimWebConfig`
shape, and the `SecureStoragePort` / `AttestationPort` / `HttpFetch`
capability ports.

```ts
import { createVanaheimClient } from 'vanaheim/webview';

const client = createVanaheimClient({
  mode: 'fron',
  bifrostBaseUrl: 'https://bifrost.example.com',
  productSlug: 'acme-photo-studio',
  sdkSecret: import.meta.env.VITE_VANAHEIM_SDK_SECRET,
  storage,        // host-supplied — REQUIRED in the webview entry
});

await client.connect();
await client.activate({ licenseKey: 'LCN-XXXX-XXXX-XXXX' });
if (client.hasFeature('export-csv')) showExportButton();
```

Full integration guide — including Capacitor / Tauri / pure-web port
implementations, bundler-time `sdkSecret` injection patterns (Vite,
esbuild, webpack), and the differences vs the Node entry — is in
[`WEBVIEW_QUICKSTART.md`](./WEBVIEW_QUICKSTART.md).

---

## Node entry

Use this from Electron main, server-side renderers, CLI tools, and any
Node 20+ runtime that needs to activate licenses, verify entitlements,
or drive checkout flows.

> Node 20+ exclusively. Uses native `fetch`, `crypto.subtle`, and
> `crypto.sign('ed25519')`.

## Modes

Like the Dart + Swift halves, the Node SDK supports two transport modes:

| Mode | When to use |
|---|---|
| `VanaheimMode.l2` (default) | You operate an Alfheim L2 backend that brokers traffic to Bifrost. |
| `VanaheimMode.fron` | You do **not** operate a backend. The SDK speaks the FRON wire format directly to Bifrost over HTTPS. |

See the parent repo's [`QUICKSTART.md`](../../QUICKSTART.md) for the FRON
architecture overview that applies to all three SDK halves (Dart, Swift, TS).

## Install

```bash
npm install vanaheim
# or
pnpm add vanaheim
# or
yarn add vanaheim
```

Requires Node 20+ (uses built-in `fetch`, `crypto.subtle`, and
`crypto.sign('ed25519')`).

## Quickstart

A Node-specific QUICKSTART will be added once the Implement phase lands. In
the meantime, the FRON wire format, error taxonomy, and configuration knobs
described in [`../../QUICKSTART.md`](../../QUICKSTART.md) (Dart + Swift)
apply identically to this SDK.

```ts
// Placeholder — full surface lands in 0.0.23 Implement phase.
import { DirectClient, VanaheimConfig } from "vanaheim";
```

## Secure storage

Node has no built-in secure storage. This SDK exposes a `SecureStorage` port
interface; you wire your own implementation. We recommend
[`keytar`](https://www.npmjs.com/package/keytar) or
[`@napi-rs/keyring`](https://www.npmjs.com/package/@napi-rs/keyring) in
production. For unit tests an in-memory implementation ships with the SDK.

## Documentation

| Doc | Location |
|---|---|
| FRON architecture + threat model | [`../../SECURITY.md`](../../SECURITY.md) |
| L1→L2→L3 integration | [`../../INTEGRATION.md`](../../INTEGRATION.md) |
| Migration from pre-1.0 packages | [`../../MIGRATION.md`](../../MIGRATION.md) |
| Symptom → cause → fix | [`../../TROUBLESHOOTING.md`](../../TROUBLESHOOTING.md) |

For backend integration (the L2 path), see the sibling
[`alfheim/`](../../../alfheim/) repo.

## License

Apache License 2.0 — see [`LICENSE`](LICENSE).

Copyright © 2026 AJTEK.IO (OPC) Private Limited.
