# Vanaheim Dart SDK — API Reference (FRON mode)

> Man-page-level reference for `package:vanaheim` (FRON / Bifrost-Direct mode).
> Source of truth: `/Users/kanishka/kk_apps/ajtek.io_lc/vanaheim/dart/vanaheim/lib/src/direct/`.
> Wire-shape source of truth: `bifrost/packages/api-types/src/fron-parity-fixtures.json`.
> Design doc: `bifrost/docs/FRON_design.md`.

This document covers **FRON mode only** — the `DirectClient` surface that talks
straight to Bifrost via `/direct/v1/*` with no Alfheim L2 on the path. For L2
mode (`LicenseClient`) see `INTEGRATION.md` and `MIGRATION.md` in the package
root.

---

## Table of Contents

1. [Overview](#1-overview) — when to use DirectClient (FRON) vs LicenseClient (L2)
2. [Configuration](#2-configuration) — `VanaheimConfig` + `DirectConfig`
3. [Lifecycle](#3-lifecycle) — `connect`, `connectAgain`, `dispose`
4. [License & entitlement](#4-license--entitlement) — `register`, `activate`,
   `verify`, `heartbeat`, `deactivate`, `getCatalog`, `acknowledgeKidRotation`
5. [Notifications](#5-notifications) — `registerFcmToken`, `ackNotification`
6. [Telemetry](#6-telemetry) — `sendStats`, `reportError`
7. [Payment](#7-payment) — `startCheckout`, `startNativePayment`, `openPortal`,
   `restorePurchases`, `verifyIapReceipt`, `refreshAfterPayment`, browser glue
8. [Capability gates](#8-capability-gates) — `hasFeature`, `quota`, getters
9. [Error taxonomy](#9-error-taxonomy) — every `DirectError` subclass
10. [Wire protocol cheat sheet](#10-wire-protocol-cheat-sheet)

---

## 1. Overview

### Which client should I use?

| Question | `LicenseClient` (L2 mode) | `DirectClient` (FRON mode) |
| --- | --- | --- |
| Does the product team run their own Alfheim L2 backend? | yes | no |
| HTTP target | `{l2BaseUrl}/v2/...` | `{bifrostBaseUrl}/direct/v1/...` |
| Crypto envelope | JWE-required default + JWS allow-list | JWE-on-egress + durable-key JWS-on-ingress |
| Device enrollment | L2 `DevicesAPI.register` (X25519 pubkey upload) | `/direct/v1/register` (ephemeral keypair promoted on success) |
| Heartbeat scheduler | server-driven, L2 owns cadence | server-driven, Bifrost owns cadence |
| Mode selector | `VanaheimConfig.mode = VanaheimMode.l2` (default) | `VanaheimConfig.mode = VanaheimMode.fron` |

Construct via `VanaheimConfig(... mode: VanaheimMode.fron, directConfig: DirectConfig(...))`,
then either:

- Call the unified `LicenseClient.connect(config)` (factory dispatches to FRON
  internals automatically); **or**
- Call `DirectClient.connect(config: directConfig)` directly when you want
  raw FRON access without the polymorphic façade.

### FRON-mode invariants

- **Two-key identity** — every device holds a paired X25519 (JWE) + Ed25519
  (JWS) keypair. The first `register()` call generates them as *ephemeral*
  and **promotes** them to durable storage only after the server returns 2xx
  with the entitlement JWS.
- **`aud` namespace convergence (W6 D-Fix 3)** — every JWS audience is
  colon-namespaced (`direct:<area>[.endpoint]`). HTTP route paths stay
  whatever the wire requires; only the inner JWS `aud` claim is affected.
- **JWE-on-egress** — every response is a JWE wrapping an inner JWS that
  carries the claims. The SDK verifies the outer envelope, the JWS sig,
  the audience pin, the request-id, and the route-path binding before
  surfacing claims to the caller.
- **Fail-closed on revocation** — when `heartbeat()` raises
  `DirectDeviceRevokedError` the SDK **synchronously** clears
  `_entitlements`, `_cachedEntitlementJws`, and `_identity` BEFORE
  rethrowing so any racing `hasFeature()` / `quota()` call fails closed.

---

## 2. Configuration

### `VanaheimConfig` (parent — selects mode)

```dart
@immutable
class VanaheimConfig {
  VanaheimConfig({
    required this.projectId,
    required this.l2BaseUrl,
    required this.jweDecryptor,
    required this.deviceKeypairProvider,
    this.refreshBefore = const Duration(days: 1),
    this.hardOfflineGrace,
    this.pinnedSpkiSha256 = const [],
    this.jwksCacheTtl = const Duration(hours: 1),
    this.httpTimeout = const Duration(seconds: 15),
    this.clockSkew = const Duration(minutes: 5),
    this.allowDevAuthBypass = false,
    this.mode = VanaheimMode.l2,
    this.directConfig,
  });
}
```

| Field | Type | Required | Description / Constraints |
| --- | --- | --- | --- |
| `projectId` | `int` | yes | Bound into JWE AAD `<project_id>\|<route_path>\|<request_id>` and the `X-LS-Project-Id` header. |
| `l2BaseUrl` | `Uri` | yes | L2 base URL. **Ignored in FRON mode** but still required by the parent config. |
| `jweDecryptor` | `JwePayloadDecryptor` | yes | L2-mode decryptor. Unused in FRON. |
| `deviceKeypairProvider` | `DeviceKeypairProvider` | yes | L2-mode keypair provider. Unused in FRON. |
| `refreshBefore` | `Duration` | no | Proactive JWT refresh window. Default 1 d. |
| `hardOfflineGrace` | `Duration?` | no | Hard cap past server `exp`. Default null = trust server. |
| `pinnedSpkiSha256` | `List<String>` | no | L2-leg SPKI pins; FRON pins live in `DirectConfig.pinnedSpkiSha256`. |
| `jwksCacheTtl` | `Duration` | no | Default 1 h. |
| `httpTimeout` | `Duration` | no | Per-request. Default 15 s. |
| `clockSkew` | `Duration` | no | JWT iat/nbf/exp tolerance. Default 5 min. |
| `allowDevAuthBypass` | `bool` | no | `dev:<uid>:<email>` token fallback. **Never true in prod.** Default false. |
| `mode` | `VanaheimMode` | no | `l2` (default) or `fron`. |
| `directConfig` | `DirectConfig?` | conditional | **Required when** `mode == VanaheimMode.fron`; ignored otherwise. |

### `DirectConfig` (FRON-mode knobs)

```dart
@immutable
class DirectConfig {
  DirectConfig({
    required this.bifrostBaseUrl,
    required this.projectId,
    this.initialHeartbeatCadence = const Duration(hours: 24),
    this.statsFlushInterval = const Duration(minutes: 5),
    this.statsFlushBatchSize = 50,
    this.statsRingBufferCapacity = 500,
    this.httpTimeout = const Duration(seconds: 15),
    this.jwksCacheTtl = const Duration(hours: 1),
    this.pinnedSpkiSha256 = const [],
    this.swallowBackgroundErrors = true,
    this.clockSkew = const Duration(minutes: 5),
  });
}
```

| Field | Type | Required | Description / Constraints |
| --- | --- | --- | --- |
| `bifrostBaseUrl` | `Uri` | yes | e.g. `https://bifrost.example.com`. SDK appends `/direct/v1/*`. No default. |
| `projectId` | `String` | yes | Mirrored into inner-JWS claims for cross-project replay defence. |
| `initialHeartbeatCadence` | `Duration` | no | Default 24 h. Overridden by server `heartbeat_cadence_ms`. |
| `statsFlushInterval` | `Duration` | no | Default 5 min. |
| `statsFlushBatchSize` | `int` | no | Default 50. Triggers flush when buffer reaches this size. |
| `statsRingBufferCapacity` | `int` | no | Default 500. Drops oldest when full + offline. |
| `httpTimeout` | `Duration` | no | Default 15 s. |
| `jwksCacheTtl` | `Duration` | no | Default 1 h. |
| `pinnedSpkiSha256` | `List<String>` | no | Bifrost SPKI pins. Each entry must be **32 raw bytes** = 43 chars (unpadded) or 44 chars (padded) base64; `ArgumentError` at construction otherwise (W6 D-Fix 2). Empty = pinning disabled (dev only). |
| `swallowBackgroundErrors` | `bool` | no | Default true. Background heartbeat/stats failures don't bubble to UI. |
| `clockSkew` | `Duration` | no | JWS iat/nbf/exp tolerance. Default 5 min. |

### `VanaheimMode`

```dart
enum VanaheimMode { l2, fron }
```

---

## 3. Lifecycle

### `DirectClient.connect`

**Signature**
```dart
static Future<DirectClient> connect({
  required DirectConfig config,
  SecureCache? cache,
  PushTokenProvider? push,
  http.Client? httpClient,
})
```

**Description.** Sole construction entry point. Pulls JWKS, loads any durable
identity left by a previous run, restores pending stats events from disk, and
wires the heartbeat scheduler + stats batcher + (optional) FCM bridge. Returns
with schedulers **wired but not started** — they kick on after the first
successful `register()` / `activate()` / `verify()`.

**Parameters**

| Name | Type | Required | Description / Constraints |
| --- | --- | --- | --- |
| `config` | `DirectConfig` | yes | See §2. |
| `cache` | `SecureCache?` | no | Defaults to `FlutterSecureCache()`. Inject for test/non-Flutter. |
| `push` | `PushTokenProvider?` | no | Wires `DirectFcmBridge`. `NoPushTokenProvider` (or null) disables FCM. |
| `httpClient` | `http.Client?` | no | Defaults to `http.Client()`. Inject for test/proxy. |

**Returns.** `Future<DirectClient>` — fully wired. Inspect `isRegistered`
to decide whether to call `register()` (false → first boot) or
`activate()/verify()` (true → returning user).

**Throws.** Never throws on JWKS fetch failure (lazy retry); never throws on
absent durable identity. Constructor errors (e.g. malformed pin) surface as
`ArgumentError` from `DirectConfig`'s own validator.

**Wire protocol.** Pre-fetches `GET {bifrostBaseUrl}/direct/v1/keys` (JWKS).
No other calls.

**Example.**
```dart
final client = await DirectClient.connect(
  config: DirectConfig(
    bifrostBaseUrl: Uri.parse('https://bifrost.example.com'),
    projectId: 'com.example.zenkit',
    pinnedSpkiSha256: const ['Pa2vlV9yE+iA…43chars…'],
  ),
);
if (!client.isRegistered) {
  await client.register(licenseKey: ..., fingerprint: ...);
}
```

**Security notes.** Cert pinning is wired BEFORE any request body crosses the
TLS boundary. Malformed pins throw `ArgumentError` at `DirectConfig`
construction — fail loudly so the operator notices.

---

### `connectAgain`

**Signature**
```dart
Future<void> connectAgain()
```

**Description.** Re-fetches JWKS (`force=true`) and reloads durable identity.
Idempotent. Useful for tests + manual recovery flows after a long sleep where
the JWKS TTL has lapsed silently.

**Returns.** `Future<void>`.

**Throws.** `NetworkException` if JWKS refresh fails.

**Wire protocol.** `GET /direct/v1/keys` (forced).

**Example.**
```dart
await client.connectAgain(); // before a sensitive call after device wake
```

---

### `dispose`

**Signature**
```dart
Future<void> dispose()
```

**Description.** Tears down the heartbeat scheduler, flushes + closes the
stats batcher, and stops the FCM bridge. **Idempotent** — safe to call from a
`finalize`/`teardown` block that may run more than once.

**Returns.** `Future<void>` once all schedulers are quiet and pending stats
are persisted.

**Throws.** Never. Background errors are caught + swallowed.

**Security notes.** Pending stats events are persisted via `SecureCache`
before disposal completes — calling `dispose` does not lose telemetry.

---

## 4. License & entitlement

### `register`

**Signature**
```dart
Future<RegisterResult> register({
  required String licenseKey,
  required String fingerprint,
  Map<String, dynamic> appMeta = const {},
})
```

**Description.** First-boot registration. Generates an ephemeral X25519 +
Ed25519 pair, signs the inner JWS with the ephemeral Ed25519 key, JWE-wraps
for Bifrost. On 2xx promotes the ephemeral pair to durable storage and
persists the server-issued `device_id` + `server_nonce`. Starts the heartbeat
scheduler using the server-supplied cadence.

**Parameters**

| Name | Type | Required | Description / Constraints |
| --- | --- | --- | --- |
| `licenseKey` | `String` | yes | The license key the user pasted. Server validates format. |
| `fingerprint` | `String` | yes | Device fingerprint (host product computes). |
| `appMeta` | `Map<String, dynamic>` | no | Free-form app metadata. Default empty. |

**Returns.** `RegisterResult`:

| Field | Type | Description |
| --- | --- | --- |
| `deviceId` | `String` | Server-minted, stable across SDK restarts. |
| `serverNonce` | `String` | Anti-keypair-reuse echo claim. Persisted; echoed on every durable call. |
| `entitlementJws` | `String` | Compact JWS; persist for offline re-verification. |
| `entitlements` | `DirectEntitlements` | Decoded snapshot — `tier`, `version`, `features`, `quotas`. |
| `heartbeatCadenceMs` | `int` | Server-authoritative cadence (24 h free / 1 h paid by default). |

**Throws.**
- `DirectLicenseInvalidError` — license not found / malformed.
- `DirectLicenseExpiredError` — license past valid_until.
- `DirectSeatExceededError` — cap reached; UX should prompt deactivate-other-device.
- `DirectProjectDisabledError` — project didn't opt into FRON mode.
- `DirectReplayDetectedError` — ephemeral pubkey thumbprint in anti-reuse ledger.
- `DirectRateLimitError` — server saturated; respect `retryAfterMs`.
- `DirectBadRequestError` — request shape failed validation.
- `NetworkException` — transport timeout / 5xx / DNS / TLS.
- `CertificatePinException` — SPKI mismatch; treat as MITM.
- `LicenseStoreException` — `device_id` / `entitlement_jws` missing in response.

**Wire protocol.** `POST /direct/v1/register` with body
`{project_id, license_key, fingerprint, app_meta, ephemeral_pubkey (auto)}`.
Inner JWS `aud = "direct:register"`. Fixture key: `register.request.body` /
`register.response.claims` in `fron-parity-fixtures.json`.

**Example.**
```dart
final res = await client.register(
  licenseKey: 'LS-XXXX-XXXX-XXXX',
  fingerprint: await computeFingerprint(),
  appMeta: {'app_version': '1.4.2', 'os': 'ios'},
);
await secureStore.write('entitlement_jws', res.entitlementJws);
```

**Security notes.** The `ephemeral_pubkey` field is auto-injected by
`DirectRequestBuilder` so it always equals the JWS header `device_pub_jwk.x`
— **do not set it manually**. The builder owns that binding to defend against
caller-side desync. The `project_id` is duplicated in the inner-JWS top level
**and** the body so the server's `assertRegisterBody` can cross-check both.

---

### `activate`

**Signature**
```dart
Future<ActivateResult> activate(String licenseKey)
```

**Description.** Re-activate against a (potentially new) license key — e.g.
post-purchase upgrade or after a key migration. Updates local
entitlements + cached JWS in-place.

**Parameters**

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `licenseKey` | `String` | yes | New / refreshed license key. |

**Returns.** `ActivateResult { deviceId, entitlementJws, entitlements }`.

**Throws.**
- `NotConnectedException` — `register()` has not yet succeeded.
- `DirectLicenseInvalidError`, `DirectLicenseExpiredError`,
  `DirectSeatExceededError`, `DirectDeviceRevokedError`,
  `DirectRateLimitError`, `DirectBadRequestError`.
- `NetworkException`, `CertificatePinException`.

**Wire protocol.** `POST /direct/v1/activate` with body `{license_key}`. Inner
JWS `aud = "direct:activate"`. Tier 2 (durable JWS).

**Example.**
```dart
final res = await client.activate('LS-NEW-KEY');
// hasFeature() now reflects the new tier.
```

**Security notes.** Server may rotate `server_nonce` on this call; the SDK
does NOT automatically update its stored nonce on `activate` (only `verify`
does that, see below). If you change keys frequently, follow with `verify()`.

---

### `verify`

**Signature**
```dart
Future<VerifyResult> verify()
```

**Description.** Pulls a fresh entitlement JWS, refreshes local state, and
applies any server-supplied heartbeat cadence override. Also rotates the
stored `server_nonce` when the server provides a new one.

**Parameters.** None.

**Returns.** `VerifyResult`:

| Field | Type | Description |
| --- | --- | --- |
| `entitlementJws` | `String` | Compact JWS — re-persist for offline re-verify. |
| `entitlements` | `DirectEntitlements` | Decoded snapshot. |
| `issuedAtMs` | `int` | Server wall clock at issue. Drift-correct against local clock. |

**Throws.** `NotConnectedException`, `DirectDeviceRevokedError`,
`DirectRateLimitError`, `DirectBadRequestError`, `NetworkException`,
`CertificatePinException`.

**Wire protocol.** `POST /direct/v1/verify` with empty body. Inner JWS
`aud = "direct:verify"`.

**Example.**
```dart
final fresh = await client.verify();
final clockSkew = DateTime.now().millisecondsSinceEpoch - fresh.issuedAtMs;
```

**Security notes.** When the server rotates `server_nonce` here, the SDK
calls `_keys.updateServerNonce(...)` so future durable calls echo the new
value. Failing to surface this rotation (e.g. crashing between the parse and
the persist) would mean the next call gets rejected; the SDK does the writes
in single awaits to minimise the window.

---

### `heartbeat`

**Signature**
```dart
Future<HeartbeatResult> heartbeat()
```

**Description.** Keep-alive + revoke probe. Driven by `DirectHeartbeatScheduler`
on a background timer at the server-supplied cadence; callable directly for
manual flush (e.g. after app foregrounds). Updates entitlements + cadence
in-place when the server pushes a new bundle.

**Returns.** `HeartbeatResult`:

| Field | Type | Description |
| --- | --- | --- |
| `alive` | `bool` | True = device still authorised. False only via thrown `DirectDeviceRevokedError`. |
| `entitlementJws` | `String?` | Null when no tier change since last call. |
| `entitlements` | `DirectEntitlements?` | Non-null iff `entitlementJws` is non-null. |
| `heartbeatCadenceMs` | `int?` | Server cadence override; null = keep prior. |

**Throws.** `DirectDeviceRevokedError` — see security note below.
Plus: `NotConnectedException`, `DirectRateLimitError`, `NetworkException`,
`CertificatePinException`.

**Wire protocol.** `POST /direct/v1/heartbeat` with empty body. Inner JWS
`aud = "direct:heartbeat"`.

**Example.**
```dart
try {
  await client.heartbeat();
} on DirectDeviceRevokedError {
  // SDK already cleared local state; show "session revoked" UX.
  navigateToSignedOutScreen();
}
```

**Security notes (CRITICAL).** When `DirectDeviceRevokedError` fires the SDK
**synchronously** clears `_entitlements`, `_cachedEntitlementJws`, and
`_identity` BEFORE rethrowing — so any racing `hasFeature()`/`quota()` from
another isolate gate fails closed. Storage is wiped via `_keys.clear()`; the
scheduler is stopped. **Do not catch-and-continue** without redirecting the
user to a re-register flow.

---

### `deactivate`

**Signature**
```dart
Future<void> deactivate(String reason)
```

**Description.** Graceful uninstall / device-swap. Tells the server to free
the seat, then clears local durable keypair + entitlements + stops the
heartbeat scheduler.

**Parameters**

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `reason` | `String` | yes | Free-form audit log line (e.g. `"user_uninstall"`, `"device_swap"`). |

**Returns.** `Future<void>`.

**Throws.** `NotConnectedException`, `DirectRateLimitError`,
`NetworkException`, `CertificatePinException`. **Note** — the local wipe runs
only on 2xx; if the server call fails, durable state remains so a retry can
attempt deactivation again.

**Wire protocol.** `POST /direct/v1/deactivate` with body `{reason}`. Inner
JWS `aud = "direct:deactivate"`.

**Example.**
```dart
await client.deactivate('user_uninstall');
await client.dispose();
```

---

### `getCatalog`

**Signature**
```dart
Future<CatalogSnapshot> getCatalog()
```

**Description.** Encrypted catalog pull — returns tier names, feature
matrices, and minor-unit prices for the upgrade UI.

**Returns.** `CatalogSnapshot`:

| Field | Type | Description |
| --- | --- | --- |
| `version` | `int` | Monotonic; caller can short-circuit if unchanged. |
| `tiers` | `List<DirectTierInfo>` | Ordered cheapest → most expensive. |
| `raw` | `Map<String, dynamic>` | Raw JSON for products that render custom UI. |

`DirectTierInfo`:

| Field | Type | Description |
| --- | --- | --- |
| `id` | `String` | Tier slug (matches `tier` arg in `startCheckout`). |
| `displayName` | `String` | User-facing label. |
| `features` | `List<String>` | Feature flags this tier unlocks. |
| `priceMinor` | `int?` | Minor units; null on free tiers. |
| `currency` | `String?` | ISO-4217; null when `priceMinor` is null. |

**Throws.** `NotConnectedException`, `DirectRateLimitError`,
`NetworkException`, `CertificatePinException`.

**Wire protocol.** `POST /direct/v1/catalog` with empty body. Inner JWS
`aud = "direct:catalog"`.

**Example.**
```dart
final cat = await client.getCatalog();
for (final tier in cat.tiers) {
  print('${tier.displayName}: ${tier.priceMinor} ${tier.currency}');
}
```

---

### `acknowledgeKidRotation`

**Signature**
```dart
Future<void> acknowledgeKidRotation(String kid)
```

**Description.** Acknowledge the SDK observed a JWKS `kid` rotation. The
server uses these acks to count down the grace period before dropping the
stale `kid` from its trust list. After the ack succeeds, the SDK eagerly
refreshes its local JWKS so subsequent calls verify against the new signing
key (no waiting for TTL).

**Parameters**

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `kid` | `String` | yes | The stale `kid` the SDK is now done with. |

**Throws.** `NotConnectedException`, `NetworkException`.

**Wire protocol.** `POST /direct/v1/keys/rotate-ack` with body `{kid}`. Inner
JWS `aud = "direct:keys.rotate_ack"`.

**Example.**
```dart
// After verifier surfaces "kid is deprecated" via SDK telemetry:
await client.acknowledgeKidRotation(oldKid);
```

---

## 5. Notifications

### `registerFcmToken`

**Signature**
```dart
Future<void> registerFcmToken(String token, String platform)
```

**Description.** Register / refresh an FCM (Android) or APNs (iOS) device
token so Bifrost can push entitlement updates and license events.
Automatically driven by `DirectFcmBridge` when a `PushTokenProvider` was
passed to `connect()`; callable directly for manual refreshes.

**Parameters**

| Name | Type | Required | Description / Constraints |
| --- | --- | --- | --- |
| `token` | `String` | yes | Push token. Provider-supplied. |
| `platform` | `String` | yes | `"ios"` / `"android"` / `"web"`. |

**Throws.** `DirectFcmTokenReusedError` — token already bound to a different
device; caller should rotate. Plus: `NotConnectedException`, generic FRON
errors.

**Wire protocol.** `POST /direct/v1/notifications/register-fcm` with body
`{fcm_token, platform}`. Inner JWS `aud = "direct:notifications.register_fcm"`.

**Example.**
```dart
final fcmToken = await FirebaseMessaging.instance.getToken();
await client.registerFcmToken(fcmToken!, 'android');
```

**Security notes.** FCM tokens are PII-adjacent — log only via `hash(token)`
in production telemetry.

---

### `ackNotification`

**Signature**
```dart
Future<void> ackNotification(
  String notificationId,
  int receivedAtMs, {
  bool? displayed,
})
```

**Description.** Delivery confirmation for a server-initiated push. The
server uses ACKs to deduplicate retries and to drive analytics on push
deliverability (`displayed=false` indicates suppressed-by-OS).

**Parameters**

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `notificationId` | `String` | yes | Echo of `notification_id` from the push payload. |
| `receivedAtMs` | `int` | yes | Local wall-clock at receipt (epoch ms). |
| `displayed` | `bool?` | no | True = banner shown; false = suppressed; null = unknown. |

**Throws.** Generic FRON errors.

**Wire protocol.** `POST /direct/v1/notifications/ack` with body
`{notification_id, received_at_ms, displayed?}`. Inner JWS
`aud = "direct:notifications.ack"`.

**Example.**
```dart
FirebaseMessaging.onMessage.listen((m) {
  client.ackNotification(m.messageId!, DateTime.now().millisecondsSinceEpoch,
      displayed: true);
});
```

---

## 6. Telemetry

### `sendStats`

**Signature**
```dart
Future<StatsResult> sendStats(List<StatsEvent> events)
```

**Description.** **Enqueue** events into the in-memory batcher — does NOT
make a network call directly. The batcher flushes on its own cadence
(`statsFlushInterval`) and on size triggers (`statsFlushBatchSize`); flushes
hit `/direct/v1/telemetry/stats` and post-process the receipt.

**Parameters**

| Name | Type | Required | Description / Constraints |
| --- | --- | --- | --- |
| `events` | `List<StatsEvent>` | yes | Each event ≤ a few KB. Large blobs belong on a file-upload API. |

`StatsEvent`:

| Field | Type | Description |
| --- | --- | --- |
| `name` | `String` | Event name (snake_case convention). |
| `timestampMs` | `int` | Epoch ms at occurrence. |
| `attributes` | `Map<String, dynamic>` | Free-form payload. Default empty. |

**Returns.** `StatsResult { accepted, rejected }`. When called from
`sendStats` (vs the batcher's flush), `accepted` always equals `events.length`
and `rejected` is 0 — the result is the *enqueue* receipt, not the wire
receipt. The wire receipt is surfaced via `swallowBackgroundErrors` /
zone-error handlers.

**Throws.** Never (enqueue path). Background flush failures surface only when
`swallowBackgroundErrors == false`.

**Wire protocol (background flush).** `POST /direct/v1/telemetry/stats` with
body `{events: [...]}`. Inner JWS `aud = "direct:telemetry.stats"`.

**Example.**
```dart
await client.sendStats([
  StatsEvent(
    name: 'export_run',
    timestampMs: DateTime.now().millisecondsSinceEpoch,
    attributes: {'rows': 1024},
  ),
]);
```

**Security notes.** Events ride out an offline window in the ring buffer
(`statsRingBufferCapacity = 500` default); the oldest are dropped on overflow.
Persistence is via `SecureCache`, not plaintext disk.

---

### `reportError`

**Signature**
```dart
Future<ErrorResult> reportError(ErrorReport error)
```

**Description.** Submit a single crash/error report — synchronous wire call,
NOT batched. Rate-limited by the server; check `result.throttled` to back
off.

**Parameters**

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `error` | `ErrorReport` | yes | See below. |

`ErrorReport`:

| Field | Type | Required | Description / Constraints |
| --- | --- | --- | --- |
| `message` | `String` | yes | One-line summary. |
| `stack` | `String?` | no | Stack trace. |
| `severity` | `String?` | no | One of `"fatal"`, `"error"`, `"warn"`, `"info"`. |
| `context` | `Map<String, dynamic>` | no | Free-form. Default empty. |

**Returns.** `ErrorResult { errorId, throttled }`. `errorId` surfaces in
support tickets so SRE can pivot.

**Throws.** `NotConnectedException`, `DirectRateLimitError` (with
`retryAfterMs`), generic FRON errors.

**Wire protocol.** `POST /direct/v1/telemetry/error` with body matching
`ErrorReport.toJson()`. Inner JWS `aud = "direct:telemetry.error"`.

**Example.**
```dart
try {
  await doRisky();
} catch (e, st) {
  final r = await client.reportError(ErrorReport(
    message: e.toString(),
    stack: st.toString(),
    severity: 'error',
  ));
  if (r.throttled) backoffReporting();
}
```

**Security notes.** Strip PII from `context` before submission — the server
does not run a PII scrubber.

---

## 7. Payment

All six payment methods live on the `DirectPaymentMethods` extension. Import
them via `package:vanaheim/vanaheim.dart`. The extension is intentionally
tree-shake-friendly — products that never reference payment methods don't
retain the payment-side error taxonomy.

### `startCheckout`

**Signature**
```dart
Future<CheckoutSession> startCheckout({
  required String tier,
  required String billingCycle,
  required String currency,
  required String returnUrl,
  String? cancelUrl,
  String? provider,
})
```

**Description.** Start a provider-hosted checkout (Stripe Checkout / Paddle /
Lemon Squeezy / Razorpay). Returns the hosted URL + session id; host app
drives a browser to the URL via `openCheckoutUrl()` and calls
`refreshAfterPayment(sessionId: ...)` once the return-URL deep link fires.

**Parameters**

| Name | Type | Required | Description / Constraints |
| --- | --- | --- | --- |
| `tier` | `String` | yes | Must match `^[a-z0-9_]{1,64}$`. |
| `billingCycle` | `String` | yes | `"monthly"` or `"yearly"`. |
| `currency` | `String` | yes | ISO-4217 `^[A-Z]{3}$`. |
| `returnUrl` | `String` | yes | `https://...` or app-custom scheme; ≤ 2048 chars. |
| `cancelUrl` | `String?` | no | Same constraints as `returnUrl`. |
| `provider` | `String?` | no | One of `stripe`/`paddle`/`lemon_squeezy`/`razorpay`. Server enforces project allowlist. |

**Returns.** `CheckoutSession { sessionId, hostedUrl, expiresAtMs }`.

**Throws.**
- `DirectBadRequestError` — client-side validation (tier regex, currency,
  scheme, provider tag).
- `DirectNoProviderConfiguredError` — no payment provider wired for project.
- `DirectPaymentProviderFailedError` — opaque provider-side failure (server
  scrubs provider text; only coarse provider tag surfaces).
- `NotConnectedException`, `NetworkException`, `DirectRateLimitError`.

**Wire protocol.** `POST /direct/v1/payment/checkout` with body
`{project_id, tier, billing_cycle, currency, return_url, cancel_url?, provider?}`.
Inner JWS `aud = "direct:payment.checkout"`. Fixture key:
`payment.checkout.*` in `fron-parity-fixtures.json`.

**Example.**
```dart
final session = await client.startCheckout(
  tier: 'pro_yearly',
  billingCycle: 'yearly',
  currency: 'USD',
  returnUrl: 'myapp://upgrade-done',
);
await openCheckoutUrl(session, opener: opener);
```

**Security notes.** Non-https URLs are rejected at the SDK layer before the
wire hit; custom app schemes (`myapp://`) are allowed but blocked schemes
(`javascript:`, `data:`, `file:`, `ftp:`, `vbscript:`) are refused. The
`provider` flag is server-validated against the project's
`allow_provider_override` setting — host apps can't bypass that gate.

---

### `startNativePayment`

**Signature**
```dart
Future<PaymentIntent> startNativePayment({
  required String tier,
  required String billingCycle,
  required String currency,
  required String platform,
  String? provider,
})
```

**Description.** Mint a provider intent for the platform's native payment
sheet (Stripe Payment Sheet, Apple Pay, Google Pay). Pass the returned
`clientSecret` to the platform API verbatim.

**Parameters**

| Name | Type | Required | Description / Constraints |
| --- | --- | --- | --- |
| `tier` | `String` | yes | Same constraints as `startCheckout`. |
| `billingCycle` | `String` | yes | `monthly` / `yearly`. |
| `currency` | `String` | yes | ISO-4217. |
| `platform` | `String` | yes | `ios` / `android` / `web`. |
| `provider` | `String?` | no | Provider tag. |

**Returns.** `PaymentIntent { intentId, clientSecret, expiresAtMs }`.

**Throws.** Same as `startCheckout`.

**Wire protocol.** `POST /direct/v1/payment/intent`. Inner JWS
`aud = "direct:payment.intent"`.

**Example.**
```dart
final intent = await client.startNativePayment(
  tier: 'pro_monthly', billingCycle: 'monthly',
  currency: 'USD', platform: 'ios',
);
await Stripe.instance.initPaymentSheet(
  paymentIntentClientSecret: intent.clientSecret,
);
```

**Security notes.** **Do NOT log `clientSecret`** — it grants payment
authorisation. The SDK does not retain it after returning.

---

### `openPortal`

**Signature**
```dart
Future<PortalSession> openPortal({required String returnUrl})
```

**Description.** Mint a customer-portal URL (Stripe Billing Portal / Paddle
customer portal / etc.) so the user can manage their subscription. Host app
drives a browser to the URL via `openPortalUrl()`.

**Parameters**

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `returnUrl` | `String` | yes | https or custom scheme; ≤ 2048 chars. |

**Returns.** `PortalSession { portalUrl, expiresAtMs }`.

**Throws.**
- `DirectNoActiveSubscriptionError` — device has no active/trialing sub;
  route the user through `startCheckout` instead.
- Generic FRON / payment errors.

**Wire protocol.** `POST /direct/v1/payment/portal`. Inner JWS
`aud = "direct:payment.portal"`.

**Example.**
```dart
final portal = await client.openPortal(returnUrl: 'myapp://billing-done');
await openPortalUrl(portal, opener: opener);
```

---

### `restorePurchases`

**Signature**
```dart
Future<RestoreResult> restorePurchases({required String platform})
```

**Description.** Restore device-bound purchases (iOS reinstall / Android
account sign-in). On non-empty restore, the SDK **automatically adopts** the
returned entitlement JWS as its current bundle (via
`adoptEntitlementJwsInternal`) so subsequent `hasFeature()` / `quota()` calls
immediately reflect the restored tier.

**Parameters**

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `platform` | `String` | yes | `ios` / `android` (no `web`). |

**Returns.** `RestoreResult`:

| Field | Type | Description |
| --- | --- | --- |
| `restored` | `List<RestoredPurchase>` | Per-row `{licenseKey, tier, validUntil}`. Capped at 100 (defence-in-depth). |
| `entitlementJws` | `String?` | Fresh JWS minted off longest-valid purchase. Null when `restoredCount == 0`. |
| `restoredCount` | `int` | Server-supplied count. |

**Invariant.** `restoredCount > 0` ⇒ `entitlementJws != null` (server-side
hard-fail on the half-success path; see `payment.ts` B-FRON.5.4).

**Throws.** `DirectPaymentProviderFailedError` (`provider == "restore"`),
generic FRON errors.

**Wire protocol.** `POST /direct/v1/payment/restore`. Inner JWS
`aud = "direct:payment.restore"`.

**Example.**
```dart
final r = await client.restorePurchases(platform: 'ios');
if (r.restoredCount == 0) showSnack('No purchases to restore.');
```

**Security notes.** Defence-in-depth bound at 100 rows in
`RestoreResult.fromJson` prevents a malicious or buggy server from OOM-ing
the SDK with an unbounded restore set.

---

### `verifyIapReceipt`

**Signature**
```dart
Future<IapVerifyResult> verifyIapReceipt({
  required String platform,
  required String receipt,
})
```

**Description.** Verify an App Store / Play Store receipt server-side. On
success the server binds `license_key → device` and returns a fresh
entitlement JWS (auto-adopted by the SDK). On soft-rejection the result is
`valid=false` + a narrow `reason`. **Hard provider failures** (Apple/Google
API down) surface as a thrown `DirectPaymentProviderFailedError` rather than
a `valid=false` result so the retry classifier handles them uniformly.

**Parameters**

| Name | Type | Required | Description / Constraints |
| --- | --- | --- | --- |
| `platform` | `String` | yes | `ios` / `android`. |
| `receipt` | `String` | yes | Non-empty; ≤ `kIapReceiptMaxBytes` = **24 KB**. |

**Returns.** `IapVerifyResult`:

| Field | Type | Description |
| --- | --- | --- |
| `valid` | `bool` | True iff server bound a license. |
| `licenseKey` | `String?` | Bound license key on success. |
| `tier` | `String?` | Bound tier on success. |
| `validUntil` | `int?` | Epoch ms entitlement-window end. |
| `entitlementJws` | `String?` | Fresh JWS; auto-adopted when `valid`. |
| `reason` | `String?` | Soft-rejection reason: `unknown` / `expired` / `consumed` / `cross_account`. |

**Throws.**
- `DirectBadRequestError` — empty or oversized receipt (client-side, before
  wire hit).
- `DirectPaymentProviderFailedError` (`provider == "apple_iap"`/`"google_iap"`)
  — provider outage.
- Generic FRON errors.

**Wire protocol.** `POST /direct/v1/payment/iap-verify`. Inner JWS
`aud = "direct:payment.iap_verify"`.

**Example.**
```dart
final r = await client.verifyIapReceipt(platform: 'ios', receipt: signedJws);
if (!r.valid) handleReason(r.reason); // 'expired', etc.
```

**Security notes (W6 D-Fix 3).** The 24 KB cap matches Swift parity. Apple
signed JWS receipts run 4-8 KB; if you're hitting this cap, something is
wrong with the receipt source. The cap stays just above the server's 16 KB
ceiling so you fail fast without burning rate-limit budget.

---

### `refreshAfterPayment`

**Signature**
```dart
Future<VerifyResult> refreshAfterPayment({String? sessionId})
```

**Description.** Force-refresh entitlements after a checkout / payment
completes. When `sessionId` is supplied the server **confirms the webhook
has flipped the session to `completed=true`** before re-minting; otherwise
the call degrades to a `/verify`-equivalent. Returns the same shape as
`verify()` so callers can treat results identically. Auto-adopts the new
JWS into local state.

**Parameters**

| Name | Type | Required | Description |
| --- | --- | --- | --- |
| `sessionId` | `String?` | no | Checkout session id (omit for native-payment-sheet flows). |

**Returns.** `VerifyResult` (see §4).

**Throws.**
- `DirectSessionNotFoundError` — unknown or wrong-device session id.
- `DirectSessionNotCompleteError` — webhook hasn't reconciled yet; back off
  + retry.
- `LicenseStoreException` — server response missing `entitlement_jws`.
- Generic FRON errors.

**Wire protocol.** `POST /direct/v1/payment/refresh`. Inner JWS
`aud = "direct:payment.refresh"`.

**Example.**
```dart
DirectPaymentDeepLinkHandler.instance.onReturn.listen((ret) async {
  if (ret.sessionId == null) return;
  try {
    final fresh = await client.refreshAfterPayment(sessionId: ret.sessionId);
    rerenderEntitlements(fresh.entitlements);
  } on DirectSessionNotCompleteError {
    scheduleRetry(after: const Duration(seconds: 3));
  }
});
```

---

### Payment browser glue (no wire calls)

#### `openCheckoutUrl` / `openPortalUrl`

```dart
Future<void> openCheckoutUrl(CheckoutSession session,
    {required DirectPaymentUrlOpener opener});

Future<void> openPortalUrl(PortalSession portal,
    {required DirectPaymentUrlOpener opener});
```

Rejects non-https URLs at SDK layer (raises `ArgumentError`). Rethrows
whatever the opener throws.

#### `DirectPaymentUrlOpener`

```dart
class DirectPaymentUrlOpener {
  final DirectPaymentUrlOpenerFn open;       // Future<void> Function(String url)
  final String label;                        // diagnostic tag
  const DirectPaymentUrlOpener({required this.open, this.label = 'host-opener'});
}
```

#### `DirectPaymentDeepLinkHandler` (singleton)

| Member | Signature | Description |
| --- | --- | --- |
| `instance` | `static DirectPaymentDeepLinkHandler instance` | Process-wide singleton. |
| `onReturn` | `Stream<DirectPaymentReturn>` | Broadcast of parsed deep-link returns. |
| `handleReturnUri(Uri)` | `DirectPaymentReturn?` | Parses `session_id` / `intent_id` / `status` query params; emits + returns when recognised, null otherwise. |
| `dispose()` | `Future<void>` | Test seam — closes the broadcast stream. |

`DirectPaymentReturn { sessionId?, intentId?, cancelled }`.

---

## 8. Capability gates

### `hasFeature` (instance method)

**Signature**
```dart
bool hasFeature(String name)
```

**Description.** Local-only entitlement check. **Never** hits the network.
Returns `false` when no entitlements have been fetched yet — caller must
have completed `register()`/`activate()`/`verify()` (or restore/iap-verify)
first.

**Returns.** `bool`. `true` iff feature flag is present and truthy
(`bool true`, non-zero `num`, or any non-bool/non-num value).

**Throws.** Never.

**Example.**
```dart
if (client.hasFeature('export_pdf')) showExportButton();
```

**Security notes.** Fails CLOSED on revocation — `heartbeat` clears
`_entitlements` BEFORE rethrowing `DirectDeviceRevokedError`.

---

### `quota`

**Signature**
```dart
int quota(String name)
```

**Description.** Local quota lookup. Returns `0` when entitlements have not
been fetched OR the quota isn't defined for the current tier. **Caller must
treat 0 as "deny"** rather than "unlimited".

**Returns.** `int`.

**Throws.** Never.

**Example.**
```dart
final maxSeats = client.quota('max_seats');
if (maxSeats == 0) showUpgradePrompt();
```

---

### Getters

| Getter | Signature | Description |
| --- | --- | --- |
| `isRegistered` | `bool get isRegistered` | True iff a durable identity is loaded. False ⇒ caller must call `register()`. |
| `projectId` | `String get projectId` | Project id passed to `DirectConfig`. Exposed for SDK-private extensions. |
| `entitlements` | `DirectEntitlements? get entitlements` | Currently-known entitlements; null until first successful call. |
| `entitlementJws` | `String? get entitlementJws` | Compact entitlement JWS for offline re-verification persistence. |

### `DirectEntitlements`

```dart
@immutable
class DirectEntitlements {
  final String tier;                       // tier slug
  final int version;                       // monotonic version
  final Map<String, dynamic> features;     // unmodifiable
  final Map<String, int> quotas;           // unmodifiable

  bool has(String name);                   // feature truthiness
  int quotaFor(String name);               // 0 when missing
  factory DirectEntitlements.fromJson(Map<String, dynamic> j);
}
```

---

### SDK-private seams (`@internal`)

These two methods exist so the `DirectPaymentMethods` extension can reuse the
crypto path without duplicating it. They are **not part of the public
surface** — host products MUST NOT call them.

| Method | Signature | Purpose |
| --- | --- | --- |
| `callDurableInternal` | `Future<Map<String, dynamic>> callDurableInternal({required String routePath, required Map<String, dynamic> body, String? aud})` | Tier 2 (durable JWS) call returning raw verified claims. Used by all 6 payment methods. |
| `adoptEntitlementJwsInternal` | `DirectEntitlements adoptEntitlementJwsInternal(String entJws)` | Decode + adopt a JWS bundle as current state. Used by `restorePurchases`, `verifyIapReceipt`, `refreshAfterPayment`. |

---

## 9. Error taxonomy

All FRON errors derive from `DirectError`, which itself extends
`LicenseStoreException` — so existing `try { ... } on LicenseStoreException`
blocks keep working. Every subclass exposes a stable `code` string that
matches the Bifrost wire code 1:1 (see
`bifrost/packages/functions/src/direct/errors.ts`).

### Base class

```dart
abstract class DirectError extends LicenseStoreException {
  final String code; // e.g. "DIRECT_LICENSE_INVALID"
  DirectError(this.code, String message, {Object? cause});
}
```

### Subclass table

| Class | Wire code | Triggered when | How to handle |
| --- | --- | --- | --- |
| `DirectBadRequestError` | `DIRECT_BAD_REQUEST` | Request shape failed validation (server) OR client-side guard (tier slug, currency, receipt size, URL scheme). | Bug — fix call site. Never retry. |
| `DirectLicenseInvalidError` | `DIRECT_LICENSE_INVALID` | License key not found, malformed, or refused. | Prompt user to re-enter key. |
| `DirectLicenseExpiredError` | `DIRECT_LICENSE_EXPIRED` | License past `valid_until`. | Prompt renewal. |
| `DirectSeatExceededError` | `DIRECT_LICENSE_SEAT_EXCEEDED` | Seat cap reached. | Prompt deactivate-another-device or upgrade. |
| `DirectRateLimitError` | `DIRECT_RATE_LIMITED` / `DIRECT_RATE_LIMIT` | Server saturated. Exposes `int retryAfterMs`. | Back off `retryAfterMs` and retry; surface UX after the second 429. |
| `DirectFcmTokenReusedError` | `DIRECT_FCM_TOKEN_REUSED` | Supplied push token already bound to a different device. | Force FCM token rotation, then re-register. |
| `DirectNoProviderConfiguredError` | `DIRECT_NO_PROVIDER_CONFIGURED` | Project has no provider wired for the capability (payment, KYC, etc.). | Surface "ask the app developer to wire X". |
| `DirectProviderFailedError` | `DIRECT_<area>_FAILED` (catch-all) | Generic provider outage. Exposes `String providerCode` with the full wire string. | Treat as transient; retry with backoff. |
| `DirectProjectDisabledError` | `DIRECT_PROJECT_DISABLED` | Project didn't opt into FRON mode. | Surface "contact the app developer". |
| `DirectReplayDetectedError` | `DIRECT_REPLAY_DETECTED` | Ephemeral pubkey thumbprint in anti-reuse ledger. | Regenerate ephemeral keypair (re-register flow). |
| `DirectDeviceRevokedError` | `DIRECT_DEVICE_REVOKED` | Admin or fraud signal kicked this device. SDK auto-wipes local state. | Surface "session revoked", route to fresh register. |
| `DirectPaymentProviderFailedError` | `DIRECT_PAYMENT_PROVIDER_FAILED` | Payment provider refused/errored. Exposes `String provider` (coarse tag: `stripe` / `paddle` / `lemon_squeezy` / `razorpay` / `apple_iap` / `google_iap` / `restore` / `default`). | Treat as transient; retry with backoff; alert ops on repeat. |
| `DirectNoActiveSubscriptionError` | `DIRECT_NO_ACTIVE_SUBSCRIPTION` | `openPortal` called for a device with no active/trialing sub. | Route user through `startCheckout` instead. |
| `DirectSessionNotFoundError` | `DIRECT_SESSION_NOT_FOUND` | `session_id` unknown OR belongs to another device (probe defence — same code either way). | Re-start checkout. |
| `DirectSessionNotCompleteError` | `DIRECT_SESSION_NOT_COMPLETE` | Webhook hasn't flipped session to `completed=true`. | Back off short (1-3 s), retry `refreshAfterPayment`. |
| `DirectIapReceiptInvalidError` | `DIRECT_IAP_RECEIPT_INVALID` | Apple/Google rejected. Exposes `String? reason` (`unknown`/`expired`/`consumed`/`cross_account`). | Branch UX on `reason`. **Note:** soft-rejections come back as `IapVerifyResult(valid:false, reason:...)` — this thrown form only surfaces if the server elevates to the typed error. |

### Wire-code router

```dart
DirectError directErrorFromCode(
  String code, {
  String? message,
  int? retryAfterMs,
  String? reason,
  String? provider,
});
```

Built-in codes resolve via the static switch. Payment codes are routed
through the `directPaymentErrorFromCode` extension installed by
`ensureDirectPaymentErrorsRegistered()` (called automatically on first
payment-method invocation). Unknown `DIRECT_*_FAILED` codes fall through to
`DirectProviderFailedError`; any other unknown code surfaces as a generic
`_GenericDirectError` so callers can still pattern-match on `DirectError`.

#### Custom code resolvers

```dart
typedef DirectErrorExtension = DirectError? Function(
  String code, {
  String? message,
  int? retryAfterMs,
  String? reason,
  String? provider,
});

void registerDirectErrorExtension(DirectErrorExtension ext);
```

Resolvers run in registration order; first non-null wins. Duplicates are
deduped by identity, so calling `registerDirectErrorExtension` multiple times
with the same closure is safe.

### Adjacent (non-`DirectError`) exceptions that FRON paths can raise

These come from `lib/src/exceptions.dart` and surface from the transport /
crypto layer:

| Exception | When | Handle |
| --- | --- | --- |
| `NotConnectedException` | Durable-call before `register()` succeeded. | Bug — call `register()` first. |
| `NetworkException` | Transport timeout / 5xx / DNS / TLS (carries `statusCode?`). | Retry with backoff. |
| `CertificatePinException` | SPKI pin mismatch. **MITM signal.** | Refuse + alert ops. Do NOT auto-retry. |
| `LicenseStoreException` | Generic SDK failure (missing fields in response, decode failure). | Investigate — should be rare. |
| `StateError` | `DirectClient` used after `dispose()` or `adoptEntitlementJwsInternal` before JWKS load. | Bug — fix call site. |

---

## 10. Wire protocol cheat sheet

Canonical wire shapes live in
`bifrost/packages/api-types/src/fron-parity-fixtures.json`. Authoritative
design narrative in `bifrost/docs/FRON_design.md` (esp. §6 Payment surface).

| SDK call | HTTP | Inner-JWS `aud` | Tier | Fixture key |
| --- | --- | --- | --- | --- |
| `register` | `POST /direct/v1/register` | `direct:register` | 1 (ephemeral) | `register.*` |
| `activate` | `POST /direct/v1/activate` | `direct:activate` | 2 (durable) | `activate.*` |
| `verify` | `POST /direct/v1/verify` | `direct:verify` | 2 | `verify.*` |
| `heartbeat` | `POST /direct/v1/heartbeat` | `direct:heartbeat` | 2 | `heartbeat.*` |
| `deactivate` | `POST /direct/v1/deactivate` | `direct:deactivate` | 2 | `deactivate.*` |
| `getCatalog` | `POST /direct/v1/catalog` | `direct:catalog` | 2 | `catalog.*` |
| `acknowledgeKidRotation` | `POST /direct/v1/keys/rotate-ack` | `direct:keys.rotate_ack` | 2 | `keys.rotate_ack.*` |
| `registerFcmToken` | `POST /direct/v1/notifications/register-fcm` | `direct:notifications.register_fcm` | 2 | `notifications.register_fcm.*` |
| `ackNotification` | `POST /direct/v1/notifications/ack` | `direct:notifications.ack` | 2 | `notifications.ack.*` |
| `sendStats` (batched) | `POST /direct/v1/telemetry/stats` | `direct:telemetry.stats` | 2 | `telemetry.stats.*` |
| `reportError` | `POST /direct/v1/telemetry/error` | `direct:telemetry.error` | 2 | `telemetry.error.*` |
| `startCheckout` | `POST /direct/v1/payment/checkout` | `direct:payment.checkout` | 2 | `payment.checkout.*` |
| `startNativePayment` | `POST /direct/v1/payment/intent` | `direct:payment.intent` | 2 | `payment.intent.*` |
| `openPortal` | `POST /direct/v1/payment/portal` | `direct:payment.portal` | 2 | `payment.portal.*` |
| `restorePurchases` | `POST /direct/v1/payment/restore` | `direct:payment.restore` | 2 | `payment.restore.*` |
| `verifyIapReceipt` | `POST /direct/v1/payment/iap-verify` | `direct:payment.iap_verify` | 2 | `payment.iap_verify.*` |
| `refreshAfterPayment` | `POST /direct/v1/payment/refresh` | `direct:payment.refresh` | 2 | `payment.refresh.*` |
| JWKS bootstrap | `GET /direct/v1/keys` | — | — | `keys.*` |

### Common HTTP headers (every POST)

| Header | Value |
| --- | --- |
| `Content-Type` | `application/jose+json` |
| `Accept` | `application/jose+json` |
| `X-LS-Request-Id` | UUIDv7 (48-bit ms + 74-bit random; SDK-generated per call). |
| `X-LS-Project-Id` | `config.projectId`. |

### Envelope shape

- **Tier 1 (register).** Inner JWS signed with **ephemeral** Ed25519; outer
  JWE wraps for Bifrost's active recipient X25519.
- **Tier 2 (durable).** Inner JWS signed with **durable** Ed25519 + carries
  `device_id` + `server_nonce` claims; outer JWE wraps for Bifrost's active
  recipient.
- **Responses.** Always JWE-on-egress wrapping a JWS that carries claims.
  Parser verifies: outer JWE decrypt → JWS sig → audience pin → request-id
  echo → route-path binding → `iat`/`nbf`/`exp` within `clockSkew` → claims
  surfaced to caller.

### Constants

| Name | Value | Purpose |
| --- | --- | --- |
| `kIapReceiptMaxBytes` | `24 * 1024` | Client-side bound on `verifyIapReceipt` receipt size (W6 D-Fix 3 — Swift parity). |
| `kRestorePurchasesMaxRows` | `100` | Defence-in-depth cap on `RestoreResult.restored` length. |
| `kDirectAud*` constants | colon-namespaced strings | Canonical JWS audiences; see §10 table. |

---

*Last reviewed: keep in sync with*
`/Users/kanishka/kk_apps/ajtek.io_lc/vanaheim/dart/vanaheim/lib/src/direct/`
*and the fixture+design files referenced above.*
