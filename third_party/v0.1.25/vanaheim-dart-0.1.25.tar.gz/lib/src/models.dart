// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:meta/meta.dart';

/// Result of a successful activation. KickedDevice is non-null when a
/// floating-tier activation bumped an older session to make room.
@immutable
class ActivationResult {
  final String activationId;
  final DateTime expiresAt;
  final Entitlements entitlements;
  final KickedDevice? kickedDevice;

  const ActivationResult({
    required this.activationId,
    required this.expiresAt,
    required this.entitlements,
    this.kickedDevice,
  });
}

/// (Sanitized) record of a device that was deactivated to make room for a
/// new floating activation. The device fingerprint is intentionally NOT
/// included — surface only the human-friendly fields to the user.
@immutable
class KickedDevice {
  final String activationId;
  final String? deviceName;
  final String? os;
  final DateTime lastSeenAt;

  const KickedDevice({
    required this.activationId,
    required this.lastSeenAt,
    this.deviceName,
    this.os,
  });

  factory KickedDevice.fromJson(Map<String, dynamic> j) {
    final id = j['activation_id'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('KickedDevice JSON missing activation_id');
    }
    final lastSeen = j['last_seen_at'];
    if (lastSeen is! String || lastSeen.isEmpty) {
      throw const FormatException('KickedDevice JSON missing last_seen_at');
    }
    return KickedDevice(
      activationId: id,
      deviceName: j['device_name'] is String ? j['device_name'] as String : null,
      os: j['os'] is String ? j['os'] as String : null,
      lastSeenAt: DateTime.parse(lastSeen),
    );
  }
}

/// Tier + per-feature entitlements. Read via [hasFeature]/[quota] on
/// [LicenseClient]; the raw map is exposed for diagnostics.
@immutable
class Entitlements {
  final String tier;
  final int version;
  final Map<String, dynamic> values;

  const Entitlements({
    required this.tier,
    required this.version,
    required this.values,
  });

  bool has(String key) {
    final v = values[key];
    if (v == null) return false;
    if (v is bool) return v;
    if (v is List) return v.isNotEmpty;
    return true;
  }

  T? quota<T>(String key) {
    final v = values[key];
    if (v is T) return v;
    if (T == int && v is num) return v.toInt() as T;
    if (T == double && v is num) return v.toDouble() as T;
    return null;
  }
}

/// Emitted on [LicenseClient.stateChanges] when something the product UI
/// might care about happens.
@immutable
class LicenseStateChange {
  final LicenseStateChangeKind kind;
  final Entitlements? entitlements;
  final KickedDevice? kickedDevice;
  final Object? error;

  /// Optional inbox notification payload for [LicenseStateChangeKind.notificationReceived].
  final NotificationMessage? notification;

  const LicenseStateChange({
    required this.kind,
    this.entitlements,
    this.kickedDevice,
    this.error,
    this.notification,
  });
}

enum LicenseStateChangeKind {
  /// First successful activation after [LicenseClient.connect].
  activated,

  /// `entitlements_version` bumped server-side (tier change or refund);
  /// product should re-render gated UI.
  entitlementsUpdated,

  /// `cfg_v` bumped server-side (runtime config override). Product should
  /// re-read any value previously fetched via `client.config<T>()`.
  configUpdated,

  /// `prefs_v` bumped server-side (cross-product preferences change).
  preferencesUpdated,

  /// A new inbox notification arrived via push wake-trigger; payload is
  /// in [LicenseStateChange.notification].
  notificationReceived,

  /// This device was bumped by another login (floating tier) or admin revoked.
  sessionRevoked,

  /// JWT expired and refresh failed.
  expired,

  /// Persistent error after retries (network / auth / pinning).
  error,
}

/// Decoded JWT claims relevant to the SDK. Other claims are ignored.
///
/// Forward-compat: new optional claims may appear server-side without an SDK
/// bump. Unknown claims are silently ignored by the verifier.
@immutable
class LicenseJwtClaims {
  final String issuer;
  final String licenseId;
  final String productId;
  final String accountId;
  final String tier;
  final Map<String, dynamic> entitlements;
  final int entitlementsVersion;

  /// Merged runtime-config overlay payload from the backend (global → region
  /// → country → product → tier → license). Read via [LicenseClient.config].
  /// Empty when backend isn't yet emitting cfg claims.
  final Map<String, dynamic> config;

  /// Bumped server-side on every override that affects this license.
  final int configVersion;

  /// Multi-valued roles (e.g., `["customer", "partner"]`). Empty list when
  /// backend isn't yet emitting roles claim.
  final List<String> roles;

  /// Organization context if the caller acts on behalf of a B2B account.
  final String? orgId;

  /// Per-org role (owner / admin / member) when [orgId] is set.
  final String? orgRole;

  /// Bumped server-side on every cross-product preferences write.
  final int preferencesVersion;

  /// Resolved user locale (e.g., "en-US"). Null when not set server-side;
  /// SDK falls back to system locale.
  final String? locale;

  final DateTime issuedAt;
  final DateTime notBefore;
  final DateTime expiresAt;
  final String kid;

  const LicenseJwtClaims({
    required this.issuer,
    required this.licenseId,
    required this.productId,
    required this.accountId,
    required this.tier,
    required this.entitlements,
    required this.entitlementsVersion,
    required this.issuedAt,
    required this.notBefore,
    required this.expiresAt,
    required this.kid,
    this.config = const {},
    this.configVersion = 0,
    this.roles = const [],
    this.orgId,
    this.orgRole,
    this.preferencesVersion = 0,
    this.locale,
  });
}

// ===========================================================================
// 2A.3 Notification SDK surface — inbox + preferences + stream payload
// ===========================================================================

/// One inbox row delivered by License Store. Persistent record of a
/// notification (cross-channel) viewable in the product's bell icon.
@immutable
class NotificationMessage {
  final String id;
  final String productId;
  final String kind; // e.g. "license.config_changed", "billing.invoice_paid"
  final String? title;
  final String? body;
  final String? deepLink;
  final DateTime createdAt;
  final DateTime? readAt;

  const NotificationMessage({
    required this.id,
    required this.productId,
    required this.kind,
    required this.createdAt,
    this.title,
    this.body,
    this.deepLink,
    this.readAt,
  });

  bool get isUnread => readAt == null;

  factory NotificationMessage.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final productId = j['product_id'];
    final kind = j['kind'];
    final createdAtStr = j['created_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('NotificationMessage missing id');
    }
    if (productId is! String || productId.isEmpty) {
      throw const FormatException('NotificationMessage missing product_id');
    }
    if (kind is! String || kind.isEmpty) {
      throw const FormatException('NotificationMessage missing kind');
    }
    if (createdAtStr is! String || createdAtStr.isEmpty) {
      throw const FormatException('NotificationMessage missing created_at');
    }
    return NotificationMessage(
      id: id,
      productId: productId,
      kind: kind,
      title: j['title'] is String ? j['title'] as String : null,
      body: j['body'] is String ? j['body'] as String : null,
      deepLink: j['deep_link'] is String ? j['deep_link'] as String : null,
      createdAt: DateTime.parse(createdAtStr),
      readAt: j['read_at'] is String
          ? DateTime.tryParse(j['read_at'] as String)
          : null,
    );
  }
}

/// Result of a paged inbox fetch. `nextCursor` is null when no more rows.
@immutable
class NotificationInboxPage {
  final List<NotificationMessage> messages;
  final String? nextCursor;
  const NotificationInboxPage({required this.messages, this.nextCursor});

  factory NotificationInboxPage.fromJson(Map<String, dynamic> j) {
    final raw = j['messages'];
    final messages = raw is List
        ? raw
            .whereType<Map<String, dynamic>>()
            .map(NotificationMessage.fromJson)
            .toList()
        : <NotificationMessage>[];
    final cursor = j['next_cursor'];
    return NotificationInboxPage(
      messages: messages,
      nextCursor: cursor is String && cursor.isNotEmpty ? cursor : null,
    );
  }
}

/// Per-channel × per-template preferences. Read/write via
/// `client.notifications.preferences`.
@immutable
class NotificationPreferences {
  /// Top-level master switch per channel. Example keys:
  /// `"email"`, `"push"`, `"sms"`, `"in_app"`.
  final Map<String, bool> channels;

  /// Per-template overrides. Key is template id ("welcome", "upgrade_success");
  /// value is a per-channel bool map. Falls back to [channels] when absent.
  final Map<String, Map<String, bool>> perTemplate;

  const NotificationPreferences({
    this.channels = const {},
    this.perTemplate = const {},
  });

  factory NotificationPreferences.fromJson(Map<String, dynamic> j) {
    final channelsRaw = j['channels'];
    final perTemplateRaw = j['per_template'];
    final channels = <String, bool>{};
    if (channelsRaw is Map) {
      channelsRaw.forEach((k, v) {
        if (k is String && v is bool) channels[k] = v;
      });
    }
    final perTemplate = <String, Map<String, bool>>{};
    if (perTemplateRaw is Map) {
      perTemplateRaw.forEach((k, v) {
        if (k is String && v is Map) {
          final inner = <String, bool>{};
          v.forEach((ik, iv) {
            if (ik is String && iv is bool) inner[ik] = iv;
          });
          perTemplate[k] = inner;
        }
      });
    }
    return NotificationPreferences(
      channels: channels,
      perTemplate: perTemplate,
    );
  }

  Map<String, dynamic> toJson() => {
        'channels': channels,
        'per_template': perTemplate,
      };
}

// ===========================================================================
// 2A.4 Feedback SDK surface — categories, attachments, return values
// ===========================================================================

/// Submission categories. Products may extend with custom strings; the
/// server treats unknown values as "other" but preserves the string.
class FeedbackCategory {
  static const String bug = 'bug';
  static const String feature = 'feature';
  static const String uxComplaint = 'ux';
  static const String pricing = 'pricing';
  static const String praise = 'praise';
  static const String other = 'other';
}

/// In-memory attachment to ship with a feedback submission. Bytes are
/// streamed to the backend's GCS bucket via signed upload URL — the SDK
/// hides that protocol; products just supply the bytes + content type.
@immutable
class FeedbackAttachment {
  final String filename;
  final String contentType;
  final List<int> bytes;
  const FeedbackAttachment({
    required this.filename,
    required this.contentType,
    required this.bytes,
  });
}

/// Receipt returned by `client.feedback.submit` etc. — server-assigned id
/// + acknowledgement timestamp.
@immutable
class FeedbackReceipt {
  final String id;
  final DateTime receivedAt;
  const FeedbackReceipt({required this.id, required this.receivedAt});

  factory FeedbackReceipt.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final ts = j['received_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('FeedbackReceipt missing id');
    }
    if (ts is! String || ts.isEmpty) {
      throw const FormatException('FeedbackReceipt missing received_at');
    }
    return FeedbackReceipt(id: id, receivedAt: DateTime.parse(ts));
  }
}

// ===========================================================================
// 2A.7 Subscription self-serve SDK surface
// ===========================================================================

/// A tier description returned by `client.subscription.tiers()`. Drives
/// product-side upgrade screens without the product having to talk to the
/// catalog SDK separately.
@immutable
class SubscriptionTier {
  final String slug;
  final String displayName;
  final String? description;
  final int amountCents;
  final String currency;
  final String interval; // "month" | "year" | "one_time" | "lifetime"
  final Map<String, dynamic> entitlements;

  const SubscriptionTier({
    required this.slug,
    required this.displayName,
    required this.amountCents,
    required this.currency,
    required this.interval,
    this.description,
    this.entitlements = const {},
  });

  factory SubscriptionTier.fromJson(Map<String, dynamic> j) {
    final slug = j['slug'];
    final name = j['display_name'];
    final amount = j['amount_cents'];
    final cur = j['currency'];
    final interval = j['interval'];
    if (slug is! String || slug.isEmpty) {
      throw const FormatException('SubscriptionTier missing slug');
    }
    if (name is! String || name.isEmpty) {
      throw const FormatException('SubscriptionTier missing display_name');
    }
    if (amount is! num) {
      throw const FormatException('SubscriptionTier missing amount_cents');
    }
    if (cur is! String || cur.isEmpty) {
      throw const FormatException('SubscriptionTier missing currency');
    }
    if (interval is! String || interval.isEmpty) {
      throw const FormatException('SubscriptionTier missing interval');
    }
    return SubscriptionTier(
      slug: slug,
      displayName: name,
      description: j['description'] is String ? j['description'] as String : null,
      amountCents: amount.toInt(),
      currency: cur,
      interval: interval,
      entitlements: (j['entitlements'] as Map?)?.cast<String, dynamic>() ??
          const <String, dynamic>{},
    );
  }
}

/// Invoice summary returned by `client.subscription.invoices()`. PDF download
/// is via [pdfUrl] (signed, short-lived).
@immutable
class InvoiceSummary {
  final String id;
  final String number;
  final int amountCents;
  final String currency;
  final String status; // "paid" | "open" | "void" | "uncollectible"
  final DateTime issuedAt;
  final DateTime? paidAt;
  final Uri? pdfUrl;

  const InvoiceSummary({
    required this.id,
    required this.number,
    required this.amountCents,
    required this.currency,
    required this.status,
    required this.issuedAt,
    this.paidAt,
    this.pdfUrl,
  });

  factory InvoiceSummary.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final number = j['number'];
    final amount = j['amount_cents'];
    final cur = j['currency'];
    final status = j['status'];
    final issued = j['issued_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('InvoiceSummary missing id');
    }
    if (number is! String || number.isEmpty) {
      throw const FormatException('InvoiceSummary missing number');
    }
    if (amount is! num) {
      throw const FormatException('InvoiceSummary missing amount_cents');
    }
    if (cur is! String || cur.isEmpty) {
      throw const FormatException('InvoiceSummary missing currency');
    }
    if (status is! String || status.isEmpty) {
      throw const FormatException('InvoiceSummary missing status');
    }
    if (issued is! String || issued.isEmpty) {
      throw const FormatException('InvoiceSummary missing issued_at');
    }
    Uri? pdf;
    final pdfRaw = j['pdf_url'];
    if (pdfRaw is String && pdfRaw.isNotEmpty) {
      pdf = Uri.tryParse(pdfRaw);
    }
    return InvoiceSummary(
      id: id,
      number: number,
      amountCents: amount.toInt(),
      currency: cur,
      status: status,
      issuedAt: DateTime.parse(issued),
      paidAt: j['paid_at'] is String
          ? DateTime.tryParse(j['paid_at'] as String)
          : null,
      pdfUrl: pdf,
    );
  }
}

/// Paged invoice listing.
@immutable
class InvoicePage {
  final List<InvoiceSummary> invoices;
  final String? nextCursor;
  const InvoicePage({required this.invoices, this.nextCursor});

  factory InvoicePage.fromJson(Map<String, dynamic> j) {
    final raw = j['invoices'];
    final invoices = raw is List
        ? raw
            .whereType<Map<String, dynamic>>()
            .map(InvoiceSummary.fromJson)
            .toList()
        : <InvoiceSummary>[];
    final cursor = j['next_cursor'];
    return InvoicePage(
      invoices: invoices,
      nextCursor: cursor is String && cursor.isNotEmpty ? cursor : null,
    );
  }
}

// ===========================================================================
// 2A.6 Roles & multi-context — partner + organization profile snapshots
// ===========================================================================

/// Snapshot of partner-specific fields exposed when the JWT carries
/// `'partner' ∈ roles`. Null otherwise. Read via `client.partnerProfile`.
@immutable
class PartnerProfile {
  final String accountId;
  final String marginTier;
  final int? commissionRateBps;
  final String applicationStatus; // applied / approved / suspended / rejected
  final String? resellerTaxId;
  const PartnerProfile({
    required this.accountId,
    required this.marginTier,
    required this.applicationStatus,
    this.commissionRateBps,
    this.resellerTaxId,
  });

  factory PartnerProfile.fromJson(Map<String, dynamic> j) {
    final acc = j['account_id'];
    final tier = j['margin_tier'];
    final status = j['application_status'];
    if (acc is! String || acc.isEmpty) {
      throw const FormatException('PartnerProfile missing account_id');
    }
    if (tier is! String || tier.isEmpty) {
      throw const FormatException('PartnerProfile missing margin_tier');
    }
    if (status is! String || status.isEmpty) {
      throw const FormatException('PartnerProfile missing application_status');
    }
    final rate = j['commission_rate_bps'];
    final tax = j['reseller_tax_id'];
    return PartnerProfile(
      accountId: acc,
      marginTier: tier,
      applicationStatus: status,
      commissionRateBps: rate is num ? rate.toInt() : null,
      resellerTaxId: tax is String && tax.isNotEmpty ? tax : null,
    );
  }
}

/// Snapshot of org context exposed when the JWT carries `org_id`. Null for
/// individual consumer accounts. Read via `client.organization`.
@immutable
class OrganizationContext {
  final String orgId;
  final String orgRole; // owner | admin | member
  const OrganizationContext({required this.orgId, required this.orgRole});
}

// ===========================================================================
// 2A.9 Privacy + consent SDK surface
// ===========================================================================

/// Standard consent scopes — products may pass custom strings; server stores
/// unknown keys verbatim.
class ConsentScope {
  static const String essential = 'essential';
  static const String analytics = 'analytics';
  static const String marketing = 'marketing';
  static const String advertising = 'advertising';
  static const String shareWithPartners = 'share_with_partners';
}

/// User's current consent state.
@immutable
class ConsentState {
  final Map<String, bool> scopes;
  final DateTime? capturedAt;
  const ConsentState({required this.scopes, this.capturedAt});

  factory ConsentState.fromJson(Map<String, dynamic> j) {
    final scopesRaw = j['scopes'];
    final scopes = <String, bool>{};
    if (scopesRaw is Map) {
      scopesRaw.forEach((k, v) {
        if (k is String && v is bool) scopes[k] = v;
      });
    }
    final ts = j['captured_at'];
    return ConsentState(
      scopes: scopes,
      capturedAt: ts is String ? DateTime.tryParse(ts) : null,
    );
  }

  Map<String, dynamic> toJson() => {'scopes': scopes};
}

/// Job handle for async data-export. Poll status via the returned id.
@immutable
class PrivacyJob {
  final String id;
  final String status; // pending | running | ready | failed
  final Uri? downloadUrl;
  const PrivacyJob(
      {required this.id, required this.status, this.downloadUrl});

  factory PrivacyJob.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final status = j['status'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('PrivacyJob missing id');
    }
    if (status is! String || status.isEmpty) {
      throw const FormatException('PrivacyJob missing status');
    }
    final url = j['download_url'];
    return PrivacyJob(
      id: id,
      status: status,
      downloadUrl:
          url is String && url.isNotEmpty ? Uri.tryParse(url) : null,
    );
  }
}

// ===========================================================================
// 2A.11 Support SDK surface
// ===========================================================================

/// One support ticket summary.
@immutable
class SupportTicket {
  final String id;
  final String subject;
  final String status; // open | pending | resolved | closed
  final String? priority;
  final DateTime openedAt;
  final DateTime? resolvedAt;
  const SupportTicket({
    required this.id,
    required this.subject,
    required this.status,
    required this.openedAt,
    this.priority,
    this.resolvedAt,
  });

  factory SupportTicket.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final subject = j['subject'];
    final status = j['status'];
    final opened = j['opened_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('SupportTicket missing id');
    }
    if (subject is! String || subject.isEmpty) {
      throw const FormatException('SupportTicket missing subject');
    }
    if (status is! String || status.isEmpty) {
      throw const FormatException('SupportTicket missing status');
    }
    if (opened is! String || opened.isEmpty) {
      throw const FormatException('SupportTicket missing opened_at');
    }
    return SupportTicket(
      id: id,
      subject: subject,
      status: status,
      priority: j['priority'] is String ? j['priority'] as String : null,
      openedAt: DateTime.parse(opened),
      resolvedAt: j['resolved_at'] is String
          ? DateTime.tryParse(j['resolved_at'] as String)
          : null,
    );
  }
}

/// One message in a ticket thread.
@immutable
class SupportMessage {
  final String id;
  final String role; // customer | agent | system | ai
  final String body;
  final DateTime sentAt;
  const SupportMessage({
    required this.id,
    required this.role,
    required this.body,
    required this.sentAt,
  });

  factory SupportMessage.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final role = j['role'];
    final body = j['body'];
    final sent = j['sent_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('SupportMessage missing id');
    }
    if (role is! String || role.isEmpty) {
      throw const FormatException('SupportMessage missing role');
    }
    if (body is! String) {
      throw const FormatException('SupportMessage missing body');
    }
    if (sent is! String || sent.isEmpty) {
      throw const FormatException('SupportMessage missing sent_at');
    }
    return SupportMessage(
      id: id,
      role: role,
      body: body,
      sentAt: DateTime.parse(sent),
    );
  }
}

/// A ticket plus its full message thread.
@immutable
class SupportTicketDetail {
  final SupportTicket ticket;
  final List<SupportMessage> messages;
  const SupportTicketDetail(
      {required this.ticket, required this.messages});
}

// ===========================================================================
// 2B.3 AI assistant
// ===========================================================================

/// One assistant message — assistant reply or user prompt echo.
@immutable
class AssistantMessage {
  final String id;
  final String role; // user | assistant | system
  final String content;
  final DateTime sentAt;
  final List<String> citations;
  const AssistantMessage({
    required this.id,
    required this.role,
    required this.content,
    required this.sentAt,
    this.citations = const [],
  });

  factory AssistantMessage.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final role = j['role'];
    final content = j['content'];
    final sent = j['sent_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('AssistantMessage missing id');
    }
    if (role is! String || role.isEmpty) {
      throw const FormatException('AssistantMessage missing role');
    }
    if (content is! String) {
      throw const FormatException('AssistantMessage missing content');
    }
    if (sent is! String || sent.isEmpty) {
      throw const FormatException('AssistantMessage missing sent_at');
    }
    final citationsRaw = j['citations'];
    final citations = citationsRaw is List
        ? citationsRaw.whereType<String>().toList()
        : const <String>[];
    return AssistantMessage(
      id: id,
      role: role,
      content: content,
      sentAt: DateTime.parse(sent),
      citations: citations,
    );
  }
}

@immutable
class AssistantConversation {
  final String id;
  final String? title;
  final DateTime createdAt;
  final DateTime updatedAt;
  const AssistantConversation({
    required this.id,
    required this.createdAt,
    required this.updatedAt,
    this.title,
  });

  factory AssistantConversation.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final created = j['created_at'];
    final updated = j['updated_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('AssistantConversation missing id');
    }
    if (created is! String || created.isEmpty) {
      throw const FormatException('AssistantConversation missing created_at');
    }
    if (updated is! String || updated.isEmpty) {
      throw const FormatException('AssistantConversation missing updated_at');
    }
    return AssistantConversation(
      id: id,
      title: j['title'] is String ? j['title'] as String : null,
      createdAt: DateTime.parse(created),
      updatedAt: DateTime.parse(updated),
    );
  }
}

@immutable
class AssistantConversationDetail {
  final AssistantConversation conversation;
  final List<AssistantMessage> messages;
  const AssistantConversationDetail(
      {required this.conversation, required this.messages});
}

// ===========================================================================
// 2B.4 Referrals
// ===========================================================================

@immutable
class ReferralCode {
  final String code;
  final Uri? shareUrl;
  const ReferralCode({required this.code, this.shareUrl});

  factory ReferralCode.fromJson(Map<String, dynamic> j) {
    final code = j['code'];
    if (code is! String || code.isEmpty) {
      throw const FormatException('ReferralCode missing code');
    }
    final url = j['share_url'];
    return ReferralCode(
      code: code,
      shareUrl: url is String && url.isNotEmpty ? Uri.tryParse(url) : null,
    );
  }
}

/// One outgoing referral. Status tracks the funnel: invited → signed_up →
/// converted → rewarded.
@immutable
class ReferralInvite {
  final String id;
  final String status;
  final DateTime invitedAt;
  final DateTime? convertedAt;
  final int? rewardAmountCents;
  final String? rewardCurrency;
  const ReferralInvite({
    required this.id,
    required this.status,
    required this.invitedAt,
    this.convertedAt,
    this.rewardAmountCents,
    this.rewardCurrency,
  });

  factory ReferralInvite.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final status = j['status'];
    final invited = j['invited_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('ReferralInvite missing id');
    }
    if (status is! String || status.isEmpty) {
      throw const FormatException('ReferralInvite missing status');
    }
    if (invited is! String || invited.isEmpty) {
      throw const FormatException('ReferralInvite missing invited_at');
    }
    return ReferralInvite(
      id: id,
      status: status,
      invitedAt: DateTime.parse(invited),
      convertedAt: j['converted_at'] is String
          ? DateTime.tryParse(j['converted_at'] as String)
          : null,
      rewardAmountCents:
          (j['reward_amount_cents'] as num?)?.toInt(),
      rewardCurrency:
          j['reward_currency'] is String ? j['reward_currency'] as String : null,
    );
  }
}

// ===========================================================================
// 2B.5 Status page
// ===========================================================================

/// Overall system status (worst-of all components).
enum SystemStatusLevel {
  operational,
  degradedPerformance,
  partialOutage,
  majorOutage,
  underMaintenance,
}

SystemStatusLevel _parseStatusLevel(String s) {
  switch (s) {
    case 'operational':
      return SystemStatusLevel.operational;
    case 'degraded_performance':
      return SystemStatusLevel.degradedPerformance;
    case 'partial_outage':
      return SystemStatusLevel.partialOutage;
    case 'major_outage':
      return SystemStatusLevel.majorOutage;
    case 'under_maintenance':
      return SystemStatusLevel.underMaintenance;
    default:
      return SystemStatusLevel.operational;
  }
}

@immutable
class SystemComponent {
  final String name;
  final SystemStatusLevel status;
  const SystemComponent({required this.name, required this.status});

  factory SystemComponent.fromJson(Map<String, dynamic> j) {
    final name = j['name'];
    final status = j['status'];
    if (name is! String || name.isEmpty) {
      throw const FormatException('SystemComponent missing name');
    }
    if (status is! String || status.isEmpty) {
      throw const FormatException('SystemComponent missing status');
    }
    return SystemComponent(name: name, status: _parseStatusLevel(status));
  }
}

@immutable
class SystemStatus {
  final SystemStatusLevel overall;
  final List<SystemComponent> components;
  final List<IncidentSummary> activeIncidents;
  final DateTime updatedAt;
  const SystemStatus({
    required this.overall,
    required this.components,
    required this.activeIncidents,
    required this.updatedAt,
  });

  factory SystemStatus.fromJson(Map<String, dynamic> j) {
    final overall = j['overall'];
    final updated = j['updated_at'];
    if (overall is! String || overall.isEmpty) {
      throw const FormatException('SystemStatus missing overall');
    }
    if (updated is! String || updated.isEmpty) {
      throw const FormatException('SystemStatus missing updated_at');
    }
    final componentsRaw = j['components'];
    final components = componentsRaw is List
        ? componentsRaw
            .whereType<Map<String, dynamic>>()
            .map(SystemComponent.fromJson)
            .toList()
        : <SystemComponent>[];
    final incidentsRaw = j['active_incidents'];
    final incidents = incidentsRaw is List
        ? incidentsRaw
            .whereType<Map<String, dynamic>>()
            .map(IncidentSummary.fromJson)
            .toList()
        : <IncidentSummary>[];
    return SystemStatus(
      overall: _parseStatusLevel(overall),
      components: components,
      activeIncidents: incidents,
      updatedAt: DateTime.parse(updated),
    );
  }
}

@immutable
class IncidentSummary {
  final String id;
  final String title;
  final String severity; // sev0 | sev1 | sev2 | sev3 | maintenance
  final String status; // open | investigating | identified | monitoring | resolved
  final DateTime startedAt;
  const IncidentSummary({
    required this.id,
    required this.title,
    required this.severity,
    required this.status,
    required this.startedAt,
  });

  factory IncidentSummary.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final title = j['title'];
    final severity = j['severity'];
    final status = j['status'];
    final started = j['started_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('IncidentSummary missing id');
    }
    if (title is! String || title.isEmpty) {
      throw const FormatException('IncidentSummary missing title');
    }
    if (severity is! String || severity.isEmpty) {
      throw const FormatException('IncidentSummary missing severity');
    }
    if (status is! String || status.isEmpty) {
      throw const FormatException('IncidentSummary missing status');
    }
    if (started is! String || started.isEmpty) {
      throw const FormatException('IncidentSummary missing started_at');
    }
    return IncidentSummary(
      id: id,
      title: title,
      severity: severity,
      status: status,
      startedAt: DateTime.parse(started),
    );
  }
}

// ===========================================================================
// 2B.6 Account portability
// ===========================================================================

@immutable
class AccountRequest {
  final String id;
  final String kind; // transfer | merge
  final String status; // pending | admin_review | approved | rejected
  final DateTime requestedAt;
  const AccountRequest({
    required this.id,
    required this.kind,
    required this.status,
    required this.requestedAt,
  });

  factory AccountRequest.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final kind = j['kind'];
    final status = j['status'];
    final requested = j['requested_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('AccountRequest missing id');
    }
    if (kind is! String || kind.isEmpty) {
      throw const FormatException('AccountRequest missing kind');
    }
    if (status is! String || status.isEmpty) {
      throw const FormatException('AccountRequest missing status');
    }
    if (requested is! String || requested.isEmpty) {
      throw const FormatException('AccountRequest missing requested_at');
    }
    return AccountRequest(
      id: id,
      kind: kind,
      status: status,
      requestedAt: DateTime.parse(requested),
    );
  }
}

// ===========================================================================
// 2B.7 Organization / B2B
// ===========================================================================

@immutable
class OrgMember {
  final String accountId;
  final String email; // server returns only what admin context allows
  final String role; // owner | admin | member
  final DateTime joinedAt;
  const OrgMember({
    required this.accountId,
    required this.email,
    required this.role,
    required this.joinedAt,
  });

  factory OrgMember.fromJson(Map<String, dynamic> j) {
    final acc = j['account_id'];
    final email = j['email'];
    final role = j['role'];
    final joined = j['joined_at'];
    if (acc is! String || acc.isEmpty) {
      throw const FormatException('OrgMember missing account_id');
    }
    if (email is! String) {
      throw const FormatException('OrgMember missing email');
    }
    if (role is! String || role.isEmpty) {
      throw const FormatException('OrgMember missing role');
    }
    if (joined is! String || joined.isEmpty) {
      throw const FormatException('OrgMember missing joined_at');
    }
    return OrgMember(
      accountId: acc,
      email: email,
      role: role,
      joinedAt: DateTime.parse(joined),
    );
  }
}

@immutable
class OrgInvite {
  final String id;
  final String email;
  final String role;
  final String status; // sent | accepted | revoked | expired
  final DateTime createdAt;
  const OrgInvite({
    required this.id,
    required this.email,
    required this.role,
    required this.status,
    required this.createdAt,
  });

  factory OrgInvite.fromJson(Map<String, dynamic> j) {
    final id = j['id'];
    final email = j['email'];
    final role = j['role'];
    final status = j['status'];
    final created = j['created_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('OrgInvite missing id');
    }
    if (email is! String || email.isEmpty) {
      throw const FormatException('OrgInvite missing email');
    }
    if (role is! String || role.isEmpty) {
      throw const FormatException('OrgInvite missing role');
    }
    if (status is! String || status.isEmpty) {
      throw const FormatException('OrgInvite missing status');
    }
    if (created is! String || created.isEmpty) {
      throw const FormatException('OrgInvite missing created_at');
    }
    return OrgInvite(
      id: id,
      email: email,
      role: role,
      status: status,
      createdAt: DateTime.parse(created),
    );
  }
}

// ===========================================================================
// 2B.8 Offer redemption
// ===========================================================================

@immutable
class OfferRedemption {
  final String code;
  final int? discountPct;
  final int? discountAmountCents;
  final String? currency;
  final DateTime appliedAt;
  const OfferRedemption({
    required this.code,
    required this.appliedAt,
    this.discountPct,
    this.discountAmountCents,
    this.currency,
  });

  factory OfferRedemption.fromJson(Map<String, dynamic> j) {
    final code = j['code'];
    final applied = j['applied_at'];
    if (code is! String || code.isEmpty) {
      throw const FormatException('OfferRedemption missing code');
    }
    if (applied is! String || applied.isEmpty) {
      throw const FormatException('OfferRedemption missing applied_at');
    }
    return OfferRedemption(
      code: code,
      appliedAt: DateTime.parse(applied),
      discountPct: (j['discount_pct'] as num?)?.toInt(),
      discountAmountCents: (j['discount_amount_cents'] as num?)?.toInt(),
      currency: j['currency'] is String ? j['currency'] as String : null,
    );
  }
}

// ===========================================================================
// 2A.8 — MFA + session management
// ===========================================================================

/// One enrolled MFA factor.
@immutable
class MfaFactor {
  final String id;
  final String type; // "totp" | "webauthn"
  final String label;
  final DateTime? confirmedAt;
  final DateTime? lastUsedAt;
  final DateTime createdAt;
  const MfaFactor({
    required this.id,
    required this.type,
    required this.label,
    required this.createdAt,
    this.confirmedAt,
    this.lastUsedAt,
  });

  bool get isConfirmed => confirmedAt != null;

  factory MfaFactor.fromJson(Map<String, dynamic> j) {
    final id = j['ID'] ?? j['id'];
    final type = j['Type'] ?? j['type'];
    final label = j['Label'] ?? j['label'];
    final created = j['CreatedAt'] ?? j['created_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('MfaFactor missing id');
    }
    if (type is! String || type.isEmpty) {
      throw const FormatException('MfaFactor missing type');
    }
    if (label is! String) {
      throw const FormatException('MfaFactor missing label');
    }
    if (created is! String || created.isEmpty) {
      throw const FormatException('MfaFactor missing created_at');
    }
    DateTime? parseTs(dynamic v) {
      if (v is String && v.isNotEmpty) return DateTime.tryParse(v);
      return null;
    }
    return MfaFactor(
      id: id,
      type: type,
      label: label,
      confirmedAt: parseTs(j['ConfirmedAt'] ?? j['confirmed_at']),
      lastUsedAt: parseTs(j['LastUsedAt'] ?? j['last_used_at']),
      createdAt: DateTime.parse(created),
    );
  }
}

/// Aggregate status returned by `client.security.status()`.
@immutable
class MfaStatus {
  final bool enabled;
  final List<MfaFactor> factors;
  final int recoveryCodesLeft;
  const MfaStatus({
    required this.enabled,
    required this.factors,
    required this.recoveryCodesLeft,
  });

  factory MfaStatus.fromJson(Map<String, dynamic> j) {
    final raw = j['factors'];
    final factors = raw is List
        ? raw
            .whereType<Map<String, dynamic>>()
            .map(MfaFactor.fromJson)
            .toList()
        : <MfaFactor>[];
    return MfaStatus(
      enabled: j['enabled'] == true,
      factors: factors,
      recoveryCodesLeft: (j['recovery_codes_left'] as num?)?.toInt() ?? 0,
    );
  }
}

/// Returned by `client.security.enrollTotp()` — drives the QR code UI.
@immutable
class TotpEnrollment {
  final String factorId;
  final String type;          // "totp"
  final String otpAuthUri;    // for QR rendering
  final String base32Secret;  // for manual entry fallback
  const TotpEnrollment({
    required this.factorId,
    required this.type,
    required this.otpAuthUri,
    required this.base32Secret,
  });

  factory TotpEnrollment.fromJson(Map<String, dynamic> j) {
    final id = j['factor_id'];
    final t = j['type'];
    final uri = j['otpauth_uri'];
    final secret = j['base32_secret'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('TotpEnrollment missing factor_id');
    }
    if (t is! String || t.isEmpty) {
      throw const FormatException('TotpEnrollment missing type');
    }
    if (uri is! String || uri.isEmpty) {
      throw const FormatException('TotpEnrollment missing otpauth_uri');
    }
    if (secret is! String || secret.isEmpty) {
      throw const FormatException('TotpEnrollment missing base32_secret');
    }
    return TotpEnrollment(
      factorId: id,
      type: t,
      otpAuthUri: uri,
      base32Secret: secret,
    );
  }
}

/// One client session as returned by `client.security.listSessions()`.
/// Fields use the Go-style PascalCase the server emits; the SDK normalises
/// to dart camelCase on the in-memory side.
@immutable
class MfaSession {
  final String id;
  final String deviceFingerprint;
  final String? deviceName;
  final String? os;
  final String? ipAtCreate;
  final String? userAgent;
  final DateTime? mfaVerifiedAt;
  final DateTime lastSeenAt;
  final DateTime expiresAt;
  final DateTime? revokedAt;
  final String? revokedReason;
  final DateTime createdAt;

  const MfaSession({
    required this.id,
    required this.deviceFingerprint,
    required this.lastSeenAt,
    required this.expiresAt,
    required this.createdAt,
    this.deviceName,
    this.os,
    this.ipAtCreate,
    this.userAgent,
    this.mfaVerifiedAt,
    this.revokedAt,
    this.revokedReason,
  });

  bool get isRevoked => revokedAt != null;

  factory MfaSession.fromJson(Map<String, dynamic> j) {
    String? str(dynamic v) =>
        v is String && v.isNotEmpty ? v : null;
    DateTime? ts(dynamic v) =>
        v is String && v.isNotEmpty ? DateTime.tryParse(v) : null;

    // Go json.Marshal of struct fields emits PascalCase by default
    // (we accept both for forward-compat).
    final id = j['ID'] ?? j['id'];
    final fp = j['DeviceFingerprint'] ?? j['device_fingerprint'];
    final lastSeen = j['LastSeenAt'] ?? j['last_seen_at'];
    final expiresAt = j['ExpiresAt'] ?? j['expires_at'];
    final created = j['CreatedAt'] ?? j['created_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('MfaSession missing id');
    }
    if (fp is! String) {
      throw const FormatException('MfaSession missing device_fingerprint');
    }
    if (lastSeen is! String || lastSeen.isEmpty) {
      throw const FormatException('MfaSession missing last_seen_at');
    }
    if (expiresAt is! String || expiresAt.isEmpty) {
      throw const FormatException('MfaSession missing expires_at');
    }
    if (created is! String || created.isEmpty) {
      throw const FormatException('MfaSession missing created_at');
    }
    return MfaSession(
      id: id,
      deviceFingerprint: fp,
      deviceName: str(j['DeviceName'] ?? j['device_name']),
      os: str(j['OS'] ?? j['os']),
      ipAtCreate: str(j['IPAtCreate'] ?? j['ip_at_create']),
      userAgent: str(j['UserAgent'] ?? j['user_agent']),
      mfaVerifiedAt: ts(j['MfaVerifiedAt'] ?? j['mfa_verified_at']),
      lastSeenAt: DateTime.parse(lastSeen),
      expiresAt: DateTime.parse(expiresAt),
      revokedAt: ts(j['RevokedAt'] ?? j['revoked_at']),
      revokedReason: str(j['RevokedReason'] ?? j['revoked_reason']),
      createdAt: DateTime.parse(created),
    );
  }
}

/// Step-up grant — short-lived "MFA-fresh" marker for sensitive ops.
@immutable
class StepUpGrant {
  final String id;
  final String scope;
  final DateTime expiresAt;
  const StepUpGrant({
    required this.id,
    required this.scope,
    required this.expiresAt,
  });

  bool isValidFor(String s, DateTime now) =>
      scope == s && expiresAt.isAfter(now);

  factory StepUpGrant.fromJson(Map<String, dynamic> j) {
    final id = j['ID'] ?? j['id'];
    final scope = j['Scope'] ?? j['scope'];
    final exp = j['ExpiresAt'] ?? j['expires_at'];
    if (id is! String || id.isEmpty) {
      throw const FormatException('StepUpGrant missing id');
    }
    if (scope is! String || scope.isEmpty) {
      throw const FormatException('StepUpGrant missing scope');
    }
    if (exp is! String || exp.isEmpty) {
      throw const FormatException('StepUpGrant missing expires_at');
    }
    return StepUpGrant(
      id: id,
      scope: scope,
      expiresAt: DateTime.parse(exp),
    );
  }
}

// ===========================================================================
// 2B.2 Docs / KB search
// ===========================================================================

@immutable
class DocsHit {
  final String title;
  final String snippet;
  final Uri url;
  final double score;
  const DocsHit({
    required this.title,
    required this.snippet,
    required this.url,
    required this.score,
  });

  factory DocsHit.fromJson(Map<String, dynamic> j) {
    final title = j['title'];
    final snippet = j['snippet'];
    final urlRaw = j['url'];
    if (title is! String || title.isEmpty) {
      throw const FormatException('DocsHit missing title');
    }
    if (snippet is! String) {
      throw const FormatException('DocsHit missing snippet');
    }
    if (urlRaw is! String || urlRaw.isEmpty) {
      throw const FormatException('DocsHit missing url');
    }
    final url = Uri.tryParse(urlRaw);
    if (url == null) {
      throw const FormatException('DocsHit url is invalid');
    }
    return DocsHit(
      title: title,
      snippet: snippet,
      url: url,
      score: (j['score'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
