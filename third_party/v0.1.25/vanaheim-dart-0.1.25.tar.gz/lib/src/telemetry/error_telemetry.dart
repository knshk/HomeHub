// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:async';
import 'dart:convert';

import 'package:meta/meta.dart';

import '../storage/secure_cache.dart';

/// One captured error event. Immutable; serializable to JSON for export
/// (support / diagnostics flow) and for persistence in secure storage.
@immutable
class TelemetryEvent {
  final DateTime timestamp;
  final TelemetrySeverity severity;
  final String source;
  final String errorClass;
  final String message;
  final String? stack;
  final Map<String, dynamic> context;

  const TelemetryEvent({
    required this.timestamp,
    required this.severity,
    required this.source,
    required this.errorClass,
    required this.message,
    this.stack,
    this.context = const {},
  });

  Map<String, dynamic> toJson() => {
        'ts': timestamp.toUtc().toIso8601String(),
        'severity': severity.name,
        'source': source,
        'error_class': errorClass,
        'message': _truncate(message, 2000),
        if (stack != null) 'stack': _truncate(stack!, 4000),
        if (context.isNotEmpty) 'context': context,
      };

  factory TelemetryEvent.fromJson(Map<String, dynamic> j) => TelemetryEvent(
        timestamp: DateTime.parse(j['ts'] as String),
        severity: TelemetrySeverity.values
            .firstWhere((s) => s.name == j['severity'], orElse: () => TelemetrySeverity.error),
        source: j['source'] as String,
        errorClass: j['error_class'] as String,
        message: j['message'] as String,
        stack: j['stack'] as String?,
        context: (j['context'] as Map?)?.cast<String, dynamic>() ?? const {},
      );

  static String _truncate(String s, int max) =>
      s.length <= max ? s : '${s.substring(0, max)}…[truncated]';
}

enum TelemetrySeverity { warn, error, panic }

/// Captures errors locally in a bounded ring buffer, persists to secure
/// storage with a small debounce, and exposes a public diagnostic API so
/// users can attach `client.errors().toJson()` to a support email.
///
/// Properties guaranteed:
///   * `capture()` returns synchronously; never blocks the caller, never
///     throws (catches its own internal errors).
///   * Persistence is debounced (default 2s) so a burst of errors doesn't
///     thrash secure storage.
///   * Ring-buffer size is bounded — old events are dropped first.
///   * Never includes JWT, SDK secret, or other sensitive material — the
///     SDK only puts those in `error_class` / `message` indirectly via
///     exception .toString().
class ErrorTelemetry {
  final int maxBuffer;
  final Duration persistDebounce;
  final SecureCache? cache;

  final List<TelemetryEvent> _ring = [];
  Timer? _flushTimer;
  bool _restored = false;

  ErrorTelemetry({
    this.cache,
    this.maxBuffer = 50,
    this.persistDebounce = const Duration(seconds: 2),
  });

  /// Loads any previously-persisted events from secure storage. Call once
  /// from LicenseClient.connect(); subsequent calls are no-ops.
  Future<void> restore() async {
    if (_restored || cache == null) {
      _restored = true;
      return;
    }
    _restored = true;
    try {
      final raw = await cache!.getTelemetry();
      if (raw == null || raw.isEmpty) return;
      final list = jsonDecode(raw);
      if (list is! List) return;
      for (final j in list) {
        if (j is Map<String, dynamic>) {
          try {
            _ring.add(TelemetryEvent.fromJson(j));
          } catch (_) {
            // skip malformed entry; don't let restore poison the buffer
          }
        }
      }
    } catch (_) {
      // Persisted blob is corrupt or storage failed — start fresh.
    }
  }

  /// Capture an error. Synchronous, non-throwing, non-blocking.
  void capture({
    required String source,
    required Object error,
    StackTrace? stack,
    Map<String, dynamic>? context,
    TelemetrySeverity severity = TelemetrySeverity.error,
  }) {
    try {
      final ev = TelemetryEvent(
        timestamp: DateTime.now().toUtc(),
        severity: severity,
        source: source,
        errorClass: error.runtimeType.toString(),
        message: error.toString(),
        stack: stack?.toString(),
        context: context ?? const {},
      );
      _ring.add(ev);
      while (_ring.length > maxBuffer) {
        _ring.removeAt(0);
      }
      _schedulePersist();
    } catch (_) {
      // Capture must never throw. If something is wrong with the buffer
      // (e.g. concurrent modification on web), drop silently — the caller
      // already has the original exception to deal with.
    }
  }

  /// Returns a copy of recent events (newest last). Caller may not mutate.
  List<TelemetryEvent> recent({int? limit}) {
    final out = List<TelemetryEvent>.unmodifiable(_ring);
    if (limit == null || limit >= out.length) return out;
    return List<TelemetryEvent>.unmodifiable(out.sublist(out.length - limit));
  }

  /// JSON-serializable bundle for support / diagnostics. Includes only what
  /// the SDK captured itself; no automatic correlation to backend logs.
  Map<String, dynamic> exportForDiagnostics({int? limit}) => {
        'generated_at': DateTime.now().toUtc().toIso8601String(),
        'events': recent(limit: limit).map((e) => e.toJson()).toList(),
      };

  /// Clear the buffer + persisted blob. Use after a successful upload to
  /// the backend, or when the user toggles "send diagnostics" off.
  Future<void> clear() async {
    _ring.clear();
    _flushTimer?.cancel();
    if (cache != null) {
      try {
        await cache!.putTelemetry('[]');
      } catch (_) {
        // best-effort
      }
    }
  }

  /// Force-flush to storage. Called on dispose so in-flight events aren't
  /// lost between debounce intervals.
  Future<void> flush() async {
    _flushTimer?.cancel();
    await _persistNow();
  }

  void _schedulePersist() {
    if (cache == null) return;
    _flushTimer?.cancel();
    _flushTimer = Timer(persistDebounce, _persistNow);
  }

  Future<void> _persistNow() async {
    if (cache == null) return;
    try {
      final blob = jsonEncode(_ring.map((e) => e.toJson()).toList());
      await cache!.putTelemetry(blob);
    } catch (_) {
      // Storage failure is non-fatal; the in-memory ring still has the
      // events for the current session.
    }
  }
}
