// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../exceptions.dart';

/// v0.1.19 — `LicenseClient.reportCapability` wire path (Bifrost B-9.19).
///
/// A separate concept from the client-side `SdkCapabilities` in
/// `../capabilities.dart`:
///
///   * `SdkCapabilities` gates which sub-APIs a product's SDK exposes
///     (feedback / support / etc). Purely local, product-owned config.
///   * `LicenseClient.reportCapability(...)` PUBLISHES a per-project boolean
///     presence signal (e.g. "does this app support offline export?") to
///     Bifrost so the MS catalog can surface it in aggregate reports WITHOUT
///     any PII crossing the trust boundary.
///
/// Wire contract (mirrored across Dart / Swift / TS SDKs — see
/// `bifrost/packages/api-types/src/fron-parity-fixtures.json §apps`):
///
///   * `POST /v1/apps/capabilities`
///   * auth: PAK-JWE (per-project scope derived from PAK claim)
///   * body: `{ "key": "<has_[a-z0-9_]{2,64}>", "value": <bool> }`
///   * response 200: `{ "key", "value", "updated_at_ms" }`
///   * idempotent by `(project_id, key)`; replay with same value = no-op.
///
/// Client-side validation is fail-fast + defence-in-depth (server also
/// rejects with `CAPABILITY_KEY_INVALID` / `CAPABILITY_VALUE_TYPE_INVALID`).

/// Argument-validation error for `LicenseClient.reportCapability`.
///
/// Thrown BEFORE any wire round-trip when the caller supplies a key that
/// doesn't match `^has_[a-z0-9_]{2,64}$`. The server rejects the same
/// shape with `CAPABILITY_KEY_INVALID` — the client-side check is a
/// fast-fail so a typo surfaces immediately.
class CapabilityKeyInvalidException extends LicenseStoreException {
  /// The offending key the caller passed (echoed for diagnostics).
  final String key;
  CapabilityKeyInvalidException(this.key, {Object? cause})
      : super(
          'Capability key "$key" is invalid — must match '
          '^has_[a-z0-9_]{2,64}\$ (server rejects with '
          'CAPABILITY_KEY_INVALID otherwise).',
          cause: cause,
        );
}

/// Namespace for capability-report validation shared across the Dart SDK.
/// Public so host products can validate keys before calling
/// `reportCapability` (e.g. to gate a UI toggle).
abstract final class CapabilityReportValidation {
  /// The exact regex the server enforces on the wire — mirrored here
  /// byte-for-byte so client-side rejects are identical to server-side.
  ///
  /// Anchored full-string match: only lowercase ASCII letters, digits, and
  /// underscores, `has_`-prefixed, 6..68 total characters.
  static final RegExp keyPattern = RegExp(r'^has_[a-z0-9_]{2,64}$');

  /// Validates [key]. Throws [CapabilityKeyInvalidException] on any mismatch.
  static void requireValidKey(String key) {
    if (!keyPattern.hasMatch(key)) {
      throw CapabilityKeyInvalidException(key);
    }
  }
}

/// Canonical wire keys for the `reportCapability` body — pinned so the
/// cross-language parity fixture can assert on them without re-declaring
/// string literals.
abstract final class ReportCapabilityWire {
  /// Endpoint path — mirrored in the Swift + TS SDKs and pinned in
  /// `fron-parity-fixtures.json §apps.report_capability.route_path`.
  static const String routePath = '/v1/apps/capabilities';

  /// Body key for the capability identifier.
  static const String bodyKeyKey = 'key';

  /// Body key for the boolean value.
  static const String bodyKeyValue = 'value';

  /// Retry policy — maximum attempts INCLUDING the initial call.
  ///
  /// Matches the Swift SDK's `ReportCapabilityWire.maxAttempts` and the
  /// parity fixture's `sdk_retry.max_attempts` (3).
  static const int maxAttempts = 3;

  /// Initial backoff on the first 429 retry, in milliseconds. Doubles per
  /// retry — 100 → 200 → 400ms, matching the parity fixture ladder
  /// `[100, 200, 400]`. No jitter (intentional: the server bucket is
  /// 10 req/min per (project_id, PAK), so a long client-side back-off just
  /// moves the pressure to the next tick).
  static const int backoffMsInitial = 100;
}
