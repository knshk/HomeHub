// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Client-side glue for the FRON payment surface.
///
/// These helpers DO NOT make wire calls — they sit between the typed
/// payment results returned by [DirectClient] and the host app's
/// browser / deep-link plumbing. The SDK deliberately avoids depending
/// on `url_launcher` (or any other browser-launcher package) so that
/// products using a custom in-app browser, an embedded WebView, or a
/// platform-specific deep-link router can wire their own opener
/// without pulling in a runtime they don't need.
///
/// Typical host-app wiring:
/// ```dart
/// final opener = DirectPaymentUrlOpener(
///   open: (url) async {
///     // e.g. url_launcher:
///     await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
///   },
/// );
///
/// final session = await client.startCheckout(
///   tier: 'pro_yearly',
///   billingCycle: 'yearly',
///   currency: 'USD',
///   returnUrl: 'myapp://upgrade-done',
/// );
/// await openCheckoutUrl(session, opener: opener);
///
/// // Later, when the host app receives the return-URL deep-link:
/// final handled = await DirectPaymentDeepLinkHandler.instance
///     .handleReturnUri(uri);
/// if (handled != null) {
///   final fresh = await client.refreshAfterPayment(
///     sessionId: handled.sessionId,
///   );
///   // re-render UI based on `fresh.entitlements`
/// }
/// ```
library;

import 'dart:async';

import 'direct_payment_models.dart';

/// Callable adapter the host app implements to actually open a URL —
/// kept as a typedef-based seam so the SDK has no opinion on whether the
/// host uses `url_launcher`, an embedded WebView, a custom in-app
/// browser, or a platform-channel call.
typedef DirectPaymentUrlOpenerFn = Future<void> Function(String url);

/// Wraps a [DirectPaymentUrlOpenerFn] together with a label so error
/// messages can point ops at the host-app wiring instead of "the SDK
/// failed to open the URL".
class DirectPaymentUrlOpener {
  /// Host-app-provided opener. Receives the URL as a [String]; impl is
  /// free to parse it via `Uri.parse` internally. Must throw on failure
  /// — the SDK rethrows whatever the opener raises so the host's error
  /// telemetry stays unified.
  final DirectPaymentUrlOpenerFn open;

  /// Short label for the underlying impl — surfaces in diagnostic
  /// messages when the SDK rejects a non-https URL.
  final String label;

  const DirectPaymentUrlOpener({
    required this.open,
    this.label = 'host-opener',
  });
}

/// Result of [DirectPaymentDeepLinkHandler.handleReturnUri] — surfaces
/// the parsed `session_id` + `intent_id` the host app should echo back
/// to `refreshAfterPayment` / native payment-sheet completion.
class DirectPaymentReturn {
  /// Hosted-checkout session id, when the deep-link came from a
  /// `startCheckout` flow.
  final String? sessionId;

  /// Native-payment intent id, when the deep-link came from a
  /// `startNativePayment` flow.
  final String? intentId;

  /// Whether the user cancelled (provider-side `?status=cancel`).
  final bool cancelled;

  const DirectPaymentReturn({
    this.sessionId,
    this.intentId,
    this.cancelled = false,
  });
}

/// Opens a hosted-checkout URL via the supplied opener.
///
/// SECURITY: rejects non-https URLs at the SDK layer. The server-side
/// allowlist already validates `return_url`, but a pre-check here
/// catches the failure case BEFORE the user sees the (potentially
/// scary) in-app browser flicker — and prevents an SDK / server skew
/// from leaking a `http://` URL to the host opener.
Future<void> openCheckoutUrl(
  CheckoutSession session, {
  required DirectPaymentUrlOpener opener,
}) async {
  _assertHttpsUrl(session.hostedUrl, field: 'hostedUrl');
  await opener.open(session.hostedUrl);
}

/// Opens a customer-portal URL via the supplied opener.
///
/// SECURITY: same https pre-check as [openCheckoutUrl].
Future<void> openPortalUrl(
  PortalSession portal, {
  required DirectPaymentUrlOpener opener,
}) async {
  _assertHttpsUrl(portal.portalUrl, field: 'portalUrl');
  await opener.open(portal.portalUrl);
}

/// Singleton handler the host app routes inbound deep-link URIs through
/// after a checkout / portal session returns.
///
/// The handler is intentionally stateless re: in-flight session ids —
/// it just parses the URI and reports what it found. The host app
/// correlates the parsed [DirectPaymentReturn] with whatever client-side
/// state it's tracking and decides whether to call
/// `refreshAfterPayment`.
class DirectPaymentDeepLinkHandler {
  DirectPaymentDeepLinkHandler._();
  static final DirectPaymentDeepLinkHandler instance =
      DirectPaymentDeepLinkHandler._();

  final StreamController<DirectPaymentReturn> _controller =
      StreamController<DirectPaymentReturn>.broadcast();

  /// Broadcast stream of parsed deep-link returns. Host apps can listen
  /// here as an alternative to the imperative [handleReturnUri] return
  /// value (useful when the deep-link arrives on a different code path
  /// than the one that started the checkout).
  Stream<DirectPaymentReturn> get onReturn => _controller.stream;

  /// Parses an inbound deep-link [Uri] and, if it looks like a payment
  /// return, emits it on [onReturn] and returns the parsed result.
  /// Returns null when the URI does not look like a payment return so
  /// the host app can fall through to other deep-link handlers.
  ///
  /// Recognised query params (matching server convention):
  ///   * `session_id` — hosted-checkout session
  ///   * `intent_id`  — native-payment intent
  ///   * `status=cancel` — user cancelled
  DirectPaymentReturn? handleReturnUri(Uri uri) {
    final sessionId = uri.queryParameters['session_id'];
    final intentId = uri.queryParameters['intent_id'];
    final status = uri.queryParameters['status'];
    final cancelled = status == 'cancel' || status == 'cancelled';
    if (sessionId == null && intentId == null && !cancelled) {
      return null;
    }
    final parsed = DirectPaymentReturn(
      sessionId: sessionId,
      intentId: intentId,
      cancelled: cancelled,
    );
    _controller.add(parsed);
    return parsed;
  }

  /// Test seam — close the broadcast stream.
  Future<void> dispose() async {
    await _controller.close();
  }
}

void _assertHttpsUrl(String url, {required String field}) {
  // Bound the size to catch obvious garbage before parsing — Uri.parse
  // on a multi-MB string is wasteful.
  if (url.isEmpty || url.length > 4096) {
    throw ArgumentError.value(
      url.length > 64 ? '${url.substring(0, 64)}…' : url,
      field,
      '$field must be a non-empty URL under 4096 characters',
    );
  }
  Uri parsed;
  try {
    parsed = Uri.parse(url);
  } catch (_) {
    throw ArgumentError.value(url, field, '$field is not a valid URL');
  }
  if (parsed.scheme.toLowerCase() != 'https') {
    throw ArgumentError.value(
      parsed.scheme,
      field,
      '$field must use https (got ${parsed.scheme}://)',
    );
  }
}
