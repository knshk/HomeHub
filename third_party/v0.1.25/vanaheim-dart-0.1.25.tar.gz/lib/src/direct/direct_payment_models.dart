// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// FRON payment-surface DTOs + extended error taxonomy.
///
/// Mirrors the wire shapes emitted by Bifrost's
/// `bifrost/packages/functions/src/direct/handlers/payment.ts` 1:1. Kept in
/// a sibling file to `direct_models.dart` so the L2 surface stays untouched
/// and the FRON payment leg can evolve independently.
///
/// All payment endpoints are Tier 2 (durable JWS + JWE response) — there is
/// NO new crypto path here; the existing [DirectRequestBuilder] +
/// [DirectResponseParser] handle envelope construction and verification.
library;

import 'package:meta/meta.dart';

import 'direct_models.dart';

// ---------------------------------------------------------------------------
// Payment DTOs
// ---------------------------------------------------------------------------

/// Result of `startCheckout` — host-app should drive a browser to
/// [hostedUrl] (use [openCheckoutUrl] helper). Server-side reconciliation
/// is keyed on [sessionId]; pass it to `refreshAfterPayment` once the
/// return-URL deep-link fires.
@immutable
class CheckoutSession {
  /// Provider-side session identifier (e.g. Stripe `cs_test_*`). The SDK
  /// echoes this back to `/payment/refresh` once the user returns from
  /// the hosted checkout so the server can confirm the webhook has
  /// reconciled the session before re-minting the entitlement.
  final String sessionId;

  /// Provider-hosted checkout URL. Must be opened in an in-app browser /
  /// the system browser; host-app responsibility (see
  /// [openCheckoutUrl] in `direct_payment_browser.dart`).
  final String hostedUrl;

  /// Wall-clock epoch ms after which the hosted URL stops working. The
  /// SDK does NOT auto-refresh — host app should re-call `startCheckout`
  /// when the user re-enters the upgrade flow past this point.
  final int expiresAtMs;

  const CheckoutSession({
    required this.sessionId,
    required this.hostedUrl,
    required this.expiresAtMs,
  });

  factory CheckoutSession.fromJson(Map<String, dynamic> j) => CheckoutSession(
        sessionId: (j['session_id'] as String?) ?? '',
        hostedUrl: (j['hosted_url'] as String?) ?? '',
        expiresAtMs: (j['expires_at_ms'] is num)
            ? (j['expires_at_ms'] as num).toInt()
            : 0,
      );
}

/// Result of `startNativePayment` — pass [clientSecret] to the platform's
/// native payment sheet (Stripe Payment Sheet / Apple Pay / Google Pay).
@immutable
class PaymentIntent {
  /// Provider-side intent identifier. Echoed by the platform payment-
  /// sheet completion callback so the host app can correlate intent →
  /// webhook → entitlement refresh.
  final String intentId;

  /// Provider-issued client secret. Confidential at the host-app layer —
  /// do NOT log. Passed to the platform payment-sheet API verbatim.
  final String clientSecret;

  /// Wall-clock epoch ms after which the intent can no longer be
  /// captured. Provider-side default is typically 24h; do not cache.
  final int expiresAtMs;

  const PaymentIntent({
    required this.intentId,
    required this.clientSecret,
    required this.expiresAtMs,
  });

  factory PaymentIntent.fromJson(Map<String, dynamic> j) => PaymentIntent(
        intentId: (j['intent_id'] as String?) ?? '',
        clientSecret: (j['client_secret'] as String?) ?? '',
        expiresAtMs: (j['expires_at_ms'] is num)
            ? (j['expires_at_ms'] as num).toInt()
            : 0,
      );
}

/// Result of `openPortal` — host-app drives a browser to [portalUrl]
/// (use [openPortalUrl]). Server marks the portal session expired after
/// [expiresAtMs].
@immutable
class PortalSession {
  /// Provider-hosted customer-portal URL (Stripe Billing Portal, Paddle
  /// customer portal, etc.). Single-use; do NOT persist past the
  /// host-app open call.
  final String portalUrl;
  final int expiresAtMs;

  const PortalSession({
    required this.portalUrl,
    required this.expiresAtMs,
  });

  factory PortalSession.fromJson(Map<String, dynamic> j) => PortalSession(
        portalUrl: (j['portal_url'] as String?) ?? '',
        expiresAtMs: (j['expires_at_ms'] is num)
            ? (j['expires_at_ms'] as num).toInt()
            : 0,
      );
}

/// One row in [RestoreResult.restored]. Mirrors the server's per-purchase
/// projection — license_key + tier + valid_until (no PII).
@immutable
class RestoredPurchase {
  final String licenseKey;
  final String tier;
  /// Epoch ms — when this restored purchase's entitlement window ends.
  final int validUntil;

  const RestoredPurchase({
    required this.licenseKey,
    required this.tier,
    required this.validUntil,
  });

  factory RestoredPurchase.fromJson(Map<String, dynamic> j) => RestoredPurchase(
        licenseKey: (j['license_key'] as String?) ?? '',
        tier: (j['tier'] as String?) ?? '',
        validUntil: (j['valid_until'] is num)
            ? (j['valid_until'] as num).toInt()
            : 0,
      );
}

/// Result of `restorePurchases` — invariant: `restoredCount > 0` ⇒
/// `entitlementJws != null` (server hard-fails the half-success path; see
/// `payment.ts` B-FRON.5.4 invariant). When [restoredCount] == 0 the SDK
/// should surface a "no purchases found" UX without erroring.
@immutable
class RestoreResult {
  /// Projection of the restored purchases — license_key + tier +
  /// valid_until per row. Capped at 100 entries by the SDK (defence-in-
  /// depth against a server that returns an unbounded list).
  final List<RestoredPurchase> restored;

  /// Fresh entitlement JWS minted off the longest-valid restored
  /// purchase. Null when [restoredCount] == 0.
  final String? entitlementJws;

  /// Convenience accessor — server-supplied count (matches
  /// `restored.length` when the response was not truncated client-side).
  final int restoredCount;

  const RestoreResult({
    required this.restored,
    required this.entitlementJws,
    required this.restoredCount,
  });

  factory RestoreResult.fromJson(Map<String, dynamic> j) {
    final raw = j['restored'];
    final list = <RestoredPurchase>[];
    if (raw is List) {
      for (final r in raw) {
        if (r is Map) {
          list.add(RestoredPurchase.fromJson(r.cast<String, dynamic>()));
          // Defence-in-depth: bound at 100 so a malicious server cannot
          // OOM the SDK with an unbounded restore set.
          if (list.length >= 100) break;
        }
      }
    }
    final jws = j['entitlement_jws'];
    final count = (j['restored_count'] is num)
        ? (j['restored_count'] as num).toInt()
        : list.length;
    return RestoreResult(
      restored: List.unmodifiable(list),
      entitlementJws: (jws is String && jws.isNotEmpty) ? jws : null,
      restoredCount: count,
    );
  }
}

/// Result of `verifyIapReceipt`. Mirrors the dual-shape wire response —
/// on success: `valid=true` + license fields + entitlementJws; on
/// soft-rejection (server-side `DirectIapReceiptInvalidError` with a
/// narrow reason): `valid=false` + [reason]. Hard provider failures
/// surface as [DirectPaymentProviderFailedError] instead.
@immutable
class IapVerifyResult {
  final bool valid;
  final String? licenseKey;
  final String? tier;
  /// Epoch ms — entitlement window end.
  final int? validUntil;
  /// Fresh entitlement JWS minted off the verified IAP. Null when
  /// [valid] is false.
  final String? entitlementJws;
  /// Narrow soft-rejection reason when [valid] is false. Stable wire
  /// strings (e.g. `unknown`, `expired`, `consumed`, `cross_account`).
  final String? reason;

  const IapVerifyResult({
    required this.valid,
    this.licenseKey,
    this.tier,
    this.validUntil,
    this.entitlementJws,
    this.reason,
  });

  factory IapVerifyResult.fromJson(Map<String, dynamic> j) {
    final valid = (j['valid'] as bool?) ?? false;
    final licenseKey = j['license_key'];
    final tier = j['tier'];
    final until = j['valid_until'];
    final jws = j['entitlement_jws'];
    final reason = j['reason'];
    return IapVerifyResult(
      valid: valid,
      licenseKey: licenseKey is String ? licenseKey : null,
      tier: tier is String ? tier : null,
      validUntil: until is num ? until.toInt() : null,
      entitlementJws: jws is String && jws.isNotEmpty ? jws : null,
      reason: reason is String ? reason : null,
    );
  }
}

// ---------------------------------------------------------------------------
// Payment-specific error taxonomy
//
// These extend the FRON error hierarchy from `direct_models.dart`. The
// router `directPaymentErrorFromCode` is consumed by the extended
// `directErrorFromCode` helper (see `direct_models.dart`) — we register
// the payment codes there via the [registerDirectPaymentErrorCodes] hook
// invoked at library init.
// ---------------------------------------------------------------------------

/// Server returned `DIRECT_PAYMENT_PROVIDER_FAILED` — the configured
/// payment provider (Stripe / Paddle / etc.) refused or errored. The
/// payload is scrubbed of provider text on the server (defence against
/// info-leak); only the coarse [provider] tag lands here.
class DirectPaymentProviderFailedError extends DirectError {
  /// Coarse provider tag (`stripe`, `paddle`, `lemon_squeezy`, `razorpay`,
  /// `apple_iap`, `google_iap`, `restore`, or `default` when the server
  /// could not pin a specific provider).
  final String provider;

  DirectPaymentProviderFailedError(this.provider, [String? message])
      : super(
          'DIRECT_PAYMENT_PROVIDER_FAILED',
          message ?? 'Payment provider call failed ($provider)',
        );
}

/// Server returned `DIRECT_NO_ACTIVE_SUBSCRIPTION` — `openPortal` was
/// called for a device with no active / trialing subscription. SDK
/// should route the user through `startCheckout` instead.
class DirectNoActiveSubscriptionError extends DirectError {
  DirectNoActiveSubscriptionError(
      [String message = 'No active subscription for this device'])
      : super('DIRECT_NO_ACTIVE_SUBSCRIPTION', message);
}

/// Server returned `DIRECT_SESSION_NOT_FOUND` — the supplied
/// `session_id` is unknown OR belongs to a different device (probe
/// defence — both surface the same code). Caller should re-start
/// checkout.
class DirectSessionNotFoundError extends DirectError {
  DirectSessionNotFoundError(
      [String message = 'Checkout session not found'])
      : super('DIRECT_SESSION_NOT_FOUND', message);
}

/// Server returned `DIRECT_SESSION_NOT_COMPLETE` — the webhook has not
/// yet flipped the session to completed=true. SDK should back off and
/// retry `refreshAfterPayment` after a short delay.
class DirectSessionNotCompleteError extends DirectError {
  DirectSessionNotCompleteError(
      [String message = 'Checkout session not yet complete'])
      : super('DIRECT_SESSION_NOT_COMPLETE', message);
}

/// Server returned `DIRECT_IAP_RECEIPT_INVALID` — Apple / Google
/// rejected the receipt. [reason] is the narrow wire string (e.g.
/// `unknown`, `expired`, `consumed`, `cross_account`).
class DirectIapReceiptInvalidError extends DirectError {
  final String? reason;

  DirectIapReceiptInvalidError({this.reason, String? message})
      : super(
          'DIRECT_IAP_RECEIPT_INVALID',
          message ??
              'IAP receipt rejected${reason != null ? ' ($reason)' : ''}',
        );
}

/// Map a payment wire code → typed exception. Falls through to null when
/// the code is not a payment-surface code so the caller can fall back to
/// the general [directErrorFromCode] router.
DirectError? directPaymentErrorFromCode(
  String code, {
  String? message,
  int? retryAfterMs,
  String? reason,
  String? provider,
}) {
  switch (code) {
    case 'DIRECT_PAYMENT_PROVIDER_FAILED':
      return DirectPaymentProviderFailedError(
        provider ?? 'default',
        message,
      );
    case 'DIRECT_NO_ACTIVE_SUBSCRIPTION':
      return DirectNoActiveSubscriptionError(
          message ?? 'No active subscription for this device');
    case 'DIRECT_SESSION_NOT_FOUND':
      return DirectSessionNotFoundError(
          message ?? 'Checkout session not found');
    case 'DIRECT_SESSION_NOT_COMPLETE':
      return DirectSessionNotCompleteError(
          message ?? 'Checkout session not yet complete');
    case 'DIRECT_IAP_RECEIPT_INVALID':
      return DirectIapReceiptInvalidError(
        reason: reason,
        message: message,
      );
    default:
      return null;
  }
}

/// Ensures the payment-surface wire codes are registered with the global
/// [directErrorFromCode] router. Safe to call repeatedly — registration
/// is idempotent. Invoked automatically by [DirectPaymentMethods] the
/// first time a payment method runs; tests may call it eagerly.
void ensureDirectPaymentErrorsRegistered() {
  registerDirectErrorExtension(directPaymentErrorFromCode);
}

