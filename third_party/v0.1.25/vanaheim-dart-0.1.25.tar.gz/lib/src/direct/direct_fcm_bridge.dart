// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Wires the existing [PushTokenProvider] (firebase_messaging on Flutter)
/// into `DirectClient.registerFcmToken`. The bridge:
///
///   * On `start()`: pulls the current token, sends it once if non-empty.
///   * Listens to `tokenChanges`: re-sends on rotation.
///   * Listens to `incomingMessages`: pulls out `notification_id` and
///     calls `DirectClient.ackNotification` so the server can confirm
///     delivery.
///
/// Errors during send are swallowed (forwarded to [onError] if given) so
/// a flaky network doesn't surface inside the Firebase plugin's stream.
library;

import 'dart:async';
import 'dart:io' show Platform;

import '../push/push_token_provider.dart';

typedef SendFcmTokenFn = Future<void> Function(String token, String platform);
typedef AckNotificationFn = Future<void> Function(
    String notificationId, int receivedAtMs, {bool? displayed});

class DirectFcmBridge {
  final PushTokenProvider _push;
  final SendFcmTokenFn _sendToken;
  final AckNotificationFn _ack;
  final void Function(Object error, StackTrace st)? onError;

  StreamSubscription<String>? _tokenSub;
  StreamSubscription<Map<String, dynamic>>? _msgSub;
  String? _lastSentToken;
  bool _disposed = false;

  DirectFcmBridge({
    required PushTokenProvider push,
    required SendFcmTokenFn sendToken,
    required AckNotificationFn ack,
    this.onError,
  })  : _push = push,
        _sendToken = sendToken,
        _ack = ack;

  /// Subscribe to the underlying provider + send the current token (if any).
  /// Idempotent — calling twice is a no-op.
  Future<void> start() async {
    if (_disposed) return;
    if (_push is NoPushTokenProvider) return;
    _tokenSub ??= _push.tokenChanges.listen(
      (tok) => unawaited(_maybeSend(tok)),
      onError: (Object e, StackTrace st) => onError?.call(e, st),
    );
    _msgSub ??= _push.incomingMessages.listen(
      (msg) => unawaited(_maybeAck(msg)),
      onError: (Object e, StackTrace st) => onError?.call(e, st),
    );
    try {
      final tok = await _push.getToken();
      if (tok.isNotEmpty) await _maybeSend(tok);
    } catch (e, st) {
      onError?.call(e, st);
    }
  }

  Future<void> stop() async {
    await _tokenSub?.cancel();
    await _msgSub?.cancel();
    _tokenSub = null;
    _msgSub = null;
  }

  Future<void> dispose() async {
    _disposed = true;
    await stop();
  }

  Future<void> _maybeSend(String token) async {
    if (token.isEmpty || token == _lastSentToken) return;
    try {
      await _sendToken(token, _platformName());
      _lastSentToken = token;
    } catch (e, st) {
      onError?.call(e, st);
    }
  }

  Future<void> _maybeAck(Map<String, dynamic> message) async {
    final id = message['notification_id'] ?? message['notificationId'];
    if (id is! String || id.isEmpty) return;
    final receivedAt = DateTime.now().toUtc().millisecondsSinceEpoch;
    try {
      await _ack(id, receivedAt, displayed: true);
    } catch (e, st) {
      onError?.call(e, st);
    }
  }

  static String _platformName() {
    try {
      if (Platform.isAndroid) return 'android';
      if (Platform.isIOS) return 'ios';
      if (Platform.isMacOS) return 'macos';
      if (Platform.isWindows) return 'windows';
      if (Platform.isLinux) return 'linux';
      if (Platform.isFuchsia) return 'fuchsia';
    } catch (_) {
      // dart:io is unavailable on the web — fall through to 'web'.
    }
    return 'web';
  }
}
