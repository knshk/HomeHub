// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Builds the FRON wire envelope:
///
///   1. Inner Ed25519 JWS over the request claims.
///      - Ephemeral mode (`/direct/v1/register`):
///        * `typ: bifrost-direct+ephemeral+jws`
///        * `device_pub_jwk` embedded in header (Ed25519 pubkey)
///        * Signed with the ephemeral Ed25519 priv key
///      - Durable mode (everything else):
///        * `typ: bifrost-direct+durable+jws`
///        * Claims carry `device_id`
///        * Signed with the durable Ed25519 priv key
///
///   2. JWE-wrap the inner JWS bytes for the Bifrost X25519 recipient
///      using the existing [crypto/jwe_codec.JweCodec].
///      - `typ: bifrost-direct+jwe`, `lcs_v: 2`
///      - `apu` = SHA-256(X25519 pubkey) — the SDK's X25519 thumbprint
///        (ephemeral on register, durable on every other call)
///      - `apv` = recipient kid
///
/// Output is a single compact 5-segment JWE string ready to POST to
/// `/direct/v1/<endpoint>` with `Content-Type: application/jose+json`.
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' as c;
import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;

import '../crypto/thumbprint.dart' show pubKeyThumbprint;
import 'direct_keypair_store.dart';
import 'direct_recipient_resolver.dart';

/// `typ` values pinned in the FRON envelope. The server rejects anything
/// else BEFORE touching the key material — keep these in lockstep with
/// `bifrost/packages/functions/src/direct/jws-verifier.ts` +
/// `jwe-recipient.ts`.
const String kDirectJweTyp = 'bifrost-direct+jwe';
const String kDirectJwsTypEphemeral = 'bifrost-direct+ephemeral+jws';
const String kDirectJwsTypDurable = 'bifrost-direct+durable+jws';
const int kDirectLcsVersion = 2;

/// Result of [DirectRequestBuilder.build]. The caller POSTs [compactJwe]
/// to the FRON endpoint; the JWE codec generates a fresh `epk` per call
/// for forward secrecy, but the JWS-level X25519 thumbprint stays stable
/// — that's what gets recorded as the apu binding.
class DirectRequestEnvelope {
  final String compactJwe;
  /// X25519 pub used as the apu binding source. Useful for diagnostics.
  final Uint8List senderX25519Pub;
  const DirectRequestEnvelope({
    required this.compactJwe,
    required this.senderX25519Pub,
  });
}

/// Pure-function builder. No I/O. The crypto comes from the existing
/// `JweCodec` (X25519 ECDH-ES + A256GCM ConcatKDF) and `ed25519_edwards`
/// for the inner JWS.
class DirectRequestBuilder {
  final String projectId;

  const DirectRequestBuilder({required this.projectId});

  // -------------------------------------------------------------- ephemeral

  /// Build a Tier-1 (registration) envelope. The inner JWS embeds the
  /// ephemeral Ed25519 pubkey in `header.device_pub_jwk` so the server
  /// can verify the signature without prior knowledge.
  ///
  /// For the `/direct/v1/register` route, the SDK MUST place the
  /// base64url-encoded Ed25519 pubkey under `body.ephemeral_pubkey` so
  /// the Bifrost handler can cross-check it against the JWS header's
  /// `device_pub_jwk.x`. This builder injects it automatically — the
  /// caller does NOT need to set it on `body`.
  ///
  /// [aud] is the canonical, colon-namespaced JWS audience claim
  /// (e.g. `direct:register`, `direct:payment.checkout`). When omitted
  /// the builder falls back to [routePath] for backward compatibility,
  /// but new callers SHOULD always pass an explicit `aud` — see B-Fix 2
  /// (aud namespace convergence) in the W6 fix-pass notes.
  Future<DirectRequestEnvelope> buildEphemeral({
    required String routePath,
    required String requestId,
    required Map<String, dynamic> body,
    required DirectEphemeralIdentity ephemeral,
    required BifrostRecipientKey recipient,
    String? aud,
    int? nowMs,
  }) async {
    // Auto-inject ephemeral_pubkey into the body so it always matches the
    // JWS header's device_pub_jwk.x. We use raw Ed25519 pub bytes,
    // base64url-no-pad — byte-identical to the header `x` field.
    final stampedBody = <String, dynamic>{
      ...body,
      'ephemeral_pubkey': _b64UrlNoPad(ephemeral.ed25519Pub),
    };
    final jws = _signEd25519(
      typ: kDirectJwsTypEphemeral,
      ed25519Pub: ephemeral.ed25519Pub,
      ed25519Priv: ephemeral.ed25519Priv,
      claims: _stamp(
        body: stampedBody,
        routePath: routePath,
        aud: aud ?? routePath,
        requestId: requestId,
        deviceId: null,
        nowMs: nowMs,
      ),
      embedDevicePubJwk: true,
    );
    return _wrapJwe(
      innerJws: jws,
      senderX25519Pub: ephemeral.x25519Pub,
      recipient: recipient,
      routePath: routePath,
      requestId: requestId,
    );
  }

  // ---------------------------------------------------------------- durable

  /// Build a Tier-2 envelope signed with the durable device keypair.
  ///
  /// [aud] is the canonical, colon-namespaced JWS audience claim
  /// (e.g. `direct:verify`, `direct:payment.checkout`). When omitted
  /// the builder falls back to [routePath] for backward compatibility,
  /// but new callers SHOULD always pass an explicit `aud` — see B-Fix 2
  /// (aud namespace convergence) in the W6 fix-pass notes.
  Future<DirectRequestEnvelope> buildDurable({
    required String routePath,
    required String requestId,
    required Map<String, dynamic> body,
    required DirectDurableIdentity identity,
    required BifrostRecipientKey recipient,
    String? aud,
    int? nowMs,
  }) async {
    // server_nonce belongs in the body (it's a per-call FRON-route
    // payload field), not at the JWS top level — the server treats the
    // top-level claims as fixed shape and inspects body for everything
    // else.
    final stampedBody = <String, dynamic>{
      ...body,
      if (identity.serverNonce != null) 'server_nonce': identity.serverNonce,
    };
    final jws = _signEd25519(
      typ: kDirectJwsTypDurable,
      ed25519Pub: identity.ed25519Pub,
      ed25519Priv: identity.ed25519Priv,
      claims: _stamp(
        body: stampedBody,
        routePath: routePath,
        aud: aud ?? routePath,
        requestId: requestId,
        deviceId: identity.deviceId,
        nowMs: nowMs,
      ),
      embedDevicePubJwk: false,
    );
    return _wrapJwe(
      innerJws: jws,
      senderX25519Pub: identity.x25519Pub,
      recipient: recipient,
      routePath: routePath,
      requestId: requestId,
    );
  }

  // ----------------------------------------------------------------- shared

  /// Default JWS expiry window — 60s of skew matches the Bifrost
  /// `DIRECT_JWS_CLOCK_SKEW_MS_DEFAULT`. Kept as a const so wire-compat
  /// tests can pin it.
  static const int kDefaultExpiryWindowMs = 60000;

  /// Build the inner JWS claims with the Bifrost-required shape:
  /// `{aud, iat, nbf, exp, jti, project_id, device_id?, body}` — RFC 7519
  /// standard claim names, per the server's `DirectJwsClaims` interface in
  /// `bifrost/packages/functions/src/direct/jws-verifier.ts`. `aud`
  /// carries the route audience (e.g. `direct:register`) and `jti` is the
  /// caller-supplied request id (the server's anti-replay ledger keys on
  /// it alongside the JWE epk thumbprint).
  ///
  /// iat/nbf/exp are MILLISECONDS-SINCE-EPOCH (not seconds) — this matches
  /// the server's ms-based clock-skew arithmetic. A flat claim layout
  /// would silently drift past the server's `parseDirectBody` helper which
  /// expects payload-specific fields nested under `body`.
  Map<String, dynamic> _stamp({
    required Map<String, dynamic> body,
    required String routePath,
    required String aud,
    required String requestId,
    String? deviceId,
    int? nowMs,
  }) {
    // Allow the caller to inject a fixed timestamp for deterministic
    // parity / fixture testing. Production callers leave it null and we
    // fall back to wall-clock time.
    final stampMs = nowMs ?? DateTime.now().toUtc().millisecondsSinceEpoch;
    return <String, dynamic>{
      'iat': stampMs,
      'nbf': stampMs,
      'exp': stampMs + kDefaultExpiryWindowMs, // iat + 60_000ms (60s skew)
      'aud': aud,
      'jti': requestId,
      'project_id': projectId,
      if (deviceId != null) 'device_id': deviceId,
      'body': body,
    };
  }

  /// Constructs a compact 3-segment Ed25519 JWS. `embedDevicePubJwk=true`
  /// inlines the pubkey for ephemeral-mode verification.
  String _signEd25519({
    required String typ,
    required Uint8List ed25519Pub,
    required Uint8List ed25519Priv,
    required Map<String, dynamic> claims,
    required bool embedDevicePubJwk,
  }) {
    final header = <String, dynamic>{
      'alg': 'EdDSA',
      'typ': typ,
    };
    if (embedDevicePubJwk) {
      header['device_pub_jwk'] = {
        'kty': 'OKP',
        'crv': 'Ed25519',
        'x': _b64UrlNoPad(ed25519Pub),
      };
    }

    final headerJson = jsonEncode(header);
    final claimsJson = jsonEncode(claims);
    final headerB64 = _b64UrlNoPad(Uint8List.fromList(utf8.encode(headerJson)));
    final claimsB64 = _b64UrlNoPad(Uint8List.fromList(utf8.encode(claimsJson)));
    final signingInput = ascii.encode('$headerB64.$claimsB64');
    final sig = ed25519.sign(
      ed25519.PrivateKey(ed25519Priv),
      Uint8List.fromList(signingInput),
    );
    final sigB64 = _b64UrlNoPad(Uint8List.fromList(sig));
    return '$headerB64.$claimsB64.$sigB64';
  }

  Future<DirectRequestEnvelope> _wrapJwe({
    required String innerJws,
    required Uint8List senderX25519Pub,
    required BifrostRecipientKey recipient,
    required String routePath,
    required String requestId,
  }) async {
    // apu = b64url(SHA-256(sender X25519 pubkey)) — stable across calls
    // for a given identity (ephemeral or durable).
    final apu = await pubKeyThumbprint(senderX25519Pub);
    final apv = recipient.kid;

    // Reuse the production JWE codec — it already enforces
    // single-recipient, ECDH-ES, A256GCM, with header AAD per RFC 7516.
    // The `typ`/`lcs_v` defaults inside the codec match L2 ("lcs+jwe");
    // FRON needs `bifrost-direct+jwe`. The codec sets typ from a constant
    // we cannot override per-call, so we wrap the envelope through the
    // public encryptForRecipient surface and then patch the typ in the
    // header.
    //
    // To keep the build cryptographically equivalent we mint the envelope
    // via the codec, decode the header, swap `typ`, recompute the AAD
    // binding (header b64) -- but that would invalidate the GCM tag.
    //
    // Therefore: roll the envelope here, matching the codec's algorithm
    // exactly (X25519 ECDH-ES → ConcatKDF → A256GCM). The math is
    // identical so any byte-for-byte regression vs JweCodec will surface
    // in cross-SDK fixtures.
    final compact = await _encryptForRecipientWithFronTyp(
      innerJwsBytes: Uint8List.fromList(utf8.encode(innerJws)),
      recipientPub: c.SimplePublicKey(recipient.pub, type: c.KeyPairType.x25519),
      recipientKid: recipient.kid,
      apu: apu,
      apv: apv,
      routePath: routePath,
      requestId: requestId,
      projectId: projectId,
    );

    return DirectRequestEnvelope(
      compactJwe: compact,
      senderX25519Pub: senderX25519Pub,
    );
  }

  // ------------------------------------------------------------- crypto core
  //
  // Mirrors `JweCodec.encryptForRecipient` exactly EXCEPT the header `typ`
  // is `bifrost-direct+jwe` instead of `lcs+jwe`. Header layout, AAD
  // binding, ECDH-ES, ConcatKDF, A256GCM nonce/tag handling — all
  // identical. This keeps cross-SDK fixture parity with the L2 codec
  // while letting the server route on `typ` unambiguously.

  static final c.X25519 _x25519 = c.X25519();
  static final c.AesGcm _aesGcm = c.AesGcm.with256bits();

  Future<String> _encryptForRecipientWithFronTyp({
    required Uint8List innerJwsBytes,
    required c.SimplePublicKey recipientPub,
    required String recipientKid,
    required String apu,
    required String apv,
    required String routePath,
    required String requestId,
    required String projectId,
  }) async {
    // 1. Fresh ephemeral X25519 keypair for the JWE epk.
    final epk = await _x25519.newKeyPair();
    final epkPub = await epk.extractPublicKey();

    final headerMap = <String, dynamic>{
      'alg': 'ECDH-ES',
      'enc': 'A256GCM',
      'kid': recipientKid,
      'epk': {
        'kty': 'OKP',
        'crv': 'X25519',
        'x': _b64UrlNoPad(Uint8List.fromList(epkPub.bytes)),
      },
      'apu': apu,
      'apv': apv,
      'project_id': projectId,
      'route_path': routePath,
      'request_id': requestId,
      'typ': kDirectJweTyp,
      'lcs_v': kDirectLcsVersion,
    };
    final headerJsonBytes =
        Uint8List.fromList(utf8.encode(jsonEncode(headerMap)));
    final protectedB64 = _b64UrlNoPad(headerJsonBytes);

    // 2. ECDH-ES → ConcatKDF(A256GCM, apu, apv) → CEK.
    final cekBytes =
        await _deriveCek(myKeyPair: epk, peerPub: recipientPub, apu: apu, apv: apv);
    final cek = c.SecretKey(cekBytes);

    // 3. AES-GCM. AAD = ASCII(b64url(protected header)).
    final aadBytes = ascii.encode(protectedB64);
    final secretBox =
        await _aesGcm.encrypt(innerJwsBytes, secretKey: cek, aad: aadBytes);

    return [
      protectedB64,
      '', // encrypted_key empty for ECDH-ES direct (RFC 7518 §4.6).
      _b64UrlNoPad(Uint8List.fromList(secretBox.nonce)),
      _b64UrlNoPad(Uint8List.fromList(secretBox.cipherText)),
      _b64UrlNoPad(Uint8List.fromList(secretBox.mac.bytes)),
    ].join('.');
  }

  /// Direct ECDH-ES → ConcatKDF (NIST SP 800-56A §5.8.1 per RFC 7518 §4.6.2).
  /// Identical bytes-for-bytes to `JweCodec._deriveCek` — keep in sync.
  Future<Uint8List> _deriveCek({
    required c.SimpleKeyPair myKeyPair,
    required c.SimplePublicKey peerPub,
    required String apu,
    required String apv,
  }) async {
    final shared = await _x25519.sharedSecretKey(
      keyPair: myKeyPair,
      remotePublicKey: peerPub,
    );
    final z = Uint8List.fromList(await shared.extractBytes());
    if (z.length != 32) {
      throw StateError('X25519 shared secret must be 32 bytes, got ${z.length}');
    }
    final algId = utf8.encode('A256GCM');
    final apuBytes = utf8.encode(apu);
    final apvBytes = utf8.encode(apv);

    final otherInfo = BytesBuilder()
      ..add(_u32be(algId.length))
      ..add(algId)
      ..add(_u32be(apuBytes.length))
      ..add(apuBytes)
      ..add(_u32be(apvBytes.length))
      ..add(apvBytes)
      ..add(_u32be(256));

    final hashInput = BytesBuilder()
      ..add(_u32be(1))
      ..add(z)
      ..add(otherInfo.toBytes());

    final digest = await c.Sha256().hash(hashInput.toBytes());
    return Uint8List.fromList(digest.bytes);
  }

  // ----------------------------------------------------------------- bytes

  static Uint8List _u32be(int v) {
    final out = ByteData(4)..setUint32(0, v, Endian.big);
    return out.buffer.asUint8List();
  }

  static String _b64UrlNoPad(Uint8List bytes) =>
      base64Url.encode(bytes).replaceAll('=', '');
}

