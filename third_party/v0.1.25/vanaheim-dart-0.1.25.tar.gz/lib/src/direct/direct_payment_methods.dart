// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// FRON payment-surface methods exposed as a [DirectClient] extension.
///
/// All six methods are Tier 2 (durable JWS + JWE response) — they reuse
/// the existing [DirectRequestBuilder.buildDurable] + [DirectResponseParser]
/// path via the SDK-private [DirectClient.callDurableInternal] seam. No
/// new crypto path, no new wire shape — just typed wrappers around the
/// `/direct/v1/payment/*` endpoints documented in
/// `bifrost/docs/FRON_design.md` §6.
///
/// The methods are intentionally added as an extension (not member
/// methods on [DirectClient]) so the payment surface can evolve without
/// re-cutting the L2 client class — and so a host product that never
/// uses billing can still tree-shake the payment-side error taxonomy
/// (the extension's symbol graph is only retained when at least one
/// method is referenced).
library;

import '../exceptions.dart';
import 'direct_client.dart';
import 'direct_models.dart';
import 'direct_payment_models.dart';

/// Client-side bound for the IAP `receipt` field. Apple JWS receipts run
/// ~4-8 KB, Google Play purchase tokens are ~250-500 chars. The server
/// hard-caps at 16 KB; we cap at 24 KB here (matching Swift parity after
/// S-Fix 3 in the W6 fix-pass) to leave a small wiggle-room headroom over
/// the server bound while still failing CLOSED before any malicious or
/// buggy payload eats the project's rate-limit budget. Anything past
/// this is malformed — exceeding triggers a client-side
/// [DirectBadRequestError] before any wire hit, preventing the SDK from
/// burning rate-limit budget on garbage payloads.
///
/// Previous value (64 KB) was discovered to massively over-shoot the
/// server's 16 KB ceiling, meaning oversized payloads were eating wire
/// budget on every retry before the server rejected them. D-Fix 3 of
/// the W6 fix-pass aligns Dart with Swift at 24 KB.
const int kIapReceiptMaxBytes = 24 * 1024;

// ---------------------------------------------------------------------------
// Canonical JWS `aud` audiences for the payment surface.
//
// Per B-Fix 2 (aud namespace convergence) in the W6 fix-pass, all FRON
// SDK endpoints must emit the colon-namespaced audience shape
// (`direct:<area>.<endpoint>`) so server-side audience pinning has a
// single canonical value across Dart + Swift + future SDKs. The HTTP
// route path stays whatever the wire requires (`/direct/v1/payment/...`)
// — only the inner-JWS `aud` claim changes.
// ---------------------------------------------------------------------------

const String kDirectAudPaymentCheckout = 'direct:payment.checkout';
const String kDirectAudPaymentIntent = 'direct:payment.intent';
const String kDirectAudPaymentPortal = 'direct:payment.portal';
const String kDirectAudPaymentRestore = 'direct:payment.restore';
const String kDirectAudPaymentIapVerify = 'direct:payment.iap_verify';
const String kDirectAudPaymentRefresh = 'direct:payment.refresh';

/// Per-method limit on the `restored` array length the SDK is willing to
/// parse from a `restorePurchases` response. Defence-in-depth against a
/// malicious / buggy server that returns an unbounded list. Matches the
/// cap inside [RestoreResult.fromJson].
const int kRestorePurchasesMaxRows = 100;

/// Payment-surface methods on [DirectClient]. See class-level docs above.
extension DirectPaymentMethods on DirectClient {
  /// Start a hosted-checkout session. Returns the provider-hosted URL +
  /// session id; host app should drive a browser to the URL (use
  /// [openCheckoutUrl] from `direct_payment_browser.dart`) and call
  /// [refreshAfterPayment] once the user returns.
  ///
  /// `returnUrl` MUST be an https URL — the server-side allowlist
  /// validates it again, but the client-side pre-check catches malformed
  /// URLs without a wasted round-trip.
  ///
  /// `provider` is optional — when set, the server enforces the
  /// project's `allow_provider_override` flag (the SDK does NOT trust
  /// the host to bypass that gate).
  ///
  /// Throws [DirectBadRequestError] for malformed inputs;
  /// [DirectNoProviderConfiguredError] when the project has no payment
  /// provider wired; [DirectPaymentProviderFailedError] for opaque
  /// provider-side failures.
  Future<CheckoutSession> startCheckout({
    required String tier,
    required String billingCycle,
    required String currency,
    required String returnUrl,
    String? cancelUrl,
    String? provider,
  }) async {
    ensureDirectPaymentErrorsRegistered();
    _assertTierAndCycleCurrency(
        tier: tier, billingCycle: billingCycle, currency: currency);
    _assertHttpsUrlInternal(returnUrl, field: 'returnUrl');
    if (cancelUrl != null) {
      _assertHttpsUrlInternal(cancelUrl, field: 'cancelUrl');
    }
    if (provider != null) _assertProviderTag(provider);

    final body = <String, dynamic>{
      'project_id': projectId,
      'tier': tier,
      'billing_cycle': billingCycle,
      'currency': currency,
      'return_url': returnUrl,
      if (cancelUrl != null) 'cancel_url': cancelUrl,
      if (provider != null) 'provider': provider,
    };
    final claims = await callDurableInternal(
      routePath: '/direct/v1/payment/checkout',
      body: body,
      aud: kDirectAudPaymentCheckout,
    );
    return CheckoutSession.fromJson(claims);
  }

  /// Start a native payment (Stripe Payment Sheet / Apple Pay / Google
  /// Pay). Returns a `clientSecret` the host app passes to the platform
  /// payment-sheet API.
  ///
  /// `platform` MUST be one of `ios` / `android` / `web` — matches the
  /// server's [`IntentBody`](https://github.com) shape.
  Future<PaymentIntent> startNativePayment({
    required String tier,
    required String billingCycle,
    required String currency,
    required String platform,
    String? provider,
  }) async {
    ensureDirectPaymentErrorsRegistered();
    _assertTierAndCycleCurrency(
        tier: tier, billingCycle: billingCycle, currency: currency);
    _assertPlatform(platform, allowWeb: true);
    if (provider != null) _assertProviderTag(provider);

    final body = <String, dynamic>{
      'project_id': projectId,
      'tier': tier,
      'billing_cycle': billingCycle,
      'currency': currency,
      'platform': platform,
      if (provider != null) 'provider': provider,
    };
    final claims = await callDurableInternal(
      routePath: '/direct/v1/payment/intent',
      body: body,
      aud: kDirectAudPaymentIntent,
    );
    return PaymentIntent.fromJson(claims);
  }

  /// Mint a customer-portal URL for subscription management. Host app
  /// drives a browser to the returned URL (use [openPortalUrl]).
  ///
  /// Throws [DirectNoActiveSubscriptionError] when the device has no
  /// active / trialing subscription — SDK should route the user through
  /// [startCheckout] in that case.
  Future<PortalSession> openPortal({
    required String returnUrl,
  }) async {
    ensureDirectPaymentErrorsRegistered();
    _assertHttpsUrlInternal(returnUrl, field: 'returnUrl');

    final body = <String, dynamic>{
      'project_id': projectId,
      'return_url': returnUrl,
    };
    final claims = await callDurableInternal(
      routePath: '/direct/v1/payment/portal',
      body: body,
      aud: kDirectAudPaymentPortal,
    );
    return PortalSession.fromJson(claims);
  }

  /// Restore purchases tied to this device (iOS reinstall / sign-in).
  /// Server returns the list of restored purchases + a freshly minted
  /// entitlement JWS for the longest-valid restored purchase (when any).
  ///
  /// On a non-empty restore, the SDK adopts the returned entitlement
  /// JWS as the current bundle so subsequent `hasFeature` / `quota`
  /// calls immediately reflect the restored tier.
  Future<RestoreResult> restorePurchases({
    required String platform,
  }) async {
    ensureDirectPaymentErrorsRegistered();
    _assertPlatform(platform, allowWeb: false);

    final body = <String, dynamic>{
      'project_id': projectId,
      'platform': platform,
    };
    final claims = await callDurableInternal(
      routePath: '/direct/v1/payment/restore',
      body: body,
      aud: kDirectAudPaymentRestore,
    );
    final result = RestoreResult.fromJson(claims);
    final jws = result.entitlementJws;
    if (jws != null) {
      adoptEntitlementJwsInternal(jws);
    }
    return result;
  }

  /// Verify an App Store / Play Store receipt server-side. On success
  /// the server binds license_key → device and returns a fresh
  /// entitlement JWS; on soft-rejection (server-side
  /// `DirectIapReceiptInvalidError`) returns a typed [IapVerifyResult]
  /// with `valid=false` + a narrow reason.
  ///
  /// Hard provider failures (Apple/Google API down, server bug) surface
  /// as a thrown [DirectPaymentProviderFailedError] — NOT a `valid=false`
  /// result — so the SDK retry classifier handles them via the same
  /// path as any other transient provider blip.
  ///
  /// `receipt` is bounded at [kIapReceiptMaxBytes] (24 KB); larger
  /// payloads trigger a client-side [DirectBadRequestError] before any
  /// wire hit. Apple's signed JWS receipts run ~4-8 KB; if you're
  /// hitting this cap, something is wrong with the receipt source.
  Future<IapVerifyResult> verifyIapReceipt({
    required String platform,
    required String receipt,
  }) async {
    ensureDirectPaymentErrorsRegistered();
    _assertPlatform(platform, allowWeb: false);
    if (receipt.isEmpty) {
      throw DirectBadRequestError('verifyIapReceipt: receipt is empty');
    }
    final bytes = receipt.codeUnits.length;
    if (bytes > kIapReceiptMaxBytes) {
      throw DirectBadRequestError(
        'verifyIapReceipt: receipt exceeds $kIapReceiptMaxBytes bytes '
        '(got $bytes)',
      );
    }

    final body = <String, dynamic>{
      'project_id': projectId,
      'platform': platform,
      'receipt': receipt,
    };
    final claims = await callDurableInternal(
      routePath: '/direct/v1/payment/iap-verify',
      body: body,
      aud: kDirectAudPaymentIapVerify,
    );
    final result = IapVerifyResult.fromJson(claims);
    final jws = result.entitlementJws;
    if (result.valid && jws != null) {
      adoptEntitlementJwsInternal(jws);
    }
    return result;
  }

  /// Force-refresh entitlements after a checkout / payment completes.
  /// When [sessionId] is supplied the server confirms the webhook has
  /// flipped the session to `completed=true` before re-minting;
  /// otherwise the call degrades to a `/verify`-equivalent
  /// "give me my current entitlement".
  ///
  /// Returns the same shape as [DirectClient.verify] — same parser,
  /// same JWS path — so callers can treat the result identically.
  Future<VerifyResult> refreshAfterPayment({String? sessionId}) async {
    ensureDirectPaymentErrorsRegistered();
    final body = <String, dynamic>{
      'project_id': projectId,
      if (sessionId != null) 'session_id': sessionId,
    };
    final claims = await callDurableInternal(
      routePath: '/direct/v1/payment/refresh',
      body: body,
      aud: kDirectAudPaymentRefresh,
    );
    final entJws = claims['entitlement_jws'];
    if (entJws is! String || entJws.isEmpty) {
      throw LicenseStoreException(
          'payment/refresh response missing entitlement_jws');
    }
    final ent = adoptEntitlementJwsInternal(entJws);
    final issuedAt = claims['refreshed_at_ms'] ?? claims['issued_at_ms'];
    return VerifyResult(
      entitlementJws: entJws,
      entitlements: ent,
      issuedAtMs: issuedAt is num
          ? issuedAt.toInt()
          : DateTime.now().toUtc().millisecondsSinceEpoch,
    );
  }
}

// ---------------------------------------------------------------------------
// Local assertion helpers
// ---------------------------------------------------------------------------

void _assertTierAndCycleCurrency({
  required String tier,
  required String billingCycle,
  required String currency,
}) {
  if (tier.isEmpty || tier.length > 64) {
    throw DirectBadRequestError(
        'tier must be 1..64 chars (got "${_truncate(tier, 32)}")');
  }
  if (!_tierSlugRe.hasMatch(tier)) {
    throw DirectBadRequestError(
        'tier must match [a-z0-9_]{1,64} (got "${_truncate(tier, 32)}")');
  }
  if (billingCycle != 'monthly' && billingCycle != 'yearly') {
    throw DirectBadRequestError(
        'billingCycle must be monthly|yearly (got "$billingCycle")');
  }
  if (!_currencyRe.hasMatch(currency)) {
    throw DirectBadRequestError(
        'currency must be ISO-4217 [A-Z]{3} (got "$currency")');
  }
}

void _assertPlatform(String platform, {required bool allowWeb}) {
  if (platform == 'ios' || platform == 'android') return;
  if (allowWeb && platform == 'web') return;
  throw DirectBadRequestError(
    'platform must be ${allowWeb ? "ios|android|web" : "ios|android"} '
    '(got "$platform")',
  );
}

void _assertProviderTag(String provider) {
  const allowed = {'stripe', 'paddle', 'lemon_squeezy', 'razorpay'};
  if (!allowed.contains(provider)) {
    throw DirectBadRequestError(
        'provider must be one of ${allowed.join("|")} (got "$provider")');
  }
}

/// Pre-check that an open-redirect-shaped URL is https + reasonable.
/// Centralises the same shape check used by the browser helpers in
/// `direct_payment_browser.dart` so both call sites stay in sync.
void _assertHttpsUrlInternal(String url, {required String field}) {
  if (url.isEmpty || url.length > 2048) {
    throw DirectBadRequestError(
      '$field must be a non-empty URL under 2048 characters',
    );
  }
  Uri parsed;
  try {
    parsed = Uri.parse(url);
  } catch (_) {
    throw DirectBadRequestError('$field is not a valid URL');
  }
  // Allow https for the wire-bound URLs; deep-link / custom schemes are
  // legitimate for `return_url` (e.g. `myapp://upgrade-done`) but the
  // payment server's allowlist handles the deep-link case — here we only
  // pre-screen the obvious "you forgot to make it https" foot-gun.
  final scheme = parsed.scheme.toLowerCase();
  if (scheme != 'https' && !_looksLikeCustomScheme(scheme)) {
    throw DirectBadRequestError(
      '$field must use https or a custom app scheme (got "$scheme://")',
    );
  }
}

bool _looksLikeCustomScheme(String scheme) {
  // RFC 3986 scheme: ALPHA *( ALPHA / DIGIT / "+" / "-" / "." )
  if (scheme.isEmpty) return false;
  final firstChar = scheme.codeUnitAt(0);
  final isAlphaStart = (firstChar >= 0x61 && firstChar <= 0x7A) ||
      (firstChar >= 0x41 && firstChar <= 0x5A);
  if (!isAlphaStart) return false;
  // Avoid common dangerous-looking schemes that aren't app deep links.
  const blocked = {'http', 'ftp', 'file', 'javascript', 'data', 'vbscript'};
  return !blocked.contains(scheme);
}

String _truncate(String s, int n) =>
    s.length <= n ? s : '${s.substring(0, n)}…';

final RegExp _tierSlugRe = RegExp(r'^[a-z0-9_]{1,64}$');
final RegExp _currencyRe = RegExp(r'^[A-Z]{3}$');
