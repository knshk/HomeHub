// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Decrypts + verifies the response side of the FRON envelope.
///
/// Wire shape mirrors the request:
///   * Outer: single-recipient compact JWE with `typ: bifrost-direct+jwe`,
///     `lcs_v: 2`, addressed to the SDK's X25519 pubkey.
///   * Inner: Ed25519 JWS signed by Bifrost's current signing kid.
///     `typ: bifrost-direct+entitlement+jws` for entitlement payloads;
///     `typ: bifrost-direct+response+jws` for generic responses.
///
/// HTTP-error envelopes are also JWE-wrapped; the parser decodes them and
/// raises a typed [DirectError] from the wire `code`.
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:http/http.dart' as http;

import '../crypto/jwe.dart' show JweDecryptionFailedException;
import '../crypto/jwe_codec.dart';
import '../exceptions.dart';
import 'direct_keypair_store.dart';
import 'direct_models.dart';
import 'direct_recipient_resolver.dart';
import 'direct_request_builder.dart' show kDirectJweTyp, kDirectLcsVersion;

/// Parsed-and-verified server payload.
///
/// `claims` is the SUCCESS-path body (i.e. `payload` after unwrapping the
/// JWS envelope). The wire shape — after Ed25519 verify — is:
///
/// ```
/// {
///   iat, nbf, exp,
///   iss: "bifrost-direct",
///   aud: <route audience>,
///   payload: { ...successBody }   // success path
///     OR
///   error:   { code, reason?, provider?, retry_after_ms? }   // sealed error
/// }
/// ```
///
/// `DirectResponse.claims` exposes the unwrapped `payload` (NOT the
/// outer envelope) so callers don't have to know about the envelope shape.
/// If a top-level `error` claim is present the parser throws BEFORE
/// constructing a DirectResponse — `claims` on success is always the
/// inner payload map.
class DirectResponse {
  /// Inner success-path body — equal to the `payload` claim of the outer
  /// envelope. Empty map when the server returned `payload: {}`.
  final Map<String, dynamic> claims;

  /// Full envelope claims (iat/nbf/exp/iss/aud/payload). Exposed for
  /// envelope-level introspection (e.g. cross-checking the `aud` claim
  /// against the route the SDK called). Most callers should use [claims]
  /// directly.
  final Map<String, dynamic> envelopeClaims;

  /// The compact inner JWS (3 segments) — keep for re-verification across
  /// app launches when the payload is itself an entitlement JWS.
  final String innerJws;
  /// The Bifrost kid that signed [innerJws]. Useful for caching + the
  /// `/keys/rotate-ack` flow.
  final String kid;

  const DirectResponse({
    required this.claims,
    required this.envelopeClaims,
    required this.innerJws,
    required this.kid,
  });
}

class DirectResponseParser {
  final Duration allowedClockSkew;

  DirectResponseParser({this.allowedClockSkew = const Duration(minutes: 5)});

  /// Decrypts + verifies an HTTP response body.
  ///
  /// On 2xx: returns the [DirectResponse]. On non-2xx with a JWE body
  /// carrying a `code`, throws the mapped [DirectError]. On non-2xx with
  /// no parseable body, throws [NetworkException].
  Future<DirectResponse> parseResponse({
    required http.Response response,
    required DirectDurableIdentity? identity,
    required Uint8List? ephemeralX25519Priv,
    required BifrostKeySet keySet,
    required String expectedRequestId,
    required String expectedRoutePath,
  }) async {
    // Use the durable X25519 priv if we have one; otherwise the ephemeral
    // one supplied for a registration response.
    final priv = identity?.x25519Priv ?? ephemeralX25519Priv;
    final body = response.body;

    // Some failure paths (5xx, gateway timeouts, project-disabled before
    // decrypt) return plain JSON. Detect by the segment count.
    //
    // SECURITY: a plaintext JSON body from a network proxy / MITM is
    // NEVER trusted to drive SDK state transitions (keypair wipe,
    // entitlement clear, etc.). Only errors that come INSIDE the JWE
    // (after decrypt + Ed25519 verify) are authenticated and may map
    // to typed DirectError subclasses. Plaintext bodies surface as
    // NetworkException so the caller can retry / surface a generic
    // "connection failed" UX without triggering destructive flows.
    final segs = body.split('.').length;
    if (segs != 5) {
      throw NetworkException(
        'Direct HTTP ${response.statusCode} (non-JWE body)',
        statusCode: response.statusCode,
      );
    }

    if (priv == null) {
      throw StateError(
          'DirectResponseParser called without a private key (no durable '
          'identity and no ephemeral key supplied).');
    }

    // 1. Decrypt the outer JWE. The shared crypto codec enforces ECDH-ES +
    // A256GCM + ConcatKDF — identical to the L2 leg — but does NOT pin
    // the `typ` value, so we cross-check it here.
    JweDecryptionResult dec;
    try {
      dec = await JweCodec.decryptCompact(jwe: body, devicePrivBytes: priv);
    } on JweDecryptionFailedException catch (e) {
      throw LicenseStoreException(
          'FRON response decrypt failed: ${e.message}', cause: e);
    }

    final header = dec.header;
    if (header['typ'] != kDirectJweTyp) {
      throw LicenseStoreException(
          'FRON response typ mismatch (expected $kDirectJweTyp, got ${header['typ']})');
    }
    if (header['lcs_v'] != kDirectLcsVersion) {
      throw LicenseStoreException(
          'FRON response lcs_v mismatch (expected $kDirectLcsVersion, got ${header['lcs_v']})');
    }
    final headerRoute = header['route_path'];
    if (headerRoute is String && headerRoute != expectedRoutePath) {
      throw LicenseStoreException(
          'FRON response route mismatch (expected $expectedRoutePath, got $headerRoute)');
    }
    final headerReq = header['request_id'];
    if (headerReq is String && headerReq != expectedRequestId) {
      throw LicenseStoreException(
          'FRON response request_id mismatch (expected $expectedRequestId, got $headerReq)');
    }

    // 2. The plaintext is the inner JWS. Verify with Bifrost's Ed25519 keys.
    final innerJws = utf8.decode(dec.plaintext);
    final verified = _verifyEdJws(innerJws, keySet);
    final envelope = verified.envelopeClaims;

    // 3. Sealed-error envelope (D-Fix 1 of the W6 fix-pass; pairs with
    // Bifrost B-Fix 1). The server wraps non-success outcomes inside the
    // same JWE+JWS envelope as success bodies and puts the typed error
    // under an `error` claim of the OUTER envelope:
    //
    //   { iat, nbf, exp, iss, aud,
    //     error: { code, reason?, provider?, retry_after_ms? } }
    //
    // Check `error` BEFORE `payload` — the server is authoritative and
    // the two are mutually exclusive on a well-formed envelope. We honour
    // the sealed-error shape regardless of HTTP status — a 2xx wrapper
    // around an error claim is just as authenticated as a 4xx wrapper,
    // and the wire is the source of truth (HTTP status codes are visible
    // to MITM and can be flipped freely). Rejecting here closes the gap
    // where an upstream proxy strips the JWE error and slaps a 200 on a
    // forged plaintext body.
    if (envelope.containsKey('error')) {
      final errorClaim = envelope['error'];
      if (errorClaim is! Map) {
        // Malformed sealed-error envelope (e.g. `error: "boom"`). Refuse —
        // a string-or-other-scalar `error` claim cannot be safely mapped
        // to a typed exception, and falling through to the `payload` path
        // would mask a real server / proxy bug.
        throw LicenseStoreException(
            'FRON sealed-error envelope: error claim must be a dict '
            '(got ${errorClaim.runtimeType})');
      }
      final err = errorClaim.cast<String, dynamic>();
      final code = err['code'];
      if (code is String && code.isNotEmpty) {
        final message = err['message'];
        final retry = err['retry_after_ms'];
        final reason = err['reason'];
        final provider = err['provider'];
        throw directErrorFromCode(
          code,
          message: message is String ? message : null,
          retryAfterMs: retry is num ? retry.toInt() : null,
          reason: reason is String ? reason : null,
          provider: provider is String ? provider : null,
        );
      }
      // Malformed sealed-error envelope (no usable code). Refuse rather
      // than fall open — the server is misbehaving.
      throw LicenseStoreException(
          'FRON sealed-error envelope missing usable code');
    }

    // 4. Success path — unwrap `payload` from the envelope. The outer
    // envelope holds iat/nbf/exp/iss/aud; the result body lives under
    // `payload`. (D-Fix 1 of W6 fix-pass-2: previously the parser
    // returned the outer envelope verbatim as `claims`, which broke
    // every call site that looked up `device_id`, `entitlement_jws`,
    // etc. at the top level.)
    final payloadClaim = envelope['payload'];
    if (payloadClaim is! Map) {
      // Some legacy routes emit success bodies at the top level (no
      // `payload` wrapper). Fall back to the envelope itself so the
      // SDK keeps working while the server migration completes — this
      // preserves backward compatibility with the previous wire shape
      // and is still authenticated (we already verified the inner JWS).
      //
      // The `error`-claim path above already short-circuited; reaching
      // here with no `payload` means the response is a plain top-level
      // success body (the pre-envelope wire shape).
      return DirectResponse(
        claims: envelope,
        envelopeClaims: envelope,
        innerJws: verified.innerJws,
        kid: verified.kid,
      );
    }
    final payload = payloadClaim.cast<String, dynamic>();

    // 5. Defensive fallback: a non-2xx wrapper with a flat-shape error
    // (no `error` claim, no `payload`) at the envelope top level. Only
    // reachable when the legacy fallback path above unwrapped to a
    // success-shaped envelope — keep this guard so a buggy server that
    // wraps `{ code }` directly at the envelope level still maps to a
    // typed DirectError.
    if (response.statusCode >= 400) {
      final code = payload['code'] ?? envelope['code'];
      if (code is String && code.isNotEmpty) {
        final message = payload['message'] ?? envelope['message'];
        final retry = payload['retry_after_ms'] ?? envelope['retry_after_ms'];
        final reason = payload['reason'] ?? envelope['reason'];
        final provider = payload['provider'] ?? envelope['provider'];
        throw directErrorFromCode(
          code,
          message: message is String ? message : null,
          retryAfterMs: retry is num ? retry.toInt() : null,
          reason: reason is String ? reason : null,
          provider: provider is String ? provider : null,
        );
      }
      throw NetworkException(
        'Direct HTTP ${response.statusCode} (no error code in body)',
        statusCode: response.statusCode,
      );
    }

    return DirectResponse(
      claims: payload,
      envelopeClaims: envelope,
      innerJws: verified.innerJws,
      kid: verified.kid,
    );
  }

  DirectResponse _verifyEdJws(String jws, BifrostKeySet keySet) {
    final parts = jws.split('.');
    if (parts.length != 3) {
      throw LicenseStoreException('FRON inner JWS shape invalid (segments=${parts.length})');
    }
    final headerBytes = _b64UrlDecode(parts[0]);
    final claimsBytes = _b64UrlDecode(parts[1]);
    final sigBytes = _b64UrlDecode(parts[2]);

    Map<String, dynamic> header;
    Map<String, dynamic> claims;
    try {
      header = (jsonDecode(utf8.decode(headerBytes)) as Map).cast<String, dynamic>();
      claims = (jsonDecode(utf8.decode(claimsBytes)) as Map).cast<String, dynamic>();
    } catch (e) {
      throw LicenseStoreException('FRON inner JWS JSON invalid: $e');
    }

    if (header['alg'] != 'EdDSA') {
      throw LicenseStoreException(
          'FRON inner JWS alg must be EdDSA (got ${header['alg']})');
    }
    final kid = header['kid'];
    if (kid is! String) {
      throw LicenseStoreException('FRON inner JWS missing kid');
    }
    if (keySet.revokedKids.contains(kid)) {
      throw LicenseStoreException('FRON inner JWS signed by revoked kid: $kid');
    }
    final signer = keySet.signersByKid[kid];
    if (signer == null) {
      throw LicenseStoreException('FRON inner JWS kid not in JWKS: $kid');
    }

    final signingInput = ascii.encode('${parts[0]}.${parts[1]}');
    final ok = ed25519.verify(
      ed25519.PublicKey(signer.pub),
      Uint8List.fromList(signingInput),
      sigBytes,
    );
    if (!ok) {
      throw LicenseStoreException('FRON inner JWS signature verification failed');
    }

    // Clock-skew validation (best-effort — server is authoritative).
    // Bifrost stamps iat/exp in MILLISECONDS-since-epoch (matches the
    // request side); convert both to seconds for the comparison so a
    // server that stamped seconds (legacy fixtures) and a server that
    // stamped ms (current wire) both pass without false-positive skew.
    final nowSec = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final iat = claims['iat'];
    final exp = claims['exp'];
    final iatSec = _toSeconds(iat);
    final expSec = _toSeconds(exp);
    if (iatSec != null &&
        (nowSec - iatSec) > allowedClockSkew.inSeconds + 600) {
      throw LicenseStoreException('FRON inner JWS iat too old');
    }
    if (expSec != null && nowSec > expSec + allowedClockSkew.inSeconds) {
      throw LicenseStoreException('FRON inner JWS exp passed');
    }

    // The `claims` map IS the envelope (iat/nbf/exp/iss/aud/payload OR
    // iat/.../error). The caller (parseResponse) unwraps `payload`
    // before exposing the result to host code.
    return DirectResponse(
      claims: claims,
      envelopeClaims: claims,
      innerJws: jws,
      kid: kid,
    );
  }

  /// Best-effort ms-or-seconds → seconds conversion for the JWS time
  /// claims. The server stamps milliseconds (matches the request side),
  /// but legacy fixtures emit seconds. Numbers below 10^12 are almost
  /// certainly seconds (years up to 33658+); above that, they're ms.
  static int? _toSeconds(dynamic v) {
    if (v is! num) return null;
    final n = v.toInt();
    // Heuristic boundary — anything past this is ms-since-epoch.
    const msFloor = 1000000000000; // year 2001 in ms
    return n >= msFloor ? n ~/ 1000 : n;
  }

  static Uint8List _b64UrlDecode(String s) {
    final pad = (4 - s.length % 4) % 4;
    return base64Url.decode(s.padRight(s.length + pad, '='));
  }
}
