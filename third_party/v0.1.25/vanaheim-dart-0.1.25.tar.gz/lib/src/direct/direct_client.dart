// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Orchestrator for FRON (Bifrost-Direct) mode.
///
/// Mirrors the Dart `LicenseClient` surface (`activate`, `verify`,
/// `heartbeat`, …) but speaks directly to Bifrost via the `/direct/v1/*`
/// endpoints, with no L2 (Alfheim) backend on the path.
///
/// Construct via [DirectClient.connect] — equivalent to the L2-mode
/// `LicenseClient.connect()`. The client returns from `connect()` with
/// JWKS cached, durable identity loaded (if any), and the heartbeat +
/// stats schedulers wired but NOT yet started — call `register()` (first
/// run) or `activate()` / `verify()` (subsequent runs) to put the SDK in
/// a usable state.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../exceptions.dart';
import '../push/push_token_provider.dart';
import '../storage/secure_cache.dart';
import '../transport/cert_pinning.dart';
import 'direct_config.dart';
import 'direct_fcm_bridge.dart';
import 'direct_heartbeat_scheduler.dart';
import 'direct_keypair_store.dart';
import 'direct_models.dart';
import 'direct_recipient_resolver.dart';
import 'direct_request_builder.dart';
import 'direct_response_parser.dart';
import 'direct_stats_batcher.dart';

// ---------------------------------------------------------------------------
// Canonical JWS `aud` audiences for non-payment FRON routes.
//
// Per D-Fix 3 (aud namespace convergence) in the W6 fix-pass-2, every
// FRON SDK endpoint must emit the colon-namespaced audience shape
// (`direct:<area>[.endpoint]`) so server-side audience pinning has a
// single canonical value across Dart + Swift + future SDKs. The HTTP
// route path stays whatever the wire requires (`/direct/v1/...`) —
// only the inner-JWS `aud` claim changes.
//
// Payment audiences live in `direct_payment_methods.dart`
// (`kDirectAudPayment*`).
// ---------------------------------------------------------------------------

const String kDirectAudRegister = 'direct:register';
const String kDirectAudActivate = 'direct:activate';
const String kDirectAudVerify = 'direct:verify';
const String kDirectAudHeartbeat = 'direct:heartbeat';
const String kDirectAudDeactivate = 'direct:deactivate';
const String kDirectAudCatalog = 'direct:catalog';
const String kDirectAudKeysRotateAck = 'direct:keys.rotate_ack';
const String kDirectAudNotificationsRegisterFcm =
    'direct:notifications.register_fcm';
const String kDirectAudNotificationsAck = 'direct:notifications.ack';
const String kDirectAudTelemetryStats = 'direct:telemetry.stats';
const String kDirectAudTelemetryError = 'direct:telemetry.error';

/// Single product-facing FRON client. Created by [VanaheimConfig.mode] =
/// `fron` when the host product calls the unified `LicenseClient.connect`
/// (see `client.dart` factory).
class DirectClient {
  final DirectConfig _config;
  final http.Client _http;
  final DirectRecipientResolver _resolver;
  final DirectKeypairStore _keys;
  final DirectRequestBuilder _builder;
  final DirectResponseParser _parser;
  final DirectHeartbeatScheduler _heartbeatScheduler;
  final DirectStatsBatcher _statsBatcher;
  final DirectFcmBridge? _fcmBridge;
  final CertificatePinner? _certPinner;
  final Random _rng;

  BifrostKeySet? _keySet;
  DirectDurableIdentity? _identity;
  DirectEntitlements? _entitlements;
  String? _cachedEntitlementJws;

  bool _disposed = false;

  DirectClient._({
    required DirectConfig config,
    required http.Client httpClient,
    required DirectRecipientResolver resolver,
    required DirectKeypairStore keys,
    required DirectRequestBuilder builder,
    required DirectResponseParser parser,
    required DirectHeartbeatScheduler heartbeatScheduler,
    required DirectStatsBatcher statsBatcher,
    DirectFcmBridge? fcmBridge,
    CertificatePinner? certPinner,
    Random? rng,
  })  : _config = config,
        _http = httpClient,
        _resolver = resolver,
        _keys = keys,
        _builder = builder,
        _parser = parser,
        _heartbeatScheduler = heartbeatScheduler,
        _statsBatcher = statsBatcher,
        _fcmBridge = fcmBridge,
        _certPinner = certPinner,
        _rng = rng ?? Random.secure();

  /// Whether the device has a durable identity. False = caller must
  /// call [register]; true = caller can call [activate]/[verify]/etc.
  bool get isRegistered => _identity != null;

  /// Project identifier this client was configured with. Exposed for
  /// SDK-private extensions (e.g. payment methods) that mirror the
  /// project id into request bodies as required by the Bifrost
  /// cross-project assertion.
  String get projectId => _config.projectId;

  /// Currently-known entitlements. Null until the first successful
  /// register / activate / verify.
  DirectEntitlements? get entitlements => _entitlements;

  /// The compact entitlement JWS, kept so the host product can persist
  /// it (e.g. for offline-first re-verification).
  String? get entitlementJws => _cachedEntitlementJws;

  /// Construct a client. Pulls JWKS, loads durable identity, wires the
  /// scheduler + stats batcher.
  static Future<DirectClient> connect({
    required DirectConfig config,
    SecureCache? cache,
    PushTokenProvider? push,
    http.Client? httpClient,
  }) async {
    final storage = cache ?? FlutterSecureCache();
    final inner = httpClient ?? http.Client();
    final resolver = DirectRecipientResolver(
      bifrostBaseUrl: config.bifrostBaseUrl,
      defaultTtl: config.jwksCacheTtl,
      httpClient: inner,
    );
    final keys = DirectKeypairStore(cache: storage);
    final builder = DirectRequestBuilder(projectId: config.projectId);
    final parser = DirectResponseParser(allowedClockSkew: config.clockSkew);

    final client = _Pending();
    final scheduler = DirectHeartbeatScheduler(
      tick: () async {
        final c = client.bound;
        if (c == null) return;
        await c.heartbeat();
      },
      initialCadence: config.initialHeartbeatCadence,
      onError: (e, st) {
        if (!config.swallowBackgroundErrors) {
          // Swallow into stderr — the scheduler runs inside a Timer so
          // rethrow has no caller to receive it. Host products that
          // want louder failure should set swallowBackgroundErrors=false
          // AND wrap the connect() in their own zone-error handler.
        }
      },
    );
    final batcher = DirectStatsBatcher(
      cache: storage,
      flushInterval: config.statsFlushInterval,
      flushBatchSize: config.statsFlushBatchSize,
      capacity: config.statsRingBufferCapacity,
      shipper: (events) async {
        final c = client.bound;
        if (c == null) {
          throw NotConnectedException();
        }
        return c._shipStatsBatch(events);
      },
    );

    DirectFcmBridge? fcm;
    if (push != null && push is! NoPushTokenProvider) {
      fcm = DirectFcmBridge(
        push: push,
        sendToken: (token, platform) async {
          final c = client.bound;
          if (c == null) return;
          await c.registerFcmToken(token, platform);
        },
        ack: (id, ts, {bool? displayed}) async {
          final c = client.bound;
          if (c == null) return;
          await c.ackNotification(id, ts, displayed: displayed);
        },
      );
    }

    // Cert pinning parity with Swift (D-Fix 2 of W6 fix-pass). DirectConfig
    // already validated that every pin is a 32-byte SHA-256 in base64
    // form; here we just wire the pinner into the per-request hot path.
    // When pinnedSpkiSha256 is empty (dev/test) the pinner is null and
    // the wire path is unchanged.
    final certPinner = config.pinnedSpkiSha256.isEmpty
        ? null
        : CertificatePinner(pinnedSpkiSha256: config.pinnedSpkiSha256);

    final bound = DirectClient._(
      config: config,
      httpClient: inner,
      resolver: resolver,
      keys: keys,
      builder: builder,
      parser: parser,
      heartbeatScheduler: scheduler,
      statsBatcher: batcher,
      fcmBridge: fcm,
      certPinner: certPinner,
    );
    client.bound = bound;

    // Pull JWKS up-front. A network failure here is non-fatal — register/
    // verify will lazy-fetch on demand.
    try {
      bound._keySet = await resolver.get();
    } catch (_) {/* leave _keySet null; lazy fetch later */}

    // Load durable identity if present.
    bound._identity = await keys.loadDurable();

    // Restore in-flight stats events from a previous run.
    await batcher.start();

    return bound;
  }

  /// Idempotent: a callable wrapper around the connect() flow that
  /// re-fetches JWKS + reloads identity. Useful for tests + manual
  /// recovery flows.
  Future<void> connectAgain() async {
    _keySet = await _resolver.refresh();
    _identity = await _keys.loadDurable();
  }

  // -----------------------------------------------------------------
  // Tier 1 — registration
  // -----------------------------------------------------------------

  /// First-boot registration. Generates an ephemeral X25519+Ed25519 pair,
  /// signs the inner JWS with the ephemeral Ed25519 key, JWE-wraps for
  /// Bifrost, POSTs to `/direct/v1/register`. On 2xx promotes the
  /// ephemeral keypair to durable + persists the server-issued device id.
  Future<RegisterResult> register({
    required String licenseKey,
    required String fingerprint,
    Map<String, dynamic> appMeta = const {},
  }) async {
    _checkAlive();
    final keySet = await _ensureKeySet();
    final ephemeral = await _keys.generateEphemeral();
    final requestId = _newRequestId();
    const routePath = '/direct/v1/register';

    final envelope = await _builder.buildEphemeral(
      routePath: routePath,
      requestId: requestId,
      body: {
        // project_id is duplicated under body too — Bifrost's
        // assertRegisterBody checks body.project_id matches the JWS top
        // level for defence-in-depth against a downstream caller that
        // forgets to bind one of the two.
        'project_id': _config.projectId,
        'license_key': licenseKey,
        'fingerprint': fingerprint,
        'app_meta': appMeta,
        // ephemeral_pubkey is auto-injected by the builder so it always
        // equals the JWS header device_pub_jwk.x. Do NOT set it here —
        // the builder owns that binding.
      },
      ephemeral: ephemeral,
      recipient: keySet.activeRecipient,
      aud: kDirectAudRegister,
    );

    final response = await _post(
      routePath: routePath,
      compactJwe: envelope.compactJwe,
      requestId: requestId,
    );
    final parsed = await _parser.parseResponse(
      response: response,
      identity: null,
      ephemeralX25519Priv: ephemeral.x25519Priv,
      keySet: keySet,
      expectedRequestId: requestId,
      expectedRoutePath: routePath,
    );

    final deviceId = parsed.claims['device_id'];
    final serverNonce = parsed.claims['server_nonce'];
    final entJws = parsed.claims['entitlement_jws'];
    final cadenceMs = parsed.claims['heartbeat_cadence_ms'];
    if (deviceId is! String || deviceId.isEmpty) {
      throw LicenseStoreException(
          'register response missing device_id');
    }
    if (entJws is! String || entJws.isEmpty) {
      throw LicenseStoreException(
          'register response missing entitlement_jws');
    }
    final entitlements = _decodeEntitlementJws(entJws, keySet);
    final cadence = cadenceMs is num
        ? cadenceMs.toInt()
        : _config.initialHeartbeatCadence.inMilliseconds;

    // Promote — survives across restarts.
    _identity = await _keys.promoteEphemeral(
      deviceId: deviceId,
      ephemeral: ephemeral,
      serverNonce: serverNonce is String ? serverNonce : null,
    );
    _entitlements = entitlements;
    _cachedEntitlementJws = entJws;
    _heartbeatScheduler.setCadence(Duration(milliseconds: cadence));
    _heartbeatScheduler.start();

    // Fire-and-forget FCM bring-up once we have an identity.
    final fcm = _fcmBridge;
    if (fcm != null) unawaited(fcm.start());

    return RegisterResult(
      deviceId: deviceId,
      serverNonce: serverNonce is String ? serverNonce : '',
      entitlementJws: entJws,
      entitlements: entitlements,
      heartbeatCadenceMs: cadence,
    );
  }

  // -----------------------------------------------------------------
  // Tier 2 — durable JWS endpoints
  // -----------------------------------------------------------------

  /// Re-activate against a license key (e.g. after a key migration).
  Future<ActivateResult> activate(String licenseKey) async {
    final parsed = await _callDurable(
      routePath: '/direct/v1/activate',
      body: {'license_key': licenseKey},
      aud: kDirectAudActivate,
    );
    final entJws = _stringClaim(parsed.claims, 'entitlement_jws');
    final entitlements = _decodeEntitlementJws(entJws, parsed.keySet);
    _entitlements = entitlements;
    _cachedEntitlementJws = entJws;
    return ActivateResult(
      deviceId: _identity!.deviceId,
      entitlementJws: entJws,
      entitlements: entitlements,
    );
  }

  /// Pull a fresh entitlement JWS — refreshes local state and seeds the
  /// heartbeat scheduler with any cadence override.
  Future<VerifyResult> verify() async {
    final parsed = await _callDurable(
      routePath: '/direct/v1/verify',
      body: const {},
      aud: kDirectAudVerify,
    );
    final entJws = _stringClaim(parsed.claims, 'entitlement_jws');
    final entitlements = _decodeEntitlementJws(entJws, parsed.keySet);
    _entitlements = entitlements;
    _cachedEntitlementJws = entJws;
    final issuedAt = parsed.claims['issued_at_ms'];
    final cadence = parsed.claims['heartbeat_cadence_ms'];
    if (cadence is num) {
      _heartbeatScheduler.setCadence(Duration(milliseconds: cadence.toInt()));
    }
    final newNonce = parsed.claims['server_nonce'];
    if (newNonce is String) await _keys.updateServerNonce(newNonce);
    return VerifyResult(
      entitlementJws: entJws,
      entitlements: entitlements,
      issuedAtMs: issuedAt is num
          ? issuedAt.toInt()
          : DateTime.now().toUtc().millisecondsSinceEpoch,
    );
  }

  /// Keep-alive + revoke probe. Updates entitlements + cadence in-place.
  Future<HeartbeatResult> heartbeat() async {
    try {
      final parsed = await _callDurable(
        routePath: '/direct/v1/heartbeat',
        body: const {},
        aud: kDirectAudHeartbeat,
      );
      final entJws = parsed.claims['entitlement_jws'];
      DirectEntitlements? ent;
      String? entJwsStr;
      if (entJws is String && entJws.isNotEmpty) {
        ent = _decodeEntitlementJws(entJws, parsed.keySet);
        _entitlements = ent;
        _cachedEntitlementJws = entJws;
        entJwsStr = entJws;
      }
      final cadence = parsed.claims['heartbeat_cadence_ms'];
      int? cadenceMs;
      if (cadence is num) {
        cadenceMs = cadence.toInt();
        _heartbeatScheduler.setCadence(Duration(milliseconds: cadenceMs));
      }
      return HeartbeatResult(
        alive: true,
        entitlementJws: entJwsStr,
        entitlements: ent,
        heartbeatCadenceMs: cadenceMs,
      );
    } on DirectDeviceRevokedError {
      // Wipe local state — caller must surface "session revoked" UX.
      // CRITICAL: clear entitlements + cached JWS BEFORE returning so
      // hasFeature() / quota() fail-CLOSED for any synchronous caller
      // racing with the heartbeat tick. A stale `_entitlements` would
      // briefly grant the revoked session continued access otherwise.
      await _keys.clear();
      _identity = null;
      _entitlements = null;
      _cachedEntitlementJws = null;
      _heartbeatScheduler.stop();
      rethrow;
    }
  }

  /// Graceful uninstall / device-swap.
  Future<void> deactivate(String reason) async {
    await _callDurable(
      routePath: '/direct/v1/deactivate',
      body: {'reason': reason},
      aud: kDirectAudDeactivate,
    );
    await _keys.clear();
    _identity = null;
    _entitlements = null;
    _cachedEntitlementJws = null;
    _heartbeatScheduler.stop();
  }

  /// Encrypted catalog pull (tier names, features, prices).
  Future<CatalogSnapshot> getCatalog() async {
    final parsed = await _callDurable(
      routePath: '/direct/v1/catalog',
      body: const {},
      aud: kDirectAudCatalog,
    );
    final raw = parsed.claims['catalog'];
    if (raw is Map) {
      return CatalogSnapshot.fromJson(raw.cast<String, dynamic>());
    }
    return CatalogSnapshot.fromJson(parsed.claims);
  }

  /// Acknowledge SDK observed a JWKS kid rotation. Server uses this to
  /// drop stale kids out of its trust list once all clients have moved.
  Future<void> acknowledgeKidRotation(String kid) async {
    await _callDurable(
      routePath: '/direct/v1/keys/rotate-ack',
      body: {'kid': kid},
      aud: kDirectAudKeysRotateAck,
    );
    // Refresh local key cache so subsequent calls verify against the new
    // signing key without waiting for the JWKS TTL.
    _keySet = await _resolver.refresh();
  }

  /// Register / refresh an FCM (or APNs) registration token.
  Future<void> registerFcmToken(String token, String platform) async {
    await _callDurable(
      routePath: '/direct/v1/notifications/register-fcm',
      body: {'fcm_token': token, 'platform': platform},
      aud: kDirectAudNotificationsRegisterFcm,
    );
  }

  /// ACK a server-initiated push (delivery confirmation).
  Future<void> ackNotification(
    String notificationId,
    int receivedAtMs, {
    bool? displayed,
  }) async {
    await _callDurable(
      routePath: '/direct/v1/notifications/ack',
      body: {
        'notification_id': notificationId,
        'received_at_ms': receivedAtMs,
        if (displayed != null) 'displayed': displayed,
      },
      aud: kDirectAudNotificationsAck,
    );
  }

  /// Enqueue stats events into the in-memory batcher. The batcher flushes
  /// on its own cadence + on size triggers — this method does NOT make a
  /// network call directly (returns immediately).
  Future<StatsResult> sendStats(List<StatsEvent> events) async {
    if (events.isEmpty) {
      return const StatsResult(accepted: 0, rejected: 0);
    }
    for (final ev in events) {
      await _statsBatcher.enqueue(ev);
    }
    return StatsResult(accepted: events.length, rejected: 0);
  }

  /// Submit a single crash/error report. Rate-limited by the server.
  Future<ErrorResult> reportError(ErrorReport error) async {
    final parsed = await _callDurable(
      routePath: '/direct/v1/telemetry/error',
      body: error.toJson(),
      aud: kDirectAudTelemetryError,
    );
    return ErrorResult.fromJson(parsed.claims);
  }

  /// Local entitlement evaluation — never hits the network. Returns
  /// `false` if no entitlements have been pulled yet (caller must
  /// `register()` / `verify()` first).
  bool hasFeature(String name) {
    final ent = _entitlements;
    if (ent == null) return false;
    return ent.has(name);
  }

  /// Local quota lookup — returns 0 when entitlements have not yet
  /// been fetched or the quota isn't defined for the current tier.
  int quota(String name) {
    final ent = _entitlements;
    if (ent == null) return 0;
    return ent.quotaFor(name);
  }

  /// Tear down schedulers + persist pending events. Idempotent.
  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    _heartbeatScheduler.dispose();
    await _statsBatcher.dispose();
    await _fcmBridge?.dispose();
  }

  // -----------------------------------------------------------------
  // Internal seams used by SDK-private extensions / mixins
  //
  // These are intentionally marked `@internal` (meta.dart) — they are
  // NOT public API. They exist so the payment-surface extension methods
  // in `direct_payment_methods.dart` can reuse the same JWE+JWS plumbing
  // as the built-in Tier 2 endpoints without duplicating the crypto
  // path. Host products MUST NOT call them directly.
  // -----------------------------------------------------------------

  /// Invoke a Tier 2 (durable JWS) endpoint with the given body. Returns
  /// the verified inner-JWS claims map. Used by the payment-surface
  /// extension methods. Mirror of [_callDurable] minus the keyset that
  /// payment routes don't need.
  ///
  /// [aud] is the canonical, colon-namespaced JWS audience the call
  /// should advertise (e.g. `direct:payment.checkout`). The HTTP path
  /// is still [routePath]; only the inner-JWS `aud` claim is affected.
  /// Defaults to [routePath] for backward compatibility.
  ///
  /// `@internal` — SDK-private; not part of the published surface.
  Future<Map<String, dynamic>> callDurableInternal({
    required String routePath,
    required Map<String, dynamic> body,
    String? aud,
  }) async {
    final res = await _callDurable(routePath: routePath, body: body, aud: aud);
    return res.claims;
  }

  /// Decode an entitlement JWS and persist its bundle as the SDK's
  /// current state. Returns the parsed entitlements. Used by payment
  /// methods that re-mint entitlements (refresh, iap-verify, restore).
  ///
  /// `@internal` — SDK-private; not part of the published surface.
  DirectEntitlements adoptEntitlementJwsInternal(String entJws) {
    final keySet = _keySet;
    if (keySet == null) {
      throw StateError(
          'adoptEntitlementJwsInternal called before JWKS load');
    }
    final ent = _decodeEntitlementJws(entJws, keySet);
    _entitlements = ent;
    _cachedEntitlementJws = entJws;
    return ent;
  }

  // -----------------------------------------------------------------
  // Internals
  // -----------------------------------------------------------------

  Future<_DurableResponse> _callDurable({
    required String routePath,
    required Map<String, dynamic> body,
    String? aud,
  }) async {
    _checkAlive();
    final identity = _identity;
    if (identity == null) {
      throw NotConnectedException();
    }
    final keySet = await _ensureKeySet();
    final requestId = _newRequestId();
    final envelope = await _builder.buildDurable(
      routePath: routePath,
      requestId: requestId,
      body: body,
      identity: identity,
      recipient: keySet.activeRecipient,
      aud: aud,
    );
    final response = await _post(
      routePath: routePath,
      compactJwe: envelope.compactJwe,
      requestId: requestId,
    );
    final parsed = await _parser.parseResponse(
      response: response,
      identity: identity,
      ephemeralX25519Priv: null,
      keySet: keySet,
      expectedRequestId: requestId,
      expectedRoutePath: routePath,
    );
    return _DurableResponse(claims: parsed.claims, keySet: keySet);
  }

  Future<StatsResult> _shipStatsBatch(List<StatsEvent> events) async {
    final parsed = await _callDurable(
      routePath: '/direct/v1/telemetry/stats',
      body: {'events': events.map((e) => e.toJson()).toList()},
      aud: kDirectAudTelemetryStats,
    );
    return StatsResult.fromJson(parsed.claims);
  }

  Future<http.Response> _post({
    required String routePath,
    required String compactJwe,
    required String requestId,
  }) async {
    final uri = _config.bifrostBaseUrl.replace(path: routePath);
    // Cert pinning parity with Swift (D-Fix 2). The pinner runs BEFORE
    // any request body crosses the TLS boundary, so a MITM-injected
    // intermediate that doesn't match the pinned SPKI fails CLOSED
    // before the JWE is on the wire. CertificatePinException is its own
    // typed exception (subclass of LicenseStoreException) — does NOT
    // surface as NetworkException so host UX can distinguish "TLS
    // pinning failure (refuse + alert ops)" from "transient timeout
    // (retry)".
    final pinner = _certPinner;
    if (pinner != null && pinner.isEnabled) {
      await pinner.verify(uri.toString());
    }
    final headers = <String, String>{
      'Content-Type': 'application/jose+json',
      'Accept': 'application/jose+json',
      'X-LS-Request-Id': requestId,
      'X-LS-Project-Id': _config.projectId,
    };
    try {
      return await _http
          .post(uri, headers: headers, body: compactJwe)
          .timeout(_config.httpTimeout,
              onTimeout: () =>
                  throw NetworkException('FRON POST $routePath timed out'));
    } on NetworkException {
      rethrow;
    } on CertificatePinException {
      rethrow;
    } catch (e) {
      throw NetworkException('FRON POST $routePath failed: $e');
    }
  }

  Future<BifrostKeySet> _ensureKeySet() async {
    final cached = _keySet;
    if (cached != null) return cached;
    final fresh = await _resolver.get();
    _keySet = fresh;
    return fresh;
  }

  DirectEntitlements _decodeEntitlementJws(String jws, BifrostKeySet keySet) {
    // Reuse the parser's JWS verifier indirectly via decode-only path:
    // we already verified the outer JWS once (the entitlement is wrapped
    // inside that). For the entitlement itself the payload IS the JSON;
    // we don't re-verify here (the outer is the trust root). If the
    // server is strict we may need to switch to a second verify pass.
    final parts = jws.split('.');
    if (parts.length != 3) {
      throw LicenseStoreException('entitlement_jws shape invalid');
    }
    try {
      final pad = (4 - parts[1].length % 4) % 4;
      final bytes = base64Url.decode(parts[1].padRight(parts[1].length + pad, '='));
      final json = (jsonDecode(utf8.decode(bytes)) as Map).cast<String, dynamic>();
      return DirectEntitlements.fromJson(json);
    } catch (e) {
      throw LicenseStoreException('entitlement_jws decode failed: $e');
    }
  }

  void _checkAlive() {
    if (_disposed) {
      throw StateError('DirectClient has been disposed');
    }
  }

  /// RFC 4122 v7-ish — millisecond timestamp + 74 bits of randomness, set
  /// version + variant bits per the v7 draft. Good enough for FRON's
  /// single-use request id / nonce role (the server treats the value as
  /// opaque and only requires it to be unique within the replay window).
  String _newRequestId() {
    final nowMs = DateTime.now().toUtc().millisecondsSinceEpoch;
    final bytes = Uint8List(16);
    // 48-bit big-endian unix-ms.
    for (var i = 5; i >= 0; i--) {
      bytes[i] = nowMs >> (8 * (5 - i)) & 0xFF;
    }
    for (var i = 6; i < 16; i++) {
      bytes[i] = _rng.nextInt(256);
    }
    bytes[6] = (bytes[6] & 0x0F) | 0x70; // version 7
    bytes[8] = (bytes[8] & 0x3F) | 0x80; // variant
    return _formatUuid(bytes);
  }

  static String _formatUuid(Uint8List b) {
    String h(int v) => v.toRadixString(16).padLeft(2, '0');
    final s = b.map(h).join();
    return '${s.substring(0, 8)}-${s.substring(8, 12)}-${s.substring(12, 16)}'
        '-${s.substring(16, 20)}-${s.substring(20, 32)}';
  }

  String _stringClaim(Map<String, dynamic> claims, String key) {
    final v = claims[key];
    if (v is! String || v.isEmpty) {
      throw LicenseStoreException('FRON response missing $key');
    }
    return v;
  }
}

/// Internal tuple bundling decoded claims with the key set used for verify
/// so callers don't re-fetch JWKS between two passes.
class _DurableResponse {
  final Map<String, dynamic> claims;
  final BifrostKeySet keySet;
  const _DurableResponse({required this.claims, required this.keySet});
}

/// Forward-reference hack so the scheduler + batcher + FCM bridge can call
/// back into the DirectClient before the constructor returns.
class _Pending {
  DirectClient? bound;
}
