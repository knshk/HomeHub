// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// In-memory ring buffer for [StatsEvent]s with periodic + size-based flush,
/// plus persistence to [SecureCache] on app background and across restarts.
///
/// Flush triggers (whichever comes first):
///   * Time-based: every [DirectConfig.statsFlushInterval]
///   * Size-based: when ≥ [DirectConfig.statsFlushBatchSize] events queued
///   * Manual: explicit `flush()` (e.g. on app backgrounding from the host)
///
/// Buffer is bounded by [DirectConfig.statsRingBufferCapacity] — when full
/// the OLDEST event is dropped. Drops are counted in [droppedCount].
///
/// Background errors (network down, server 5xx) are surfaced through the
/// optional `onError` callback; events that failed to ship are kept in the
/// buffer for the next attempt.
library;

import 'dart:async';
import 'dart:collection';
import 'dart:convert';

import '../storage/secure_cache.dart';
import 'direct_models.dart';

/// Cache key for the persisted ring buffer.
const String kDirectStatsBufferKey = 'vanaheim:direct:stats_buffer_v1';

/// Function the batcher calls to ship a batch upstream. Returns the
/// result; if it throws, the batch is rolled back into the buffer.
typedef StatsShipper = Future<StatsResult> Function(List<StatsEvent> events);

typedef StatsErrorHandler = void Function(Object error, StackTrace stackTrace);

class DirectStatsBatcher {
  final SecureCache _cache;
  final StatsShipper _shipper;
  final Duration _flushInterval;
  final int _flushBatchSize;
  final int _capacity;
  final StatsErrorHandler? onError;

  final Queue<StatsEvent> _buffer = Queue<StatsEvent>();
  Timer? _timer;
  Future<StatsResult>? _inFlightFlush;
  int _droppedCount = 0;
  bool _disposed = false;

  DirectStatsBatcher({
    required SecureCache cache,
    required StatsShipper shipper,
    Duration flushInterval = const Duration(minutes: 5),
    int flushBatchSize = 50,
    int capacity = 500,
    this.onError,
  })  : _cache = cache,
        _shipper = shipper,
        _flushInterval = flushInterval,
        _flushBatchSize = flushBatchSize,
        _capacity = capacity;

  int get bufferedCount => _buffer.length;
  int get droppedCount => _droppedCount;
  bool get isRunning => _timer != null;

  /// Restore any persisted events from a previous run + start the
  /// periodic flush timer.
  Future<void> start() async {
    if (_disposed) return;
    await _restoreFromCache();
    _timer?.cancel();
    _timer = Timer.periodic(_flushInterval, (_) => _safeFlush(reason: 'timer'));
  }

  /// Enqueue an event. Triggers an immediate flush if the buffer hit
  /// [_flushBatchSize].
  Future<void> enqueue(StatsEvent event) async {
    if (_disposed) return;
    if (_buffer.length >= _capacity) {
      _buffer.removeFirst();
      _droppedCount++;
    }
    _buffer.addLast(event);
    if (_buffer.length >= _flushBatchSize) {
      // Fire-and-forget — caller doesn't need to await network I/O.
      unawaited(_safeFlush(reason: 'size'));
    }
  }

  /// Best-effort flush. Returns null if there's nothing to send.
  Future<StatsResult?> flush() async {
    if (_disposed) return null;
    return _safeFlush(reason: 'manual');
  }

  /// Persist the in-memory buffer + stop the timer. Call this from your
  /// host product's app-backgrounding hook (e.g. `WidgetsBindingObserver`).
  Future<void> persist() async {
    await _persistToCache();
  }

  /// Tear down. Persists once, then stops the timer.
  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    _timer?.cancel();
    _timer = null;
    await _persistToCache();
  }

  // ----------------------------------------------------------------- internal

  Future<StatsResult?> _safeFlush({required String reason}) async {
    if (_inFlightFlush != null) {
      // Coalesce concurrent flush requests onto the in-flight one.
      try {
        return await _inFlightFlush;
      } catch (_) {
        return null;
      }
    }
    if (_buffer.isEmpty) return null;

    final batch = List<StatsEvent>.from(_buffer);
    _buffer.clear();
    final fut = _shipBatch(batch).whenComplete(() => _inFlightFlush = null);
    _inFlightFlush = fut;
    try {
      return await fut;
    } catch (e, st) {
      // Roll back so the events get retried on the next flush.
      // Preserve order: original batch goes BEFORE anything queued
      // while the flush was in-flight.
      final fresh = List<StatsEvent>.from(_buffer);
      _buffer
        ..clear()
        ..addAll(batch)
        ..addAll(fresh);
      onError?.call(e, st);
      // Persist immediately so a process kill while offline doesn't lose
      // the events we just rolled back.
      await _persistToCache();
      return null;
    }
  }

  Future<StatsResult> _shipBatch(List<StatsEvent> batch) async {
    final result = await _shipper(batch);
    // On a partial-ship the server tells us how many it accepted; the
    // remainder we treat as accepted for the purposes of the buffer
    // (otherwise we'd loop forever on persistently-rejected events).
    await _persistToCache();
    return result;
  }

  Future<void> _restoreFromCache() async {
    final raw = await _cache.getRaw(kDirectStatsBufferKey);
    if (raw == null || raw.isEmpty) return;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        for (final item in decoded) {
          if (item is Map) {
            final ev = StatsEvent.fromJson(item.cast<String, dynamic>());
            if (_buffer.length < _capacity) {
              _buffer.addLast(ev);
            } else {
              _droppedCount++;
            }
          }
        }
      }
    } catch (_) {
      // Corrupt cache → wipe rather than crash. Stats are low-stakes.
      await _cache.deleteRaw(kDirectStatsBufferKey);
    }
  }

  Future<void> _persistToCache() async {
    if (_buffer.isEmpty) {
      await _cache.deleteRaw(kDirectStatsBufferKey);
      return;
    }
    final encoded = jsonEncode(_buffer.map((e) => e.toJson()).toList());
    await _cache.putRaw(kDirectStatsBufferKey, encoded);
  }
}
