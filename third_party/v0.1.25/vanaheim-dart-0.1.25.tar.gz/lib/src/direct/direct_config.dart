// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// FRON (Bifrost-Direct) configuration knobs. Separate from [VanaheimConfig]
/// so the existing L2 client surface stays untouched — host products switch
/// modes via `VanaheimConfig.mode` and supply a [DirectConfig] only when
/// they need to tune cadence / batcher / retry behaviour.
library;

import 'package:meta/meta.dart';

/// Which Vanaheim transport backs the [LicenseClient].
///
/// * [l2] — talks to the customer's Alfheim L2 (the existing v2 default).
/// * [fron] — talks DIRECTLY to Bifrost via the FRON `/direct/v1/*` surface.
///   Use this when the customer has no L2 backend of their own. No
///   per-product code changes are required; the SDK constructs a
///   [DirectClient] instead of the legacy [LicenseClient] internals.
enum VanaheimMode {
  l2,
  fron,
}

/// Direct-mode configuration. All fields have sensible defaults; supply
/// only the ones you need to override.
///
/// Required field is `bifrostBaseUrl` — there is no global default since
/// FRON deployments may run in customer-segregated Bifrost shards.
///
/// Per D-Fix 2 of the W6 fix-pass, the `pinnedSpkiSha256` strings are
/// validated at construction time so a typo (wrong length, non-base64
/// chars) is caught BEFORE the SDK ever boots a network call — a
/// pin-check that silently fails because the pin itself is malformed
/// would be indistinguishable from a benign empty-pin config.
@immutable
class DirectConfig {
  /// Base URL of the Bifrost FRON surface, e.g. `https://bifrost.example.com`.
  /// The SDK appends `/direct/v1/*` paths. Required.
  final Uri bifrostBaseUrl;

  /// Project identifier — mirrored into the inner JWS claims so Bifrost
  /// can disambiguate cross-project replay. Required.
  final String projectId;

  /// Initial heartbeat cadence used before `/register` returns the
  /// server-authoritative value. Default 24h matches the spec.
  final Duration initialHeartbeatCadence;

  /// Stats batcher flush interval — events are POSTed in bulk this often.
  /// Default 5 min.
  final Duration statsFlushInterval;

  /// Stats batcher capacity — flush is also triggered when the in-memory
  /// ring buffer grows past this many events. Default 50.
  final int statsFlushBatchSize;

  /// Hard cap on the in-memory ring buffer. Oldest events are dropped
  /// when the buffer is full and no flush is possible (offline). Default
  /// 500 — large enough to ride out a multi-day offline window for a
  /// typical low-traffic product.
  final int statsRingBufferCapacity;

  /// HTTP timeout per request. Default 15 s.
  final Duration httpTimeout;

  /// JWKS cache TTL. Bifrost serves long-lived static keys (rotation is
  /// the explicit /keys/rotate-ack path), so a multi-hour TTL is fine.
  /// Default 1 h.
  final Duration jwksCacheTtl;

  /// Optional pinned SPKI SHA-256 hashes for the Bifrost FRON host. Empty
  /// list disables pinning (only safe in dev). Default empty.
  final List<String> pinnedSpkiSha256;

  /// When true, swallows network errors during background heartbeat /
  /// stats flush so they don't bubble up to the UI. Recommended for
  /// production. Default true.
  final bool swallowBackgroundErrors;

  /// Allowed clock skew between client and server. Default 5 min — matches
  /// the FRON server's `iat`/`nbf`/`exp` tolerance.
  final Duration clockSkew;

  DirectConfig({
    required this.bifrostBaseUrl,
    required this.projectId,
    this.initialHeartbeatCadence = const Duration(hours: 24),
    this.statsFlushInterval = const Duration(minutes: 5),
    this.statsFlushBatchSize = 50,
    this.statsRingBufferCapacity = 500,
    this.httpTimeout = const Duration(seconds: 15),
    this.jwksCacheTtl = const Duration(hours: 1),
    this.pinnedSpkiSha256 = const [],
    this.swallowBackgroundErrors = true,
    this.clockSkew = const Duration(minutes: 5),
  }) {
    _validatePinnedSpkiSha256(pinnedSpkiSha256);
  }

  /// Validate every entry in [pins] is a base64(SHA-256) string of the
  /// expected length. A SHA-256 digest is 32 bytes → 44 chars of
  /// standard base64 (with `=` padding) or 43 chars of unpadded
  /// base64. Anything else is a typo and would silently fail at runtime
  /// (the underlying pinning plugin compares against the actual server
  /// SPKI hash; a typo'd pin can never match → effectively "pinning
  /// disabled because of operator error"). Fail loudly at construction
  /// instead — the host product gets a stack trace pointing at the bad
  /// config line, not a mystery TLS error two days later.
  static void _validatePinnedSpkiSha256(List<String> pins) {
    final base64Re = RegExp(r'^[A-Za-z0-9+/]+=*$');
    for (var i = 0; i < pins.length; i++) {
      final pin = pins[i];
      // Trim padding for length check (server-side pinning plugins
      // accept both padded + unpadded forms).
      final core = pin.replaceAll(RegExp(r'=+$'), '');
      if (!base64Re.hasMatch(pin)) {
        throw ArgumentError.value(
          pin,
          'pinnedSpkiSha256[$i]',
          'pinned SPKI SHA-256 must be base64 (got non-base64 char)',
        );
      }
      // 32 raw bytes → ceil(32 * 4 / 3) = 43 chars unpadded, 44 padded.
      if (core.length != 43) {
        throw ArgumentError.value(
          pin,
          'pinnedSpkiSha256[$i]',
          'pinned SPKI SHA-256 must be 32 bytes (43 base64 chars without '
              'padding, got ${core.length} chars). Did you paste a SHA-1 '
              'fingerprint or a hex string by mistake?',
        );
      }
    }
  }
}
