// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Lifecycle for the SDK's FRON keypairs.
///
/// There are two kinds:
///
///   * Ephemeral — one fresh X25519 + Ed25519 pair, generated once per
///     `register()` attempt. The X25519 half is the JWE `epk`; the Ed25519
///     half signs the inner ephemeral JWS. On a successful register the
///     Ed25519 keypair is PROMOTED to durable.
///
///   * Durable — survives across app launches in secure storage. The
///     Ed25519 half signs every Tier-2 inner JWS; the X25519 half is the
///     stable apu thumbprint binding source for response decryption.
///
/// SecureCache slot names (all under the "vanaheim:direct:" namespace):
///   * `device_id`             — opaque server-issued identifier
///   * `durable_x25519_priv`   — 32-byte raw scalar (base64url-no-pad)
///   * `durable_x25519_pub`    — 32-byte raw pub   (base64url-no-pad)
///   * `durable_ed25519_priv`  — 64-byte expanded private (base64url-no-pad)
///   * `durable_ed25519_pub`   — 32-byte raw pub   (base64url-no-pad)
///   * `server_nonce`          — opaque server-supplied nonce echoed in claims
///
/// All bytes are base64url-no-pad encoded for cross-platform storage safety.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' as c;
import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;

import '../storage/secure_cache.dart';

// Cache-key constants. Exported so tests can pre-populate the SecureCache.
const String kDirectDeviceIdKey = 'vanaheim:direct:device_id';
const String kDirectDurableX25519PrivKey =
    'vanaheim:direct:durable_x25519_priv';
const String kDirectDurableX25519PubKey =
    'vanaheim:direct:durable_x25519_pub';
const String kDirectDurableEd25519PrivKey =
    'vanaheim:direct:durable_ed25519_priv';
const String kDirectDurableEd25519PubKey =
    'vanaheim:direct:durable_ed25519_pub';
const String kDirectServerNonceKey = 'vanaheim:direct:server_nonce';

/// In-memory snapshot of the durable identity. Returned by
/// [DirectKeypairStore.loadDurable] and re-used by every Tier-2 request.
class DirectDurableIdentity {
  final String deviceId;
  final Uint8List x25519Priv;
  final Uint8List x25519Pub;
  final Uint8List ed25519Priv;
  final Uint8List ed25519Pub;
  final String? serverNonce;

  const DirectDurableIdentity({
    required this.deviceId,
    required this.x25519Priv,
    required this.x25519Pub,
    required this.ed25519Priv,
    required this.ed25519Pub,
    this.serverNonce,
  });
}

/// One-shot ephemeral pair used during `register()`.
class DirectEphemeralIdentity {
  final Uint8List x25519Priv;
  final Uint8List x25519Pub;
  final Uint8List ed25519Priv;
  final Uint8List ed25519Pub;

  const DirectEphemeralIdentity({
    required this.x25519Priv,
    required this.x25519Pub,
    required this.ed25519Priv,
    required this.ed25519Pub,
  });
}

/// Wraps [SecureCache] + crypto primitives for the FRON keypair lifecycle.
class DirectKeypairStore {
  final SecureCache _cache;
  final c.X25519 _x25519;

  DirectKeypairStore({
    required SecureCache cache,
    c.X25519? x25519,
  })  : _cache = cache,
        _x25519 = x25519 ?? c.X25519();

  // ----------------------------------------------------------------- ephemeral

  /// Generates a fresh ephemeral identity. NOT persisted — the caller
  /// promotes it via [promoteEphemeral] only on a successful register.
  Future<DirectEphemeralIdentity> generateEphemeral() async {
    final xkp = await _x25519.newKeyPair();
    final xPub = await xkp.extractPublicKey();
    final xPriv = await xkp.extractPrivateKeyBytes();

    final edKp = ed25519.generateKey();
    final edPriv = Uint8List.fromList(edKp.privateKey.bytes);
    final edPub = Uint8List.fromList(edKp.publicKey.bytes);

    return DirectEphemeralIdentity(
      x25519Priv: Uint8List.fromList(xPriv),
      x25519Pub: Uint8List.fromList(xPub.bytes),
      ed25519Priv: edPriv,
      ed25519Pub: edPub,
    );
  }

  // ----------------------------------------------------------------- durable

  /// Loads the durable identity from secure storage, or returns null if
  /// the device has never successfully registered.
  Future<DirectDurableIdentity?> loadDurable() async {
    final id = await _cache.getRaw(kDirectDeviceIdKey);
    if (id == null || id.isEmpty) return null;
    final xPriv = await _readBytes(kDirectDurableX25519PrivKey);
    final xPub = await _readBytes(kDirectDurableX25519PubKey);
    final edPriv = await _readBytes(kDirectDurableEd25519PrivKey);
    final edPub = await _readBytes(kDirectDurableEd25519PubKey);
    if (xPriv == null || xPub == null || edPriv == null || edPub == null) {
      // Partial state — treat as not-registered. The register() flow will
      // generate a fresh ephemeral and overwrite below.
      return null;
    }
    final nonce = await _cache.getRaw(kDirectServerNonceKey);
    return DirectDurableIdentity(
      deviceId: id,
      x25519Priv: xPriv,
      x25519Pub: xPub,
      ed25519Priv: edPriv,
      ed25519Pub: edPub,
      serverNonce: nonce,
    );
  }

  /// Persists [ephemeral] as the durable identity for [deviceId].
  /// Called by `DirectClient.register()` on a 2xx response.
  Future<DirectDurableIdentity> promoteEphemeral({
    required String deviceId,
    required DirectEphemeralIdentity ephemeral,
    String? serverNonce,
  }) async {
    await _cache.putRaw(kDirectDeviceIdKey, deviceId);
    await _writeBytes(kDirectDurableX25519PrivKey, ephemeral.x25519Priv);
    await _writeBytes(kDirectDurableX25519PubKey, ephemeral.x25519Pub);
    await _writeBytes(kDirectDurableEd25519PrivKey, ephemeral.ed25519Priv);
    await _writeBytes(kDirectDurableEd25519PubKey, ephemeral.ed25519Pub);
    if (serverNonce != null) {
      await _cache.putRaw(kDirectServerNonceKey, serverNonce);
    }
    return DirectDurableIdentity(
      deviceId: deviceId,
      x25519Priv: ephemeral.x25519Priv,
      x25519Pub: ephemeral.x25519Pub,
      ed25519Priv: ephemeral.ed25519Priv,
      ed25519Pub: ephemeral.ed25519Pub,
      serverNonce: serverNonce,
    );
  }

  /// Updates the persisted server nonce. Some endpoints (e.g. heartbeat,
  /// verify) refresh it.
  Future<void> updateServerNonce(String nonce) async {
    await _cache.putRaw(kDirectServerNonceKey, nonce);
  }

  /// Wipes every FRON-related slot. Called on `DIRECT_DEVICE_REVOKED` so
  /// the next `connect()` re-registers cleanly.
  ///
  /// Uses [SecureCache.deletePrefix] over the `vanaheim:direct:`
  /// namespace so future direct slots are covered automatically — a
  /// per-key delete sweep would silently leak any new key the FRON
  /// subsystem adds without an update to this method.
  Future<void> clear() async {
    await _cache.deletePrefix(kDirectNamespacePrefix);
  }

  // ----------------------------------------------------------------- helpers

  Future<Uint8List?> _readBytes(String key) async {
    final s = await _cache.getRaw(key);
    if (s == null || s.isEmpty) return null;
    try {
      final pad = (4 - s.length % 4) % 4;
      return base64Url.decode(s.padRight(s.length + pad, '='));
    } catch (_) {
      return null;
    }
  }

  Future<void> _writeBytes(String key, Uint8List bytes) async {
    final encoded = base64Url.encode(bytes).replaceAll('=', '');
    await _cache.putRaw(key, encoded);
  }
}

/// Common namespace prefix for every FRON SecureCache slot. Used by
/// [DirectKeypairStore.clear] (via [SecureCache.deletePrefix]) so we
/// can sweep the entire FRON state in one call without enumerating
/// every key explicitly.
const String kDirectNamespacePrefix = 'vanaheim:direct:';
