// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Periodic heartbeat scheduler.
///
/// Calls a caller-supplied `tick()` function on a configurable cadence.
/// The cadence is mutable — `setCadence()` is invoked from
/// `DirectClient.register/verify/heartbeat` to honour the server-supplied
/// `heartbeat_cadence_ms`.
///
/// Network errors raised by `tick()` are swallowed (logged via the
/// optional [onError] callback) so a flaky connection doesn't surface
/// as an uncaught exception inside a Flutter `Timer`. If the SDK is
/// `pause()`d (e.g. the host product reports the device is offline),
/// ticks are silently skipped and resume on the next `resume()`.
library;

import 'dart:async';

typedef HeartbeatTick = Future<void> Function();
typedef HeartbeatErrorHandler = void Function(
    Object error, StackTrace stackTrace);

class DirectHeartbeatScheduler {
  final HeartbeatTick _tick;
  final HeartbeatErrorHandler? onError;

  Duration _cadence;
  Timer? _timer;
  bool _paused = false;
  bool _running = false;
  bool _disposed = false;

  DirectHeartbeatScheduler({
    required HeartbeatTick tick,
    required Duration initialCadence,
    this.onError,
  })  : _tick = tick,
        _cadence = initialCadence;

  Duration get cadence => _cadence;
  bool get isPaused => _paused;
  bool get isRunning => _timer != null;

  /// Start (or restart) the heartbeat timer. Safe to call repeatedly —
  /// existing timers are cancelled first.
  void start() {
    if (_disposed) return;
    _timer?.cancel();
    _timer = Timer.periodic(_cadence, (_) => _safeTick());
  }

  /// Stop firing ticks. The current in-flight tick (if any) is allowed
  /// to complete.
  void stop() {
    _timer?.cancel();
    _timer = null;
  }

  /// Pause ticking without tearing down the timer. Ticks fire on the
  /// normal cadence but are no-ops until [resume].
  void pause() {
    _paused = true;
  }

  /// Resume ticking after a [pause]. Optionally fires a tick immediately
  /// to catch up any state that may have drifted while offline.
  void resume({bool fireImmediately = true}) {
    _paused = false;
    if (fireImmediately) {
      // Don't await — the timer's normal cadence is what matters; the
      // immediate call just means the caller doesn't have to wait one
      // full cadence to learn the device is back online.
      unawaited(_safeTick());
    }
  }

  /// Lower bound on the heartbeat cadence. Anything shorter is treated
  /// as a buggy server response and clamped — a cadence of 0 (or even a
  /// few ms) would create a runaway tick loop that hammers the network
  /// + drains battery.
  static const Duration kMinCadence = Duration(seconds: 1);

  /// Upper bound on the heartbeat cadence. Anything longer is treated
  /// as an invalid server response and clamped — a 30-day cadence would
  /// silently keep a revoked device alive for far too long.
  static const Duration kMaxCadence = Duration(hours: 24);

  /// Update the cadence and reset the timer so the next tick fires
  /// at the new interval. Called from `DirectClient` after every
  /// register / verify / heartbeat that returns a cadence override.
  ///
  /// The cadence is CLAMPED to [kMinCadence] .. [kMaxCadence] before
  /// being applied so a buggy / malicious server response can't push
  /// the SDK into a hot-loop or an effectively-disabled heartbeat.
  void setCadence(Duration cadence) {
    if (_disposed) return;
    final clamped = _clamp(cadence);
    if (clamped == _cadence) return;
    _cadence = clamped;
    if (_timer != null) {
      // Restart with the new period.
      start();
    }
  }

  static Duration _clamp(Duration d) {
    if (d < kMinCadence) return kMinCadence;
    if (d > kMaxCadence) return kMaxCadence;
    return d;
  }

  /// Tear down. After this the scheduler is inert.
  void dispose() {
    _disposed = true;
    stop();
  }

  Future<void> _safeTick() async {
    if (_disposed) return;
    if (_paused) return;
    if (_running) return; // avoid re-entrancy when a tick overruns the cadence
    _running = true;
    try {
      await _tick();
    } catch (e, st) {
      onError?.call(e, st);
    } finally {
      _running = false;
    }
  }
}
