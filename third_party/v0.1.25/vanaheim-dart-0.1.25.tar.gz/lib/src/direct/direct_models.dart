// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// FRON (Bifrost-Direct) DTOs + typed error taxonomy.
///
/// These mirror the Bifrost FRON wire codes 1:1 — see
/// `bifrost/packages/functions/src/direct/errors.ts` for the server side.
/// Wire codes are PUBLIC; only the coarse string lands on the network.
library;

import 'package:meta/meta.dart';

import '../exceptions.dart';

// ---------------------------------------------------------------------------
// DTOs
// ---------------------------------------------------------------------------

/// Result of [DirectClient.register].
///
/// `deviceId` and `serverNonce` are persisted to secure storage and must be
/// echoed on every subsequent durable-mode call. `heartbeatCadenceMs` comes
/// from the server (per-project, per-tier) and overrides the SDK default.
@immutable
class RegisterResult {
  /// The device identifier minted by Bifrost. Stable across SDK restarts.
  final String deviceId;

  /// Server-side nonce echoed in subsequent durable JWS claims so Bifrost
  /// can detect device-keypair reuse without trusting the client clock.
  final String serverNonce;

  /// Compact JWS carrying the device's entitlement claims. The SDK parses
  /// the inner claims via [entitlements]; the raw JWS is kept for offline
  /// re-verification across app restarts.
  final String entitlementJws;

  /// Initial entitlement snapshot decoded from [entitlementJws].
  final DirectEntitlements entitlements;

  /// Server-suggested heartbeat cadence in milliseconds.
  /// Default per spec: 24h for free tier, 1h for paid; the server is
  /// authoritative once registration completes.
  final int heartbeatCadenceMs;

  const RegisterResult({
    required this.deviceId,
    required this.serverNonce,
    required this.entitlementJws,
    required this.entitlements,
    required this.heartbeatCadenceMs,
  });
}

/// Result of [DirectClient.activate] — re-activation against a license key.
@immutable
class ActivateResult {
  final String deviceId;
  final String entitlementJws;
  final DirectEntitlements entitlements;

  const ActivateResult({
    required this.deviceId,
    required this.entitlementJws,
    required this.entitlements,
  });
}

/// Result of [DirectClient.verify] — pulls a fresh entitlement JWS.
@immutable
class VerifyResult {
  final String entitlementJws;
  final DirectEntitlements entitlements;
  /// Server-stamped wall clock at the time of issue (epoch ms). Used by
  /// the heartbeat scheduler to drift-correct against the client clock.
  final int issuedAtMs;

  const VerifyResult({
    required this.entitlementJws,
    required this.entitlements,
    required this.issuedAtMs,
  });
}

/// Result of [DirectClient.heartbeat] — keep-alive + revoke probe.
@immutable
class HeartbeatResult {
  /// True if the server says the device is still alive. False means the
  /// caller must surface a "session revoked" UX and stop using cached
  /// entitlements.
  final bool alive;

  /// Server may push down a new entitlement JWS if the tier rotated since
  /// the last verify. Null when nothing changed.
  final String? entitlementJws;

  /// Updated entitlements when [entitlementJws] is non-null.
  final DirectEntitlements? entitlements;

  /// Server may bump the cadence (e.g. after an upgrade). Null = keep the
  /// previous cadence.
  final int? heartbeatCadenceMs;

  const HeartbeatResult({
    required this.alive,
    this.entitlementJws,
    this.entitlements,
    this.heartbeatCadenceMs,
  });
}

/// Tier + per-feature entitlements as parsed from a FRON inner JWS.
/// Parallel to [Entitlements] in `models.dart` but lives in the direct
/// subtree so the FRON code path doesn't pull in the full L2 model graph.
@immutable
class DirectEntitlements {
  final String tier;
  final int version;
  final Map<String, dynamic> features;
  final Map<String, int> quotas;

  const DirectEntitlements({
    required this.tier,
    required this.version,
    required this.features,
    required this.quotas,
  });

  bool has(String name) {
    final v = features[name];
    if (v == null) return false;
    if (v is bool) return v;
    if (v is num) return v != 0;
    return true;
  }

  int quotaFor(String name) => quotas[name] ?? 0;

  factory DirectEntitlements.fromJson(Map<String, dynamic> j) {
    final tier = (j['tier'] as String?) ?? 'free';
    final version = (j['version'] is num) ? (j['version'] as num).toInt() : 0;
    final features = (j['features'] is Map)
        ? (j['features'] as Map).cast<String, dynamic>()
        : <String, dynamic>{};
    final rawQuotas = (j['quotas'] is Map)
        ? (j['quotas'] as Map).cast<String, dynamic>()
        : <String, dynamic>{};
    final quotas = <String, int>{};
    rawQuotas.forEach((k, v) {
      if (v is num) quotas[k] = v.toInt();
    });
    return DirectEntitlements(
      tier: tier,
      version: version,
      features: Map.unmodifiable(features),
      quotas: Map.unmodifiable(quotas),
    );
  }
}

/// Snapshot of the encrypted catalog (tier names, feature matrices, prices).
@immutable
class CatalogSnapshot {
  /// Monotonic catalog version. Caller can short-circuit if unchanged.
  final int version;

  /// List of tiers in catalog order (cheapest → most expensive).
  final List<DirectTierInfo> tiers;

  /// Raw catalog JSON for products that want to render custom UI.
  final Map<String, dynamic> raw;

  const CatalogSnapshot({
    required this.version,
    required this.tiers,
    required this.raw,
  });

  factory CatalogSnapshot.fromJson(Map<String, dynamic> j) {
    final tiers = <DirectTierInfo>[];
    final rawTiers = j['tiers'];
    if (rawTiers is List) {
      for (final t in rawTiers) {
        if (t is Map) tiers.add(DirectTierInfo.fromJson(t.cast<String, dynamic>()));
      }
    }
    return CatalogSnapshot(
      version: (j['version'] is num) ? (j['version'] as num).toInt() : 0,
      tiers: List.unmodifiable(tiers),
      raw: Map.unmodifiable(j),
    );
  }
}

/// One row in [CatalogSnapshot.tiers].
@immutable
class DirectTierInfo {
  final String id;
  final String displayName;
  final List<String> features;
  /// Price in minor units (cents); null for free tiers.
  final int? priceMinor;
  /// ISO-4217 currency code; null when [priceMinor] is null.
  final String? currency;

  const DirectTierInfo({
    required this.id,
    required this.displayName,
    required this.features,
    this.priceMinor,
    this.currency,
  });

  factory DirectTierInfo.fromJson(Map<String, dynamic> j) {
    final id = (j['id'] as String?) ?? '';
    final name = (j['display_name'] as String?) ?? id;
    final feats = <String>[];
    final rawF = j['features'];
    if (rawF is List) {
      for (final f in rawF) {
        if (f is String) feats.add(f);
      }
    }
    final price = (j['price_minor'] is num) ? (j['price_minor'] as num).toInt() : null;
    final cur = j['currency'] is String ? j['currency'] as String : null;
    return DirectTierInfo(
      id: id,
      displayName: name,
      features: List.unmodifiable(feats),
      priceMinor: price,
      currency: cur,
    );
  }
}

/// Result of [DirectClient.sendStats] — aggregate write receipt.
@immutable
class StatsResult {
  /// Number of events the server accepted into its persistence layer.
  final int accepted;

  /// Number of events the server rejected (typically schema or rate).
  final int rejected;

  const StatsResult({required this.accepted, required this.rejected});

  factory StatsResult.fromJson(Map<String, dynamic> j) => StatsResult(
        accepted: (j['accepted'] is num) ? (j['accepted'] as num).toInt() : 0,
        rejected: (j['rejected'] is num) ? (j['rejected'] as num).toInt() : 0,
      );
}

/// Result of [DirectClient.reportError] — single crash/error ingest receipt.
@immutable
class ErrorResult {
  /// Server-side identifier for the error record. Surface in support
  /// tickets so SRE can pivot.
  final String errorId;

  /// True if the server applied rate-limiting and dropped this event;
  /// the client should back off before reporting more.
  final bool throttled;

  const ErrorResult({required this.errorId, required this.throttled});

  factory ErrorResult.fromJson(Map<String, dynamic> j) => ErrorResult(
        errorId: (j['error_id'] as String?) ?? '',
        throttled: (j['throttled'] as bool?) ?? false,
      );
}

/// A single statistic event queued by the stats batcher. Products should
/// keep these small — large blobs go through the file-upload API.
@immutable
class StatsEvent {
  final String name;
  final int timestampMs;
  final Map<String, dynamic> attributes;

  const StatsEvent({
    required this.name,
    required this.timestampMs,
    this.attributes = const {},
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'ts_ms': timestampMs,
        'attrs': attributes,
      };

  factory StatsEvent.fromJson(Map<String, dynamic> j) => StatsEvent(
        name: (j['name'] as String?) ?? '',
        timestampMs: (j['ts_ms'] is num) ? (j['ts_ms'] as num).toInt() : 0,
        attributes: (j['attrs'] is Map)
            ? (j['attrs'] as Map).cast<String, dynamic>()
            : const {},
      );
}

/// A single error report event submitted via [DirectClient.reportError].
@immutable
class ErrorReport {
  final String message;
  final String? stack;
  final String? severity; // "fatal" | "error" | "warn" | "info"
  final Map<String, dynamic> context;

  const ErrorReport({
    required this.message,
    this.stack,
    this.severity,
    this.context = const {},
  });

  Map<String, dynamic> toJson() => {
        'message': message,
        if (stack != null) 'stack': stack,
        if (severity != null) 'severity': severity,
        'context': context,
      };
}

// ---------------------------------------------------------------------------
// Error taxonomy
//
// Mirrors the Bifrost FRON wire codes 1:1. Subclasses of [DirectError] are
// what `DirectResponseParser` raises when the server returns a non-2xx FRON
// envelope. All inherit from [LicenseStoreException] so existing
// `try { … } on LicenseStoreException { … }` blocks keep working.
// ---------------------------------------------------------------------------

/// Base class for every Bifrost-Direct (FRON) wire failure.
abstract class DirectError extends LicenseStoreException {
  /// Stable wire code (e.g. `DIRECT_LICENSE_INVALID`).
  final String code;

  DirectError(this.code, super.message, {super.cause});
}

/// Server returned `DIRECT_BAD_REQUEST` — request shape failed validation.
class DirectBadRequestError extends DirectError {
  DirectBadRequestError([String message = 'Direct request rejected'])
      : super('DIRECT_BAD_REQUEST', message);
}

/// Server returned `DIRECT_LICENSE_INVALID` — license key not found, malformed,
/// or otherwise refused.
class DirectLicenseInvalidError extends DirectError {
  DirectLicenseInvalidError([String message = 'License key invalid'])
      : super('DIRECT_LICENSE_INVALID', message);
}

/// Server returned `DIRECT_LICENSE_EXPIRED` — caller may prompt for renewal.
class DirectLicenseExpiredError extends DirectError {
  DirectLicenseExpiredError([String message = 'License expired'])
      : super('DIRECT_LICENSE_EXPIRED', message);
}

/// Server returned `DIRECT_LICENSE_SEAT_EXCEEDED` — license cap reached.
class DirectSeatExceededError extends DirectError {
  DirectSeatExceededError([String message = 'License seat cap exceeded'])
      : super('DIRECT_LICENSE_SEAT_EXCEEDED', message);
}

/// Server returned `DIRECT_RATE_LIMITED` — back off for [retryAfterMs].
class DirectRateLimitError extends DirectError {
  final int retryAfterMs;
  DirectRateLimitError({this.retryAfterMs = 0, String? message})
      : super(
          'DIRECT_RATE_LIMITED',
          message ?? 'Direct rate limit (retry after ${retryAfterMs}ms)',
        );
}

/// Server returned `DIRECT_FCM_TOKEN_REUSED` — the supplied token is already
/// bound to a different device. Caller should rotate the device's FCM token.
class DirectFcmTokenReusedError extends DirectError {
  DirectFcmTokenReusedError([String message = 'FCM token already bound to another device'])
      : super('DIRECT_FCM_TOKEN_REUSED', message);
}

/// Server returned `DIRECT_NO_PROVIDER_CONFIGURED` — the project has no
/// third-party provider wired for this capability (e.g. payment, KYC, e-sign).
class DirectNoProviderConfiguredError extends DirectError {
  DirectNoProviderConfiguredError([String message = 'No provider configured for this capability'])
      : super('DIRECT_NO_PROVIDER_CONFIGURED', message);
}

/// Server returned a `DIRECT_*_FAILED` code (provider-side outage / refusal).
/// The exact provider lives in [providerCode].
class DirectProviderFailedError extends DirectError {
  /// The full wire code (e.g. `DIRECT_PAYMENT_FAILED`).
  final String providerCode;
  DirectProviderFailedError(this.providerCode, [String? message])
      : super(providerCode, message ?? 'Provider call failed ($providerCode)');
}

/// Server returned `DIRECT_PROJECT_DISABLED` — the project hasn't opted in
/// to FRON mode. Caller must surface a "contact the app developer" message.
class DirectProjectDisabledError extends DirectError {
  DirectProjectDisabledError([String message = 'Direct mode not enabled for this project'])
      : super('DIRECT_PROJECT_DISABLED', message);
}

/// Server returned `DIRECT_REPLAY_DETECTED` — the epk thumbprint is in the
/// anti-reuse ledger. Caller should regenerate the ephemeral keypair.
class DirectReplayDetectedError extends DirectError {
  DirectReplayDetectedError([String message = 'Direct replay detected'])
      : super('DIRECT_REPLAY_DETECTED', message);
}

/// Server returned `DIRECT_DEVICE_REVOKED` — admin or fraud signal kicked
/// this device. Caller must clear the durable keypair and re-register.
class DirectDeviceRevokedError extends DirectError {
  DirectDeviceRevokedError([String message = 'Device was revoked by the server'])
      : super('DIRECT_DEVICE_REVOKED', message);
}

/// Hook for the payment subsystem to plug additional wire-code mappings
/// into [directErrorFromCode] without forcing this file to import the
/// payment-model layer (keeps the dependency direction one-way:
/// `direct_payment_models.dart` → `direct_models.dart`, not the other
/// way round).
///
/// The payment models file installs its router via
/// [registerDirectErrorExtension] at library init. Tests / alternative
/// transports can install their own resolvers similarly.
typedef DirectErrorExtension = DirectError? Function(
  String code, {
  String? message,
  int? retryAfterMs,
  String? reason,
  String? provider,
});

final List<DirectErrorExtension> _directErrorExtensions =
    <DirectErrorExtension>[];

/// Register an additional wire-code → typed exception resolver. Resolvers
/// run in registration order; the first non-null result wins. Safe to
/// call multiple times (duplicates are deduped by identity).
void registerDirectErrorExtension(DirectErrorExtension ext) {
  if (!_directErrorExtensions.contains(ext)) {
    _directErrorExtensions.add(ext);
  }
}

/// Map a wire code → typed exception. Unknown codes fall through to a
/// generic [DirectError] subclass so the caller can still pattern-match.
DirectError directErrorFromCode(
  String code, {
  String? message,
  int? retryAfterMs,
  String? reason,
  String? provider,
}) {
  // Built-in resolution first.
  switch (code) {
    case 'DIRECT_BAD_REQUEST':
      return DirectBadRequestError(message ?? 'Direct request rejected');
    case 'DIRECT_LICENSE_INVALID':
      return DirectLicenseInvalidError(message ?? 'License key invalid');
    case 'DIRECT_LICENSE_EXPIRED':
      return DirectLicenseExpiredError(message ?? 'License expired');
    case 'DIRECT_LICENSE_SEAT_EXCEEDED':
      return DirectSeatExceededError(message ?? 'License seat cap exceeded');
    case 'DIRECT_RATE_LIMITED':
    case 'DIRECT_RATE_LIMIT':
      return DirectRateLimitError(
        retryAfterMs: retryAfterMs ?? 0,
        message: message,
      );
    case 'DIRECT_FCM_TOKEN_REUSED':
      return DirectFcmTokenReusedError(
          message ?? 'FCM token already bound to another device');
    case 'DIRECT_NO_PROVIDER_CONFIGURED':
      return DirectNoProviderConfiguredError(
          message ?? 'No provider configured for this capability');
    case 'DIRECT_PROJECT_DISABLED':
      return DirectProjectDisabledError(
          message ?? 'Direct mode not enabled for this project');
    case 'DIRECT_REPLAY_DETECTED':
      return DirectReplayDetectedError(message ?? 'Direct replay detected');
    case 'DIRECT_DEVICE_REVOKED':
      return DirectDeviceRevokedError(
          message ?? 'Device was revoked by the server');
  }

  // Then registered extensions (payment surface, future subsystems).
  for (final ext in _directErrorExtensions) {
    final mapped = ext(
      code,
      message: message,
      retryAfterMs: retryAfterMs,
      reason: reason,
      provider: provider,
    );
    if (mapped != null) return mapped;
  }

  // Catch-all: legacy DIRECT_*_FAILED → generic provider-failed.
  if (code.startsWith('DIRECT_') && code.endsWith('_FAILED')) {
    return DirectProviderFailedError(code, message);
  }
  return _GenericDirectError(code, message ?? 'Direct error: $code');
}

class _GenericDirectError extends DirectError {
  _GenericDirectError(super.code, super.message);
}
