// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Fetches + caches the Bifrost FRON recipient keys from
/// `GET /direct/v1/.well-known/jwks.json` (Tier 0 — HTTPS only, never JWE).
///
/// Returns:
///   * X25519 pubkey + kid — recipient for the outgoing JWE envelope.
///   * Ed25519 pubkey(s) keyed by kid — verification keys for any
///     server-issued entitlement JWS the SDK decrypts out of a response.
///
/// Cache TTL is governed by [DirectConfig.jwksCacheTtl]. A `Cache-Control:
/// max-age` header on the response wins over the config default. Concurrent
/// callers share a single in-flight fetch.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../exceptions.dart';

/// One Bifrost recipient key (X25519 — JWE encrypt target).
class BifrostRecipientKey {
  final String kid;
  final Uint8List pub; // 32 raw bytes
  const BifrostRecipientKey({required this.kid, required this.pub});
}

/// One Bifrost signing key (Ed25519 — entitlement JWS verify).
class BifrostSigningKey {
  final String kid;
  final Uint8List pub; // 32 raw bytes
  const BifrostSigningKey({required this.kid, required this.pub});
}

/// Resolver result: the currently-active X25519 recipient + the full set
/// of Ed25519 signing keys keyed by kid.
class BifrostKeySet {
  final BifrostRecipientKey activeRecipient;
  final Map<String, BifrostRecipientKey> recipientsByKid;
  final Map<String, BifrostSigningKey> signersByKid;

  /// kids the server marked as `status: revoked`; the SDK must refuse
  /// any inbound JWS signed under these.
  final Set<String> revokedKids;

  const BifrostKeySet({
    required this.activeRecipient,
    required this.recipientsByKid,
    required this.signersByKid,
    required this.revokedKids,
  });
}

/// Resolver against Bifrost's static FRON JWKS.
class DirectRecipientResolver {
  final Uri jwksUrl;
  final Duration defaultTtl;
  final http.Client _http;

  BifrostKeySet? _cache;
  DateTime _fetchedAt = DateTime.fromMillisecondsSinceEpoch(0);
  Duration _currentTtl = Duration.zero;
  Future<BifrostKeySet>? _inFlight;

  DirectRecipientResolver({
    required Uri bifrostBaseUrl,
    this.defaultTtl = const Duration(hours: 1),
    http.Client? httpClient,
  })  : jwksUrl = _validateBaseUrl(bifrostBaseUrl)
            .replace(path: '/direct/v1/.well-known/jwks.json'),
        _http = httpClient ?? http.Client();

  /// Reject any base URL that isn't HTTPS, except for `http://localhost`
  /// and `http://127.0.0.1` (loopback only, for testing). The JWKS body
  /// IS the trust root for every subsequent FRON call — fetching it over
  /// plain HTTP would let a network attacker substitute their own
  /// recipient + signing keys and silently MITM the entire SDK.
  static Uri _validateBaseUrl(Uri base) {
    final scheme = base.scheme.toLowerCase();
    if (scheme == 'https') return base;
    if (scheme == 'http') {
      final host = base.host.toLowerCase();
      if (host == 'localhost' || host == '127.0.0.1') return base;
    }
    throw ArgumentError.value(
      base.toString(),
      'bifrostBaseUrl',
      'Bifrost base URL must use https:// (loopback http:// is allowed '
          'for testing only). The JWKS body is the trust root for every '
          'FRON call; HTTP would allow silent MITM.',
    );
  }

  /// Returns the cached key set, fetching if cold or stale.
  Future<BifrostKeySet> get() async {
    final cached = _cache;
    if (cached != null && !_isStale()) return cached;
    return _refresh();
  }

  /// Forces a fresh fetch (e.g. after observing `acknowledgeKidRotation`).
  Future<BifrostKeySet> refresh() => _refresh(force: true);

  bool _isStale() =>
      DateTime.now().toUtc().difference(_fetchedAt) > _currentTtl;

  Future<BifrostKeySet> _refresh({bool force = false}) {
    if (_inFlight != null) return _inFlight!;
    final cached = _cache;
    if (!force && cached != null && !_isStale()) {
      return Future.value(cached);
    }
    final fut = _doFetch().whenComplete(() => _inFlight = null);
    _inFlight = fut;
    return fut;
  }

  Future<BifrostKeySet> _doFetch() async {
    http.Response res;
    try {
      res = await _http.get(jwksUrl, headers: const {
        'Accept': 'application/json',
      });
    } catch (e) {
      throw NetworkException('Bifrost JWKS fetch failed: $e');
    }
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw NetworkException(
        'Bifrost JWKS HTTP ${res.statusCode}',
        statusCode: res.statusCode,
      );
    }

    Map<String, dynamic> body;
    try {
      body = (jsonDecode(res.body) as Map).cast<String, dynamic>();
    } catch (e) {
      throw NetworkException('Bifrost JWKS invalid JSON: $e');
    }

    final keys = body['keys'];
    if (keys is! List) {
      throw NetworkException('Bifrost JWKS missing "keys" array');
    }

    final recipients = <String, BifrostRecipientKey>{};
    final signers = <String, BifrostSigningKey>{};
    final revoked = <String>{};
    BifrostRecipientKey? active;

    for (final rawKey in keys) {
      if (rawKey is! Map) continue;
      final jwk = rawKey.cast<String, dynamic>();
      final kid = jwk['kid'];
      if (kid is! String || kid.isEmpty) continue;
      if (jwk['status'] == 'revoked') {
        revoked.add(kid);
        continue;
      }
      final raw = _decodeRawPub(jwk);
      if (raw == null) continue;
      final crv = jwk['crv'];
      final use = jwk['use'];
      if (crv == 'X25519') {
        final rec = BifrostRecipientKey(kid: kid, pub: raw);
        recipients[kid] = rec;
        // First "active" or "use: enc" wins; fall back to the first
        // non-revoked X25519 key on a key set that doesn't tag use.
        final isActive = jwk['active'] == true || use == 'enc';
        if (active == null || isActive) active = rec;
      } else if (crv == 'Ed25519') {
        signers[kid] = BifrostSigningKey(kid: kid, pub: raw);
      }
    }

    if (active == null) {
      throw NetworkException(
          'Bifrost JWKS contained no active X25519 recipient key');
    }

    // Cache-Control: max-age wins over the config default.
    var ttl = defaultTtl;
    final cc = res.headers['cache-control'];
    if (cc != null) {
      final maxAge = _parseMaxAge(cc);
      if (maxAge != null) ttl = Duration(seconds: maxAge);
    }

    final set = BifrostKeySet(
      activeRecipient: active,
      recipientsByKid: Map.unmodifiable(recipients),
      signersByKid: Map.unmodifiable(signers),
      revokedKids: Set.unmodifiable(revoked),
    );
    _cache = set;
    _fetchedAt = DateTime.now().toUtc();
    _currentTtl = ttl;
    return set;
  }

  static Uint8List? _decodeRawPub(Map<String, dynamic> jwk) {
    final kty = jwk['kty'];
    if (kty != 'OKP') return null;
    final x = jwk['x'];
    if (x is! String || x.isEmpty) return null;
    try {
      final pad = (4 - x.length % 4) % 4;
      final bytes = base64Url.decode(x.padRight(x.length + pad, '='));
      if (bytes.length != 32) return null;
      return bytes;
    } catch (_) {
      return null;
    }
  }

  static int? _parseMaxAge(String cacheControl) {
    final lower = cacheControl.toLowerCase();
    final parts = lower.split(',');
    for (final p in parts) {
      final kv = p.trim();
      if (kv.startsWith('max-age=')) {
        final n = int.tryParse(kv.substring('max-age='.length).trim());
        if (n != null && n >= 0) return n;
      }
    }
    return null;
  }
}
