// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart'
    show KeyPairType, SimplePublicKey;

import 'crypto/thumbprint.dart' show devicePubThumbprint;
import 'api/account_api.dart';
import 'api/assistant_api.dart';
import 'api/devices_api.dart';
import 'api/docs_api.dart';
import 'api/feedback_api.dart';
import 'api/notifications_api.dart';
import 'api/offers_api.dart';
import 'api/organization_api.dart';
import 'api/preferences_api.dart';
import 'api/privacy_api.dart';
import 'api/referrals_api.dart';
import 'api/security_api.dart';
import 'api/status_api.dart';
import 'api/subscription_api.dart';
import 'api/support_api.dart';
import 'api/telemetry_api.dart';
import 'apps/capabilities.dart' as apps_capabilities;
import 'auth/auth_providers.dart';
import 'capabilities.dart';
import 'config.dart';
import 'direct/direct_client.dart';
import 'crypto/jwe.dart';
import 'crypto/jwe_codec.dart' as crypto_jwe;
import 'crypto/jwks_client.dart';
import 'crypto/jwt_verifier.dart';
import 'crypto/route_policy.dart' as crypto_route;
import 'device/fingerprint.dart';
import 'exceptions.dart';
import 'grace/grace_state_machine.dart';
import 'i18n/formatter.dart';
import 'models.dart';
import 'push/push_token_provider.dart';
import 'storage/secure_cache.dart';
import 'telemetry/error_telemetry.dart';
import 'transport/cert_pinning.dart';
import 'transport/hmac_signer.dart';
import 'transport/http_client.dart';
import 'transport/l2_keys_client.dart';

/// The single product-facing object. Construct via [LicenseClient.connect];
/// then call [activate], [verify], read entitlements via [hasFeature]/[quota],
/// and observe state changes via [stateChanges].
class LicenseClient {
  static const _issuer =
      'licenses.example.com'; // ci-allow: sdk-legacy-issuer-string — JWT `iss` claim, not a URL

  final VanaheimConfig _config;
  final SdkCapabilities _capabilities;
  final String _productSlug;
  final SignedHttpClient _http;
  final JwksClient _jwks;
  final SecureCache _cache;
  final DeviceFingerprintGenerator _fp;
  final GraceStateMachine _grace;
  final ErrorTelemetry _telemetry;
  final PushTokenProvider _push;
  final Formatter _formatter;
  // v2 / Vanaheim plumbing. _l2Keys is consulted by the transport on every
  // JWE-required call (recipient kid + kek_v), and exposed via [l2Keys] so
  // tests + diagnostics can force-refresh during PEK rotation drills.
  final L2KeysClient _l2Keys;
  final DevicesAPI _devices;
  // Lazily-started internal telemetry pipeline. Created lazily so products
  // that disable the capability don't pay for its background timers.
  TelemetryApi? _telemetryApi;
  StreamSubscription<String>? _pushTokenSub;
  StreamSubscription<Map<String, dynamic>>? _pushMessageSub;

  final Uri _regionEndpoint;
  String? _licenseId;
  String? _activationId;
  // Tracked for diagnostic inspection (see example/test_deploy/smoke_test.dart)
  // and to keep an in-memory mirror of the on-disk JWT for future fast-paths.
  // ignore: unused_field
  String? _cachedJwt;
  LicenseJwtClaims? _claims;
  int _knownEntitlementsVersion = 0;
  int _knownConfigVersion = 0;
  int _knownPreferencesVersion = 0;
  String? _lastSentPushToken;
  Timer? _refreshTimer;
  bool _disposed = false;

  final _stateController = StreamController<LicenseStateChange>.broadcast();

  // Lazily-constructed sub-API namespaces. All hang off the same
  // SignedHttpClient + regional endpoint that the lifecycle methods use;
  // they do NOT establish a parallel transport.
  NotificationsApi? _notifications;
  FeedbackApi? _feedback;
  SubscriptionApi? _subscription;
  PrivacyApi? _privacy;
  PreferencesApi? _preferences;
  SupportApi? _support;
  AssistantApi? _assistant;
  ReferralsApi? _referrals;
  StatusApi? _status;
  AccountApi? _account;
  OrganizationApi? _organization;
  OffersApi? _offers;
  DocsApi? _docs;
  SecurityApi? _security;

  LicenseClient._({
    required VanaheimConfig config,
    required SdkCapabilities capabilities,
    required String productSlug,
    required SignedHttpClient http,
    required JwksClient jwks,
    required SecureCache cache,
    required DeviceFingerprintGenerator fp,
    required GraceStateMachine grace,
    required ErrorTelemetry telemetry,
    required Uri regionEndpoint,
    required PushTokenProvider push,
    required Formatter formatter,
    required L2KeysClient l2Keys,
    required DevicesAPI devices,
  })  : _config = config,
        _capabilities = capabilities,
        _productSlug = productSlug,
        _http = http,
        _jwks = jwks,
        _cache = cache,
        _fp = fp,
        _grace = grace,
        _telemetry = telemetry,
        _push = push,
        _formatter = formatter,
        _l2Keys = l2Keys,
        _devices = devices,
        _regionEndpoint = regionEndpoint;

  // ----------------------------- Construction ----------------------------

  /// Connects the SDK: resolves the regional API endpoint from the control
  /// plane, restores any cached JWT, and starts the background refresh loop.
  ///
  /// Must be called once per app session. Assumes Firebase has been initialized
  /// and a user is signed in (unless [auth] is overridden for tests).
  ///
  /// v2 / Vanaheim: [config] is now REQUIRED — it carries the per-product
  /// `l2BaseUrl`, `projectId`, JWE decryptor, and device-keypair provider.
  /// On first boot (no `device_registered_v1` cache marker) the SDK also
  /// enrolls the device's X25519 pubkey with L2 before returning — so the
  /// caller can immediately `activate()` without an extra round-trip.
  static Future<LicenseClient> connect({
    required Uri controlPlaneUrl,
    required String productSlug,
    required String sdkSecret,
    required VanaheimConfig config,
    SdkCapabilities? capabilities,
    AuthTokenProvider? auth,
    AppCheckTokenProvider? appCheck,
    SecureCache? cache,
    DeviceFingerprintGenerator? fingerprint,
    PushTokenProvider? pushTokenProvider,
    Map<String, String> i18nCatalog = const {},
  }) async {
    final cfg = config;
    final caps = capabilities ?? SdkCapabilities.defaults;
    final push = pushTokenProvider ?? const NoPushTokenProvider();
    final signer =
        HmacSigner(productSlug: productSlug, sdkSecret: sdkSecret);
    final pinner = CertificatePinner(pinnedSpkiSha256: cfg.pinnedSpkiSha256);
    final storage = cache ?? FlutterSecureCache();
    // v2 / Vanaheim: pre-build the JWE machinery BEFORE SignedHttpClient so
    // every outbound call — including DevicesAPI._maybeEnrollDevice on a
    // JWE-required POST /v1/devices/enroll — routes through the JWE leg.
    // Wave 10c review: prior to this wave the transport was constructed
    // with none of the JWE wiring, so postJson silently fell back to
    // _postPlain on JWE-required routes. Closing that.
    final l2Keys = L2KeysClient(
      url: cfg.l2BaseUrl.replace(path: '/.well-known/lcs-keys'),
    );
    final http = SignedHttpClient(
      signer: signer,
      auth: auth ?? FirebaseAuthTokenProvider(),
      appCheck: appCheck ?? FirebaseAppCheckTokenProvider(),
      pinner: pinner,
      timeout: cfg.httpTimeout,
      routePolicy: const _CryptoRoutePolicyAdapter(),
      jweCodec: _CryptoJweCodecAdapter(
        senderIdProvider: () => devicePubThumbprint(cfg.deviceKeypairProvider),
      ),
      l2Keys: l2Keys,
      projectIdProvider: _ConfigProjectIdProvider(cfg.projectId.toString()),
      secureCache: storage,
      deviceKeypairProvider: cfg.deviceKeypairProvider,
    );
    final jwksUrl =
        controlPlaneUrl.replace(path: '/v1/.well-known/jwks.json');
    final jwks = JwksClient(
      jwksUrl: jwksUrl,
      http: http,
      defaultTtl: cfg.jwksCacheTtl,
    );
    final fp = fingerprint ?? DeviceFingerprintGenerator();
    final telemetry = ErrorTelemetry(cache: storage);
    // Restore prior-session error history before any I/O can fail and create
    // new events; otherwise a connect-time failure overwrites history.
    await telemetry.restore();

    // v2 / Vanaheim: pre-fetch L2 recipient key so the first JWE-required
    // outbound call has a target key (no extra round-trip from inside the
    // transport on the hot path). Errors are not fatal here — the transport
    // will lazy-fetch on first use if this fails (e.g. offline cold-start
    // from a warm-cache user with a still-valid JWT).
    try {
      await l2Keys.get();
    } catch (e, st) {
      telemetry.capture(
        source: 'connect.l2KeysClient.initialFetch',
        error: e,
        stack: st,
        severity: TelemetrySeverity.warn,
      );
      // Continue — transport will retry on demand.
    }

    // Region resolution: ask the control plane where this account lives,
    // and pin the result for the rest of the session. Cached across launches
    // so a logged-in user makes zero control-plane round-trips on warm start.
    Uri region;
    final cachedEndpoint = await storage.getRegionEndpoint();
    if (cachedEndpoint != null) {
      region = Uri.parse(cachedEndpoint);
    } else {
      try {
        region = await _resolveRegion(http, controlPlaneUrl, productSlug);
        await storage.putRegionEndpoint(region.toString());
      } catch (e, st) {
        telemetry.capture(
          source: 'connect.resolveRegion',
          error: e,
          stack: st,
          context: {'control_plane': controlPlaneUrl.toString()},
        );
        await telemetry.flush();
        rethrow;
      }
    }

    final devices = DevicesAPI(http: http, l2BaseUrl: cfg.l2BaseUrl);
    final client = LicenseClient._(
      config: cfg,
      capabilities: caps,
      productSlug: productSlug,
      http: http,
      jwks: jwks,
      cache: storage,
      fp: fp,
      grace: GraceStateMachine(
        refreshBefore: cfg.refreshBefore,
        clockSkew: cfg.clockSkew,
      ),
      telemetry: telemetry,
      regionEndpoint: region,
      push: push,
      formatter: Formatter(catalog: i18nCatalog),
      l2Keys: l2Keys,
      devices: devices,
    );

    // v2: first-boot device enrollment. The marker key
    // `device_registered_v1` lives in SecureCache; cleared by
    // [DeviceRevokedException] handling so a revoked device naturally
    // re-enrolls on next connect. We do this BEFORE rehydrate so the
    // cached JWT path can rely on a device being registered with L2.
    await client._maybeEnrollDevice();

    await client._rehydrate();
    // §2A.1 / §3A.3: subscribe to incoming push messages so we can re-verify
    // on `license.changed` / `license.config_changed` wake-triggers. Token
    // changes get auto-sent to the server during the next activate/verify
    // cycle (we never send the token out-of-band).
    if (push is! NoPushTokenProvider) {
      client._wirePush();
    }
    // §2B.1: start telemetry pipeline (restore offline queue + periodic flush)
    // only if the capability is enabled.
    if (caps.telemetry) {
      await client._startTelemetry();
    }
    return client;
  }

  /// Factory for FRON (Bifrost-Direct) mode.
  ///
  /// Returns a [DirectClient] that speaks directly to Bifrost via the
  /// `/direct/v1/*` surface — no L2 (Alfheim) backend on the path. Use
  /// this when `VanaheimConfig.mode == VanaheimMode.fron` and the
  /// customer has no L2 of their own.
  ///
  /// The existing [connect] factory keeps its L2 behaviour for backward
  /// compatibility; this factory is a sibling, not a wrapper, so callers
  /// pick the transport explicitly at connect time. Both clients expose
  /// the same `activate / verify / heartbeat / deactivate / hasFeature /
  /// quota / sendStats / reportError` shape so the host product code
  /// path is largely the same.
  ///
  /// Throws [StateError] if `config.mode != VanaheimMode.fron` OR
  /// `config.directConfig == null`.
  static Future<DirectClient> connectDirect({
    required VanaheimConfig config,
    SecureCache? cache,
    PushTokenProvider? pushTokenProvider,
  }) async {
    if (config.mode != VanaheimMode.fron) {
      throw StateError(
          'LicenseClient.connectDirect requires VanaheimConfig.mode == VanaheimMode.fron');
    }
    final direct = config.directConfig;
    if (direct == null) {
      throw StateError(
          'LicenseClient.connectDirect requires VanaheimConfig.directConfig');
    }
    return DirectClient.connect(
      config: direct,
      cache: cache,
      push: pushTokenProvider,
    );
  }

  /// v2 / Vanaheim first-boot device enrollment.
  ///
  /// Idempotent via the `device_registered_v1` SecureCache marker:
  ///   * If marker is set, skip — device is already enrolled with L2.
  ///   * Else, ask the configured `deviceKeypairProvider` for the X25519
  ///     pubkey, POST to L2 `/v1/devices/enroll`, persist the assigned
  ///     `device_id`, and write the marker.
  ///
  /// Enrollment failures bubble up — without an L2 device record the SDK
  /// can't run JWE-required calls, so failing fast is correct. The caller
  /// (`connect()`) wraps this so a transient enrollment failure surfaces
  /// to the host product with full diagnostics.
  Future<void> _maybeEnrollDevice() async {
    final marker = await _cache.getRaw('device_registered_v1');
    if (marker == 'true') return;
    final pubKey = await _config.deviceKeypairProvider.getPublicKey();
    if (pubKey.isEmpty) {
      throw StateError(
          'VanaheimConfig.deviceKeypairProvider returned an empty pubkey; '
          'v2 SDK requires a real X25519 keypair for L2 device enrollment.');
    }
    try {
      final enrollment = await _devices.register(devicePubKey: pubKey);
      await _cache.putRaw('device_id_v1', enrollment.deviceId);
      await _cache.putRaw('device_registered_v1', 'true');
    } on DeviceRevokedException {
      // Server claims this fingerprint is permanently revoked. Clear any
      // stale marker so a fresh keypair-rotation flow can re-enroll on the
      // next connect attempt (host product decides whether to rotate).
      await _cache.deleteRaw('device_registered_v1');
      await _cache.deleteRaw('device_id_v1');
      rethrow;
    } catch (e, st) {
      _telemetry.capture(
        source: 'connect.devices.register',
        error: e,
        stack: st,
      );
      rethrow;
    }
  }

  /// Idempotent: starts/replays telemetry restore + flush timer.
  Future<void> _startTelemetry() async {
    final api = TelemetryApi(
      http: _http,
      endpoint: () => _regionEndpoint,
      cache: _cache,
      capabilities: _capabilities,
      productSlug: _productSlug,
    );
    _telemetryApi = api;
    await api.restore();
    api.start();
  }

  /// §3A.3 push wake-trigger: incoming `license.changed` /
  /// `license.config_changed` messages should immediately trigger verify()
  /// so the SDK observes any cfg_v / ev / prefs_v bump within seconds.
  void _wirePush() {
    _pushTokenSub = _push.tokenChanges.listen((_) {
      // Token rotated. We re-send during the next activate/verify cycle —
      // a dedicated POST is not needed because every authenticated call can
      // carry the up-to-date token.
      _lastSentPushToken = null;
    });
    _pushMessageSub = _push.incomingMessages.listen((msg) {
      final kind = msg['kind'];
      if (kind == 'license.changed' ||
          kind == 'license.config_changed' ||
          kind == 'license.notification') {
        verify().catchError((e) {
          _emit(LicenseStateChangeKind.error, _claims, error: e);
        });
      }
    });
  }

  static Future<Uri> _resolveRegion(
      SignedHttpClient http, Uri controlPlane, String productSlug) async {
    // POST /v1/accounts returns { account_id, region, suggested_endpoint }.
    // Server is idempotent on (firebase_uid) so this acts as "ensure account
    // + tell me my region".
    final body = await http.postJson(
      controlPlane.replace(path: '/v1/accounts'),
      body: {'product_slug': productSlug},
    );
    final endpoint = body['suggested_endpoint'] as String?;
    if (endpoint == null) {
      throw NetworkException('Control plane returned no region endpoint');
    }
    return Uri.parse(endpoint);
  }

  Future<void> _rehydrate() async {
    _licenseId = await _cache.getLicenseId();
    _activationId = await _cache.getActivationId();
    final jwt = await _cache.getJwt();
    if (jwt != null) {
      try {
        final claims = await _verifyCachedJwt(jwt);
        _cachedJwt = jwt;
        _claims = claims;
        _knownEntitlementsVersion = claims.entitlementsVersion;
        _knownConfigVersion = claims.configVersion;
        _knownPreferencesVersion = claims.preferencesVersion;
        _maybeSeedPreferencesSnapshot(claims);
        _scheduleRefresh(claims.expiresAt);
      } on JwtVerificationException {
        // Cached JWT failed structure/signature checks — kid rotated/revoked,
        // tampered, alg mismatch, etc. Drop it; caller can activate/verify
        // again to get a fresh one.
        await _cache.clear();
        await _cache.putRegionEndpoint(_regionEndpoint.toString());
        _claims = null;
        _cachedJwt = null;
      } on LicenseExpiredException {
        // Cached JWT is past exp — verifier surfaces this as a distinct
        // category from signature failure (Blocker 4 fix). Same cleanup,
        // but no need to re-fetch the region pointer.
        await _cache.clear();
        await _cache.putRegionEndpoint(_regionEndpoint.toString());
        _claims = null;
        _cachedJwt = null;
      }
    }
  }

  // ----------------------------- Public surface --------------------------

  /// Binds this device to the license and returns the signed JWT. Idempotent
  /// on (license, device). If the tier is floating and the new activation
  /// bumped an older session, [ActivationResult.kickedDevice] is set so the
  /// product UI can show "signed out on Device X".
  Future<ActivationResult> activate({String? deviceName, String? os}) async {
    _check();
    final fp = await _fp.generate(productSlug: _productSlug);
    final licenseId = _licenseId ?? await _ensureLicense();

    // v2 / Vanaheim: the `device_pubkey` field that v1 sent in the activate
    // body is GONE. Device enrollment now happens up-front during connect()
    // via DevicesAPI.register — by the time we get here, L2 already knows
    // this device's recipient pubkey. The activate response can be
    // JWE-wrapped immediately; _verifyCachedJwt handles JWE detection.

    // §2A.1 / §3A.3: attach push token if the product wired up FCM/APNs.
    // Empty token = product hasn't requested permission yet — backend stays
    // pull-only for this device. We cache the last-sent token so we don't
    // re-emit unchanged tokens on every activate/verify cycle.
    String? pushToken;
    if (_push is! NoPushTokenProvider) {
      try {
        final t = await _push.getToken();
        if (t.isNotEmpty && t != _lastSentPushToken) {
          pushToken = t;
          _lastSentPushToken = t;
        }
      } catch (_) {
        // Push token acquisition failures are non-fatal — don't block activate.
      }
    }

    final res = await _http.postJson(
      _regionEndpoint.replace(path: '/v1/licenses/$licenseId/activate'),
      body: {
        'device_fingerprint': fp,
        if (deviceName != null) 'device_name': deviceName,
        if (os != null) 'os': os,
        if (pushToken != null) 'push_token': pushToken,
      },
    );
    final jwt = res['jwt'] as String;
    final claims = await _verifyCachedJwt(jwt);
    final kickedRaw = res['kicked_device'] as Map?;
    final kicked = kickedRaw != null
        ? KickedDevice.fromJson(kickedRaw.cast<String, dynamic>())
        : null;

    _activationId = res['activation_id'] as String?;
    _cachedJwt = jwt;
    _claims = claims;
    _knownEntitlementsVersion = claims.entitlementsVersion;
    _knownConfigVersion = claims.configVersion;
    _knownPreferencesVersion = claims.preferencesVersion;
    _maybeSeedPreferencesSnapshot(claims);

    await Future.wait([
      _cache.putJwt(jwt),
      if (_activationId != null) _cache.putActivationId(_activationId!),
      _cache.putLicenseId(licenseId),
    ]);
    _scheduleRefresh(claims.expiresAt);
    _emit(LicenseStateChangeKind.activated, claims);

    return ActivationResult(
      activationId: _activationId ?? '',
      expiresAt: claims.expiresAt,
      entitlements: _entitlementsFromClaims(claims),
      kickedDevice: kicked,
    );
  }

  /// Refreshes the JWT and re-verifies. Throws on failure; the SDK does NOT
  /// silently fall back to a stale JWT on auth errors (only on transient
  /// network errors, during the grace window).
  Future<void> verify() async {
    _check();
    final licenseId = _licenseId;
    if (licenseId == null) {
      throw NotConnectedException();
    }
    final fp = await _fp.generate(productSlug: _productSlug);
    // Snapshot the pre-network grace decision; we use this in the offline
    // catch branch to decide whether refresh failure is "transient (retry)"
    // or "license is dead (LicenseExpiredException)".
    final preGrace = _grace.evaluate(
      jwtExpiresAt: _claims?.expiresAt,
      now: DateTime.now().toUtc(),
    );
    try {
      final res = await _http.postJson(
        _regionEndpoint.replace(path: '/v1/licenses/verify'),
        body: {
          'license_id': licenseId,
          'device_fingerprint': fp,
        },
      );
      final jwt = res['jwt'] as String;
      final claims = await _verifyCachedJwt(jwt);
      _cachedJwt = jwt;
      _claims = claims;
      _expiredEmitted = false; // fresh JWT — clear the one-shot guard
      await _cache.putJwt(jwt);
      if (claims.entitlementsVersion > _knownEntitlementsVersion) {
        _knownEntitlementsVersion = claims.entitlementsVersion;
        _emit(LicenseStateChangeKind.entitlementsUpdated, claims);
      }
      if (claims.configVersion > _knownConfigVersion) {
        _knownConfigVersion = claims.configVersion;
        _emit(LicenseStateChangeKind.configUpdated, claims);
      }
      if (claims.preferencesVersion > _knownPreferencesVersion) {
        _knownPreferencesVersion = claims.preferencesVersion;
        _maybeSeedPreferencesSnapshot(claims);
        _emit(LicenseStateChangeKind.preferencesUpdated, claims);
      }
      _scheduleRefresh(claims.expiresAt);
    } on SessionRevokedException catch (e, st) {
      // Floating-tier bump from another device, or admin revoke.
      _telemetry.capture(source: 'verify', error: e, stack: st);
      await _cache.clear();
      _claims = null;
      _cachedJwt = null;
      _emit(LicenseStateChangeKind.sessionRevoked, null, error: e);
      rethrow;
    } on LicenseExpiredException catch (e, st) {
      // Direct throw from JwtVerifier on a JWT we just received (e.g. clock
      // skew larger than our tolerance). Treat as terminal for this attempt.
      _telemetry.capture(source: 'verify', error: e, stack: st);
      _emit(LicenseStateChangeKind.expired, _claims, error: e);
      rethrow;
    } on NetworkException catch (e, st) {
      // Blocker 4 fix (offline branch): if we can't reach the server AND our
      // cached JWT was already expired pre-request, the license is dead —
      // surface as LicenseExpiredException so the SDK contract holds. Pure
      // transient failures (cached JWT still in grace) just rethrow.
      if (preGrace.state == GraceState.expired) {
        _onExpiryObserved(_claims!); // safe: preGrace==expired implies _claims != null
        final err = LicenseExpiredException(
            'Cached JWT expired and refresh failed: ${e.message}');
        _telemetry.capture(source: 'verify.offline_expired', error: err, stack: st);
        throw err;
      }
      _telemetry.capture(
        source: 'verify',
        error: e,
        stack: st,
        severity: TelemetrySeverity.warn, // transient network — not necessarily a bug
      );
      rethrow;
    }
  }

  /// Hard-lock transfer: deactivate this binding so the user can activate on
  /// a new device. Honors the tier's cooldown — throws
  /// [TransferCooldownException] with `availableAt` if too soon.
  Future<void> transferToNewDevice() async {
    _check();
    final licenseId = _licenseId;
    final activationId = _activationId;
    if (licenseId == null || activationId == null) {
      throw NotConnectedException();
    }
    await _http.postJson(
      _regionEndpoint.replace(path: '/v1/licenses/$licenseId/transfer'),
      body: {'activation_id': activationId},
    );
    await _cache.clear();
    _claims = null;
    _cachedJwt = null;
    _activationId = null;
  }

  /// Frees this device's seat. Use for "sign out everywhere except here"
  /// flows or app uninstall hooks.
  Future<void> deactivate() async {
    _check();
    final licenseId = _licenseId;
    final activationId = _activationId;
    if (licenseId == null || activationId == null) return;
    await _http.postJson(
      _regionEndpoint.replace(path: '/v1/licenses/$licenseId/deactivate'),
      body: {'activation_id': activationId},
    );
    await _cache.clear();
    _claims = null;
    _cachedJwt = null;
    _activationId = null;
  }

  /// True if the cached JWT carries [key] as a truthy entitlement. Pure
  /// offline read. Returns false (fail-closed) if there is no cached JWT or
  /// the cached JWT is past `exp` per the grace state machine — never
  /// fail-open. Emits [LicenseStateChangeKind.expired] the first time
  /// expiry is observed so product UI can react.
  bool hasFeature(String key) {
    final c = _claims;
    if (c == null) return false;
    if (_isExpired(c)) {
      _onExpiryObserved(c);
      return false;
    }
    return _entitlementsFromClaims(c).has(key);
  }

  /// Returns the typed quota value or null. Pure offline read. Returns null
  /// (fail-closed) when no JWT is cached OR when the cached JWT is expired.
  T? quota<T>(String key) {
    final c = _claims;
    if (c == null) return null;
    if (_isExpired(c)) {
      _onExpiryObserved(c);
      return null;
    }
    return _entitlementsFromClaims(c).quota<T>(key);
  }

  // Blocker 3 helpers: consult the grace state machine to know if the cached
  // JWT should be treated as live. Pure functions; no I/O. The state-change
  // emit is one-shot per session so we don't spam listeners on every check.
  bool _expiredEmitted = false;
  bool _isExpired(LicenseJwtClaims c) {
    return _grace
            .evaluate(
              jwtExpiresAt: c.expiresAt,
              now: DateTime.now().toUtc(),
            )
            .state ==
        GraceState.expired;
  }

  void _onExpiryObserved(LicenseJwtClaims c) {
    if (_expiredEmitted) return;
    _expiredEmitted = true;
    _emit(LicenseStateChangeKind.expired, c,
        error: LicenseExpiredException('Cached JWT past exp'));
  }

  /// Current tier slug ("pro", "plus", …) or null if not activated.
  String? get tier => _claims?.tier;

  /// JWT expiry. The SDK refreshes ~1 day before this by default.
  DateTime? get expiresAt => _claims?.expiresAt;

  /// `entitlements_version` from the most recent JWT. Bumped server-side on
  /// every tier change; the SDK fires [LicenseStateChangeKind.entitlementsUpdated]
  /// when it observes a higher value after refresh.
  int get entitlementsVersion => _knownEntitlementsVersion;

  /// `cfg_v` from the most recent JWT. Bumped server-side whenever a runtime
  /// config override that affects this license is written or deleted.
  /// SDK fires [LicenseStateChangeKind.configUpdated] on bump.
  int get configVersion => _knownConfigVersion;

  /// `prefs_v` from the most recent JWT. Bumped on cross-product preferences
  /// change. SDK fires [LicenseStateChangeKind.preferencesUpdated] on bump.
  int get preferencesVersion => _knownPreferencesVersion;

  // -------------------- 2A.1 Runtime config sync read --------------------

  /// Reads a runtime-config value by key. Fail-closed:
  ///   * Returns [defaultValue] when no cached JWT, no `cfg` claim, missing
  ///     key, or wrong-typed value.
  ///   * Returns [defaultValue] when the cached JWT is expired (matching
  ///     `hasFeature` / `quota` semantics — never serve stale config that
  ///     a license may no longer be entitled to).
  T config<T>(String key, T defaultValue) {
    final c = _claims;
    if (c == null) return defaultValue;
    if (_isExpired(c)) {
      _onExpiryObserved(c);
      return defaultValue;
    }
    final v = c.config[key];
    if (v is T) return v;
    if (T == int && v is num) return v.toInt() as T;
    if (T == double && v is num) return v.toDouble() as T;
    return defaultValue;
  }

  // -------------------- 2A.2 Feature-flag convenience --------------------

  /// Returns true if the runtime-config flag `feature.<key>.enabled` is true.
  /// Default false — fail-closed: if the flag is missing, the feature is OFF.
  /// Use this gate at the top of every feature's product UI flow.
  bool featureEnabled(String key) => config<bool>('feature.$key.enabled', false);

  // -------------------- 2A.6 Roles + multi-context getters --------------

  /// Multi-valued roles from the JWT (`["customer", "partner", ...]`). Empty
  /// when backend hasn't started emitting the claim.
  List<String> get roles => _claims?.roles ?? const [];

  /// True if the JWT carries [role] (e.g. `'partner'`, `'admin'`).
  bool hasRole(String role) => roles.contains(role);

  /// Partner snapshot if this account has applied/been approved as a partner.
  /// Null when `'partner' ∉ roles`. The fields below the role gate (margin
  /// tier, commission rate) require an authenticated call — products use
  /// [PartnerProfile] surfaces returned from server endpoints for the dash;
  /// this getter is a lightweight role-gated marker.
  bool get isPartner => hasRole('partner');

  /// Organization context if the JWT carries `org_id`. Null for individual
  /// consumer accounts.
  OrganizationContext? get organization {
    final c = _claims;
    if (c == null) return null;
    final orgId = c.orgId;
    final orgRole = c.orgRole;
    if (orgId == null || orgRole == null) return null;
    return OrganizationContext(orgId: orgId, orgRole: orgRole);
  }

  // -------------------- 2A.12 Locale --------------------

  /// Resolved user locale from the JWT (e.g. `"en-US"`). Null when not set
  /// server-side — products should fall back to the platform's system locale.
  String? get locale => _claims?.locale;

  // -------------------- 2A.3 / 2A.4 / 2A.7 / 2A.9 / 2A.10 / 2A.11 --------------------
  // Sub-API namespaces. Lazily constructed on first access. Each shares the
  // same SignedHttpClient + regional endpoint as the lifecycle methods; the
  // endpoint closure captures `this` so future region migrations would be
  // picked up automatically.

  /// Notification inbox + preferences (§2A.3).
  NotificationsApi get notifications => _notifications ??=
      NotificationsApi(_http, () => _regionEndpoint, _capabilities);

  /// Feedback / NPS / CSAT submission (§2A.4).
  FeedbackApi get feedback =>
      _feedback ??= FeedbackApi(_http, () => _regionEndpoint, _capabilities);

  /// Self-serve subscription management (§2A.7).
  SubscriptionApi get subscription => _subscription ??=
      SubscriptionApi(_http, () => _regionEndpoint, _capabilities);

  /// Privacy + consent center (§2A.9).
  PrivacyApi get privacy =>
      _privacy ??= PrivacyApi(_http, () => _regionEndpoint, _capabilities);

  /// Cross-product preferences (§2A.10). The SDK seeds the in-memory snapshot
  /// from JWT-embedded prefs claims (when present) so `cachedValue` works
  /// offline; products call `.refresh()` to force a server round-trip.
  PreferencesApi get preferences => _preferences ??=
      PreferencesApi(_http, () => _regionEndpoint, _capabilities);

  /// Support / tickets / KB search (§2A.11).
  SupportApi get support =>
      _support ??= SupportApi(_http, () => _regionEndpoint, _capabilities);

  /// AI customer assistant (§2B.3). Gated by `capabilities.assistant`.
  AssistantApi get assistant => _assistant ??=
      AssistantApi(_http, () => _regionEndpoint, _capabilities);

  /// Referrals — give-a-month/get-a-month (§2B.4). Gated by
  /// `capabilities.referrals`.
  ReferralsApi get referrals => _referrals ??=
      ReferralsApi(_http, () => _regionEndpoint, _capabilities);

  /// System status + incident stream (§2B.5). Gated by `capabilities.status`.
  StatusApi get status =>
      _status ??= StatusApi(_http, () => _regionEndpoint, _capabilities);

  /// Account portability — transfer + merge (§2B.6).
  AccountApi get account =>
      _account ??= AccountApi(_http, () => _regionEndpoint, _capabilities);

  /// Organization / B2B SSO (§2B.7). Gated by `capabilities.organization`.
  OrganizationApi get organizationApi => _organization ??=
      OrganizationApi(_http, () => _regionEndpoint, _capabilities);

  /// Spot-offer redemption (§2B.8). Gated by `capabilities.offers`.
  OffersApi get offers =>
      _offers ??= OffersApi(_http, () => _regionEndpoint, _capabilities);

  /// Docs / KB search (§2B.2). Gated by `capabilities.docs`.
  DocsApi get docs =>
      _docs ??= DocsApi(_http, () => _regionEndpoint, _capabilities);

  /// MFA + session management (§2A.8). Gated by `capabilities.mfa`.
  /// Surfaces TOTP enrollment + verify, recovery code rotation + verify,
  /// session listing + revoke (single + all), and step-up grant minting
  /// for sensitive operations.
  SecurityApi get security =>
      _security ??= SecurityApi(_http, () => _regionEndpoint, _capabilities);

  /// v0.1.19 / B-9.19 — publishes a per-project boolean capability
  /// presence signal to the License Store.
  ///
  /// Presence signals ("does this app build ship offline export?", "does
  /// this build ship the AI assistant?") are POSTed to
  /// `/v1/apps/capabilities` via the existing PAK-JWE transport. Bifrost
  /// stores the flag on `catalog/products/items/{pid}.capabilities.{key}`;
  /// the MS side later reads them via the bearer-authed admin catalog
  /// surface. No PII crosses the trust boundary — the SDK sends only
  /// `{ key, value }`.
  ///
  /// [key] MUST match `^has_[a-z0-9_]{2,64}$`. Values are BOOLEAN ONLY in
  /// v0.1.19 (scalar expansion deferred).
  ///
  /// Idempotent by `(project_id, key)` — replay with the same value is a
  /// 200 no-op server-side. Retries on 429 with capped exponential backoff
  /// (100→200→400ms, max 3 attempts). Other 4xx / 5xx surface immediately
  /// as [NetworkException].
  ///
  /// Throws:
  ///   * [CapabilityKeyInvalidException] if [key] fails the client-side
  ///     regex — thrown BEFORE any HTTP call.
  ///   * [NetworkException] on non-recoverable HTTP failure.
  ///   * Any standard transport exception ([AuthException],
  ///     [DeviceRevokedException], etc.) from the underlying JWE envelope.
  ///
  /// Not gated by [SdkCapabilities] — capability reporting is a platform
  /// primitive, not a product-facing sub-API.
  Future<void> reportCapability(String key, bool value) async {
    // Client-side validation FIRST — fail fast, no wire round-trip on a
    // typo. Server also enforces (fail-closed) so a stale SDK that skipped
    // this check would still surface a typed NetworkException.
    apps_capabilities.CapabilityReportValidation.requireValidKey(key);

    final url = _regionEndpoint.replace(
        path: apps_capabilities.ReportCapabilityWire.routePath);
    final body = <String, dynamic>{
      apps_capabilities.ReportCapabilityWire.bodyKeyKey: key,
      apps_capabilities.ReportCapabilityWire.bodyKeyValue: value,
    };

    // Retry-on-429 ONLY — other 4xx are terminal validation failures
    // and 5xx propagate immediately so the caller sees fast failure signals.
    // Ladder: 100ms → 200ms → 400ms (mirrors Swift ReportCapabilityWire).
    final delay = _reportCapabilityDelay;
    var attempt = 0;
    var backoffMs = apps_capabilities.ReportCapabilityWire.backoffMsInitial;
    while (true) {
      try {
        await _http.postJson(url, body: body);
        return;
      } on NetworkException catch (e) {
        attempt++;
        if (e.statusCode != 429 ||
            attempt >= apps_capabilities.ReportCapabilityWire.maxAttempts) {
          rethrow;
        }
        await delay(Duration(milliseconds: backoffMs));
        backoffMs *= 2;
      }
    }
  }

  /// Test hook — overridable delay callback for [reportCapability]'s 429
  /// backoff. Production wiring uses `Future.delayed`; tests inject a
  /// zero-delay stub via the visible-for-testing setter.
  Future<void> Function(Duration) _reportCapabilityDelay =
      Future<void>.delayed;

  /// Visible for tests only. Overrides the delay callback used by
  /// [reportCapability] between 429 retries so tests can sidestep real-time
  /// waits. Not exported from the public barrel.
  ///
  /// Callers outside `test/apps_capability_test.dart` should not touch this.
  // ignore: use_setters_to_change_properties
  void debugSetReportCapabilityDelay(
      Future<void> Function(Duration) delay) {
    _reportCapabilityDelay = delay;
  }

  /// v2 / Vanaheim: device enrollment + heartbeat + revoke.
  /// First-boot enrollment happens automatically during `connect()` via the
  /// `device_registered_v1` SecureCache marker; this getter is for products
  /// that want to trigger heartbeats on app foreground / revoke on logout.
  DevicesAPI get devices => _devices;

  /// v2 / Vanaheim: read-only access to the L2 recipient-key client. Most
  /// products will never call this — the transport consults it on every
  /// JWE-required outbound call. Exposed for tests + diagnostics.
  L2KeysClient get l2Keys => _l2Keys;

  // -------------------- 2B.1 Telemetry + 2A.12 i18n format --------------------

  /// Records an analytics event. Buffered + batched + retried. No-ops when
  /// `capabilities.telemetry` is disabled. Returns immediately — never
  /// blocks the caller on network latency.
  Future<void> track(String eventName, [Map<String, dynamic>? props]) async {
    if (!_capabilities.telemetry) return;
    final api = _telemetryApi;
    if (api == null) return;
    await api.track(eventName, props);
  }

  /// Records a metering counter (usage-quota, billing-relevant counts).
  /// No-ops when `capabilities.telemetry` is disabled.
  Future<void> recordMetering({
    required String key,
    int count = 1,
    Map<String, dynamic>? metadata,
  }) async {
    if (!_capabilities.telemetry) return;
    final api = _telemetryApi;
    if (api == null) return;
    await api.recordMetering(key: key, count: count, metadata: metadata);
  }

  /// Associates user traits (tier, plan, signup_date, etc.). Email + phone
  /// are auto-stripped at the SDK layer (defense-in-depth PII protection).
  Future<void> identify(Map<String, dynamic> traits) async {
    if (!_capabilities.telemetry) return;
    final api = _telemetryApi;
    if (api == null) return;
    await api.identify(traits);
  }

  /// Forces an immediate telemetry flush. Use when an important event
  /// MUST land before app exit. May throw on network failure.
  Future<void> flushTelemetry() async {
    final api = _telemetryApi;
    if (api == null) return;
    await api.flush();
  }

  /// Formats an i18n message by key. Catalog is injected at `connect()` via
  /// the `i18nCatalog` parameter; products can replace at runtime via
  /// [withI18nCatalog]. See [Formatter] for the supported syntax (simple
  /// variable substitution + ICU plurals).
  String format(String key, [Map<String, Object?> vars = const {}]) =>
      _formatter.format(key, vars);

  /// Stream of significant state changes for the product UI to react to.
  Stream<LicenseStateChange> get stateChanges => _stateController.stream;

  /// Currently-loaded capability config (read-only). Products inspect this
  /// to know which sub-APIs are safe to call without a try/catch.
  SdkCapabilities get capabilities => _capabilities;

  /// Diagnostics: bounded ring buffer of recent error events captured during
  /// connect / activate / verify / transfer. Persists across app restarts
  /// via secure storage. Use for support-ticket bundles ("attach diagnostics")
  /// or for surfacing recent failures in a settings/debug screen.
  ///
  /// Returns a JSON-serializable map; the SDK never auto-uploads this. If
  /// the product wants to send it to its own backend, that's the product's
  /// call.
  Map<String, dynamic> diagnostics({int? limit}) =>
      _telemetry.exportForDiagnostics(limit: limit);

  /// Clear the diagnostic history (and the persisted blob).
  Future<void> clearDiagnostics() => _telemetry.clear();

  /// Releases timers and the underlying HTTP client. Call from your
  /// app's dispose path. Flushes telemetry to storage so events captured
  /// since the last debounce tick aren't lost.
  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    _refreshTimer?.cancel();
    await _pushTokenSub?.cancel();
    await _pushMessageSub?.cancel();
    await _telemetryApi?.dispose();
    await _status?.dispose();
    await _telemetry.flush();
    _http.close();
    await _stateController.close();
  }

  // ----------------------------- Internals -------------------------------

  void _check() {
    if (_disposed) throw StateError('LicenseClient has been disposed');
  }

  Future<String> _ensureLicense() async {
    // The flutter app gets a trial issued at signup. If the SDK is connecting
    // for the first time after a fresh install, we ask the data plane to
    // either confirm the existing license or issue a trial.
    final res = await _http.postJson(
      _regionEndpoint.replace(path: '/v1/licenses'),
      body: {'product_slug': _productSlug, 'intent': 'trial_if_none'},
    );
    final id = res['id'] as String?;
    if (id == null) {
      throw NetworkException('Server returned no license id');
    }
    _licenseId = id;
    await _cache.putLicenseId(id);
    return id;
  }

  Future<LicenseJwtClaims> _verifyCachedJwt(String token) async {
    // §2A.5 JWE detection: if the token is a 5-segment JWE, hand it to the
    // configured decryptor first; the inner JWS is verified normally below.
    // Backend can roll out JWE per-product without an SDK update — the SDK
    // contract is that JWS-only deployments keep working with zero config.
    String jwt = token;
    if (detectTokenFormat(token) == LicenseTokenFormat.jwe) {
      final decryptor = _config.jweDecryptor;
      // Defense-in-depth: VanaheimConfig.jweDecryptor is required-non-null
      // in v2, but the SDK contract is "fail fast on a configuration error"
      // — keep this guard so a future refactor that flips the field back to
      // nullable (or a `null!` assertion bypass) still surfaces as a typed
      // exception rather than a NoSuchMethodError mid-decrypt.
      // ignore: unnecessary_null_comparison
      if (decryptor == null) {
        throw JweDecryptionRequiredException();
      }
      jwt = await decryptor.decrypt(token);
    }
    final parts = jwt.split('.');
    if (parts.length != 3) throw JwtVerificationException('malformed JWT');
    // Peek kid from header without trusting signature yet.
    final headerKid = _peekKid(parts[0]);
    Uint8List? pub = await _jwks.getKey(headerKid);
    if (pub == null) {
      // Maybe a fresh rotation; force refresh once.
      await _jwks.refresh();
      pub = await _jwks.getKey(headerKid);
    }
    if (pub == null) {
      throw JwtVerificationException('Unknown kid: $headerKid');
    }
    return JwtVerifier.verifyAndDecode(
      jwt: jwt,
      publicKey: pub,
      expectedIssuer: _issuer,
      expectedAudience: _peekAud(parts[1]),
      clockSkew: _config.clockSkew,
    );
  }

  // Trust-on-first-read header / aud peek — we extract the kid so we can look
  // up the right public key, AND the audience so we can pass the expected
  // value to JwtVerifier. The actual verification still runs on the canonical
  // bytes, so manipulating either field can't help an attacker.
  String _peekKid(String headerB64) =>
      _requireString(_decodeSegment(headerB64), 'kid', 'header');

  String _peekAud(String claimsB64) =>
      _requireString(_decodeSegment(claimsB64), 'aud', 'claims');

  Map<String, dynamic> _decodeSegment(String segB64) {
    final pad = (4 - segB64.length % 4) % 4;
    final bytes = base64Url.decode(segB64.padRight(segB64.length + pad, '='));
    return jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
  }

  String _requireString(Map<String, dynamic> m, String key, String where) {
    final v = m[key];
    if (v is! String || v.isEmpty) {
      throw JwtVerificationException('JWT $where missing $key');
    }
    return v;
  }

  void _scheduleRefresh(DateTime expiresAt) {
    _refreshTimer?.cancel();
    final now = DateTime.now().toUtc();
    final when = expiresAt.subtract(_config.refreshBefore);
    final delay = when.isAfter(now) ? when.difference(now) : Duration.zero;
    _refreshTimer = Timer(delay, () async {
      if (_disposed) return;
      try {
        await verify();
      } catch (e) {
        _emit(LicenseStateChangeKind.error, _claims, error: e);
        // Re-schedule a retry attempt in 10 minutes; we don't want to spin.
        if (!_disposed) {
          // Use an async callback so the retry's verify() error path actually
          // surfaces via stateChanges rather than disappearing into a
          // dangling Future (audit finding).
          _refreshTimer = Timer(const Duration(minutes: 10), () async {
            if (_disposed) return;
            try {
              await verify();
            } catch (e2) {
              _emit(LicenseStateChangeKind.error, _claims, error: e2);
            }
          });
        }
      }
    });
  }

  void _emit(LicenseStateChangeKind kind, LicenseJwtClaims? claims,
      {KickedDevice? kicked, Object? error}) {
    _stateController.add(LicenseStateChange(
      kind: kind,
      entitlements: claims == null ? null : _entitlementsFromClaims(claims),
      kickedDevice: kicked,
      error: error,
    ));
  }

  Entitlements _entitlementsFromClaims(LicenseJwtClaims c) => Entitlements(
        tier: c.tier,
        version: c.entitlementsVersion,
        values: c.entitlements,
      );

  /// Seeds `PreferencesApi`'s in-memory snapshot from a JWT-embedded prefs
  /// payload (`ent['_prefs']` by convention — backend may or may not emit it).
  /// This keeps `client.preferences.cachedValue(key)` working offline without
  /// a separate `/get` call. Wins over previous snapshot only when the JWT
  /// actually carries a `_prefs` map.
  void _maybeSeedPreferencesSnapshot(LicenseJwtClaims c) {
    if (_preferences == null) return;
    final raw = c.entitlements['_prefs'];
    if (raw is Map) {
      _preferences!.primeSnapshot(raw.cast<String, dynamic>());
    }
  }
}

// ---------------------------------------------------------------------------
// Wave 10c connect-time JWE wiring adapters.
//
// The transport defines abstract `RoutePolicy` + `JweTransportCodec` +
// `ProjectIdProvider` interfaces; the concrete implementations live in
// `crypto/route_policy.dart` (top-level `classify()` function) and
// `crypto/jwe_codec.dart` (static-method `JweCodec` class with a
// `JweAadContext`-shaped signature). The adapters below bridge the two
// without leaking either side's idioms.
// ---------------------------------------------------------------------------

/// Adapter: maps the transport's `RoutePolicy` interface onto the top-level
/// `classify()` function in `crypto/route_policy.dart`. The crypto module's
/// `RouteConfidentiality` enum and the transport's `RouteConfidentiality`
/// enum are intentionally separate (one for the codec layer, one for the
/// transport layer); the adapter does the trivial value translation so the
/// two layers stay decoupled.
class _CryptoRoutePolicyAdapter implements RoutePolicy {
  const _CryptoRoutePolicyAdapter();

  @override
  RouteConfidentiality classify(String path) {
    final r = crypto_route.classify(path);
    switch (r) {
      case crypto_route.RouteConfidentiality.jweRequired:
        return RouteConfidentiality.jweRequired;
      case crypto_route.RouteConfidentiality.jwsAllowed:
        return RouteConfidentiality.jwsAllowed;
    }
  }
}

/// Adapter: bridges the static-method `crypto/jwe_codec.dart#JweCodec` onto
/// the transport's instance-based `JweTransportCodec` interface. The crypto
/// codec's encrypt path needs a `JweAadContext` with `senderId` + `recipientId`
/// derived from key-thumbprint metadata; we synthesize them from the
/// transport-supplied aad map (`project_id`, `route_path`, `request_id`) +
/// recipient kid. The `senderIdProvider` closure lets us defer extracting the
/// device-pubkey thumbprint until the first JWE-required call.
class _CryptoJweCodecAdapter implements JweTransportCodec {
  final Future<String> Function() _senderIdProvider;

  _CryptoJweCodecAdapter({
    required Future<String> Function() senderIdProvider,
  }) : _senderIdProvider = senderIdProvider;

  @override
  Future<String> encryptForRecipient({
    required Uint8List recipientPub,
    required String recipientKid,
    required Uint8List innerJwsBytes,
    required Map<String, String> aad,
  }) async {
    final senderId = await _senderIdProvider();
    final projectIdStr = aad['project_id'] ?? '';
    final projectId = int.tryParse(projectIdStr) ?? 0;
    final ctx = crypto_jwe.JweAadContext(
      senderId: senderId,
      recipientId: recipientKid,
      projectId: projectId,
      routePath: aad['route_path'] ?? '',
      requestId: aad['request_id'] ?? '',
    );
    final pub = SimplePublicKey(recipientPub, type: KeyPairType.x25519);
    return crypto_jwe.JweCodec.encryptForRecipient(
      innerJwsBytes: innerJwsBytes,
      recipientPub: pub,
      recipientKid: recipientKid,
      aad: ctx,
    );
  }

  @override
  Future<Uint8List> decryptForDevice({
    required String compactJwe,
    required Map<String, String> expectedAad,
  }) async {
    // Production decryption goes through `CryptographyJweDecryptor` which
    // already plumbs the device private bytes. The transport calls this
    // method only for inner-JWS responses; we cannot decrypt without the
    // device priv-key and the codec-level adapter intentionally does not
    // hold it (kept inside [CryptographyDeviceKeypairProvider]). This path
    // is exercised only in tests that inject a fake codec — production
    // calls go through `_verifyCachedJwt -> config.jweDecryptor` instead.
    throw UnimplementedError(
        'JWE response decryption is owned by VanaheimConfig.jweDecryptor; '
        'the transport adapter does not hold the device private key. '
        'Wave 10d (TODO-V2-D-09) will move response decrypt into the '
        'transport via the InnerJwsVerifier path.');
  }
}

/// Adapter: surfaces `VanaheimConfig.projectId` as the transport's
/// `ProjectIdProvider`. Held as a const-friendly class so wiring is cheap.
class _ConfigProjectIdProvider implements ProjectIdProvider {
  @override
  final String projectId;
  const _ConfigProjectIdProvider(this.projectId);
}

// `_devicePubThumbprint` moved to `crypto/thumbprint.dart` as
// `devicePubThumbprint` + `pubKeyThumbprint` so cross-SDK lock-in tests can
// drive the helper directly with raw byte vectors (see
// `test/thumbprint_test.dart` and the Swift twin
// `Tests/LicenseStoreSDKTests/ThumbprintTests.swift`).
