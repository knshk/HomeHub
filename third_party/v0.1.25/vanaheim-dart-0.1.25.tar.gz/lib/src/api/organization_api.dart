// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// §2B.7 Organization / B2B SSO surface. Lists members, sends invites,
/// generates SAML/OIDC redirect URLs. Backend may stub until §3B.11 lands.
class OrganizationApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;
  OrganizationApi(this._http, this._endpoint, this._capabilities);

  /// Lists members of the current org. Caller must be an org admin or owner;
  /// otherwise server returns 403 mapped to [AuthException].
  Future<List<OrgMember>> members() async {
    _capabilities.require('organization');
    final url = _endpoint().replace(path: '/v1/organization/members');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    final raw = body['members'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map<String, dynamic>>()
        .map(OrgMember.fromJson)
        .toList();
  }

  /// Sends an invite to [email] with [role]. Returns the created invite.
  Future<OrgInvite> invite({
    required String email,
    String role = 'member',
  }) async {
    _capabilities.require('organization');
    final url = _endpoint().replace(path: '/v1/organization/invites');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'email': email,
      'role': role,
    });
    return OrgInvite.fromJson(body);
  }

  /// Lists outstanding invites for the org.
  Future<List<OrgInvite>> listInvites() async {
    _capabilities.require('organization');
    final url = _endpoint().replace(path: '/v1/organization/invites/list');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    final raw = body['invites'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map<String, dynamic>>()
        .map(OrgInvite.fromJson)
        .toList();
  }

  /// Revokes a pending invite.
  Future<void> revokeInvite(String inviteId) async {
    _capabilities.require('organization');
    final url = _endpoint().replace(
        path: '/v1/organization/invites/$inviteId/revoke');
    await _http.postJson(url, body: const <String, dynamic>{});
  }

  /// Generates a SAML SP-initiated AuthnRequest redirect URL for the org's
  /// IdP. Products redirect the user to this URL to start SSO; the IdP
  /// posts back to the org's ACS endpoint server-side. Short-lived.
  Future<Uri> ssoStartUrl({required String orgSlug, Uri? returnUrl}) async {
    _capabilities.require('organization');
    final url = _endpoint().replace(path: '/v1/organization/sso/start');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'org_slug': orgSlug,
      if (returnUrl != null) 'return_url': returnUrl.toString(),
    });
    final raw = body['url'];
    if (raw is! String || raw.isEmpty) {
      throw const FormatException('sso/start returned no URL');
    }
    final parsed = Uri.tryParse(raw);
    if (parsed == null) {
      throw const FormatException('sso/start returned invalid URL');
    }
    return parsed;
  }
}
