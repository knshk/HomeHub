// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:async';

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// §2B.5 Status page consumer surface. Reads the public system status +
/// subscribes to live updates. Backend may stub initially or proxy a
/// hosted Statuspage.io feed (Project_Plan.md §3B.2); SDK contract is
/// stable from day-1.
class StatusApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;

  Timer? _pollTimer;
  StreamController<SystemStatus>? _streamController;

  StatusApi(this._http, this._endpoint, this._capabilities);

  /// Fetches the current system status snapshot. Authenticated so server can
  /// surface customer-specific outages (e.g. "your region is degraded").
  Future<SystemStatus> current() async {
    _capabilities.require('status');
    final url = _endpoint().replace(path: '/v1/status/current');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    return SystemStatus.fromJson(body);
  }

  /// Returns a stream that polls status every [pollInterval] (default 60 s)
  /// and emits whenever the snapshot changes. Stops on the first subscriber
  /// cancellation; call again to restart.
  ///
  /// Backend may upgrade this to SSE later — products keep the same stream
  /// API and pay no migration cost.
  Stream<SystemStatus> subscribe(
      {Duration pollInterval = const Duration(seconds: 60)}) {
    _capabilities.require('status');
    _streamController?.close();
    final controller = StreamController<SystemStatus>.broadcast(
      onCancel: () {
        _pollTimer?.cancel();
        _pollTimer = null;
      },
    );
    _streamController = controller;

    SystemStatus? lastEmit;
    Future<void> tick() async {
      try {
        final s = await current();
        if (lastEmit == null ||
            s.overall != lastEmit!.overall ||
            s.updatedAt != lastEmit!.updatedAt) {
          lastEmit = s;
          if (!controller.isClosed) controller.add(s);
        }
      } catch (_) {
        // Transient failure — drop, retry on next tick. Subscribers don't
        // want to handle network errors per tick; just stale data.
      }
    }

    // Prime immediately so subscribers don't wait pollInterval for the first value.
    Future<void>.delayed(Duration.zero, tick);
    _pollTimer = Timer.periodic(pollInterval, (_) => tick());
    return controller.stream;
  }

  /// Stops the polling timer. Called by [LicenseClient.dispose].
  Future<void> dispose() async {
    _pollTimer?.cancel();
    _pollTimer = null;
    await _streamController?.close();
    _streamController = null;
  }
}
