// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// Notification inbox + preferences. Construct via [LicenseClient.notifications].
///
/// All calls use the existing HMAC + Firebase + App Check signed POST scheme.
/// The backend may stub these endpoints initially (Project_Plan.md §3A.3) —
/// the SDK contract is stable from day-1.
class NotificationsApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;

  NotificationsApi(this._http, this._endpoint, this._capabilities);

  /// Returns one page of inbox messages, newest first. [cursor] is the opaque
  /// pagination token returned by a prior call; pass null for the first page.
  Future<NotificationInboxPage> inbox({
    int? limit,
    String? cursor,
  }) async {
    _capabilities.require('notifications');
    limit ??= _capabilities.notificationInboxPageSize;
    final url = _endpoint().replace(path: '/v1/notifications/inbox');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'limit': limit,
      if (cursor != null && cursor.isNotEmpty) 'cursor': cursor,
    });
    return NotificationInboxPage.fromJson(body);
  }

  /// Marks one message read. Idempotent.
  Future<void> markRead(String id) async {
    _capabilities.require('notifications');
    final url = _endpoint().replace(path: '/v1/notifications/$id/mark-read');
    await _http.postJson(url, body: const <String, dynamic>{});
  }

  /// Fetches the user's current per-channel × per-template preferences.
  Future<NotificationPreferences> getPreferences() async {
    _capabilities.require('notifications');
    final url = _endpoint().replace(path: '/v1/notifications/preferences/get');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    return NotificationPreferences.fromJson(body);
  }

  /// Updates preferences. Server merges with stored state — partial updates
  /// preserve unmentioned channels/templates.
  Future<NotificationPreferences> updatePreferences(
      NotificationPreferences prefs) async {
    _capabilities.require('notifications');
    final url =
        _endpoint().replace(path: '/v1/notifications/preferences/update');
    final body = await _http.postJson(url, body: prefs.toJson());
    return NotificationPreferences.fromJson(body);
  }
}
