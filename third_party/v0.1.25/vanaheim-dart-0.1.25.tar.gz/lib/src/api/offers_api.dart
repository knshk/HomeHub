// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// §2B.8 Offer code redemption. Spot offers are token-bound per user
/// (admin creates an offer restricted to N users → server generates a
/// per-user redemption token). SDK calls in here when the user clicks the
/// redemption link or pastes a code.
class OffersApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;
  OffersApi(this._http, this._endpoint, this._capabilities);

  /// Redeems an offer by [token] (the opaque string from the per-user link)
  /// OR by [code] (raw promo code). At least one must be non-null. Server
  /// validates eligibility + applies the discount via Stripe coupon or
  /// Paddle promo and returns the redemption record.
  Future<OfferRedemption> redeem({String? token, String? code}) async {
    _capabilities.require('offers');
    if ((token == null || token.isEmpty) && (code == null || code.isEmpty)) {
      throw ArgumentError('Either token or code must be provided');
    }
    final url = _endpoint().replace(path: '/v1/offers/redeem');
    final body = await _http.postJson(url, body: <String, dynamic>{
      if (token != null && token.isNotEmpty) 'token': token,
      if (code != null && code.isNotEmpty) 'code': code,
    });
    return OfferRedemption.fromJson(body);
  }

  /// Reads the redemption history for the current account.
  Future<List<OfferRedemption>> history() async {
    _capabilities.require('offers');
    final url = _endpoint().replace(path: '/v1/offers/history');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    final raw = body['redemptions'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map<String, dynamic>>()
        .map(OfferRedemption.fromJson)
        .toList();
  }
}
