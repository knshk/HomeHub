// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:async';

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// §2B.3 AI customer assistant. Grounded on the user's license, tier,
/// billing, support, and feedback context — fields the SDK doesn't fill in
/// because they live server-side. Backend may stub this initially (per
/// Project_Plan.md §3B.6); the SDK contract is stable from day-1.
class AssistantApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;

  AssistantApi(this._http, this._endpoint, this._capabilities);

  /// Sends a prompt to the assistant. Day-1 contract returns the full
  /// response as a single message; streaming is a future extension. The
  /// optional [conversationId] threads multi-turn context.
  Future<AssistantMessage> ask({
    required String prompt,
    String? conversationId,
  }) async {
    _capabilities.require('assistant');
    final url = _endpoint().replace(path: '/v1/assistant/ask');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'prompt': prompt,
      if (conversationId != null) 'conversation_id': conversationId,
    });
    final raw = body['message'];
    if (raw is! Map<String, dynamic>) {
      throw const FormatException('assistant/ask returned no message');
    }
    return AssistantMessage.fromJson(raw);
  }

  /// Lists this user's recent conversations.
  Future<List<AssistantConversation>> conversations({int limit = 20}) async {
    _capabilities.require('assistant');
    final url = _endpoint().replace(path: '/v1/assistant/conversations');
    final body = await _http
        .postJson(url, body: <String, dynamic>{'limit': limit});
    final raw = body['conversations'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map<String, dynamic>>()
        .map(AssistantConversation.fromJson)
        .toList();
  }

  /// Fetches one conversation with full message history.
  Future<AssistantConversationDetail> conversation(String id) async {
    _capabilities.require('assistant');
    final url = _endpoint().replace(path: '/v1/assistant/conversations/$id');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    final convoRaw = body['conversation'];
    if (convoRaw is! Map<String, dynamic>) {
      throw const FormatException('assistant/conversations returned no conversation');
    }
    final msgsRaw = body['messages'];
    final msgs = msgsRaw is List
        ? msgsRaw
            .whereType<Map<String, dynamic>>()
            .map(AssistantMessage.fromJson)
            .toList()
        : <AssistantMessage>[];
    return AssistantConversationDetail(
      conversation: AssistantConversation.fromJson(convoRaw),
      messages: msgs,
    );
  }
}
