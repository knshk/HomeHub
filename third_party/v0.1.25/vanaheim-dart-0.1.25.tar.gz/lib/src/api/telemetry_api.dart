// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import '../capabilities.dart';
import '../storage/secure_cache.dart';
import '../transport/http_client.dart';

/// §2B.1 Telemetry / metering / analytics. The SDK buffers events locally,
/// batches them, and posts them to the backend on a fixed interval. Survives
/// app restarts via [SecureCache]. Backend may stub the ingestion endpoint
/// initially — the SDK contract is stable from day-1 so adding the real
/// aggregation pipeline later does NOT require a future SDK release.
///
/// Three call surfaces:
///
///   * `client.track(event, props)` — analytics events (feature_used, etc.)
///   * `client.metering.record(key, count, metadata)` — usage counters
///   * `client.identify(traits)` — user-trait association (call from product
///      when sign-in completes; usually one-shot per session)
///
/// PII stripping: the SDK never accepts a raw email / phone / payment number
/// in [props] or [metadata] — values matching the canonical regex patterns
/// are dropped at the SDK layer (defense-in-depth even if the product
/// accidentally passes them).
class TelemetryApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SecureCache _cache;
  final SdkCapabilities _capabilities;
  final String _productSlug;

  static const String _cacheKey = 'telemetry_buffer_v1';
  static const String _meteringCacheKey = 'metering_buffer_v1';

  // Bounded queues for analytics events + metering counters. Events get
  // dropped from the head when the queue exceeds [SdkCapabilities.telemetryMaxBuffer].
  final List<_TelemetryEvent> _events = [];
  final List<_MeteringRecord> _metering = [];

  Timer? _flushTimer;
  bool _disposed = false;

  // Sampling controls per event type. Default 1.0 (100% sampled). Products
  // can lower the rate for high-volume events. Range [0.0, 1.0].
  final Map<String, double> _samplingRates = {};

  TelemetryApi({
    required SignedHttpClient http,
    required Uri Function() endpoint,
    required SecureCache cache,
    required SdkCapabilities capabilities,
    required String productSlug,
  })  : _http = http,
        _endpoint = endpoint,
        _cache = cache,
        _capabilities = capabilities,
        _productSlug = productSlug;

  // ---------- public API ----------

  /// Records an analytics event. Buffered + batched. Returns immediately —
  /// no network latency for the caller. Auto-attaches product context.
  Future<void> track(String eventName, [Map<String, dynamic>? props]) async {
    _capabilities.require('telemetry');
    if (_disposed) return;

    // Sampling — drop the event if it's filtered out at this rate.
    final rate = _samplingRates[eventName] ?? 1.0;
    if (rate < 1.0 && _rng.nextDouble() > rate) return;

    final clean = _stripPii(props ?? const {});
    _events.add(_TelemetryEvent(
      name: eventName,
      props: clean,
      occurredAt: DateTime.now().toUtc(),
    ));
    _trimEvents();
  }

  /// Associates traits with the current user. Idempotent — call as often as
  /// needed. Common traits: tier, plan, signup_date. Email / name are
  /// stripped at the SDK layer.
  Future<void> identify(Map<String, dynamic> traits) async {
    _capabilities.require('telemetry');
    if (_disposed) return;
    final clean = _stripPii(traits);
    await track('__identify', clean);
  }

  /// Records a metering counter. Use for usage-quotas, billing-relevant
  /// counts, or product-analytics roll-ups.
  Future<void> recordMetering({
    required String key,
    int count = 1,
    Map<String, dynamic>? metadata,
  }) async {
    _capabilities.require('telemetry');
    if (_disposed) return;
    if (count <= 0) return;
    final clean = _stripPii(metadata ?? const {});
    _metering.add(_MeteringRecord(
      key: key,
      count: count,
      metadata: clean,
      occurredAt: DateTime.now().toUtc(),
    ));
    _trimMetering();
  }

  /// Adjusts sampling rate for [eventName]. Useful for high-frequency events
  /// (e.g. `screen_viewed`) that don't need 100% capture. Rate is in
  /// `[0.0, 1.0]`; values outside the range are clamped.
  void setSampleRate(String eventName, double rate) {
    _samplingRates[eventName] = rate.clamp(0.0, 1.0);
  }

  /// Forces an immediate flush. Call from product code when an important
  /// event MUST land server-side before app exit. Throws on network failure;
  /// caller may retry. Periodic background flushes never throw.
  Future<void> flush() async {
    if (_disposed) return;
    if (_events.isEmpty && _metering.isEmpty) return;
    await _flush();
  }

  /// Restores the offline queue from secure storage. Called by [LicenseClient]
  /// during `connect()`.
  Future<void> restore() async {
    final eventsRaw = await _cache.getRaw(_cacheKey);
    if (eventsRaw != null && eventsRaw.isNotEmpty) {
      try {
        final parsed = jsonDecode(eventsRaw) as List;
        for (final e in parsed) {
          if (e is Map<String, dynamic>) {
            _events.add(_TelemetryEvent.fromJson(e));
          }
        }
        _trimEvents();
      } catch (_) {
        // Corrupt blob — drop and continue. Capture into telemetry would
        // recurse; the offline queue is by design "best effort".
      }
    }
    final mRaw = await _cache.getRaw(_meteringCacheKey);
    if (mRaw != null && mRaw.isNotEmpty) {
      try {
        final parsed = jsonDecode(mRaw) as List;
        for (final m in parsed) {
          if (m is Map<String, dynamic>) {
            _metering.add(_MeteringRecord.fromJson(m));
          }
        }
        _trimMetering();
      } catch (_) {}
    }
  }

  /// Starts the periodic flush timer. Idempotent.
  void start() {
    if (_disposed) return;
    _flushTimer?.cancel();
    _flushTimer = Timer.periodic(_capabilities.telemetryFlushInterval, (_) {
      _flushSilently();
    });
  }

  /// Stops the periodic timer + persists the queue to secure storage so
  /// nothing is lost on app exit.
  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    _flushTimer?.cancel();
    _flushTimer = null;
    await _persistQueues();
  }

  // ---------- internals ----------

  Future<void> _flush() async {
    final eventsBatch = <_TelemetryEvent>[];
    final batchSize = _capabilities.telemetryBatchSize;
    while (_events.isNotEmpty && eventsBatch.length < batchSize) {
      eventsBatch.add(_events.removeAt(0));
    }
    final meteringBatch = <_MeteringRecord>[];
    while (_metering.isNotEmpty && meteringBatch.length < batchSize) {
      meteringBatch.add(_metering.removeAt(0));
    }
    if (eventsBatch.isEmpty && meteringBatch.isEmpty) return;

    try {
      if (eventsBatch.isNotEmpty) {
        final url = _endpoint().replace(path: '/v1/analytics/events');
        await _http.postJson(url, body: <String, dynamic>{
          'product_slug': _productSlug,
          'events': eventsBatch.map((e) => e.toJson()).toList(),
        });
      }
      if (meteringBatch.isNotEmpty) {
        final url = _endpoint().replace(path: '/v1/metering/record');
        await _http.postJson(url, body: <String, dynamic>{
          'product_slug': _productSlug,
          'records': meteringBatch.map((m) => m.toJson()).toList(),
        });
      }
    } catch (e) {
      // Network failure — push the batch back onto the front of the queue so
      // it's retried on the next flush tick. We tolerate transient failures
      // but don't grow the buffer unbounded; the ring will drop on overflow.
      _events.insertAll(0, eventsBatch);
      _metering.insertAll(0, meteringBatch);
      _trimEvents();
      _trimMetering();
      rethrow;
    }
  }

  Future<void> _flushSilently() async {
    try {
      await _flush();
      await _persistQueues();
    } catch (_) {
      // Periodic flushes never escape; persisted queue survives restart.
      await _persistQueues();
    }
  }

  Future<void> _persistQueues() async {
    final eventsJson = jsonEncode(_events.map((e) => e.toJson()).toList());
    final meteringJson = jsonEncode(_metering.map((m) => m.toJson()).toList());
    try {
      await _cache.putRaw(_cacheKey, eventsJson);
      await _cache.putRaw(_meteringCacheKey, meteringJson);
    } catch (_) {
      // Persist is best effort — same rationale as restore.
    }
  }

  void _trimEvents() {
    final max = _capabilities.telemetryMaxBuffer;
    while (_events.length > max) {
      _events.removeAt(0);
    }
  }

  void _trimMetering() {
    final max = _capabilities.telemetryMaxBuffer;
    while (_metering.length > max) {
      _metering.removeAt(0);
    }
  }

  // PII patterns: emails, US-style 10-digit phone, 16-digit card-like
  // sequences. Strip wholesale rather than redact — products that legitimately
  // need to send these should call their own analytics layer directly.
  static final RegExp _emailRe = RegExp(r'[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}', caseSensitive: false);
  static final RegExp _phoneRe = RegExp(r'\b\d{10,15}\b');
  static final RegExp _cardRe = RegExp(r'\b(?:\d[ -]?){13,19}\b');

  Map<String, dynamic> _stripPii(Map<String, dynamic> input) {
    final out = <String, dynamic>{};
    input.forEach((k, v) {
      if (v is String) {
        if (_emailRe.hasMatch(v) ||
            _phoneRe.hasMatch(v) ||
            _cardRe.hasMatch(v)) {
          return;
        }
        out[k] = v;
      } else if (v is Map<String, dynamic>) {
        out[k] = _stripPii(v);
      } else if (v is List) {
        out[k] = v
            .map((e) => e is Map<String, dynamic> ? _stripPii(e) : e)
            .toList();
      } else {
        out[k] = v;
      }
    });
    return out;
  }

  static final math.Random _rng = math.Random();
}

class _TelemetryEvent {
  final String name;
  final Map<String, dynamic> props;
  final DateTime occurredAt;

  _TelemetryEvent({
    required this.name,
    required this.props,
    required this.occurredAt,
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'props': props,
        'occurred_at': occurredAt.toIso8601String(),
      };

  factory _TelemetryEvent.fromJson(Map<String, dynamic> j) => _TelemetryEvent(
        name: (j['name'] as String?) ?? '',
        props: (j['props'] as Map?)?.cast<String, dynamic>() ?? const {},
        occurredAt:
            DateTime.tryParse(j['occurred_at'] as String? ?? '') ?? DateTime.now(),
      );
}

class _MeteringRecord {
  final String key;
  final int count;
  final Map<String, dynamic> metadata;
  final DateTime occurredAt;

  _MeteringRecord({
    required this.key,
    required this.count,
    required this.metadata,
    required this.occurredAt,
  });

  Map<String, dynamic> toJson() => {
        'key': key,
        'count': count,
        'metadata': metadata,
        'occurred_at': occurredAt.toIso8601String(),
      };

  factory _MeteringRecord.fromJson(Map<String, dynamic> j) => _MeteringRecord(
        key: (j['key'] as String?) ?? '',
        count: (j['count'] as num?)?.toInt() ?? 1,
        metadata: (j['metadata'] as Map?)?.cast<String, dynamic>() ?? const {},
        occurredAt:
            DateTime.tryParse(j['occurred_at'] as String? ?? '') ?? DateTime.now(),
      );
}
