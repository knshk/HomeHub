// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../capabilities.dart';
import '../transport/http_client.dart';

/// Cross-product user preferences: locale, timezone, theme, accessibility
/// flags, communication frequency. Server-side `account_preferences` table.
///
/// SYNC read path: products call `client.preferences.cachedValue(key)` to read
/// from the JWT-embedded snapshot without a round-trip. Use [refresh] +
/// [update] for write/explicit-refresh paths.
class PreferencesApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;

  /// Last-known snapshot keyed by preference name. Populated from server on
  /// [refresh] and after [update]. Reads via [cachedValue] are sync.
  Map<String, dynamic> _snapshot = const <String, dynamic>{};

  PreferencesApi(this._http, this._endpoint, this._capabilities);

  // ---------- standard preference keys (products may add custom) ----------
  static const String localeKey = 'locale';
  static const String timezoneKey = 'timezone';
  static const String themeKey = 'theme';
  static const String accessibilityHighContrastKey =
      'accessibility.high_contrast';
  static const String accessibilityReduceMotionKey =
      'accessibility.reduce_motion';
  static const String communicationSummaryFrequencyKey =
      'communication.summary_frequency';

  /// Returns the cached value typed as [T] — null if missing or wrong type.
  /// Sync; fed by the most recent [refresh] / [update].
  T? cachedValue<T>(String key) {
    final v = _snapshot[key];
    if (v is T) return v;
    if (T == int && v is num) return v.toInt() as T;
    if (T == double && v is num) return v.toDouble() as T;
    return null;
  }

  /// Replaces the in-memory snapshot. Called internally by [LicenseClient]
  /// when a fresh JWT carries a prefs payload, and by [refresh] / [update].
  void primeSnapshot(Map<String, dynamic> snapshot) {
    _snapshot = Map.unmodifiable(snapshot);
  }

  /// Fetches the user's current preferences from the server.
  Future<Map<String, dynamic>> refresh() async {
    _capabilities.require('preferences');
    final url = _endpoint().replace(path: '/v1/preferences/get');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    final values = (body['values'] as Map?)?.cast<String, dynamic>() ??
        const <String, dynamic>{};
    primeSnapshot(values);
    return _snapshot;
  }

  /// Writes a single preference key/value. Returns the merged snapshot.
  Future<Map<String, dynamic>> update(String key, dynamic value) async {
    _capabilities.require('preferences');
    final url = _endpoint().replace(path: '/v1/preferences/update');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'key': key,
      'value': value,
    });
    final values = (body['values'] as Map?)?.cast<String, dynamic>() ??
        const <String, dynamic>{};
    primeSnapshot(values);
    return _snapshot;
  }

  /// Writes multiple keys atomically. Server merges with existing state.
  Future<Map<String, dynamic>> updateMany(
      Map<String, dynamic> updates) async {
    _capabilities.require('preferences');
    final url = _endpoint().replace(path: '/v1/preferences/update-many');
    final body = await _http
        .postJson(url, body: <String, dynamic>{'updates': updates});
    final values = (body['values'] as Map?)?.cast<String, dynamic>() ??
        const <String, dynamic>{};
    primeSnapshot(values);
    return _snapshot;
  }
}
