// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// §2A.8 — MFA + session management.
///
/// Day-1 contract covers TOTP, recovery codes, sessions list/revoke, step-up
/// grants. WebAuthn is a forward-compat surface — the registration ceremony
/// is platform-native and best driven by the consuming app's own UI;
/// `client.security.beginWebauthnRegistration()` will be added once the
/// backend ships the challenge endpoint.
///
/// All methods gated by `capabilities.mfa` (extension to SdkCapabilities;
/// defaults to enabled with opt-out semantics).
class SecurityApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;
  SecurityApi(this._http, this._endpoint, this._capabilities);

  /// Returns MFA status — whether the account has any confirmed factors,
  /// the factor list, and remaining recovery-code count.
  Future<MfaStatus> status() async {
    _capabilities.require('mfa');
    final url = _endpoint().replace(path: '/v1/security/mfa/status');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    return MfaStatus.fromJson(body);
  }

  /// Begins a TOTP enrollment. Returns the `otpauth://` URI for the QR code
  /// + the raw base32 secret (so users can type it into authenticators that
  /// don't support QR scan). The factor is unconfirmed until the user enters
  /// a valid code via [verifyTotp].
  Future<TotpEnrollment> enrollTotp(
      {required String accountEmail, String? label}) async {
    _capabilities.require('mfa');
    final url = _endpoint().replace(path: '/v1/security/mfa/totp/enroll');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'account_email': accountEmail,
      if (label != null) 'label': label,
    });
    return TotpEnrollment.fromJson(body);
  }

  /// Confirms a TOTP factor by verifying the user-entered 6-digit code.
  Future<void> verifyTotp(
      {required String factorId, required String code}) async {
    _capabilities.require('mfa');
    final url = _endpoint().replace(path: '/v1/security/mfa/totp/verify');
    await _http.postJson(url, body: <String, dynamic>{
      'factor_id': factorId,
      'code': code,
    });
  }

  /// Rotates the recovery codes. Returns the freshly-generated codes
  /// ONCE — the SDK does NOT persist them; product UX must display and
  /// prompt the user to save them immediately.
  Future<List<String>> regenerateRecoveryCodes() async {
    _capabilities.require('mfa');
    final url =
        _endpoint().replace(path: '/v1/security/mfa/recovery-codes/regenerate');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    final raw = body['codes'];
    if (raw is! List) return const [];
    return raw.whereType<String>().toList();
  }

  /// Consumes a recovery code (single-use). Used to unlock account when the
  /// authenticator app is unavailable.
  Future<void> verifyRecoveryCode(String code) async {
    _capabilities.require('mfa');
    final url =
        _endpoint().replace(path: '/v1/security/mfa/recovery-codes/verify');
    await _http.postJson(url, body: <String, dynamic>{'code': code});
  }

  /// Lists this user's active client sessions.
  Future<List<MfaSession>> listSessions() async {
    _capabilities.require('mfa');
    final url = _endpoint().replace(path: '/v1/security/sessions');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    final raw = body['sessions'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map<String, dynamic>>()
        .map(MfaSession.fromJson)
        .toList();
  }

  /// Revokes a specific session — the next `verify()` call against the
  /// associated JWT throws [SessionRevokedException] and the SDK emits a
  /// `sessionRevoked` state-change event.
  Future<void> revokeSession(String id) async {
    _capabilities.require('mfa');
    final url = _endpoint().replace(path: '/v1/security/sessions/$id/revoke');
    await _http.postJson(url, body: const <String, dynamic>{});
  }

  /// Revokes every active session for this account — "sign out everywhere".
  Future<void> revokeAllSessions() async {
    _capabilities.require('mfa');
    final url = _endpoint().replace(path: '/v1/security/sessions/revoke-all');
    await _http.postJson(url, body: const <String, dynamic>{});
  }

  /// Mints a short-lived "MFA-fresh" grant for [scope]. Used right before
  /// the user attempts a sensitive operation (cancel subscription, change
  /// payout method, account deletion) so the server can re-confirm MFA
  /// without the SDK invoking the verifier directly.
  Future<StepUpGrant> mintStepUp(
      {required String scope, Duration? ttl}) async {
    _capabilities.require('mfa');
    final url = _endpoint().replace(path: '/v1/security/step-up/mint');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'scope': scope,
      'ttl_secs': (ttl ?? const Duration(minutes: 5)).inSeconds,
    });
    return StepUpGrant.fromJson(body);
  }
}
