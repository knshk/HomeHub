// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// Privacy + consent center: GDPR Art. 20 data export, Art. 17 erasure,
/// per-scope consent management. Construct via [LicenseClient.privacy].
class PrivacyApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;
  PrivacyApi(this._http, this._endpoint, this._capabilities);

  /// Initiates an async data export (GDPR Art. 20). Returns a job handle —
  /// poll [getJob] to learn when the download URL is ready.
  Future<PrivacyJob> exportData() async {
    _capabilities.require('privacy');
    final url = _endpoint().replace(path: '/v1/privacy/export');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    return PrivacyJob.fromJson(body);
  }

  /// Requests account erasure (GDPR Art. 17). Backend crypto-shreds PII
  /// while retaining encrypted aggregate financial data for tax-retention
  /// compliance per jurisdiction.
  ///
  /// [confirmation] must be the exact account email — server rejects
  /// otherwise as a defense-in-depth against accidental erasure.
  Future<PrivacyJob> requestErasure({required String confirmation}) async {
    _capabilities.require('privacy');
    final url = _endpoint().replace(path: '/v1/privacy/erase');
    final body = await _http.postJson(
        url, body: <String, dynamic>{'confirmation': confirmation});
    return PrivacyJob.fromJson(body);
  }

  /// Polls a previously-initiated privacy job.
  Future<PrivacyJob> getJob(String id) async {
    _capabilities.require('privacy');
    final url = _endpoint().replace(path: '/v1/privacy/jobs/$id');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    return PrivacyJob.fromJson(body);
  }

  /// Fetches the user's current per-scope consent state.
  Future<ConsentState> getConsents() async {
    _capabilities.require('privacy');
    final url = _endpoint().replace(path: '/v1/privacy/consents/get');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    return ConsentState.fromJson(body);
  }

  /// Updates per-scope consents. Server records timestamp + IP + UA + exact
  /// text version into the consent ledger for GDPR Art. 7 proof.
  ///
  /// [consentTextVersion] should be the version string of the exact privacy
  /// text the user just accepted (e.g. "ppv4-2026-03-15"). The server stores
  /// it so we have proof of WHAT they consented to, not just THAT they did.
  Future<ConsentState> updateConsents({
    required ConsentState state,
    String? consentTextVersion,
  }) async {
    _capabilities.require('privacy');
    final url = _endpoint().replace(path: '/v1/privacy/consents/update');
    final body = await _http.postJson(url, body: <String, dynamic>{
      ...state.toJson(),
      if (consentTextVersion != null)
        'consent_text_version': consentTextVersion,
    });
    return ConsentState.fromJson(body);
  }
}
