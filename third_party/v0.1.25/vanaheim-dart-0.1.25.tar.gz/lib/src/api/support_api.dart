// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// Support / tickets / KB search. Construct via [LicenseClient.support].
///
/// Tickets auto-attach license + tier + payment + recent telemetry context
/// server-side from the authenticated JWT — products don't need to fill it.
class SupportApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;

  SupportApi(this._http, this._endpoint, this._capabilities);

  int get _maxAttachmentBytes =>
      _capabilities.feedbackMaxAttachmentMb * 1024 * 1024;

  /// Opens a new ticket and returns the created ticket.
  Future<SupportTicket> openTicket({
    required String subject,
    required String body,
    String? category,
    String? priority,
    List<FeedbackAttachment> attachments = const [],
  }) async {
    _capabilities.require('support');
    final encodedAttachments = attachments
        .where((a) => a.bytes.length <= _maxAttachmentBytes)
        .map((a) => <String, dynamic>{
              'filename': a.filename,
              'content_type': a.contentType,
              'bytes_b64': base64Encode(a.bytes),
            })
        .toList();
    final url = _endpoint().replace(path: '/v1/support/tickets');
    final res = await _http.postJson(url, body: <String, dynamic>{
      'subject': subject,
      'body': body,
      if (category != null) 'category': category,
      if (priority != null) 'priority': priority,
      if (encodedAttachments.isNotEmpty) 'attachments': encodedAttachments,
    });
    final ticketRaw = res['ticket'];
    if (ticketRaw is! Map<String, dynamic>) {
      throw const FormatException('openTicket returned no ticket');
    }
    return SupportTicket.fromJson(ticketRaw);
  }

  /// Lists this user's tickets, newest first.
  Future<List<SupportTicket>> listTickets({String? status}) async {
    _capabilities.require('support');
    final url = _endpoint().replace(path: '/v1/support/tickets/list');
    final res = await _http.postJson(url, body: <String, dynamic>{
      if (status != null) 'status': status,
    });
    final raw = res['tickets'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map<String, dynamic>>()
        .map(SupportTicket.fromJson)
        .toList();
  }

  /// Fetches one ticket plus its full message thread.
  Future<SupportTicketDetail> getTicket(String id) async {
    _capabilities.require('support');
    final url = _endpoint().replace(path: '/v1/support/tickets/$id');
    final res = await _http.postJson(url, body: const <String, dynamic>{});
    final ticketRaw = res['ticket'];
    if (ticketRaw is! Map<String, dynamic>) {
      throw const FormatException('getTicket returned no ticket');
    }
    final messagesRaw = res['messages'];
    final messages = messagesRaw is List
        ? messagesRaw
            .whereType<Map<String, dynamic>>()
            .map(SupportMessage.fromJson)
            .toList()
        : <SupportMessage>[];
    return SupportTicketDetail(
      ticket: SupportTicket.fromJson(ticketRaw),
      messages: messages,
    );
  }

  /// Posts a reply on an open ticket.
  Future<SupportMessage> replyTo(
      {required String ticketId, required String message}) async {
    _capabilities.require('support');
    final url = _endpoint().replace(path: '/v1/support/tickets/$ticketId/reply');
    final res = await _http
        .postJson(url, body: <String, dynamic>{'message': message});
    final msgRaw = res['message'];
    if (msgRaw is! Map<String, dynamic>) {
      throw const FormatException('replyTo returned no message');
    }
    return SupportMessage.fromJson(msgRaw);
  }
}
