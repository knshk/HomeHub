// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// §2B.2 KB / docs search. Surfaces help-center content + AI assistant
/// citations from the same index. Backend may stub initially; SDK contract
/// is stable from day-1.
class DocsApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;
  DocsApi(this._http, this._endpoint, this._capabilities);

  /// Searches the docs index. [limit] caps results (server further clamps).
  Future<List<DocsHit>> search(String query, {int limit = 10}) async {
    _capabilities.require('docs');
    if (query.trim().isEmpty) return const [];
    final url = _endpoint().replace(path: '/v1/docs/search');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'query': query,
      'limit': limit,
    });
    final raw = body['hits'];
    if (raw is! List) return const [];
    return raw.whereType<Map<String, dynamic>>().map(DocsHit.fromJson).toList();
  }
}
