// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// §2B.4 Referrals — 1:1 user-driven "give a month, get a month". Distinct
/// from partner reseller program (§D, partner role). Reuses offer-code
/// machinery server-side; SDK contract is stable from day-1.
class ReferralsApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;
  ReferralsApi(this._http, this._endpoint, this._capabilities);

  /// Returns this user's referral code, creating it if missing. Idempotent.
  Future<ReferralCode> code() async {
    _capabilities.require('referrals');
    final url = _endpoint().replace(path: '/v1/referrals/code');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    return ReferralCode.fromJson(body);
  }

  /// Lists outgoing referral invites + their funnel status.
  Future<List<ReferralInvite>> invites() async {
    _capabilities.require('referrals');
    final url = _endpoint().replace(path: '/v1/referrals/invites');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    final raw = body['invites'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map<String, dynamic>>()
        .map(ReferralInvite.fromJson)
        .toList();
  }

  /// Generates a platform-specific share URL pre-populated with this user's
  /// referral code. [channel] is e.g. `"twitter"`, `"sms"`, `"email"`,
  /// `"native_share"`. Server returns the formatted URL appropriate for the
  /// channel.
  Future<Uri> shareLink({required String channel}) async {
    _capabilities.require('referrals');
    final url = _endpoint().replace(path: '/v1/referrals/share-link');
    final body = await _http
        .postJson(url, body: <String, dynamic>{'channel': channel});
    final raw = body['url'];
    if (raw is! String || raw.isEmpty) {
      throw const FormatException('share-link returned no URL');
    }
    final parsed = Uri.tryParse(raw);
    if (parsed == null) {
      throw const FormatException('share-link returned invalid URL');
    }
    return parsed;
  }
}
