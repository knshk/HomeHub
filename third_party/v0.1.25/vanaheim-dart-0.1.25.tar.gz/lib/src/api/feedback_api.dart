// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// Feedback / NPS / CSAT / exit-survey submission. Construct via
/// [LicenseClient.feedback]. Device context (tier, app version, OS, region,
/// account age, recent error telemetry) is auto-attached server-side from the
/// authenticated JWT — products don't need to fill it in.
class FeedbackApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;

  FeedbackApi(this._http, this._endpoint, this._capabilities);

  int get _maxAttachmentBytes => _capabilities.feedbackMaxAttachmentMb * 1024 * 1024;

  /// Submits structured feedback. Body text is server-side envelope-encrypted
  /// (PII may be present in free text). [attachments] are uploaded inline as
  /// base64 in the same request; large files should be < 5 MB each.
  Future<FeedbackReceipt> submit({
    required String category,
    int? rating,
    String? text,
    List<FeedbackAttachment> attachments = const [],
  }) async {
    _capabilities.require('feedback');
    final encodedAttachments = attachments
        .where((a) => a.bytes.length <= _maxAttachmentBytes)
        .map((a) => <String, dynamic>{
              'filename': a.filename,
              'content_type': a.contentType,
              'bytes_b64': base64Encode(a.bytes),
            })
        .toList();
    final url = _endpoint().replace(path: '/v1/feedback');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'category': category,
      if (rating != null) 'rating': rating,
      if (text != null) 'text': text,
      if (encodedAttachments.isNotEmpty) 'attachments': encodedAttachments,
    });
    return FeedbackReceipt.fromJson(body);
  }

  /// Submits an NPS score (0-10). [comment] is optional follow-up text.
  Future<FeedbackReceipt> nps({required int score, String? comment}) async {
    _capabilities.require('feedback');
    if (score < 0 || score > 10) {
      throw ArgumentError.value(score, 'score', 'NPS score must be 0-10');
    }
    final url = _endpoint().replace(path: '/v1/feedback/nps');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'score': score,
      if (comment != null) 'comment': comment,
    });
    return FeedbackReceipt.fromJson(body);
  }

  /// Submits a CSAT score (1-5).
  Future<FeedbackReceipt> csat(
      {required int score, String? comment, String? ticketId}) async {
    _capabilities.require('feedback');
    if (score < 1 || score > 5) {
      throw ArgumentError.value(score, 'score', 'CSAT score must be 1-5');
    }
    final url = _endpoint().replace(path: '/v1/feedback/csat');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'score': score,
      if (comment != null) 'comment': comment,
      if (ticketId != null) 'ticket_id': ticketId,
    });
    return FeedbackReceipt.fromJson(body);
  }

  /// Records that a survey prompt was displayed (NPS, CSAT, exit-survey) so
  /// the orchestrator can apply frequency caps and dedup. Idempotent on
  /// (account, survey_id).
  Future<void> markPromptShown(String surveyId) async {
    _capabilities.require('feedback');
    final url = _endpoint().replace(path: '/v1/feedback/prompt-shown');
    await _http.postJson(url, body: <String, dynamic>{'survey_id': surveyId});
  }
}
