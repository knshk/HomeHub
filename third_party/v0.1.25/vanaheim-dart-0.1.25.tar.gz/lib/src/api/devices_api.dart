// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';
import 'dart:typed_data';

import '../exceptions.dart';
import '../transport/http_client.dart';

/// §2A.5 / v2-Vanaheim device enrollment.
///
/// In v2 the SDK no longer talks to Bifrost directly for device records —
/// enrollment, heartbeat, and revocation are all owned by L2 (Alfheim).
/// On first boot the SDK auto-registers its X25519 device pubkey via
/// [register]; subsequent boots skip enrollment by checking the
/// `device_registered_v1` SecureCache marker that `LicenseClient` writes
/// after a successful [register] call.
///
/// All three endpoints live under `{l2BaseUrl}/v1/devices/...`. The SDK
/// passes its [SignedHttpClient] in so the HMAC + auth + AppCheck
/// headers + JWE envelope are applied uniformly with the rest of the
/// data-plane API surface.
class DevicesAPI {
  final SignedHttpClient _http;
  final Uri _l2BaseUrl;

  DevicesAPI({
    required SignedHttpClient http,
    required Uri l2BaseUrl,
  })  : _http = http,
        _l2BaseUrl = l2BaseUrl;

  /// Enrolls this device's X25519 public key with L2. Idempotent on
  /// `(project_id, device_fingerprint)`; safe to retry on transient
  /// failures. Returns the server-assigned `device_id` (string) which the
  /// caller persists in SecureCache for the heartbeat / revoke endpoints
  /// and for the `X-LS-Device-Id` header on JWE-required calls.
  ///
  /// The route is JWE-required per the hard-coded policy in
  /// `route_policy.dart` — the underlying [SignedHttpClient] wraps the
  /// body in a JWE envelope automatically. Callers do NOT need to do
  /// anything special here.
  Future<DeviceEnrollment> register({
    required Uint8List devicePubKey,
  }) async {
    if (devicePubKey.isEmpty) {
      throw ArgumentError.value(
          devicePubKey, 'devicePubKey', 'device public key must not be empty');
    }
    final url = _l2BaseUrl.replace(path: '/v1/devices/enroll');
    final res = await _http.postJson(
      url,
      body: <String, dynamic>{
        // Base64url, no padding — JWE/JWS canonical form. The server uses
        // this directly as the X25519 recipient pubkey for JWE-to-device
        // and never re-encodes.
        'device_pubkey': base64Url.encode(devicePubKey).replaceAll('=', ''),
      },
    );
    final deviceId = res['device_id'] as String?;
    if (deviceId == null || deviceId.isEmpty) {
      throw NetworkException('L2 enroll returned no device_id');
    }
    return DeviceEnrollment(
      deviceId: deviceId,
      enrolledAt: _parseTimeOrNow(res['enrolled_at']),
    );
  }

  /// Marks this device as online with L2. Cheap call — used to keep the
  /// device's `last_seen_at` fresh so L2 can prune stale records on its own
  /// schedule. Idempotent. No body parameters; the device identity is
  /// pulled from the request headers (`X-LS-Device-Id` + HMAC).
  Future<void> heartbeat() async {
    final url = _l2BaseUrl.replace(path: '/v1/devices/heartbeat');
    await _http.postJson(url, body: const <String, dynamic>{});
  }

  /// Revokes a specific device by id. Most products will call this for
  /// "sign out everywhere" / "lost my phone" flows. The current device can
  /// revoke itself by passing its own [deviceId] — the SDK's normal
  /// `deactivate()` flow does NOT call this (it only frees the seat); use
  /// this when you mean "delete the device record + invalidate its
  /// pubkey on L2 permanently".
  ///
  /// Surfaces [DeviceRevokedException] if the server reports the device
  /// was already revoked.
  Future<void> revoke(String deviceId) async {
    if (deviceId.isEmpty) {
      throw ArgumentError.value(deviceId, 'deviceId', 'must not be empty');
    }
    final url = _l2BaseUrl.replace(path: '/v1/devices/$deviceId/revoke');
    await _http.postJson(url, body: const <String, dynamic>{});
  }

  static DateTime _parseTimeOrNow(Object? raw) {
    if (raw is String) {
      try {
        return DateTime.parse(raw).toUtc();
      } catch (_) {
        // Fall through to "now" so callers don't have to defensively wrap.
      }
    }
    return DateTime.now().toUtc();
  }
}

/// Result of a successful [DevicesAPI.register] call. Held briefly by the
/// SDK's connect()-time enrollment flow; the `deviceId` is persisted into
/// SecureCache for subsequent boots.
class DeviceEnrollment {
  /// L2-assigned, opaque device identifier. Used as `X-LS-Device-Id` on
  /// JWE-required calls + as the path segment in [DevicesAPI.revoke].
  final String deviceId;

  /// Server-reported enrollment timestamp (UTC). Diagnostics only.
  final DateTime enrolledAt;

  const DeviceEnrollment({
    required this.deviceId,
    required this.enrolledAt,
  });
}
