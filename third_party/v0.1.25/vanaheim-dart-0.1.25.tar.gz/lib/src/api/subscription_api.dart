// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// Self-serve subscription management: list tiers, upgrade, schedule
/// downgrade, cancel, reactivate, list invoices, generate Stripe Customer
/// Portal session URL.
///
/// Tier-change semantics match server-side policy:
///   * upgrade  → immediate (prorated)
///   * downgrade → ALWAYS scheduled to period end (defense-in-depth)
///   * cancel    → at period end, no grace
///   * reactivate → only within renewal-failure grace
class SubscriptionApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;
  SubscriptionApi(this._http, this._endpoint, this._capabilities);

  /// Fetches the user's current plan as a structured snapshot — slug + display
  /// name + amount + currency + interval + entitlements blob. Combines what
  /// `client.tier` (slug only) and `tiers()` (catalog list) provide, with one
  /// authoritative round-trip server-side.
  ///
  /// Returns null when the account has no active subscription (e.g. expired
  /// trial, never paid).
  Future<SubscriptionTier?> currentPlan() async {
    _capabilities.require('subscription');
    final url = _endpoint().replace(path: '/v1/subscription/current-plan');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    final raw = body['plan'];
    if (raw is! Map<String, dynamic>) return null;
    return SubscriptionTier.fromJson(raw);
  }

  /// Lists available tiers + pricing for the current product / region /
  /// currency. The current tier on the JWT is exposed via [LicenseClient.tier].
  Future<List<SubscriptionTier>> tiers({String? currency}) async {
    _capabilities.require('subscription');
    final url = _endpoint().replace(path: '/v1/subscription/tiers');
    final body = await _http.postJson(url, body: <String, dynamic>{
      if (currency != null) 'currency': currency,
    });
    final raw = body['tiers'];
    if (raw is! List) return const [];
    return raw
        .whereType<Map<String, dynamic>>()
        .map(SubscriptionTier.fromJson)
        .toList();
  }

  /// Immediately switches to [tier]. Server applies the catalog policy:
  /// rejects with `downgrade_must_be_scheduled` if [tier] is below current.
  Future<void> upgradeTo(String tier) async {
    _capabilities.require('subscription');
    final url = _endpoint().replace(path: '/v1/subscription/upgrade');
    await _http.postJson(url, body: <String, dynamic>{'tier': tier});
  }

  /// Schedules a downgrade to [tier] effective at period end. Server-side
  /// the downgrade-always-scheduled policy holds: even if you pass a higher
  /// tier here, the server enforces "scheduled for downgrades only".
  Future<void> scheduleDowngrade(String tier) async {
    _capabilities.require('subscription');
    final url = _endpoint().replace(path: '/v1/subscription/schedule-downgrade');
    await _http.postJson(url, body: <String, dynamic>{'tier': tier});
  }

  /// Cancels at period end (no grace). [reason] is captured for exit-survey.
  Future<void> cancel({String? reason}) async {
    _capabilities.require('subscription');
    final url = _endpoint().replace(path: '/v1/subscription/cancel');
    await _http.postJson(url, body: <String, dynamic>{
      if (reason != null) 'reason': reason,
    });
  }

  /// Reactivates a cancelled subscription, if still within the grace window.
  Future<void> reactivate() async {
    _capabilities.require('subscription');
    final url = _endpoint().replace(path: '/v1/subscription/reactivate');
    await _http.postJson(url, body: const <String, dynamic>{});
  }

  /// Lists prior invoices, newest first.
  Future<InvoicePage> invoices({int limit = 25, String? cursor}) async {
    _capabilities.require('subscription');
    final url = _endpoint().replace(path: '/v1/subscription/invoices');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'limit': limit,
      if (cursor != null && cursor.isNotEmpty) 'cursor': cursor,
    });
    return InvoicePage.fromJson(body);
  }

  /// Generates a short-lived Stripe Customer Portal session URL for card +
  /// invoice + cancellation management. The product redirects the user to
  /// this URL; Stripe handles the rest.
  Future<Uri> portalSessionUrl({Uri? returnUrl}) async {
    _capabilities.require('subscription');
    final url = _endpoint().replace(path: '/v1/subscription/portal-session');
    final body = await _http.postJson(url, body: <String, dynamic>{
      if (returnUrl != null) 'return_url': returnUrl.toString(),
    });
    final raw = body['url'];
    if (raw is! String || raw.isEmpty) {
      throw const FormatException('portal-session returned no URL');
    }
    final parsed = Uri.tryParse(raw);
    if (parsed == null) {
      throw const FormatException('portal-session returned invalid URL');
    }
    return parsed;
  }
}
