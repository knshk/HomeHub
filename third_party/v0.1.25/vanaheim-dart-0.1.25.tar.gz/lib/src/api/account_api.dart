// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import '../capabilities.dart';
import '../models.dart';
import '../transport/http_client.dart';

/// §2B.6 Account portability — license transfer + account merge requests.
/// Admin-approved server-side; SDK initiates the request and polls status.
class AccountApi {
  final SignedHttpClient _http;
  final Uri Function() _endpoint;
  final SdkCapabilities _capabilities;
  AccountApi(this._http, this._endpoint, this._capabilities);

  /// Requests a license transfer to [targetEmail]. Admin reviews + approves;
  /// returns a request handle for polling.
  ///
  /// `reason` is required so audit + admin context have it during review.
  Future<AccountRequest> transferRequest({
    required String targetEmail,
    required String reason,
  }) async {
    _capabilities.require('preferences'); // gated under preferences capability
    final url = _endpoint().replace(path: '/v1/account/transfer-request');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'target_email': targetEmail,
      'reason': reason,
    });
    return AccountRequest.fromJson(body);
  }

  /// Requests a merge of this account with the account identified by
  /// [targetEmail]. Admin-approved. Source account becomes a soft-deleted
  /// pointer to the target.
  Future<AccountRequest> mergeRequest({
    required String targetEmail,
    required String reason,
  }) async {
    _capabilities.require('preferences');
    final url = _endpoint().replace(path: '/v1/account/merge-request');
    final body = await _http.postJson(url, body: <String, dynamic>{
      'target_email': targetEmail,
      'reason': reason,
    });
    return AccountRequest.fromJson(body);
  }

  /// Polls an in-flight portability request.
  Future<AccountRequest> getRequest(String id) async {
    _capabilities.require('preferences');
    final url = _endpoint().replace(path: '/v1/account/requests/$id');
    final body = await _http.postJson(url, body: const <String, dynamic>{});
    return AccountRequest.fromJson(body);
  }
}
