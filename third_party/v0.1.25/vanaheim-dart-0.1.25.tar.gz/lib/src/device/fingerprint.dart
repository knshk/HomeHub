// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';
import 'dart:io' show Platform;
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';

/// Generates a stable, opaque device fingerprint. Per platform we mix the most
/// stable identifier with the productSlug via HKDF; raw OS identifiers
/// (IDFV, Android ID, Machine GUID, /etc/machine-id) are NEVER sent to the
/// server.
///
/// See DEVICE_BINDING.md §3 for the full spec.
class DeviceFingerprintGenerator {
  final DeviceInfoPlugin _info;
  DeviceFingerprintGenerator({DeviceInfoPlugin? info})
      : _info = info ?? DeviceInfoPlugin();

  /// Returns the hex fingerprint (64 chars). [productSlug] is mixed in so
  /// the same device gets a different fingerprint per product (no cross-
  /// product correlation).
  Future<String> generate({required String productSlug}) async {
    final stable = await _rawPlatformIdentifier();
    final ikm = sha256.convert(utf8.encode(stable)).bytes;
    final info = utf8.encode('license-store-fp-v1|$productSlug');
    final salt = utf8.encode('license-store/v1'); // public, stable
    final out = _hkdfSha256(
        ikm: Uint8List.fromList(ikm),
        salt: Uint8List.fromList(salt),
        info: Uint8List.fromList(info),
        length: 32);
    return _hex(out);
  }

  Future<String> _rawPlatformIdentifier() async {
    if (kIsWeb) {
      final info = await _info.webBrowserInfo;
      // Browser fingerprints are weak; combine the browser identifiers we can.
      return [
        info.userAgent,
        info.vendor,
        info.platform,
        info.hardwareConcurrency,
        info.maxTouchPoints,
        info.language,
      ].where((e) => e != null).join('|');
    }
    if (Platform.isIOS) {
      final ios = await _info.iosInfo;
      return ios.identifierForVendor ?? ios.utsname.machine;
    }
    if (Platform.isMacOS) {
      final mac = await _info.macOsInfo;
      return mac.systemGUID ?? '${mac.computerName}|${mac.model}';
    }
    if (Platform.isAndroid) {
      final a = await _info.androidInfo;
      // `id` is the Android ID (per-app-signing-key, per-device).
      return a.id;
    }
    if (Platform.isWindows) {
      final w = await _info.windowsInfo;
      return w.deviceId;
    }
    if (Platform.isLinux) {
      final l = await _info.linuxInfo;
      return l.machineId ?? l.id;
    }
    if (Platform.isFuchsia) {
      return 'fuchsia';
    }
    return 'unknown';
  }

  // ---- HKDF-SHA-256 (RFC 5869) — small inline implementation ------------

  static Uint8List _hkdfSha256({
    required Uint8List ikm,
    required Uint8List salt,
    required Uint8List info,
    required int length,
  }) {
    // Extract
    final prk = Hmac(sha256, salt).convert(ikm).bytes;
    // Expand
    final n = (length + 31) ~/ 32;
    final result = BytesBuilder(copy: false);
    Uint8List prev = Uint8List(0);
    for (var i = 1; i <= n; i++) {
      final input = BytesBuilder(copy: false)
        ..add(prev)
        ..add(info)
        ..addByte(i);
      prev = Uint8List.fromList(
          Hmac(sha256, prk).convert(input.takeBytes()).bytes);
      result.add(prev);
    }
    return Uint8List.fromList(result.takeBytes().sublist(0, length));
  }

  static String _hex(Uint8List bytes) {
    const a = '0123456789abcdef';
    final out = StringBuffer();
    for (final b in bytes) {
      out.write(a[(b >> 4) & 0xf]);
      out.write(a[b & 0xf]);
    }
    return out.toString();
  }
}
