// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// §2A.1 / §3A.3 push token provider — the contract the SDK uses to acquire
/// an FCM/APNs registration token + receive incoming push notifications.
///
/// Day-1 SDK ships the interface so backend FCM rollout doesn't require a
/// future SDK release. Products inject a concrete implementation — typically
/// backed by `firebase_messaging` on Flutter and `FirebaseMessaging` /
/// `UserNotifications` on Swift.
///
/// The SDK only ever calls [getToken] and listens to [tokenChanges] +
/// [incomingMessages]; it never touches platform notification permissions
/// directly (products own that UX).
abstract class PushTokenProvider {
  /// Returns the current FCM/APNs registration token. May be empty when the
  /// platform has not yet issued one (e.g. permission denied) — SDK treats
  /// empty as "no token available" and skips sending it to the backend.
  Future<String> getToken();

  /// Stream of token rotations (FCM rotates ~1/week or after app reinstall).
  /// The SDK re-sends the new token to the backend automatically.
  Stream<String> get tokenChanges;

  /// Stream of incoming push notification payloads. The SDK consumes these
  /// to trigger an immediate verify() on `kind == "license.changed"` /
  /// `"license.config_changed"`, and emits `notificationReceived` for
  /// in-app inbox arrivals.
  Stream<Map<String, dynamic>> get incomingMessages;
}

/// No-op provider used in tests + as the default when products don't need
/// push notifications. Yields empty token + never-firing streams.
class NoPushTokenProvider implements PushTokenProvider {
  const NoPushTokenProvider();

  @override
  Future<String> getToken() async => '';

  @override
  Stream<String> get tokenChanges => const Stream<String>.empty();

  @override
  Stream<Map<String, dynamic>> get incomingMessages =>
      const Stream<Map<String, dynamic>>.empty();
}
