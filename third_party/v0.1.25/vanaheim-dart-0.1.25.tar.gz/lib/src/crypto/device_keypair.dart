// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Device X25519 keypair provider — generates once, persists the private
/// scalar to [SecureCache], exposes only the 32-byte public key + a
/// scoped "extract private bytes for decrypt" hook.
///
/// v2 / Vanaheim collapsed the v1 plural-provider zoo into a single concrete
/// class. `NoDeviceKeypairProvider` (the no-op stub used in v1 tests +
/// products that didn't enable JWE) is gone — v2 makes the keypair required
/// because every device must enroll with L2 on first boot.
///
/// Platform storage:
///   * iOS / macOS  → Keychain (`kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly`)
///   * Android      → EncryptedSharedPreferences (key in Keystore)
///   * Windows      → DPAPI
///   * Linux        → libsecret
///   * Web          → IndexedDB + WebCrypto-wrapped DEK (weakest tier; not
///                    recommended for production)
///
/// Idempotency: `getPublicKey()` and `extractPrivateKeyBytes()` may be
/// called concurrently — the provider guards generation with a Future so
/// only one keypair is ever written to the cache.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

import '../storage/secure_cache.dart';
import 'jwe.dart';

/// Cache key for the persisted 32-byte X25519 scalar. Versioned so a future
/// algorithm rotation can ship without colliding with the v1 blob.
const String kDeviceX25519PrivCacheKey = 'device_x25519_priv_v1';

/// Concrete production [DeviceKeypairProvider] backed by
/// `package:cryptography` X25519 + an injected [SecureCache].
///
/// Construction is cheap (no I/O); the first call to [getPublicKey] or
/// [extractPrivateKeyBytes] triggers a one-shot read-or-generate of the
/// scalar, after which both methods serve from the in-memory cache. The
/// underlying scalar bytes are kept in a `Uint8List` for the lifetime of
/// the provider — there is no "destroy" path in v2 since the JWE codec
/// needs them on every inbound request.
class CryptographyDeviceKeypairProvider implements DeviceKeypairProvider {
  final SecureCache _cache;
  final X25519 _x25519;

  // In-memory caches. `_pub` is the 32-byte pub; `_priv` is the 32-byte
  // scalar (the seed cryptography uses to deterministically derive both).
  Uint8List? _pub;
  Uint8List? _priv;

  // Single-flight guard. Concurrent callers await the same future so we
  // never write two keypairs to the cache.
  Future<void>? _initFut;

  CryptographyDeviceKeypairProvider({
    required SecureCache cache,
    X25519? x25519,
  })  : _cache = cache,
        _x25519 = x25519 ?? X25519();

  @override
  Future<Uint8List> getPublicKey() async {
    await _ensureLoaded();
    return _pub!;
  }

  /// Returns the 32-byte raw X25519 scalar used to derive the device's
  /// private + public halves. Required by `JweCodec.decryptCompact` so it
  /// can rebuild the keypair via `newKeyPairFromSeed`.
  ///
  /// Products should NEVER call this directly — it's the wire the
  /// [CryptographyJweDecryptor] uses to bridge `cryptography`'s typed
  /// `SimpleKeyPair` into the codec's raw-bytes API. Surfacing the bytes
  /// outside this seam is what the SecureCache abstraction is preventing.
  Future<Uint8List> extractPrivateKeyBytes() async {
    await _ensureLoaded();
    return _priv!;
  }

  Future<void> _ensureLoaded() {
    if (_pub != null && _priv != null) return Future.value();
    return _initFut ??= _loadOrGenerate().whenComplete(() => _initFut = null);
  }

  Future<void> _loadOrGenerate() async {
    // 1. Try to deserialize from secure storage. v0 → byte-identical raw
    // 32-byte scalar; v1 wrappers can be added later by bumping the key.
    final raw = await _cache.getRaw(kDeviceX25519PrivCacheKey);
    if (raw != null && raw.isNotEmpty) {
      try {
        final priv = base64Url.decode(_padB64(raw));
        if (priv.length == 32) {
          final keyPair = await _x25519.newKeyPairFromSeed(priv);
          final pub = await keyPair.extractPublicKey();
          _priv = Uint8List.fromList(priv);
          _pub = Uint8List.fromList(pub.bytes);
          return;
        }
        // Fall through to regenerate on length mismatch (corrupted blob).
      } catch (_) {
        // Same — corrupted base64 → regenerate.
      }
    }

    // 2. Generate fresh. `newKeyPair()` internally seeds with secure random;
    // we then round-trip through `extractPrivateKeyBytes()` to grab the
    // scalar we'll persist.
    final keyPair = await _x25519.newKeyPair();
    final privBytes = Uint8List.fromList(await keyPair.extractPrivateKeyBytes());
    final pub = await keyPair.extractPublicKey();
    final pubBytes = Uint8List.fromList(pub.bytes);

    // 3. Persist. b64url(no-pad) so the secure-storage values stay ASCII-safe
    // across platform backends that sometimes choke on raw bytes.
    await _cache.putRaw(
      kDeviceX25519PrivCacheKey,
      base64Url.encode(privBytes).replaceAll('=', ''),
    );

    _priv = privBytes;
    _pub = pubBytes;
  }

  static String _padB64(String s) {
    final pad = (4 - s.length % 4) % 4;
    return s.padRight(s.length + pad, '=');
  }
}
