// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Concrete [JwePayloadDecryptor] used by v2 / Vanaheim. Thin adapter that
/// pulls the device X25519 scalar out of the [CryptographyDeviceKeypairProvider]
/// and hands it to [JweCodec.decryptCompact] with the strict alg/enc
/// allowlist enforced.
///
/// There is exactly one production decryptor in v2. v1 shipped a "no-op"
/// stub plus an interface for products to plug their own; v2 ships the
/// concrete impl and makes it required via [VanaheimConfig.jweDecryptor].
/// Products that don't want JWE pick a JWS-allowed route from
/// `route_policy.dart` and never see this class.
library;

import 'package:cryptography/cryptography.dart';

import 'device_keypair.dart';
import 'jwe.dart';
import 'jwe_codec.dart';

/// Decrypts L2→L1 (and downstream L3→L2→L1) compact JWE responses.
///
/// The allowlist is hard-coded to `ECDH-ES` / `A256GCM` and enforced
/// BEFORE any crypto runs. Anything else — including a downgrade to
/// v1's `ECDH-ES+A256KW` — surfaces as [JweDecryptionFailedException]
/// without exposing oracle behaviour.
class CryptographyJweDecryptor implements JwePayloadDecryptor {
  final CryptographyDeviceKeypairProvider _keypair;
  final JweAlgorithmAllowlist _allowlist;

  CryptographyJweDecryptor({
    required CryptographyDeviceKeypairProvider keypair,
    JweAlgorithmAllowlist allowlist = const JweAlgorithmAllowlist(),
  })  : _keypair = keypair,
        _allowlist = allowlist;

  @override
  Future<String> decrypt(String jwe) async {
    final privBytes = await _keypair.extractPrivateKeyBytes();
    final result = await JweCodec.decryptCompact(
      jwe: jwe,
      devicePrivBytes: privBytes,
      allowlist: _allowlist,
    );
    // The plaintext is the inner JWS (UTF-8 ASCII string per RFC 7519).
    // [JwtVerifier] re-parses it; we don't validate the signature here.
    return String.fromCharCodes(result.plaintext);
  }
}

// Re-export Cryptography's SimplePublicKey under our prefix to keep host
// products from having to add the cryptography dep directly when wiring
// L2RecipientKey → SimplePublicKey for the codec's encrypt path. Pure
// convenience — the import path is `package:vanaheim/...`.
typedef RecipientPublicKey = SimplePublicKey;
