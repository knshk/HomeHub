// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';
import 'dart:typed_data';

import 'package:ed25519_edwards/ed25519_edwards.dart' as ed;

import '../exceptions.dart';
import '../models.dart';

/// Verifies an Ed25519-signed JWT and returns the decoded claims.
///
/// Throws exactly one of:
///   * [LicenseExpiredException] — JWT was structurally valid and signature
///     was correct, but `exp` (with clock-skew tolerance) is in the past.
///     The caller can fall back to offline grace or trigger a refresh.
///   * [JwtVerificationException] — anything else: malformed JWT, wrong alg,
///     missing/wrong-typed claim, signature mismatch, future-dated `nbf`,
///     issuer/audience mismatch. The cached JWT must be discarded.
///
/// NEVER returns silently with an unverified token.
class JwtVerifier {
  static LicenseJwtClaims verifyAndDecode({
    required String jwt,
    required Uint8List publicKey,
    required String expectedIssuer,
    required String expectedAudience,
    Duration clockSkew = const Duration(minutes: 5),
    DateTime? now,
  }) {
    final parts = jwt.split('.');
    if (parts.length != 3) {
      throw JwtVerificationException('Malformed JWT (expected 3 parts)');
    }
    final headerBytes = _b64UrlDecode(parts[0]);
    final claimsBytes = _b64UrlDecode(parts[1]);
    final sigBytes = _b64UrlDecode(parts[2]);

    final header = _decodeJson(headerBytes, 'header');
    final claimsMap = _decodeJson(claimsBytes, 'claims');

    if (header['alg'] != 'EdDSA') {
      throw JwtVerificationException('Unsupported alg: ${header['alg']}');
    }
    final kid = header['kid'];
    if (kid is! String || kid.isEmpty) {
      throw JwtVerificationException('JWT header missing kid');
    }

    final signingInput =
        Uint8List.fromList(utf8.encode('${parts[0]}.${parts[1]}'));
    if (!_verifyEd25519(signingInput, sigBytes, publicKey)) {
      throw JwtVerificationException('Ed25519 signature verification failed');
    }

    // All claim extraction goes through explicit-typed helpers so a missing
    // or wrong-typed field surfaces as JwtVerificationException, never a
    // raw CastError (per audit finding on sub/acc/tier/aud).
    final iss = _requireString(claimsMap, 'iss');
    final aud = _requireString(claimsMap, 'aud');
    if (iss != expectedIssuer) {
      throw JwtVerificationException(
          'Unexpected iss: $iss (want $expectedIssuer)');
    }
    if (aud != expectedAudience) {
      throw JwtVerificationException(
          'Unexpected aud: $aud (want $expectedAudience)');
    }

    final nowMs = (now ?? DateTime.now().toUtc()).millisecondsSinceEpoch;
    final skewMs = clockSkew.inMilliseconds;
    final exp = _requireInt(claimsMap, 'exp');
    final nbf = _optInt(claimsMap, 'nbf');

    // EXPIRY is a distinct category from structural/signature failure.
    // Throwing LicenseExpiredException lets the caller (LicenseClient) emit
    // LicenseStateChangeKind.expired without conflating it with "cached JWT
    // is compromised / must clear cache."
    if (nowMs > exp * 1000 + skewMs) {
      throw LicenseExpiredException('Token expired');
    }
    if (nbf > 0 && nowMs + skewMs < nbf * 1000) {
      throw JwtVerificationException('Token not yet valid');
    }

    // Forward-compat claim extraction: cfg, cfg_v, roles, org_id, org_role,
    // prefs_v, locale. ALL optional — missing → safe defaults. This is the
    // Day-1 SDK contract: backend may roll out claims without an SDK bump,
    // SDK silently ignores anything it doesn't recognize.
    return LicenseJwtClaims(
      issuer: iss,
      licenseId: _requireString(claimsMap, 'sub'),
      productId: aud,
      accountId: _requireString(claimsMap, 'acc'),
      tier: _requireString(claimsMap, 'tier'),
      entitlements: _optMap(claimsMap, 'ent'),
      entitlementsVersion: (claimsMap['ev'] as num?)?.toInt() ?? 0,
      config: _optMap(claimsMap, 'cfg'),
      configVersion: (claimsMap['cfg_v'] as num?)?.toInt() ?? 0,
      roles: _optStringList(claimsMap, 'roles'),
      orgId: _optString(claimsMap, 'org_id'),
      orgRole: _optString(claimsMap, 'org_role'),
      preferencesVersion: (claimsMap['prefs_v'] as num?)?.toInt() ?? 0,
      locale: _optString(claimsMap, 'locale'),
      issuedAt: DateTime.fromMillisecondsSinceEpoch(
          _optInt(claimsMap, 'iat') * 1000,
          isUtc: true),
      notBefore: DateTime.fromMillisecondsSinceEpoch(nbf * 1000, isUtc: true),
      expiresAt: DateTime.fromMillisecondsSinceEpoch(exp * 1000, isUtc: true),
      kid: kid,
    );
  }

  /// Returns the string at [key] if present and non-empty, else null.
  /// Wrong-typed values silently fall back to null (forward-compat: a future
  /// claim shape change won't break the verifier).
  static String? _optString(Map<String, dynamic> m, String key) {
    final v = m[key];
    return v is String && v.isNotEmpty ? v : null;
  }

  /// Returns the Map at [key] coerced to `Map<String, dynamic>`. Wrong-typed
  /// or missing values silently fall back to an empty const map — never
  /// throw a CastError. Used for cfg + ent so a backend shape change can't
  /// break the verifier (forward-compat for the day-1 SDK contract).
  static Map<String, dynamic> _optMap(Map<String, dynamic> m, String key) {
    final v = m[key];
    if (v is! Map) return const {};
    return v.cast<String, dynamic>();
  }

  /// Returns a list of non-empty strings at [key], filtering anything that
  /// isn't a string. Empty list on missing/wrong-typed value.
  static List<String> _optStringList(Map<String, dynamic> m, String key) {
    final v = m[key];
    if (v is! List) return const [];
    final out = <String>[];
    for (final e in v) {
      if (e is String && e.isNotEmpty) out.add(e);
    }
    return List.unmodifiable(out);
  }

  static Map<String, dynamic> _decodeJson(Uint8List bytes, String kind) {
    try {
      return jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
    } catch (e) {
      throw JwtVerificationException('Invalid JSON in JWT $kind: $e');
    }
  }

  static Uint8List _b64UrlDecode(String s) {
    final pad = (4 - s.length % 4) % 4;
    final normalized = s.padRight(s.length + pad, '=');
    return base64Url.decode(normalized);
  }

  static String _requireString(Map<String, dynamic> m, String key) {
    final v = m[key];
    if (v is! String || v.isEmpty) {
      throw JwtVerificationException(
          'JWT claim "$key" missing or not a non-empty string');
    }
    return v;
  }

  static int _requireInt(Map<String, dynamic> m, String key) {
    final v = m[key];
    if (v is! num) {
      throw JwtVerificationException(
          'JWT claim "$key" missing or not a number');
    }
    return v.toInt();
  }

  static int _optInt(Map<String, dynamic> m, String key) {
    final v = m[key];
    return v is num ? v.toInt() : 0;
  }

  static bool _verifyEd25519(
      Uint8List message, Uint8List signature, Uint8List publicKey) {
    if (publicKey.length != 32 || signature.length != 64) return false;
    return ed.verify(ed.PublicKey(publicKey), message, signature);
  }
}
