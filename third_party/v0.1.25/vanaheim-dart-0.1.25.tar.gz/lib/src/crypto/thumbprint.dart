// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' show Sha256;

import 'jwe.dart' show DeviceKeypairProvider;

/// Computes a stable device-pubkey thumbprint to use as JWE `apu` (PartyUInfo).
/// Per the v2 envelope spec it's a SHA-256 of the raw 32-byte X25519 pubkey,
/// base64url-no-pad. Cached lazily — the keypair provider memoizes its pub.
///
/// Mirrors Swift's `deviceX25519PubThumbprint(_:)` in
/// `sdk/swift/LicenseStoreSDK/Sources/LicenseStoreSDK/Crypto/Thumbprint.swift`.
/// Both SDKs MUST produce byte-for-byte identical output for the same X25519
/// pubkey so the AAD bound into a JWE matches what the server cross-checks no
/// matter which SDK encrypted the envelope. The cross-SDK lock-in vectors live
/// in `test/thumbprint_test.dart` (Dart) and `Tests/.../ThumbprintTests.swift`
/// (Swift) — both pin the same byte inputs to the same expected b64url-SHA256
/// outputs so any drift in either encoder fails CI loudly.
Future<String> devicePubThumbprint(DeviceKeypairProvider kp) async {
  final pub = await kp.getPublicKey();
  return pubKeyThumbprint(pub);
}

/// Synchronous-ish helper that operates directly on the raw 32-byte pubkey.
/// Curve-agnostic by design: the spec defines the thumbprint as
/// `b64url(sha256(rawPubBytes))` regardless of which Curve25519 family the
/// caller is hashing (X25519 ECDH pub, Ed25519 signing pub, etc.). Useful in
/// unit tests + regression fixtures where the caller already has the bytes
/// in hand (e.g. cross-SDK lock-in vectors).
Future<String> pubKeyThumbprint(List<int> pubKey) async {
  final digest = await Sha256().hash(pubKey);
  return base64Url.encode(digest.bytes).replaceAll('=', '');
}

/// Convenience overload for callers that already hold the bytes as a
/// `Uint8List`. Identical math; saves a copy.
Future<String> pubKeyThumbprintBytes(Uint8List pubKey) =>
    pubKeyThumbprint(pubKey);
