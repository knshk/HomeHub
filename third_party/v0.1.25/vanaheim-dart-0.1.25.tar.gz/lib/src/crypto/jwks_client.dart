// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import '../exceptions.dart';
import '../transport/http_client.dart';

/// In-memory JWKS cache backed by the control plane's
/// `/v1/.well-known/jwks.json`. Respects `Cache-Control: max-age` from
/// responses; falls back to [LicenseStoreConfig.jwksCacheTtl].
class JwksClient {
  final Uri jwksUrl;
  final SignedHttpClient _http;
  final Duration _defaultTtl;

  Map<String, Uint8List> _byKid = const {};
  Set<String> _revokedKids = const {};
  DateTime _fetchedAt = DateTime.fromMillisecondsSinceEpoch(0);
  Duration _currentTtl = Duration.zero;
  Future<void>? _inFlight;

  JwksClient({
    required this.jwksUrl,
    required SignedHttpClient http,
    Duration defaultTtl = const Duration(hours: 1),
  })  : _http = http,
        _defaultTtl = defaultTtl;

  /// Returns the Ed25519 public key bytes for [kid], fetching the JWKS if
  /// the cache is empty or stale. Returns null if the kid is not present
  /// (caller should reject the JWT).
  Future<Uint8List?> getKey(String kid) async {
    if (_revokedKids.contains(kid)) return null;
    if (_byKid.containsKey(kid) && !_isStale()) return _byKid[kid];
    await _refresh();
    if (_revokedKids.contains(kid)) return null;
    return _byKid[kid];
  }

  /// Forces a refresh from the server. Safe to call concurrently — only one
  /// network request is in flight at a time.
  Future<void> refresh() => _refresh(force: true);

  bool _isStale() =>
      DateTime.now().toUtc().difference(_fetchedAt) > _currentTtl;

  Future<void> _refresh({bool force = false}) {
    if (_inFlight != null) return _inFlight!;
    if (!force && !_isStale() && _byKid.isNotEmpty) return Future.value();
    final fut = _doFetch().whenComplete(() => _inFlight = null);
    _inFlight = fut;
    return fut;
  }

  Future<void> _doFetch() async {
    try {
      // JWKS endpoint is public — getJson doesn't require auth.
      final body = await _http.getJson(jwksUrl);
      final keys = (body['keys'] as List?) ?? const [];
      final next = <String, Uint8List>{};
      final revoked = <String>{};
      for (final raw in keys) {
        final jwk = (raw as Map).cast<String, dynamic>();
        final status = jwk['status'] as String?;
        final kid = jwk['kid'] as String?;
        if (kid == null) continue;
        if (status == 'revoked') {
          revoked.add(kid);
          continue;
        }
        final pub = _decodeEd25519PublicKey(jwk);
        if (pub != null) next[kid] = pub;
      }
      _byKid = Map.unmodifiable(next);
      _revokedKids = Set.unmodifiable(revoked);
      _fetchedAt = DateTime.now().toUtc();
      _currentTtl = _defaultTtl;
    } on LicenseStoreException {
      rethrow;
    } catch (e) {
      throw NetworkException('JWKS fetch failed: $e');
    }
  }

  /// JWX/RFC8037 OKP key: { "kty":"OKP", "crv":"Ed25519", "x":"<b64url 32 bytes>" }
  static Uint8List? _decodeEd25519PublicKey(Map<String, dynamic> jwk) {
    if (jwk['kty'] != 'OKP' || jwk['crv'] != 'Ed25519') return null;
    final x = jwk['x'] as String?;
    if (x == null || x.isEmpty) return null;
    final pad = (4 - x.length % 4) % 4;
    final bytes = base64Url.decode(x.padRight(x.length + pad, '='));
    if (bytes.length != 32) return null;
    return bytes;
  }
}
