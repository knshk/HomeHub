// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:typed_data';

import '../exceptions.dart';

/// Token format detected from the wire.
///
/// JWS is the day-1 shape (3 segments, signed-but-readable). JWE is the
/// Phase 5 / 2A.5 confidentiality shape (5 segments) — backend can flip
/// to it per-product without an SDK bump as long as the consuming product
/// has wired up a [JwePayloadDecryptor] and [DeviceKeypairProvider].
enum LicenseTokenFormat {
  /// `header.claims.signature` — Ed25519 signed JWS. Default today.
  jws,

  /// `header.encrypted_key.iv.ciphertext.tag` — JWE wrapping an inner JWS.
  /// SDK decrypts the wrapper, then verifies the inner JWS normally.
  jwe,
}

/// Inspects a compact JWT string and returns its format. Does NOT verify
/// anything — purely a structural check.
LicenseTokenFormat detectTokenFormat(String token) {
  final dotCount = token.codeUnits.where((c) => c == 0x2e).length;
  if (dotCount == 4) return LicenseTokenFormat.jwe;
  return LicenseTokenFormat.jws;
}

/// Pluggable decryptor invoked when the SDK receives a JWE-wrapped token.
/// Returns the inner JWS string to be verified by the normal JwtVerifier.
///
/// Day-1 contract: the SDK does NOT ship a default implementation. Products
/// that need JWE confidentiality wire up a concrete decryptor (e.g. backed
/// by `package:cryptography` for X25519 ECDH-ES + A256GCM) and pass it via
/// `LicenseStoreConfig.jweDecryptor`. Backend may stay on JWS indefinitely
/// for products that don't need it.
abstract class JwePayloadDecryptor {
  /// Given a JWE compact-serialization string, decrypts and returns the
  /// inner JWS string. Implementations MUST:
  ///   * verify the JWE header `enc` and `alg` are in an allowlist
  ///     (default policy: `ECDH-ES+A256GCM` only)
  ///   * use the device private key from a `DeviceKeypairProvider`
  ///   * surface failures via [JweDecryptionFailedException]
  Future<String> decrypt(String jwe);
}

/// Generates / accesses a per-device X25519 keypair used as the JWE
/// recipient key. Day-1 SDK contract: this is OPTIONAL. When not provided
/// the SDK skips sending a device public key in the activate payload.
///
/// Implementations should:
///   * generate the keypair once and persist the PRIVATE key in
///     Keychain / Keystore with non-extractable flag where the platform
///     allows it (Secure Enclave on iOS; StrongBox-backed Keystore on
///     Android API 28+; DPAPI on Windows; libsecret on Linux)
///   * expose only the PUBLIC key to the SDK
///   * be idempotent — calling `getPublicKey()` multiple times returns
///     the same key
abstract class DeviceKeypairProvider {
  /// Returns the X25519 public key as 32 raw bytes (Curve25519 standard).
  /// The SDK includes this in the activate payload as base64url-encoded
  /// `device_pubkey`.
  Future<Uint8List> getPublicKey();
}

// v2 / Vanaheim: `NoDeviceKeypairProvider` (a no-op stub from v1 used as a
// "no JWE wanted" sentinel) is deleted. The JWE-required vs JWS-allowed
// route table is hard-coded now and JWE-required is the default; every
// device MUST enroll an X25519 pubkey with L2 on first boot. Products
// pass `CryptographyDeviceKeypairProvider(cache: ...)` from
// `device_keypair.dart`. The interface above stays so tests and alternate
// secure backings can substitute their own impl.

/// Thrown when the SDK receives a JWE-wrapped token but no
/// [JwePayloadDecryptor] is configured.
class JweDecryptionRequiredException extends JwtVerificationException {
  JweDecryptionRequiredException()
      : super(
            'Server returned a JWE-wrapped token but no JwePayloadDecryptor '
            'is configured. Set LicenseStoreConfig.jweDecryptor or have your '
            'backend disable JWE for this product.');
}

/// Thrown when decryption fails (wrong key, wrong alg, malformed JWE, etc.).
class JweDecryptionFailedException extends JwtVerificationException {
  JweDecryptionFailedException(super.message);
}
