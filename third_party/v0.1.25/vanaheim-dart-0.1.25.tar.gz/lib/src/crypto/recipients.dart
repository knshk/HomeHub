// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// L2 recipient key — single-recipient model used by the v2 / Vanaheim
/// codec. The concrete [L2RecipientKey] class itself lives in
/// `transport/l2_keys_client.dart` alongside the network client that
/// fetches it; this file is the crypto-layer re-export plus the
/// secure-cache key constant.
///
/// v1 had a plural `RecipientPublicKeys` carrying both an L2 kid AND an
/// L3 (Bifrost) kid for the General-JSON two-recipient encoder. v2 deletes
/// that — the SDK never wraps to L3 directly; Alfheim does the L2→L3 hop.
/// Cache key is bumped from `recipients_v1` to [kL2RecipientCacheKey] so a
/// v1→v2 upgrade can never read a stale plural blob and fan out to two
/// kids.
library;

export '../transport/l2_keys_client.dart' show L2RecipientKey;

/// Secure-cache slot for the persisted L2 recipient snapshot. Versioned so
/// any future shape change can land without colliding with on-disk blobs.
/// Bumped from v1's `recipients_v1` per the v2 single-recipient collapse.
const String kL2RecipientCacheKey = 'l2_recipient_v1';
