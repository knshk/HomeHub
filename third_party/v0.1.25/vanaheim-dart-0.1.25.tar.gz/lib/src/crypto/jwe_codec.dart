// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Single-recipient compact JWE codec (RFC 7516 §5 + RFC 7518 §4.6).
///
/// v2 / Vanaheim — there is exactly **one** code path:
///
///   * alg = `ECDH-ES`      (direct ECDH-ES; no AES key wrap)
///   * enc = `A256GCM`      (256-bit AES-GCM with 12-byte IV / 16-byte tag)
///   * curve = X25519       (Curve25519, 32 raw bytes per key)
///   * kdf  = ConcatKDF     (NIST SP 800-56A §5.8.1) — derives the CEK
///                          directly from the X25519 shared secret. No A256KW.
///
/// The two-recipient General-JSON encoder that lived in v1 (`encryptForRecipients`)
/// is gone. There is no shared CEK across recipients. There is no AES key wrap.
/// There is no fallback to JWS. Callers that need plaintext must pick a
/// JWS-allowed route from [RouteConfidentiality] / `route_policy.dart`.
///
/// This file owns only the crypto primitives: header construction, ConcatKDF,
/// X25519 shared-secret derivation, AES-GCM encrypt/decrypt, compact
/// serialization. AAD construction (`<project_id>|<route_path>|<request_id>`)
/// is delegated to [JweAadContext] which produces both the header fields and
/// the AAD bytes per RFC 7516 §5.1 — i.e. ASCII(b64url(protected_header)).
///
/// `dart analyze` clean. No `dart:io`, no `dart:ffi`, no platform channels —
/// pure `package:cryptography` so the same source compiles for Flutter mobile
/// (iOS/Android), Flutter desktop, and Flutter web.
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

import 'jwe.dart';

/// Inputs that go into the JWE protected header AND into the AAD chain.
///
/// Per RFC 7516 §5.1, `aad = ASCII(b64url(protected_header))`. So as long as
/// the custom claims (`project_id`, `route_path`, `request_id`, `apu`, `apv`)
/// are inside the protected header, they're cryptographically bound to the
/// ciphertext for free — the AAD is just the b64url-encoded header bytes.
///
/// Callers construct this once per request; the codec serializes it into the
/// header, computes the AAD, and never touches the fields again.
class JweAadContext {
  /// Stable identifier for the sender — for L1→L2 this is the device pubkey
  /// thumbprint (SHA-256 of the raw 32-byte X25519 pub, b64url-encoded). Goes
  /// into the JWE `apu` header (RFC 7518 §4.6.1.2).
  final String senderId;

  /// Stable identifier for the recipient — for L1→L2 this is the L2 enc-key
  /// kid (from `/.well-known/lcs-keys`). Goes into `apv` (§4.6.1.3).
  final String recipientId;

  /// Tenant / product project identifier. Mirrors `X-LS-Project-Id` header.
  final int projectId;

  /// Logical HTTP route (e.g. `/v1/account/me`). Mirrors the request line.
  final String routePath;

  /// UUIDv7 the client emitted in `X-LS-Request-Id`. Single-use; required.
  final String requestId;

  const JweAadContext({
    required this.senderId,
    required this.recipientId,
    required this.projectId,
    required this.routePath,
    required this.requestId,
  });
}

/// Result of [JweCodec.decryptCompact] — the recovered plaintext (inner JWS
/// bytes for L1→L2 responses) plus the decoded protected header so the caller
/// can cross-check `apu`/`apv`/`project_id`/`request_id` against its own
/// expectations.
class JweDecryptionResult {
  final Uint8List plaintext;
  final Map<String, dynamic> header;
  const JweDecryptionResult({required this.plaintext, required this.header});
}

/// Allowlist enforced before any crypto runs.
///
/// v2 is strict: `alg` must be `ECDH-ES`, `enc` must be `A256GCM`. Anything
/// else — including `ECDH-ES+A256KW` from v1, or `RSA-OAEP` from a malicious
/// downgrade — surfaces as [JweDecryptionFailedException] BEFORE the codec
/// touches the ciphertext.
class JweAlgorithmAllowlist {
  final Set<String> algs;
  final Set<String> encs;
  const JweAlgorithmAllowlist({
    this.algs = const {'ECDH-ES'},
    this.encs = const {'A256GCM'},
  });
}

/// Stateless codec. There is no init step, no key cache — every call
/// generates a fresh ephemeral X25519 keypair. Recipients never see `epk`
/// for more than the lifetime of one HTTP request.
class JweCodec {
  // Curve / kid constants. Tied to the v2 envelope shape; if any of these
  // change the recipients' service-side allowlist must change in lockstep.
  static const _kCurve = 'X25519';
  static const _kKty = 'OKP';
  static const _kAlg = 'ECDH-ES';
  static const _kEnc = 'A256GCM';
  static const _kTyp = 'lcs+jwe';
  static const _kLcsVersion = 2;

  // AES-GCM with 12-byte IV (RFC 7518 §5.3) and 16-byte tag (RFC 5116 §5.2).
  static final _aesGcm = AesGcm.with256bits();
  // X25519 (RFC 7748). Shared secret is 32 bytes.
  static final _x25519 = X25519();

  /// Encrypts [innerJwsBytes] (the device-signed inner JWS, as raw UTF-8
  /// bytes — typically `header.claims.signature` ASCII) for a single
  /// recipient, returning a 5-segment compact JWE string.
  ///
  /// [recipientPub] must be a 32-byte X25519 public key. [recipientKid] is
  /// the L2 enc-key kid from `/.well-known/lcs-keys`. [aad] supplies the
  /// custom header claims (`project_id` / `route_path` / `request_id`)
  /// plus `apu`/`apv` — all bound to the ciphertext automatically via the
  /// b64url-encoded header AAD per RFC 7516 §5.1.
  ///
  /// Throws [JweDecryptionFailedException] (reused as the codec's only
  /// runtime exception) if the recipient key is the wrong length / type or
  /// if the underlying cryptography stack rejects the inputs.
  static Future<String> encryptForRecipient({
    required Uint8List innerJwsBytes,
    required SimplePublicKey recipientPub,
    required String recipientKid,
    required JweAadContext aad,
  }) async {
    if (recipientPub.type != KeyPairType.x25519) {
      throw JweDecryptionFailedException(
          'recipient pubkey is not X25519 (got ${recipientPub.type})');
    }
    if (recipientPub.bytes.length != 32) {
      throw JweDecryptionFailedException(
          'recipient pubkey must be 32 bytes, got ${recipientPub.bytes.length}');
    }

    // 1. Fresh ephemeral X25519 keypair — NEVER cached, NEVER reused.
    final epk = await _x25519.newKeyPair();
    final epkPub = await epk.extractPublicKey();

    // 2. Build the protected header. Order matters only insofar as the
    // recipient must decode it as JSON — we don't pin canonical key order
    // because the AAD is the b64url of whatever bytes we emit here, and the
    // recipient re-uses those bytes verbatim.
    final headerMap = <String, dynamic>{
      'alg': _kAlg,
      'enc': _kEnc,
      'kid': recipientKid,
      'epk': {
        'kty': _kKty,
        'crv': _kCurve,
        'x': _b64UrlEncodeNoPad(Uint8List.fromList(epkPub.bytes)),
      },
      'apu': aad.senderId,
      'apv': aad.recipientId,
      'project_id': aad.projectId,
      'route_path': aad.routePath,
      'request_id': aad.requestId,
      'typ': _kTyp,
      'lcs_v': _kLcsVersion,
    };
    final headerJsonBytes = Uint8List.fromList(utf8.encode(jsonEncode(headerMap)));
    final protectedB64 = _b64UrlEncodeNoPad(headerJsonBytes);

    // 3. Derive the CEK via direct ECDH-ES → ConcatKDF (RFC 7518 §4.6).
    final cekBytes = await _deriveCek(
      myKeyPair: epk,
      peerPub: recipientPub,
      apu: aad.senderId,
      apv: aad.recipientId,
    );

    // 4. AES-GCM encrypt. AAD = ASCII bytes of the b64url-encoded header.
    final cek = SecretKey(cekBytes);
    final aadBytes = ascii.encode(protectedB64);
    final secretBox = await _aesGcm.encrypt(
      innerJwsBytes,
      secretKey: cek,
      aad: aadBytes,
    );

    // 5. Compact serialization: 5 segments.
    //    The "encrypted_key" segment is the empty string for ECDH-ES direct.
    return [
      protectedB64,
      '', // encrypted_key — empty per RFC 7518 §4.6 for direct ECDH-ES.
      _b64UrlEncodeNoPad(Uint8List.fromList(secretBox.nonce)),
      _b64UrlEncodeNoPad(Uint8List.fromList(secretBox.cipherText)),
      _b64UrlEncodeNoPad(Uint8List.fromList(secretBox.mac.bytes)),
    ].join('.');
  }

  /// Decrypts a compact JWE string with the device's X25519 private key.
  ///
  /// [devicePrivBytes] is the 32-byte raw X25519 scalar held in
  /// [DeviceKeypairProvider]'s secure-cache slot. The codec rebuilds the
  /// keypair via `newKeyPairFromSeed` — `package:cryptography` derives the
  /// matching pubkey deterministically, so the caller never has to persist
  /// both halves.
  ///
  /// [allowlist] enforces alg/enc BEFORE any crypto runs. Throws
  /// [JweDecryptionFailedException] on anything off-allowlist, malformed
  /// segments, or MAC mismatch.
  static Future<JweDecryptionResult> decryptCompact({
    required String jwe,
    required Uint8List devicePrivBytes,
    JweAlgorithmAllowlist allowlist = const JweAlgorithmAllowlist(),
  }) async {
    final parts = jwe.split('.');
    if (parts.length != 5) {
      throw JweDecryptionFailedException(
          'malformed JWE: expected 5 segments, got ${parts.length}');
    }

    final headerBytes = _b64UrlDecode(parts[0]);
    final encryptedKey = parts[1]; // must be empty for ECDH-ES direct
    final iv = _b64UrlDecode(parts[2]);
    final ciphertext = _b64UrlDecode(parts[3]);
    final tag = _b64UrlDecode(parts[4]);

    Map<String, dynamic> header;
    try {
      header = (jsonDecode(utf8.decode(headerBytes)) as Map).cast<String, dynamic>();
    } catch (e) {
      throw JweDecryptionFailedException('invalid JWE header JSON: $e');
    }

    // Allowlist FIRST. Cheap rejection before we touch the asymmetric path.
    final alg = header['alg'];
    final enc = header['enc'];
    if (alg is! String || !allowlist.algs.contains(alg)) {
      throw JweDecryptionFailedException('disallowed alg: $alg');
    }
    if (enc is! String || !allowlist.encs.contains(enc)) {
      throw JweDecryptionFailedException('disallowed enc: $enc');
    }
    if (encryptedKey.isNotEmpty) {
      // ECDH-ES direct: encrypted_key MUST be empty (RFC 7518 §4.6).
      throw JweDecryptionFailedException(
          'encrypted_key must be empty for ECDH-ES direct');
    }

    // Extract epk → SimplePublicKey.
    final epkMap = header['epk'];
    if (epkMap is! Map ||
        epkMap['kty'] != _kKty ||
        epkMap['crv'] != _kCurve ||
        epkMap['x'] is! String) {
      throw JweDecryptionFailedException(
          'invalid or missing epk header (need OKP/X25519/x)');
    }
    final epkPubBytes = _b64UrlDecode(epkMap['x'] as String);
    if (epkPubBytes.length != 32) {
      throw JweDecryptionFailedException(
          'epk.x must be 32 bytes, got ${epkPubBytes.length}');
    }
    final epkPub =
        SimplePublicKey(epkPubBytes, type: KeyPairType.x25519);

    if (devicePrivBytes.length != 32) {
      throw JweDecryptionFailedException(
          'device priv must be 32 bytes, got ${devicePrivBytes.length}');
    }

    // Rebuild our keypair from the persisted seed. `cryptography` regenerates
    // the matching pub bytes deterministically — no second secret to store.
    final myKeyPair = await _x25519.newKeyPairFromSeed(devicePrivBytes);

    final apu = (header['apu'] as String?) ?? '';
    final apv = (header['apv'] as String?) ?? '';

    final cekBytes = await _deriveCek(
      myKeyPair: myKeyPair,
      peerPub: epkPub,
      apu: apu,
      apv: apv,
    );
    final cek = SecretKey(cekBytes);

    final aadBytes = ascii.encode(parts[0]);
    final secretBox = SecretBox(
      ciphertext,
      nonce: iv,
      mac: Mac(tag),
    );

    try {
      final clear = await _aesGcm.decrypt(
        secretBox,
        secretKey: cek,
        aad: aadBytes,
      );
      return JweDecryptionResult(
        plaintext: Uint8List.fromList(clear),
        header: header,
      );
    } on SecretBoxAuthenticationError {
      throw JweDecryptionFailedException(
          'AES-GCM tag mismatch (wrong key, tampered ciphertext, or AAD mismatch)');
    } catch (e) {
      throw JweDecryptionFailedException('decrypt failed: $e');
    }
  }

  /// Direct ECDH-ES → ConcatKDF (NIST SP 800-56A §5.8.1, mapped per
  /// RFC 7518 §4.6.2). Produces a 256-bit CEK suitable for A256GCM.
  ///
  /// The "AlgorithmID" is `A256GCM` (the `enc` value, NOT the `alg`, because
  /// for direct ECDH-ES the CEK is the agreed-upon symmetric key — §4.6.2).
  /// PartyUInfo / PartyVInfo are the raw UTF-8 bytes of `apu` / `apv` per
  /// §4.6.1.2/3 — already base64url-safe in our envelope, so no further
  /// re-encoding.
  static Future<Uint8List> _deriveCek({
    required SimpleKeyPair myKeyPair,
    required SimplePublicKey peerPub,
    required String apu,
    required String apv,
  }) async {
    final shared = await _x25519.sharedSecretKey(
      keyPair: myKeyPair,
      remotePublicKey: peerPub,
    );
    final z = Uint8List.fromList(await shared.extractBytes());
    if (z.length != 32) {
      throw JweDecryptionFailedException(
          'X25519 shared secret must be 32 bytes, got ${z.length}');
    }

    // ConcatKDF input: counter(32-bit BE) || Z || OtherInfo
    //   OtherInfo = AlgorithmID || PartyUInfo || PartyVInfo || SuppPubInfo
    //   each prefixed with a big-endian 32-bit length.
    //   SuppPubInfo = keyDataLen in bits (256), big-endian 32-bit.
    final algId = utf8.encode(_kEnc); // 'A256GCM'
    final apuBytes = utf8.encode(apu);
    final apvBytes = utf8.encode(apv);

    final otherInfo = BytesBuilder()
      ..add(_uint32BE(algId.length))
      ..add(algId)
      ..add(_uint32BE(apuBytes.length))
      ..add(apuBytes)
      ..add(_uint32BE(apvBytes.length))
      ..add(apvBytes)
      ..add(_uint32BE(256)); // keyDataLen in BITS

    // For a 256-bit CEK we need exactly one SHA-256 block → counter = 1.
    final hashInput = BytesBuilder()
      ..add(_uint32BE(1))
      ..add(z)
      ..add(otherInfo.toBytes());

    final digest = await Sha256().hash(hashInput.toBytes());
    final cek = Uint8List.fromList(digest.bytes);
    if (cek.length != 32) {
      throw JweDecryptionFailedException(
          'ConcatKDF produced ${cek.length} bytes, expected 32');
    }
    return cek;
  }

  static Uint8List _uint32BE(int v) {
    final out = ByteData(4)..setUint32(0, v, Endian.big);
    return out.buffer.asUint8List();
  }

  static String _b64UrlEncodeNoPad(Uint8List bytes) {
    return base64Url.encode(bytes).replaceAll('=', '');
  }

  static Uint8List _b64UrlDecode(String s) {
    final pad = (4 - s.length % 4) % 4;
    return base64Url.decode(s.padRight(s.length + pad, '='));
  }
}
