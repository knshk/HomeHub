// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Hard-coded confidentiality policy. JWE-required is the **default-deny**;
/// JWS-or-plaintext is allowed only on the narrow carve-out below. Both lists
/// live in source — never server-driven — so a backend compromise cannot
/// downgrade a JWE-required route to JWS.
///
/// Must stay in lockstep with the Swift twin in
/// `Sources/Vanaheim/Crypto/RoutePolicy.swift` and the L2 ingress allowlist.
/// CI runs a parity check; if it fails, the failing side ships first and
/// then the other side ratchets to match.
///
/// `isMaterialChangeHint(path)` is BEST-EFFORT TELEMETRY ONLY. The
/// authoritative material-change classification lives server-side in
/// Alfheim's poll of `material_change_registry/current`; the SDK only
/// needs a coarse hint so it can label outgoing telemetry events for
/// dev-time debugging. Do NOT use the hint as a gating signal.
library;

/// Confidentiality category the SDK MUST apply to a request before
/// transmitting. Material change vs hot-path lives orthogonally to this —
/// every confidentiality tier supports both.
enum RouteConfidentiality {
  /// Default. Wrap the body in a single-recipient compact JWE (`ECDH-ES`
  /// + `A256GCM`) to the L2 enc-kid. Device Ed25519 signature on the
  /// inner JWS is also required.
  jweRequired,

  /// Narrow carve-out. Send plain JSON (no JWE wrap). Device signature
  /// not required.
  jwsAllowed,
}

/// The complete JWS-allowed carve-out. Every other route is JWE-required
/// by default-deny. Keep this list short and audited; adding to it is a
/// security review.
///
/// Each entry is a literal-prefix string. The classifier matches case-sensitive
/// against the request path (no query string). Trailing slashes are
/// normalized out of [classify] before the comparison.
const List<String> kJwsAllowedRoutes = <String>[
  // Public splash & catalog hooks (limited fields only — full catalog is JWE).
  '/v1/explore/splash',
  '/v1/catalog/explore',
  // Service metadata.
  '/v1/meta',
  '/healthz',
  '/readyz',
  // Public verifier keys.
  '/v1/.well-known/jwks.json',
  // Status / docs / marketing — all read-only public content.
  '/v1/status/',
  '/v1/docs/',
  '/v1/marketing/',
];

/// Coarse list of route PREFIXES that LIKELY produce material-change events
/// (license issue / tier upgrade / KYC milestone / payment settlement /
/// org membership flips, etc.). Used purely as a telemetry tag — the SDK
/// labels outbound events with `material_change_hint: true|false` so the
/// dev dashboard can pivot. Server-side classification is authoritative.
const List<String> kMaterialChangeHintPrefixes = <String>[
  '/v1/license/issue',
  '/v1/license/upgrade',
  '/v1/license/downgrade',
  '/v1/license/revoke',
  '/v1/license/transfer',
  '/v1/checkout',
  '/v1/payments/',
  '/v1/kyc/',
  '/v1/accreditation/',
  '/v1/esign/',
  '/v1/bank-deposit/',
  '/v1/cap-table/',
  '/v1/org/membership',
  '/v1/account/me/email-change',
  '/v1/security/mfa/',
];

/// Returns the confidentiality tier for [path]. Default-deny → if no
/// JWS-allowed prefix matches, the call MUST be wrapped in JWE.
///
/// Matching is prefix-based but path-segment-aware: `/v1/meta` matches
/// `/v1/meta` and `/v1/meta/something` but NOT `/v1/metadata`. This avoids
/// surprise downgrades from a route that happens to share a leading
/// substring with a JWS-allowed entry.
RouteConfidentiality classify(String path) {
  final normalized = _normalize(path);
  for (final prefix in kJwsAllowedRoutes) {
    if (_matchesPrefix(normalized, prefix)) {
      return RouteConfidentiality.jwsAllowed;
    }
  }
  return RouteConfidentiality.jweRequired;
}

/// Best-effort dev-time tag. NOT a security control. See library doc.
bool isMaterialChangeHint(String path) {
  final normalized = _normalize(path);
  for (final prefix in kMaterialChangeHintPrefixes) {
    if (_matchesPrefix(normalized, prefix)) return true;
  }
  return false;
}

String _normalize(String path) {
  if (path.isEmpty) return '/';
  // Strip query / fragment defensively — callers should pass path only,
  // but the classifier is robust to a stray `?` slipping through.
  final q = path.indexOf('?');
  final f = path.indexOf('#');
  var end = path.length;
  if (q >= 0) end = q < end ? q : end;
  if (f >= 0) end = f < end ? f : end;
  final p = path.substring(0, end);
  if (p.length > 1 && p.endsWith('/')) {
    return p.substring(0, p.length - 1);
  }
  return p;
}

bool _matchesPrefix(String path, String prefix) {
  // Treat the prefix as a trailing-slash-permissive equality:
  //   prefix='/v1/meta'    → matches '/v1/meta' OR '/v1/meta/...'
  //   prefix='/v1/docs/'   → matches '/v1/docs' OR '/v1/docs/...'
  final p = prefix.endsWith('/')
      ? prefix.substring(0, prefix.length - 1)
      : prefix;
  if (path == p) return true;
  return path.startsWith('$p/');
}
