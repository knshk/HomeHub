// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';

/// Computes the HMAC signature the server expects.
///
/// Server reference: internal/auth/hmac.go — verifies
///   HMAC-SHA256(secret, timestamp || "\n" || product || "\n" || body)
class HmacSigner {
  final String productSlug;
  final String sdkSecret;

  HmacSigner({required this.productSlug, required this.sdkSecret});

  /// Returns ( timestamp-string, hex-signature ). Caller attaches these
  /// as X-LS-Timestamp and X-LS-Signature headers (X-LS-Product is the
  /// productSlug).
  ({String timestamp, String signature}) sign(String body) {
    final ts = (DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000).toString();
    final mac = Hmac(sha256, utf8.encode(sdkSecret));
    final sink = mac.convert(_signingInput(ts, productSlug, body));
    return (timestamp: ts, signature: _hex(sink.bytes));
  }

  static List<int> _signingInput(String ts, String product, String body) {
    final out = BytesBuilder(copy: false)
      ..add(utf8.encode(ts))
      ..addByte(0x0a) // "\n"
      ..add(utf8.encode(product))
      ..addByte(0x0a)
      ..add(utf8.encode(body));
    return out.takeBytes();
  }

  static String _hex(List<int> bytes) {
    const alphabet = '0123456789abcdef';
    final out = StringBuffer();
    for (final b in bytes) {
      out.write(alphabet[(b >> 4) & 0xf]);
      out.write(alphabet[b & 0xf]);
    }
    return out.toString();
  }
}
