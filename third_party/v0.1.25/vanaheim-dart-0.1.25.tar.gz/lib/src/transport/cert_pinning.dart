// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:http_certificate_pinning/http_certificate_pinning.dart';

import '../exceptions.dart';

/// Verifies the server cert chain's leaf SPKI matches one of the pinned
/// hashes before making a request. Returns void on success, throws
/// [CertificatePinException] on mismatch.
///
/// Pin format: base64(SHA-256(SubjectPublicKeyInfo)). Two pins should always
/// be active during rotation windows.
///
/// Platform behavior:
///   * mobile / desktop — pinning is enforced if [pinnedSpkiSha256] is non-empty.
///   * web — pinning is SKIPPED. The underlying `http_certificate_pinning`
///     plugin is native-only and will throw MissingPluginException in a
///     browser. Browsers also can't expose the raw cert chain to JS, so
///     pinning isn't implementable there. Web products must rely on HSTS +
///     Certificate Transparency monitoring instead.
class CertificatePinner {
  final List<String> pinnedSpkiSha256;
  final Duration timeout;

  CertificatePinner({
    required this.pinnedSpkiSha256,
    this.timeout = const Duration(seconds: 5),
  });

  bool get isEnabled => pinnedSpkiSha256.isNotEmpty && !kIsWeb;

  Future<void> verify(String url) async {
    if (kIsWeb) return; // see class doc for rationale
    if (pinnedSpkiSha256.isEmpty) return;
    try {
      final check = await HttpCertificatePinning.check(
        serverURL: url,
        sha: SHA.SHA256,
        allowedSHAFingerprints: pinnedSpkiSha256,
        timeout: timeout.inSeconds,
      );
      if (!check.contains('CONNECTION_SECURE')) {
        throw CertificatePinException('Pin check returned: $check');
      }
    } on CertificatePinException {
      rethrow;
    } catch (e) {
      throw CertificatePinException('Pin check failed: $e');
    }
  }
}
