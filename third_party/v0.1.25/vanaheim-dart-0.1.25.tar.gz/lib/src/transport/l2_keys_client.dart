// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../exceptions.dart';

/// One L2 (Alfheim) recipient key bundle as published by
/// `GET {l2BaseUrl}/.well-known/lcs-keys`.
///
/// v2 collapses v1's two-recipient envelope (Bifrost + L2) to a single
/// recipient (L2 only). L2 forwards the inner device JWS to Bifrost over
/// the L2↔L3 leg — the device never wraps to Bifrost directly.
///
/// Wire shape (single recipient at a time; overlap pair only during rotation):
/// ```json
/// {
///   "kek_version": 7,
///   "x25519": { "kid": "l2-enc-7", "crv": "X25519", "x": "<b64url 32B>" },
///   "ed25519": { "kid": "l2-sig-7", "crv": "Ed25519", "x": "<b64url 32B>" }
/// }
/// ```
class L2RecipientKey {
  /// L2's encryption-key id (goes into `X-LS-Recipient-Kid`, the JWE
  /// header `kid`, and the AAD).
  final String kid;

  /// L2's X25519 public key — 32 raw bytes, the recipient key the device
  /// performs ECDH-ES against. The JWE codec wraps the CEK to this.
  final Uint8List x25519Pub;

  /// L2's Ed25519 signing-key id used to verify the `LCS-L2-Sig` header
  /// on L2-originated material-change responses (the SDK does NOT verify
  /// inner JWSes with this key — those use the JWKS Bifrost keys).
  final String sigKid;

  /// L2's Ed25519 verifying key — 32 raw bytes.
  final Uint8List ed25519Pub;

  /// KEK version published alongside the keys. Mirrored into `X-LS-KEK-V`
  /// on every outbound JWE so L2 can detect stale envelopes.
  final int kekVersion;

  const L2RecipientKey({
    required this.kid,
    required this.x25519Pub,
    required this.sigKid,
    required this.ed25519Pub,
    required this.kekVersion,
  });
}

/// Fetches and caches L2's `/.well-known/lcs-keys` endpoint.
///
/// Cache policy:
///   * 1 h TTL by default (mirrors L2's `Cache-Control: max-age=3600`).
///   * ETag-aware: a refresh after TTL sends `If-None-Match`; a `304`
///     response just extends the freshness window without replacing the
///     in-memory key.
///   * On `PekStaleException` from [SignedHttpClient], the transport calls
///     [forceRefresh] to repoll before the retry.
///   * Single-flight: concurrent callers share one in-flight request.
class L2KeysClient {
  /// `{l2BaseUrl}/.well-known/lcs-keys`. The SDK never talks to Bifrost
  /// directly for recipient keys in v2 — L2 owns its own well-known.
  final Uri url;
  final http.Client _http;
  final Duration _ttl;
  final Duration _timeout;

  L2RecipientKey? _cached;
  String? _etag;
  DateTime _fetchedAt = DateTime.fromMillisecondsSinceEpoch(0);
  Future<L2RecipientKey>? _inFlight;

  L2KeysClient({
    required this.url,
    http.Client? inner,
    Duration ttl = const Duration(hours: 1),
    Duration timeout = const Duration(seconds: 15),
  })  : _http = inner ?? http.Client(),
        _ttl = ttl,
        _timeout = timeout;

  /// Returns the current recipient key, fetching if cold or stale.
  Future<L2RecipientKey> get() {
    final cached = _cached;
    if (cached != null && !_isStale()) return Future.value(cached);
    return _refresh();
  }

  /// Forces a network refresh, bypassing TTL. Called by the transport on
  /// `PekStaleException` (412 `pek_stale` / `X-LS-KEK-V` mismatch).
  Future<L2RecipientKey> forceRefresh() {
    _fetchedAt = DateTime.fromMillisecondsSinceEpoch(0);
    return _refresh();
  }

  /// Drops the cached key. Used in tests and on explicit `clear()`.
  void invalidate() {
    _cached = null;
    _etag = null;
    _fetchedAt = DateTime.fromMillisecondsSinceEpoch(0);
  }

  bool _isStale() =>
      DateTime.now().toUtc().difference(_fetchedAt) > _ttl;

  Future<L2RecipientKey> _refresh() {
    final inFlight = _inFlight;
    if (inFlight != null) return inFlight;
    final fut = _doFetch().whenComplete(() => _inFlight = null);
    _inFlight = fut;
    return fut;
  }

  Future<L2RecipientKey> _doFetch() async {
    final headers = <String, String>{'Accept': 'application/json'};
    final etag = _etag;
    if (etag != null) headers['If-None-Match'] = etag;

    final http.Response res;
    try {
      res = await _http.get(url, headers: headers).timeout(_timeout);
    } on TimeoutException {
      throw NetworkException('l2_keys: timeout');
    } catch (e) {
      throw NetworkException('l2_keys: $e');
    }

    if (res.statusCode == 304) {
      final cached = _cached;
      if (cached == null) {
        // Server claimed Not-Modified but we have nothing — treat as a
        // protocol error and force a clean refetch next call.
        invalidate();
        throw NetworkException(
            'l2_keys: 304 without cached body', statusCode: 304);
      }
      _fetchedAt = DateTime.now().toUtc();
      return cached;
    }
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw NetworkException('l2_keys: ${res.statusCode} ${res.reasonPhrase}',
          statusCode: res.statusCode);
    }

    final Map<String, dynamic> body;
    try {
      body = jsonDecode(res.body) as Map<String, dynamic>;
    } catch (e) {
      throw NetworkException('l2_keys: malformed body: $e');
    }

    final key = _parse(body);
    _cached = key;
    _etag = res.headers['etag'];
    _fetchedAt = DateTime.now().toUtc();
    return key;
  }

  static L2RecipientKey _parse(Map<String, dynamic> body) {
    final kekVersion = (body['kek_version'] as num?)?.toInt();
    final x = (body['x25519'] as Map?)?.cast<String, dynamic>();
    final s = (body['ed25519'] as Map?)?.cast<String, dynamic>();
    if (kekVersion == null || x == null || s == null) {
      throw NetworkException('l2_keys: missing kek_version/x25519/ed25519');
    }
    final xKid = x['kid'] as String?;
    final xPub = _decodeRaw32(x, expectedCrv: 'X25519');
    final sKid = s['kid'] as String?;
    final sPub = _decodeRaw32(s, expectedCrv: 'Ed25519');
    if (xKid == null || xPub == null || sKid == null || sPub == null) {
      throw NetworkException('l2_keys: invalid key fields');
    }
    return L2RecipientKey(
      kid: xKid,
      x25519Pub: xPub,
      sigKid: sKid,
      ed25519Pub: sPub,
      kekVersion: kekVersion,
    );
  }

  /// JWK-style OKP key: `{ "kty":"OKP", "crv":"<expectedCrv>", "x":"<b64url 32B>" }`.
  /// Returns null on any decode/shape error so the caller can produce a
  /// single uniform NetworkException.
  static Uint8List? _decodeRaw32(
    Map<String, dynamic> jwk, {
    required String expectedCrv,
  }) {
    if (jwk['crv'] != expectedCrv) return null;
    final x = jwk['x'] as String?;
    if (x == null || x.isEmpty) return null;
    try {
      final pad = (4 - x.length % 4) % 4;
      final bytes = base64Url.decode(x.padRight(x.length + pad, '='));
      if (bytes.length != 32) return null;
      return bytes;
    } catch (_) {
      return null;
    }
  }

  /// Releases the underlying HTTP client.
  void close() => _http.close();
}
