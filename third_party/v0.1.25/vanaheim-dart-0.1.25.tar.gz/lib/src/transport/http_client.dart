// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../auth/auth_providers.dart';
import '../crypto/jwe.dart' show JweDecryptionFailedException;
import '../exceptions.dart';
import '../storage/secure_cache.dart';
import 'cert_pinning.dart';
import 'headers.dart';
import 'hmac_signer.dart';
import 'l2_keys_client.dart';

/// SecureCache key the SDK uses to remember a successful device enrollment.
/// Cleared on 410 `DEVICE_REVOKED` / `DEVICE_UNENROLLED` so the next
/// `LicenseClient.connect()` re-enrols. Mirrors the v1→v2 rollout doc.
const kDeviceRegisteredMarker = 'device_registered_v1';

/// Classification of a route by [RoutePolicy].
///
/// v2 default-deny is `jweRequired`; the narrow JWS-allowed carve-out is
/// hard-coded in `crypto/route_policy.dart` (TODO-V2-D-08) and is never
/// server-driven (a permissive server response on a JWE-required route
/// is treated as MITM / mis-deploy and rejected, never as a downgrade
/// signal).
enum RouteConfidentiality {
  /// Body MUST be a single-recipient compact JWE wrapping an inner device
  /// JWS. Response MUST carry `X-LS-Confidentiality: jwe`.
  jweRequired,

  /// Body is plaintext JSON. The narrow carve-out: jwks.json, healthz,
  /// docs/marketing read-only, third-party webhooks.
  jwsAllowed,
}

/// Hard-coded route-policy classifier. Implemented by
/// `crypto/route_policy.dart` (TODO-V2-D-08). The transport depends only on
/// the interface so it can be unit-tested without pulling the full route
/// table in.
abstract class RoutePolicy {
  /// Returns the confidentiality requirement for [path]. Implementations
  /// MUST default-deny — any path that doesn't match the JWS-allowed list
  /// returns [RouteConfidentiality.jweRequired].
  RouteConfidentiality classify(String path);
}

/// Single-recipient compact-JWE encoder. Implemented by
/// `crypto/jwe_codec.dart` (TODO-V2-D-01) over `package:cryptography`
/// (X25519 ECDH-ES + A256GCM). The transport doesn't depend on the
/// underlying primitive crate — it only knows the contract.
///
/// Renamed from `JweCodec` in the Wave 10c review to avoid a name clash
/// with the concrete `crypto/jwe_codec.dart#JweCodec` class — the two
/// shared a name but had incompatible signatures (this one is async with
/// raw `Uint8List` recipients, the crypto one is static-method with
/// `SimplePublicKey` recipients via `JweAadContext`). An adapter in
/// `client.dart` bridges the two for production wiring.
abstract class JweTransportCodec {
  /// Wraps [innerJwsBytes] for [recipientPub] under AAD [aad]. The header
  /// MUST contain `kid: recipientKid` and `lcs_v: 2`. Returns the compact
  /// serialization (5 dot-separated base64url segments).
  Future<String> encryptForRecipient({
    required Uint8List recipientPub,
    required String recipientKid,
    required Uint8List innerJwsBytes,
    required Map<String, String> aad,
  });

  /// Reverse of [encryptForRecipient]. Decrypts with the device's X25519
  /// private key and returns the inner JWS bytes. AAD MUST equal what the
  /// server bound (project_id, route_path, request_id).
  Future<Uint8List> decryptForDevice({
    required String compactJwe,
    required Map<String, String> expectedAad,
  });
}

/// Signs the inner device JWS (Ed25519). Implemented by the device-keypair
/// provider (TODO-V2-D-06) — the transport keeps it abstract so tests can
/// inject deterministic signatures.
abstract class DeviceJwsSigner {
  /// Returns the device id (as written to `X-LS-Device-Id`) the SDK
  /// enrolled under. Empty string if not yet enrolled (transport will
  /// short-circuit JWE-required routes pending enrollment).
  String get deviceId;

  /// Returns the current `kid` of the device's Ed25519 signing key — copied
  /// into the inner JWS header so L3 can resolve it in the device registry.
  String get sigKid;

  /// Produces a compact-JWS (3 dot-separated base64url segments) over
  /// [claims] signed with the device private key. Header MUST include
  /// `alg: EdDSA`, `kid: sigKid`, `typ: device+jws`.
  Future<String> signClaims(Map<String, dynamic> claims);
}

/// Verifies the inner JWS embedded inside a JWE response. Implemented by
/// the JWT verifier (TODO-V2-D-09). Returns the parsed claims map. Throws
/// [JwtVerificationException] on signature / kid / expiry failure.
abstract class InnerJwsVerifier {
  /// [compactJws] is the 3-segment inner JWS. [expectedRoute] is the path
  /// the SDK originally called — implementations MUST cross-check the
  /// JWS's `route_path` claim against it and raise
  /// [JweRouteMismatchException] on mismatch.
  Future<Map<String, dynamic>> verify({
    required String compactJws,
    required String expectedRoute,
    required String expectedRequestId,
  });
}

/// Project id surfaced into JWE AAD. Vended by [LicenseClient] which knows
/// it from `LicenseStoreConfig` (TODO-V2-D-04 will move this onto the
/// renamed `VanaheimConfig`). Held as an abstract getter so tests can vary
/// it without rebuilding the transport.
abstract class ProjectIdProvider {
  String get projectId;
}

/// HTTP client for v2 (Vanaheim). On every request it:
///   * generates a UUIDv7 request_id and a 16-byte nonce,
///   * classifies the route via [RoutePolicy],
///   * for JWE-required routes: signs an inner device JWS (Ed25519),
///     encrypts to L2's current X25519 recipient key via [JweTransportCodec], and
///     sends `application/jose+json` with `X-LS-Recipient-Kid`,
///     `X-LS-Device-Id`, `X-LS-Request-Id`, `X-LS-KEK-V`,
///   * for JWS-allowed routes: passes plain JSON through (legacy HMAC
///     headers still attached for the regional API layer),
///   * on response:
///       - if `X-LS-Confidentiality: jwe`, decrypts and verifies the inner
///         JWS, raising [JweRouteMismatchException] on path mismatch,
///       - if the route was JWE-required but the server returned plain
///         JSON (no `X-LS-Confidentiality: jwe` header), raises
///         [JweRequiredButGotJwsException] (fail-closed, no downgrade),
///   * on 412 `pek_stale` / `X-LS-KEK-V` mismatch: refreshes
///     [L2KeysClient] and retries once. Second failure → [PekStaleException],
///   * on 410 `DEVICE_REVOKED` / `DEVICE_UNENROLLED`: clears the
///     `device_registered_v1` SecureCache marker and raises
///     [DeviceRevokedException].
///
/// HMAC signing + Bearer auth + App Check headers are preserved on every
/// request — the JWE envelope is added on TOP of (not in place of) them.
class SignedHttpClient {
  final HmacSigner _signer;
  final AuthTokenProvider _auth;
  final AppCheckTokenProvider _appCheck;
  final CertificatePinner _pinner;
  final http.Client _inner;
  final Duration _timeout;

  // v2 / Vanaheim wiring. All optional so existing tests that don't need
  // JWE-required behaviour can construct a SignedHttpClient with the
  // legacy three providers + pinner only.
  final RoutePolicy? _routePolicy;
  final JweTransportCodec? _jweCodec;
  final DeviceJwsSigner? _deviceSigner;
  final InnerJwsVerifier? _innerVerifier;
  final L2KeysClient? _l2Keys;
  final ProjectIdProvider? _projectIdProvider;
  final SecureCache? _secureCache;
  // v2 / Vanaheim: held but not yet consumed by the transport itself
  // (the codec adapter pulls X25519 bytes through its own path). Kept on
  // the field so the wiring is explicit + future Ed25519 device-signer
  // implementations can read it without another connect-time plumbing
  // change. See Wave 10c review note.
  // ignore: unused_field
  final Object? _deviceKeypairProvider;
  final Random _rng;

  SignedHttpClient({
    required HmacSigner signer,
    required AuthTokenProvider auth,
    required AppCheckTokenProvider appCheck,
    required CertificatePinner pinner,
    http.Client? inner,
    Duration timeout = const Duration(seconds: 15),
    RoutePolicy? routePolicy,
    JweTransportCodec? jweCodec,
    DeviceJwsSigner? deviceSigner,
    InnerJwsVerifier? innerVerifier,
    L2KeysClient? l2Keys,
    ProjectIdProvider? projectIdProvider,
    SecureCache? secureCache,
    Object? deviceKeypairProvider,
    Random? rng,
  })  : _signer = signer,
        _auth = auth,
        _appCheck = appCheck,
        _pinner = pinner,
        _inner = inner ?? http.Client(),
        _timeout = timeout,
        _routePolicy = routePolicy,
        _jweCodec = jweCodec,
        _deviceSigner = deviceSigner,
        _innerVerifier = innerVerifier,
        _l2Keys = l2Keys,
        _projectIdProvider = projectIdProvider,
        _secureCache = secureCache,
        _deviceKeypairProvider = deviceKeypairProvider,
        _rng = rng ?? Random.secure();

  /// Sends a POST and returns the parsed JSON response. JWE wrapping is
  /// applied per [RoutePolicy.classify]. If no [RoutePolicy] was injected,
  /// every call falls back to plain JSON (legacy v0.1 behaviour).
  Future<Map<String, dynamic>> postJson(
    Uri url, {
    required Map<String, dynamic> body,
    bool requireAuth = true,
  }) async {
    final policy = _routePolicy;
    final classification = policy != null
        ? policy.classify(url.path)
        : RouteConfidentiality.jwsAllowed;

    if (classification == RouteConfidentiality.jweRequired) {
      return _postJwe(url, body: body, requireAuth: requireAuth);
    }
    return _postPlain(
      url,
      body: body,
      requireAuth: requireAuth,
      // No route policy => no JWE expectation; plain bodies are fine.
      expectJweResponse: false,
    );
  }

  // ------------------------------------------------------------- plain post

  Future<Map<String, dynamic>> _postPlain(
    Uri url, {
    required Map<String, dynamic> body,
    required bool requireAuth,
    required bool expectJweResponse,
    String? routePath,
  }) async {
    final raw = jsonEncode(body);
    final sig = _signer.sign(raw);
    final requestId = _uuidV7();
    final headers = <String, String>{
      'Content-Type': LsHeaders.json,
      'Accept': LsHeaders.json,
      'X-LS-Product': _signer.productSlug,
      'X-LS-Timestamp': sig.timestamp,
      'X-LS-Signature': sig.signature,
      LsHeaders.requestId: requestId,
    };
    if (requireAuth) {
      headers['Authorization'] = 'Bearer ${await _auth.getIdToken()}';
    }
    final appCheckTok = await _appCheck.getToken();
    if (appCheckTok != null && appCheckTok.isNotEmpty) {
      headers['X-Firebase-AppCheck'] = appCheckTok;
    }

    await _pinner.verify('${url.scheme}://${url.host}');

    final res = await _inner
        .post(url, headers: headers, body: raw)
        .timeout(_timeout,
            onTimeout: () => throw NetworkException('timeout'));

    // If the caller expected a JWE response (i.e. the route is
    // JWE-required) but the server returned plaintext, fail closed — see
    // class doc. We surface this BEFORE the regular decode so even a 2xx
    // plain-JSON body can't slip past.
    if (expectJweResponse) {
      final conf = res.headers[LsHeaders.confidentiality.toLowerCase()];
      if (conf != LsHeaders.confidentialityJwe) {
        throw JweRequiredButGotJwsException(routePath: routePath);
      }
    }
    return _decode(res, routePath: routePath);
  }

  // --------------------------------------------------------------- jwe post

  Future<Map<String, dynamic>> _postJwe(
    Uri url, {
    required Map<String, dynamic> body,
    required bool requireAuth,
  }) async {
    final codec = _jweCodec;
    final signer = _deviceSigner;
    final l2Keys = _l2Keys;
    final projectIdProvider = _projectIdProvider;
    if (codec == null ||
        signer == null ||
        l2Keys == null ||
        projectIdProvider == null) {
      throw LicenseStoreException(
          'Route ${url.path} requires JWE but the SDK was not configured '
          'with a JweTransportCodec / DeviceJwsSigner / L2KeysClient / '
          'projectId. See VanaheimConfig wiring (TODO-V2-D-04..D-09).');
    }

    // First attempt with the currently-cached recipient key. Retry once
    // on pek_stale after forcing a /.well-known/lcs-keys refresh.
    final firstKey = await l2Keys.get();
    try {
      return await _doJweRoundTrip(
        url,
        body: body,
        requireAuth: requireAuth,
        codec: codec,
        signer: signer,
        recipient: firstKey,
        projectId: projectIdProvider.projectId,
      );
    } on PekStaleException catch (_) {
      // Single PEK-refresh retry: re-fetch L2 keys and try once more. If
      // it fails again the second exception propagates unchanged.
      final refreshedKey = await l2Keys.forceRefresh();
      return _doJweRoundTrip(
        url,
        body: body,
        requireAuth: requireAuth,
        codec: codec,
        signer: signer,
        recipient: refreshedKey,
        projectId: projectIdProvider.projectId,
      );
    }
  }

  Future<Map<String, dynamic>> _doJweRoundTrip(
    Uri url, {
    required Map<String, dynamic> body,
    required bool requireAuth,
    required JweTransportCodec codec,
    required DeviceJwsSigner signer,
    required L2RecipientKey recipient,
    required String projectId,
  }) async {
    final routePath = url.path;
    final requestId = _uuidV7();
    final nonce = _nonce16();
    final tsMs = DateTime.now().toUtc().millisecondsSinceEpoch;
    final deviceId = signer.deviceId;

    // 1) Inner device JWS over the body. Claims bind the envelope to the
    //    physical route and nonce so L3 cannot be replayed across paths.
    final innerClaims = <String, dynamic>{
      'iat': tsMs ~/ 1000,
      'nonce': _b64u(nonce),
      'request_id': requestId,
      'route_path': routePath,
      'device_id': deviceId,
      'project_id': projectId,
      'body': body,
    };
    final innerJws = await signer.signClaims(innerClaims);
    final innerJwsBytes = Uint8List.fromList(utf8.encode(innerJws));

    // 2) JWE envelope. AAD must equal what the server cross-checks on
    //    decrypt (see L2 alfheim middleware).
    final aad = <String, String>{
      'project_id': projectId,
      'route_path': routePath,
      'request_id': requestId,
    };
    final compactJwe = await codec.encryptForRecipient(
      recipientPub: recipient.x25519Pub,
      recipientKid: recipient.kid,
      innerJwsBytes: innerJwsBytes,
      aad: aad,
    );

    // 3) Legacy HMAC over the JWE body (server still computes HMAC over
    //    the wire-form body before alfheim middleware decrypts).
    final sig = _signer.sign(compactJwe);

    final headers = <String, String>{
      'Content-Type': LsHeaders.joseJson,
      'Accept': '${LsHeaders.joseJson}, ${LsHeaders.json}',
      'X-LS-Product': _signer.productSlug,
      'X-LS-Timestamp': sig.timestamp,
      'X-LS-Signature': sig.signature,
      LsHeaders.requestId: requestId,
      LsHeaders.deviceId: deviceId,
      LsHeaders.recipientKid: recipient.kid,
      LsHeaders.kekVersion: recipient.kekVersion.toString(),
    };
    if (requireAuth) {
      headers['Authorization'] = 'Bearer ${await _auth.getIdToken()}';
    }
    final appCheckTok = await _appCheck.getToken();
    if (appCheckTok != null && appCheckTok.isNotEmpty) {
      headers['X-Firebase-AppCheck'] = appCheckTok;
    }

    await _pinner.verify('${url.scheme}://${url.host}');

    final res = await _inner
        .post(url, headers: headers, body: compactJwe)
        .timeout(_timeout,
            onTimeout: () => throw NetworkException('timeout'));

    // 4) Status-driven exception path (412 pek_stale, 410 device_revoked,
    //    415 jwe_required) BEFORE attempting to decode the body, so we
    //    don't try to JSON-parse a problem+json body.
    await _maybeThrowJweStatus(res, routePath: routePath, deviceId: deviceId);

    // 5) Confidentiality check. JWE-required routes MUST come back with
    //    X-LS-Confidentiality: jwe. A plaintext body on success is a
    //    fail-closed condition (mis-deployed L2 or MITM).
    final conf = res.headers[LsHeaders.confidentiality.toLowerCase()];
    if (conf != LsHeaders.confidentialityJwe) {
      throw JweRequiredButGotJwsException(routePath: routePath);
    }

    // 6) Decrypt the response envelope and verify the inner JWS bound to
    //    this exact route + request_id.
    final responseJwe = res.body;
    final Uint8List innerJwsResponseBytes;
    try {
      innerJwsResponseBytes = await codec.decryptForDevice(
        compactJwe: responseJwe,
        expectedAad: aad,
      );
    } catch (e) {
      throw JweDecryptionFailedException('response decrypt failed: $e');
    }
    final innerJwsResponse = utf8.decode(innerJwsResponseBytes);

    final verifier = _innerVerifier;
    final claims = verifier != null
        ? await verifier.verify(
            compactJws: innerJwsResponse,
            expectedRoute: routePath,
            expectedRequestId: requestId,
          )
        // No verifier injected (tests / staged rollout): trust the decoded
        // JWS payload but still parse it. The compact JWS is
        // header.payload.signature — payload is segment 1.
        : _peekJwsPayload(innerJwsResponse);

    // 7) Map decoded claims/body into the SDK's existing { ... } response.
    final payload = (claims['body'] as Map?)?.cast<String, dynamic>() ??
        claims.cast<String, dynamic>();
    return payload;
  }

  /// Status-code dispatch for JWE-leg failure modes. Returns normally if
  /// the response is a regular 2xx OR a non-JWE-specific error (those are
  /// re-decoded by [_decode] in the regular path).
  Future<void> _maybeThrowJweStatus(
    http.Response res, {
    required String routePath,
    required String deviceId,
  }) async {
    if (res.statusCode >= 200 && res.statusCode < 300) return;
    Map<String, dynamic>? body;
    try {
      body = jsonDecode(res.body) as Map<String, dynamic>;
    } catch (_) {/* problem+json / empty / non-JSON body */}

    final code = body?['error'] as String?;
    final reason = body?['reason_code'] as String?;

    // 412 pek_stale: L2 rotated the KEK between cache and request.
    if (res.statusCode == 412 &&
        (code == 'pek_stale' || reason == 'KEK_V_STALE')) {
      throw PekStaleException(
        sentKekV: (body?['sent_kek_v'] as num?)?.toInt(),
        expectedKekV: (body?['expected_kek_v'] as num?)?.toInt(),
      );
    }
    // 410 device revoked / unenrolled.
    if (res.statusCode == 410 &&
        (reason == 'DEVICE_REVOKED' || reason == 'DEVICE_UNENROLLED')) {
      await _clearDeviceRegistrationMarker();
      throw DeviceRevokedException(deviceId: deviceId);
    }
    // 415 jwe_required: L2 reported the body wasn't a JWE (we don't expect
    // this — the SDK always sends JWE on this path — but cover it).
    if (res.statusCode == 415 && code == 'jwe_required') {
      throw JweRequiredButGotJwsException(routePath: routePath);
    }
    // Fall through to the legacy error mapper so existing error codes
    // (seat_cap_exceeded, auth, etc.) still produce typed exceptions.
    _throwLegacy(res, body);
  }

  Future<void> _clearDeviceRegistrationMarker() async {
    final cache = _secureCache;
    if (cache == null) return;
    try {
      await cache.deleteRaw(kDeviceRegisteredMarker);
    } catch (_) {
      // SecureCache deletion best-effort; surfacing the DeviceRevoked
      // signal takes priority. The next connect() will retry the delete.
    }
  }

  // -------------------------------------------------------------- response

  /// GET — used for unauthenticated reads (JWKS, lcs-keys).
  Future<Map<String, dynamic>> getJson(Uri url) async {
    await _pinner.verify('${url.scheme}://${url.host}');
    final res = await _inner
        .get(url, headers: {'Accept': 'application/json'})
        .timeout(_timeout,
            onTimeout: () => throw NetworkException('timeout'));
    return _decode(res);
  }

  /// Returns the parsed body, or throws a typed exception based on status +
  /// the server's `error` code. Server reference: internal/platform/server.WriteError.
  Map<String, dynamic> _decode(http.Response res, {String? routePath}) {
    Map<String, dynamic>? body;
    try {
      body = jsonDecode(res.body) as Map<String, dynamic>;
    } catch (_) {
      // some errors return non-JSON bodies (e.g., LB pages)
    }
    if (res.statusCode >= 200 && res.statusCode < 300) {
      return body ?? const {};
    }
    _throwLegacy(res, body);
  }

  Never _throwLegacy(http.Response res, Map<String, dynamic>? body) {
    final code = body?['error'] as String?;
    final msg =
        (body?['message'] as String?) ?? res.reasonPhrase ?? 'request failed';

    switch (code) {
      case 'seat_cap_exceeded':
        throw SeatCapExceededException(msg);
      case 'session_revoked':
        throw SessionRevokedException(msg);
      case 'transfer_cooldown_active':
        final avail = body?['available_at'] as String?;
        throw TransferCooldownException(
            avail != null ? DateTime.parse(avail) : DateTime.now().toUtc());
      case 'hmac':
      case 'auth':
      case 'firebase':
        throw AuthException('$code: $msg');
      case 'app_check':
        throw AppCheckFailedException(msg);
    }

    if (res.statusCode == 401 || res.statusCode == 403) {
      throw AuthException(msg);
    }
    throw NetworkException(msg, statusCode: res.statusCode);
  }

  void close() => _inner.close();

  // ---------------------------------------------------------------- helpers

  /// Best-effort UUIDv7. Format per draft-ietf-uuidrev-rfc4122bis:
  /// 48-bit unix-ms timestamp || 4-bit version (0x7) || 12 bits random ||
  /// 2-bit variant (10) || 62 bits random.
  String _uuidV7() {
    final tsMs = DateTime.now().toUtc().millisecondsSinceEpoch;
    final bytes = Uint8List(16);
    bytes[0] = (tsMs >> 40) & 0xff;
    bytes[1] = (tsMs >> 32) & 0xff;
    bytes[2] = (tsMs >> 24) & 0xff;
    bytes[3] = (tsMs >> 16) & 0xff;
    bytes[4] = (tsMs >> 8) & 0xff;
    bytes[5] = tsMs & 0xff;
    for (var i = 6; i < 16; i++) {
      bytes[i] = _rng.nextInt(256);
    }
    // version 7 in bits 4..7 of byte 6
    bytes[6] = (bytes[6] & 0x0f) | 0x70;
    // variant 10 in bits 6..7 of byte 8
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    return _formatUuid(bytes);
  }

  Uint8List _nonce16() {
    final out = Uint8List(16);
    for (var i = 0; i < 16; i++) {
      out[i] = _rng.nextInt(256);
    }
    return out;
  }

  static String _formatUuid(Uint8List b) {
    String h(int i) => b[i].toRadixString(16).padLeft(2, '0');
    return '${h(0)}${h(1)}${h(2)}${h(3)}-'
        '${h(4)}${h(5)}-'
        '${h(6)}${h(7)}-'
        '${h(8)}${h(9)}-'
        '${h(10)}${h(11)}${h(12)}${h(13)}${h(14)}${h(15)}';
  }

  static String _b64u(List<int> bytes) =>
      base64Url.encode(bytes).replaceAll('=', '');

  /// Lightweight no-verify peek at a compact JWS payload — used only when
  /// the SDK is constructed without an [InnerJwsVerifier] (early-rollout
  /// + tests). In production the verifier is always wired.
  static Map<String, dynamic> _peekJwsPayload(String compactJws) {
    final parts = compactJws.split('.');
    if (parts.length != 3) {
      throw JwtVerificationException(
          'inner JWS shape invalid (${parts.length} segments)');
    }
    final pad = (4 - parts[1].length % 4) % 4;
    final padded = parts[1].padRight(parts[1].length + pad, '=');
    final decoded = utf8.decode(base64Url.decode(padded));
    return (jsonDecode(decoded) as Map).cast<String, dynamic>();
  }
}
