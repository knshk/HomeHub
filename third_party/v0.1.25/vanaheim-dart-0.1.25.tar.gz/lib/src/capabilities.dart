// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:meta/meta.dart';
import 'package:yaml/yaml.dart';

import 'exceptions.dart';

/// Per-app capability switches.
///
/// Each consuming product ships a YAML (or programmatic configuration) that
/// enables or disables individual SDK sub-APIs. The SDK gates every call at
/// runtime: calling a disabled capability throws [CapabilityDisabledException]
/// with a clear remediation message. This lets one product opt out of e.g.
/// the AI assistant or referrals while another opts in — no SDK rebuild
/// required, no half-shipped UI rendering against a backend it can't reach.
///
/// YAML schema:
///
/// ```yaml
/// vanaheim:
///   capabilities:
///     notifications: true     # client.notifications.*
///     feedback: true          # client.feedback.*
///     support: true           # client.support.*
///     subscription: true      # client.subscription.*
///     privacy: true           # client.privacy.*
///     preferences: true       # client.preferences.*
///     telemetry: true         # client.track / client.metering.*
///     assistant: false        # client.assistant.*
///     referrals: false        # client.referrals.*
///     status: true            # client.status.*
///     organization: false     # client.organization.*
///     offers: true            # client.offers.*
///     docs: true              # client.docs.*
///   defaults:
///     feedback_max_attachment_mb: 5
///     notification_inbox_page_size: 50
///     telemetry_batch_size: 20
///     telemetry_flush_interval_seconds: 30
///     telemetry_max_buffer: 500
/// ```
///
/// All capability flags default to `true` if omitted from YAML — products
/// must explicitly disable. This avoids silent disablement when a YAML is
/// missing a key.
@immutable
class SdkCapabilities {
  /// Master switches per sub-API namespace. Defaults all true.
  final bool notifications;
  final bool feedback;
  final bool support;
  final bool subscription;
  final bool privacy;
  final bool preferences;
  final bool telemetry;
  final bool assistant;
  final bool referrals;
  final bool status;
  final bool organization;
  final bool offers;
  final bool docs;
  final bool mfa;

  // Tunable defaults — products can override sensible per-capability values.
  final int feedbackMaxAttachmentMb;
  final int notificationInboxPageSize;
  final int telemetryBatchSize;
  final Duration telemetryFlushInterval;
  final int telemetryMaxBuffer;

  const SdkCapabilities({
    this.notifications = true,
    this.feedback = true,
    this.support = true,
    this.subscription = true,
    this.privacy = true,
    this.preferences = true,
    this.telemetry = true,
    this.assistant = true,
    this.referrals = true,
    this.status = true,
    this.organization = true,
    this.offers = true,
    this.docs = true,
    this.mfa = true,
    this.feedbackMaxAttachmentMb = 5,
    this.notificationInboxPageSize = 50,
    this.telemetryBatchSize = 20,
    this.telemetryFlushInterval = const Duration(seconds: 30),
    this.telemetryMaxBuffer = 500,
  });

  /// Default-everything-enabled config. Use as `const SdkCapabilities()` to
  /// opt every capability in (the safe default for new products that don't
  /// ship a YAML yet).
  static const SdkCapabilities defaults = SdkCapabilities();

  /// Loads from a YAML string. Missing capability keys default to `true`
  /// (opt-out semantics); missing tunables default to the constants above.
  ///
  /// The YAML may be either rooted at `vanaheim:` (preferred) or the
  /// legacy `license_store_sdk:` key (when bundled with other product
  /// config), or rooted at the top level.
  ///
  /// Throws [FormatException] if the YAML is malformed.
  factory SdkCapabilities.fromYaml(String yamlContent) {
    final loaded = loadYaml(yamlContent);
    if (loaded == null) return defaults;
    if (loaded is! Map) {
      throw const FormatException('SdkCapabilities: top-level YAML must be a map');
    }
    final root = loaded['vanaheim'] is Map
        ? loaded['vanaheim'] as Map
        : loaded['license_store_sdk'] is Map
            ? loaded['license_store_sdk'] as Map
            : loaded;
    final caps = root['capabilities'] is Map ? root['capabilities'] as Map : const {};
    final defs = root['defaults'] is Map ? root['defaults'] as Map : const {};

    bool capOf(String key, bool fallback) {
      final v = caps[key];
      return v is bool ? v : fallback;
    }

    int intOf(String key, int fallback) {
      final v = defs[key];
      if (v is int) return v;
      if (v is num) return v.toInt();
      return fallback;
    }

    return SdkCapabilities(
      notifications: capOf('notifications', true),
      feedback: capOf('feedback', true),
      support: capOf('support', true),
      subscription: capOf('subscription', true),
      privacy: capOf('privacy', true),
      preferences: capOf('preferences', true),
      telemetry: capOf('telemetry', true),
      assistant: capOf('assistant', true),
      referrals: capOf('referrals', true),
      status: capOf('status', true),
      organization: capOf('organization', true),
      offers: capOf('offers', true),
      docs: capOf('docs', true),
      mfa: capOf('mfa', true),
      feedbackMaxAttachmentMb: intOf('feedback_max_attachment_mb', 5),
      notificationInboxPageSize: intOf('notification_inbox_page_size', 50),
      telemetryBatchSize: intOf('telemetry_batch_size', 20),
      telemetryFlushInterval:
          Duration(seconds: intOf('telemetry_flush_interval_seconds', 30)),
      telemetryMaxBuffer: intOf('telemetry_max_buffer', 500),
    );
  }

  /// Returns true if [capabilityName] is enabled. The lookup matches one of
  /// the master switches; unknown names default to true (forward-compat:
  /// a future capability is enabled by default until products opt out).
  bool isEnabled(String capabilityName) {
    switch (capabilityName) {
      case 'notifications':
        return notifications;
      case 'feedback':
        return feedback;
      case 'support':
        return support;
      case 'subscription':
        return subscription;
      case 'privacy':
        return privacy;
      case 'preferences':
        return preferences;
      case 'telemetry':
        return telemetry;
      case 'assistant':
        return assistant;
      case 'referrals':
        return referrals;
      case 'status':
        return status;
      case 'organization':
        return organization;
      case 'offers':
        return offers;
      case 'docs':
        return docs;
      case 'mfa':
        return mfa;
      default:
        return true;
    }
  }

  /// Throws [CapabilityDisabledException] when [capabilityName] is disabled.
  /// Each sub-API namespace calls this at the top of every public method.
  void require(String capabilityName) {
    if (!isEnabled(capabilityName)) {
      throw CapabilityDisabledException(capabilityName);
    }
  }
}

/// Thrown when a product calls into an SDK capability that is disabled via
/// the YAML / programmatic [SdkCapabilities] config.
class CapabilityDisabledException extends LicenseStoreException {
  final String capability;
  CapabilityDisabledException(this.capability)
      : super('SDK capability "$capability" is disabled by the product\'s '
            'capability config. Enable it in capabilities.yaml or pass an '
            'SdkCapabilities() with the relevant flag set to true.');
}
