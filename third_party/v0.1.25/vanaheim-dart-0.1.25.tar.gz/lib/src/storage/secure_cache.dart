// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Opaque secure-storage wrapper. Products NEVER get a path or raw access —
/// the only operations are put/get/clear scoped to the SDK's namespace.
///
/// Platform backings:
///   iOS / macOS   → Keychain (kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly)
///   Android       → EncryptedSharedPreferences (key in Keystore)
///   Windows       → DPAPI
///   Linux         → libsecret
///   Web           → IndexedDB + WebCrypto-wrapped DEK (weaker; short-lived)
///
/// Inject a custom implementation for tests via [LicenseClient.connect(storage: ...)].
abstract class SecureCache {
  Future<void> putJwt(String jwt);
  Future<String?> getJwt();
  Future<void> putLicenseId(String id);
  Future<String?> getLicenseId();
  Future<void> putActivationId(String id);
  Future<String?> getActivationId();
  Future<void> putRegionEndpoint(String url);
  Future<String?> getRegionEndpoint();
  // Telemetry blob — JSON-serialized [TelemetryEvent] list. Kept under the
  // same secure-storage namespace as JWT/IDs because it may contain stack
  // traces that mention internal paths. Not cleared by clear() so a
  // sign-out doesn't erase diagnostic history; call ErrorTelemetry.clear()
  // explicitly if you want that.
  Future<void> putTelemetry(String json);
  Future<String?> getTelemetry();
  Future<void> clear();

  /// Read a value stored under an arbitrary key. Used by §2A/§2B sub-APIs
  /// (telemetry buffer, AI assistant message history cache, etc.) that need
  /// their own scoped persistence without proliferating bespoke get/put
  /// methods on this interface. Keys SHOULD be namespaced (e.g.
  /// `telemetry_buffer_v1`) to avoid collisions.
  Future<String?> getRaw(String key);

  /// Write a raw value under an arbitrary key. Storage is the same secure
  /// backing as JWT/IDs — products NEVER read these directly.
  Future<void> putRaw(String key, String value);

  /// Delete a raw value.
  Future<void> deleteRaw(String key);

  /// Clear every value whose raw-key prefix matches [prefix]. Used by
  /// the FRON DirectClient on `DIRECT_DEVICE_REVOKED` to wipe the entire
  /// `vanaheim:direct:*` namespace — including any future raw slots the
  /// FRON subsystem adds without forcing a sweep of every individual key
  /// here.
  ///
  /// Implementations MUST scope this to keys WRITTEN via [putRaw] / the
  /// typed slots — never delete keys outside the SDK's own namespace.
  Future<void> deletePrefix(String prefix);
}

/// Production implementation backed by `flutter_secure_storage`.
class FlutterSecureCache implements SecureCache {
  static const _kJwt = 'ls_jwt_v1';
  static const _kLicenseId = 'ls_license_id_v1';
  static const _kActivationId = 'ls_activation_id_v1';
  static const _kRegionEndpoint = 'ls_region_endpoint_v1';
  static const _kTelemetry = 'ls_telemetry_v1';

  final FlutterSecureStorage _s;

  FlutterSecureCache({FlutterSecureStorage? storage})
      : _s = storage ??
            const FlutterSecureStorage(
              aOptions: AndroidOptions(encryptedSharedPreferences: true),
              iOptions: IOSOptions(
                accessibility: KeychainAccessibility.first_unlock_this_device,
              ),
            );

  @override
  Future<void> putJwt(String jwt) => _s.write(key: _kJwt, value: jwt);
  @override
  Future<String?> getJwt() => _s.read(key: _kJwt);

  @override
  Future<void> putLicenseId(String id) => _s.write(key: _kLicenseId, value: id);
  @override
  Future<String?> getLicenseId() => _s.read(key: _kLicenseId);

  @override
  Future<void> putActivationId(String id) =>
      _s.write(key: _kActivationId, value: id);
  @override
  Future<String?> getActivationId() => _s.read(key: _kActivationId);

  @override
  Future<void> putRegionEndpoint(String url) =>
      _s.write(key: _kRegionEndpoint, value: url);
  @override
  Future<String?> getRegionEndpoint() => _s.read(key: _kRegionEndpoint);

  @override
  Future<void> putTelemetry(String json) =>
      _s.write(key: _kTelemetry, value: json);
  @override
  Future<String?> getTelemetry() => _s.read(key: _kTelemetry);

  @override
  Future<String?> getRaw(String key) => _s.read(key: _rawKey(key));
  @override
  Future<void> putRaw(String key, String value) =>
      _s.write(key: _rawKey(key), value: value);
  @override
  Future<void> deleteRaw(String key) => _s.delete(key: _rawKey(key));

  @override
  Future<void> deletePrefix(String prefix) async {
    // FlutterSecureStorage exposes readAll() — scan the namespace and
    // delete any raw-key match. Iteration is bounded by the SDK's own
    // slots (a few dozen), so this is fine on every supported platform.
    final all = await _s.readAll();
    final qualifiedPrefix = _rawKey(prefix);
    final toDelete = all.keys.where((k) => k.startsWith(qualifiedPrefix));
    for (final k in toDelete) {
      await _s.delete(key: k);
    }
  }

  static String _rawKey(String key) => 'ls_raw_$key';

  @override
  Future<void> clear() async {
    // Telemetry is intentionally NOT cleared here — see SecureCache doc.
    await Future.wait([
      _s.delete(key: _kJwt),
      _s.delete(key: _kLicenseId),
      _s.delete(key: _kActivationId),
      _s.delete(key: _kRegionEndpoint),
    ]);
  }
}

/// In-memory cache for tests. NOT for production.
class InMemorySecureCache implements SecureCache {
  final Map<String, String> _m = {};
  @override
  Future<void> putJwt(String jwt) async => _m['jwt'] = jwt;
  @override
  Future<String?> getJwt() async => _m['jwt'];
  @override
  Future<void> putLicenseId(String id) async => _m['license_id'] = id;
  @override
  Future<String?> getLicenseId() async => _m['license_id'];
  @override
  Future<void> putActivationId(String id) async => _m['activation_id'] = id;
  @override
  Future<String?> getActivationId() async => _m['activation_id'];
  @override
  Future<void> putRegionEndpoint(String url) async => _m['region_endpoint'] = url;
  @override
  Future<String?> getRegionEndpoint() async => _m['region_endpoint'];
  @override
  Future<void> putTelemetry(String json) async => _m['telemetry'] = json;
  @override
  Future<String?> getTelemetry() async => _m['telemetry'];

  @override
  Future<String?> getRaw(String key) async => _m['raw_$key'];
  @override
  Future<void> putRaw(String key, String value) async => _m['raw_$key'] = value;
  @override
  Future<void> deleteRaw(String key) async => _m.remove('raw_$key');

  @override
  Future<void> deletePrefix(String prefix) async {
    final qualifiedPrefix = 'raw_$prefix';
    _m.removeWhere((k, _) => k.startsWith(qualifiedPrefix));
  }

  @override
  Future<void> clear() async {
    // Match FlutterSecureCache.clear semantics: preserve telemetry. Raw
    // namespaced entries also persist across clear() (sub-APIs that need
    // sign-out clearing must call deleteRaw explicitly).
    final telemetry = _m['telemetry'];
    final preservedRaws = Map.fromEntries(
        _m.entries.where((e) => e.key.startsWith('raw_')));
    _m.clear();
    if (telemetry != null) _m['telemetry'] = telemetry;
    _m.addAll(preservedRaws);
  }
}
