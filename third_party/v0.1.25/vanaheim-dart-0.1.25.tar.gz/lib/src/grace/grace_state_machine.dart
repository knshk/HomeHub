// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// The decision logic for "is the cached JWT good, do I need to refresh, am I
/// past the cliff?" — pure function, deterministic, no I/O. Trivially
/// unit-testable.
///
/// State table:
///   no cached JWT          → noJwt          (must activate or refresh)
///   exp - now > refreshBefore  → fresh      (use cached, no network)
///   0 < exp - now <= refreshBefore → refreshNeeded  (use cached, refresh in bg)
///   exp - now <= 0 (+skew) → expired       (must refresh; offline = fail closed)
class GraceStateMachine {
  final Duration refreshBefore;
  final Duration clockSkew;

  const GraceStateMachine({
    this.refreshBefore = const Duration(days: 1),
    this.clockSkew = const Duration(minutes: 5),
  });

  GraceDecision evaluate({
    required DateTime? jwtExpiresAt,
    required DateTime now,
  }) {
    if (jwtExpiresAt == null) return const GraceDecision(state: GraceState.noJwt);
    final remaining = jwtExpiresAt.difference(now);
    if (remaining <= -clockSkew) {
      return GraceDecision(state: GraceState.expired, sinceExpiry: -remaining);
    }
    if (remaining <= refreshBefore) {
      return GraceDecision(
        state: GraceState.refreshNeeded,
        timeUntilExpiry: remaining,
      );
    }
    return GraceDecision(
      state: GraceState.fresh,
      timeUntilExpiry: remaining,
    );
  }
}

enum GraceState {
  /// No cached JWT — caller must activate or hit verify.
  noJwt,

  /// JWT valid and far from expiry — use it, no network needed.
  fresh,

  /// JWT valid but close to expiry — use it AND refresh in background.
  refreshNeeded,

  /// JWT expired (past clock-skew tolerance) — must refresh; offline = fail.
  expired,
}

class GraceDecision {
  final GraceState state;
  final Duration? timeUntilExpiry;
  final Duration? sinceExpiry;

  const GraceDecision({
    required this.state,
    this.timeUntilExpiry,
    this.sinceExpiry,
  });
}
