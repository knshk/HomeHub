// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// §2A.12 i18n message formatting.
///
/// Day-1 contract: an in-process catalog + ICU-style variable interpolation
/// (`Hello, {name}!`). Pluralization is supported via the simple
/// `{count, plural, one {…} other {…}}` form. Products typically load the
/// catalog from JSON ahead of time and inject it via [Formatter.withCatalog].
///
/// Once §3B.8 (Lokalise sync + backend i18n catalog) lands, the SDK can
/// auto-load the catalog at connect() — the public API does not change.
class Formatter {
  final String? locale;
  final Map<String, String> _catalog;

  Formatter({
    this.locale,
    Map<String, String> catalog = const {},
  }) : _catalog = Map.unmodifiable(catalog);

  /// Returns a new Formatter with an additional catalog merged in. New keys
  /// override existing ones. Useful for layered catalogs (base + region).
  Formatter withCatalog(Map<String, String> catalog) {
    final merged = Map<String, String>.from(_catalog);
    merged.addAll(catalog);
    return Formatter(locale: locale, catalog: merged);
  }

  /// Formats a message by key. [vars] holds substitutions. Returns the key
  /// itself when missing — products can detect untranslated strings in dev.
  ///
  /// Substitution syntax:
  ///   * `{name}` — simple
  ///   * `{count, plural, one {1 item} other {{count} items}}` — plural
  String format(String key, [Map<String, Object?> vars = const {}]) {
    final template = _catalog[key] ?? key;
    return _interpolate(template, vars);
  }

  String _interpolate(String template, Map<String, Object?> vars) {
    final buffer = StringBuffer();
    int i = 0;
    while (i < template.length) {
      final c = template[i];
      if (c == '{') {
        final end = _findMatchingBrace(template, i);
        if (end == -1) {
          buffer.write(template.substring(i));
          break;
        }
        final inner = template.substring(i + 1, end);
        buffer.write(_resolveExpr(inner, vars));
        i = end + 1;
      } else {
        buffer.write(c);
        i++;
      }
    }
    return buffer.toString();
  }

  int _findMatchingBrace(String s, int openIdx) {
    int depth = 0;
    for (int i = openIdx; i < s.length; i++) {
      final c = s[i];
      if (c == '{') {
        depth++;
      } else if (c == '}') {
        depth--;
        if (depth == 0) return i;
      }
    }
    return -1;
  }

  String _resolveExpr(String inner, Map<String, Object?> vars) {
    // Plural form: name, plural, one {…} other {…}
    final pluralMatch = RegExp(r'^\s*(\w+)\s*,\s*plural\s*,\s*(.+)$', dotAll: true).firstMatch(inner);
    if (pluralMatch != null) {
      final varName = pluralMatch.group(1)!;
      final spec = pluralMatch.group(2)!;
      final value = vars[varName];
      final n = (value is num) ? value.toInt() : int.tryParse('$value') ?? 0;
      final branch = _selectPluralBranch(spec, n);
      // Recursively interpolate the branch — embedded {count} replaces with n.
      return _interpolate(branch, {...vars, varName: n});
    }
    // Select form: name, select, female {…} male {…} other {…}
    // Selector-based branching for categorical (non-numeric) values like
    // gender, role, partner-tier — any string the catalog wants to switch on.
    final selectMatch = RegExp(r'^\s*(\w+)\s*,\s*select\s*,\s*(.+)$', dotAll: true).firstMatch(inner);
    if (selectMatch != null) {
      final varName = selectMatch.group(1)!;
      final spec = selectMatch.group(2)!;
      final value = vars[varName];
      final key = value?.toString() ?? 'other';
      final branches = _parseBranches(spec);
      final branch = branches[key] ?? branches['other'] ?? '';
      return _interpolate(branch, vars);
    }
    // Simple variable: {name}
    final trimmed = inner.trim();
    if (vars.containsKey(trimmed)) {
      return '${vars[trimmed]}';
    }
    // Unknown var — surface the original braces so dev can spot it.
    return '{$inner}';
  }

  /// Parses the body of a plural expression (`one {…} other {…} few {…}`)
  /// and returns the matching branch text for [n]. Falls back to `other`
  /// when no other key matches.
  String _selectPluralBranch(String spec, int n) {
    final branches = _parseBranches(spec);
    // ICU plural categories — keep it simple: one, two, few, many, other.
    final category = _pluralCategory(n);
    return branches[category] ?? branches['other'] ?? '';
  }

  Map<String, String> _parseBranches(String spec) {
    final out = <String, String>{};
    int i = 0;
    while (i < spec.length) {
      while (i < spec.length && _isWhitespace(spec[i])) {
        i++;
      }
      // Read keyword.
      final keyStart = i;
      while (i < spec.length && !_isWhitespace(spec[i]) && spec[i] != '{') {
        i++;
      }
      final keyword = spec.substring(keyStart, i).trim();
      while (i < spec.length && _isWhitespace(spec[i])) {
        i++;
      }
      if (i >= spec.length || spec[i] != '{') break;
      final end = _findMatchingBrace(spec, i);
      if (end == -1) break;
      out[keyword] = spec.substring(i + 1, end);
      i = end + 1;
    }
    return out;
  }

  bool _isWhitespace(String c) => c == ' ' || c == '\t' || c == '\n' || c == '\r';

  /// Returns the ICU plural category for [n]. English-default; products
  /// shipping non-English catalogs override per-locale by injecting custom
  /// branches in the catalog (advanced users will swap this for full ICU
  /// later in §3B.8).
  String _pluralCategory(int n) {
    if (n == 0) return 'zero';
    if (n == 1) return 'one';
    if (n == 2) return 'two';
    if (n >= 3 && n <= 10) return 'few';
    return 'other';
  }
}
