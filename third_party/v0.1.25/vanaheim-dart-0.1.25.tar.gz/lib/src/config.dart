// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:meta/meta.dart';

import 'crypto/jwe.dart';
import 'direct/direct_config.dart';

export 'direct/direct_config.dart' show VanaheimMode, DirectConfig;

/// Configuration knobs for [LicenseClient]. Sensible defaults; override only
/// when you have a concrete reason.
///
/// v2 / Vanaheim: renamed from `LicenseStoreConfig`. Adds `l2BaseUrl` +
/// `projectId` (required, no defaults — host product must wire these), and
/// flips `jweDecryptor` / `deviceKeypairProvider` from optional to required
/// since v2 routes are JWE-by-default with a hard-coded JWS-allowed list.
/// The v1 `bifrostBaseUrl` is gone — the SDK no longer talks to Bifrost
/// directly; device enrollment goes through L2 instead.
@immutable
class VanaheimConfig {
  /// Project identifier — used as part of the JWE AAD (`<project_id>|<route_path>|<request_id>`)
  /// and the X-LS-Project-Id header on outgoing requests. Required.
  ///
  /// Was previously passed positionally to `LicenseClient.connect()` in v1;
  /// moved into the config so the AAD-construction helper inside
  /// `SignedHttpClient` can read it without an extra parameter hop.
  final int projectId;

  /// Base URL of the L2 (Alfheim) tier this product is bound to.
  /// All v2 JWE-required calls + device enrollment hit `{l2BaseUrl}/...`.
  /// Required — there is no default; the host product must provide one.
  ///
  /// Replaces v1's `bifrostBaseUrl` (deleted). The L2 tier owns recipient
  /// keys and device records now; Bifrost is no longer an SDK dependency.
  final Uri l2BaseUrl;

  /// JWE confidentiality wrapper (§2A.5). v2 makes this required because
  /// the JWE-required vs JWS-allowed route table is hard-coded and most
  /// data-plane calls are encrypted. Host products should pass
  /// `CryptographyJweDecryptor(keypair, codec)` (once available) or any
  /// implementation conforming to [JwePayloadDecryptor].
  final JwePayloadDecryptor jweDecryptor;

  /// Per-device X25519 keypair provider (§2A.5). v2 makes this required
  /// because every device must enroll a pubkey with L2 on first boot
  /// (see `DevicesAPI.register`). Host products should pass
  /// `CryptographyDeviceKeypairProvider(cache)` (once available) or any
  /// implementation conforming to [DeviceKeypairProvider] that persists
  /// the private key in platform-level secure storage.
  final DeviceKeypairProvider deviceKeypairProvider;

  /// How close to JWT expiry the SDK proactively refreshes. Default 1 day.
  /// With the server's default 7-day exp, this means at-most-once-a-week
  /// network call from a logged-in active user.
  final Duration refreshBefore;

  /// Maximum offline grace. If the cached JWT's exp is past now + this value,
  /// the SDK behaves as if there is no JWT (forces network). Default = no cap
  /// (trust the server-set exp).
  final Duration? hardOfflineGrace;

  /// Pinned SPKI SHA-256 hashes (base64) for the API server cert. Provide at
  /// least one (current); add the next pin before rotation. Empty list
  /// disables pinning — only safe in dev.
  final List<String> pinnedSpkiSha256;

  /// JWKS cache TTL when the server response carries no Cache-Control. Default 1h.
  final Duration jwksCacheTtl;

  /// HTTP timeout per request. Default 15 s.
  final Duration httpTimeout;

  /// Allowed clock-skew between client and server. Default 5 min — matches
  /// the server's HMAC replay-window tolerance.
  final Duration clockSkew;

  /// In dev / local backend, the SDK can fall back to a `dev:<uid>:<email>`
  /// Firebase ID token if `firebase_auth` isn't initialized. NEVER true in
  /// production builds. Default false.
  final bool allowDevAuthBypass;

  /// Which transport backs the [LicenseClient].
  ///
  /// Default is [VanaheimMode.l2] — the existing path that talks to the
  /// customer's Alfheim L2. Flip to [VanaheimMode.fron] when the customer
  /// has no L2 of their own; the SDK then constructs a `DirectClient`
  /// against Bifrost's `/direct/v1/*` surface, using [directConfig] for
  /// FRON-specific knobs.
  ///
  /// Backward-compatible: existing host products that don't set this
  /// field keep the L2 behaviour.
  final VanaheimMode mode;

  /// Direct-mode configuration. REQUIRED when [mode] is [VanaheimMode.fron];
  /// IGNORED otherwise. Holds the Bifrost base URL, heartbeat cadence, and
  /// stats-batcher knobs.
  final DirectConfig? directConfig;

  const VanaheimConfig({
    required this.projectId,
    required this.l2BaseUrl,
    required this.jweDecryptor,
    required this.deviceKeypairProvider,
    this.refreshBefore = const Duration(days: 1),
    this.hardOfflineGrace,
    this.pinnedSpkiSha256 = const [],
    this.jwksCacheTtl = const Duration(hours: 1),
    this.httpTimeout = const Duration(seconds: 15),
    this.clockSkew = const Duration(minutes: 5),
    this.allowDevAuthBypass = false,
    this.mode = VanaheimMode.l2,
    this.directConfig,
  });
}
