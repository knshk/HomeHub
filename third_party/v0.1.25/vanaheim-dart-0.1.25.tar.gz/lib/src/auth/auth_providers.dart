// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../exceptions.dart';

/// Returns a fresh Firebase ID token for the currently signed-in user.
/// Inject a custom implementation for tests or for non-Firebase auth.
abstract class AuthTokenProvider {
  Future<String> getIdToken({bool forceRefresh = false});
}

/// Default implementation backed by `firebase_auth`. Assumes
/// `Firebase.initializeApp()` was called and a user is signed in.
class FirebaseAuthTokenProvider implements AuthTokenProvider {
  @override
  Future<String> getIdToken({bool forceRefresh = false}) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      throw AuthException('Firebase user is not signed in');
    }
    final token = await user.getIdToken(forceRefresh);
    if (token == null || token.isEmpty) {
      throw AuthException('Firebase getIdToken returned null/empty');
    }
    return token;
  }
}

/// Dev-only: returns a pre-formed `dev:<uid>:<email>` token the backend
/// accepts when `FIREBASE_PROJECT_ID` is unset. NEVER in production.
class DevAuthTokenProvider implements AuthTokenProvider {
  final String uid;
  final String email;
  DevAuthTokenProvider({required this.uid, required this.email});

  @override
  Future<String> getIdToken({bool forceRefresh = false}) async =>
      'dev:$uid:$email';
}

/// Returns a fresh Firebase App Check token attesting that this is our
/// official app on a non-tampered device.
abstract class AppCheckTokenProvider {
  Future<String?> getToken({bool forceRefresh = false});
}

/// Default implementation backed by `firebase_app_check`.
class FirebaseAppCheckTokenProvider implements AppCheckTokenProvider {
  @override
  Future<String?> getToken({bool forceRefresh = false}) async {
    try {
      return await FirebaseAppCheck.instance.getToken(forceRefresh);
    } catch (e) {
      throw AppCheckFailedException('getToken failed: $e');
    }
  }
}

/// Dev-only: returns null (server bypasses when project number is unset).
class NoAppCheckProvider implements AppCheckTokenProvider {
  @override
  Future<String?> getToken({bool forceRefresh = false}) async => null;
}
