// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Base class for all SDK exceptions. Catch this for a generic SDK failure;
/// catch the typed subclasses below to branch UX on specific cases.
class LicenseStoreException implements Exception {
  final String message;
  final Object? cause;
  LicenseStoreException(this.message, {this.cause});

  @override
  String toString() =>
      '$runtimeType: $message${cause != null ? ' (cause: $cause)' : ''}';
}

/// Activation refused because the license has reached its seat cap.
/// Product UX: prompt user to deactivate another device or upgrade plan.
class SeatCapExceededException extends LicenseStoreException {
  SeatCapExceededException([super.msg = 'License seat cap exceeded']);
}

/// Verify reports this device's activation was revoked — typically because the
/// user signed in on another device with a floating-tier license.
/// Product UX: lock the UI, show "signed out, used on another device".
class SessionRevokedException extends LicenseStoreException {
  SessionRevokedException([super.msg = 'Session revoked on another device']);
}

/// Transfer refused because the per-tier cooldown is still active.
/// Carries the next available time so UX can show it.
class TransferCooldownException extends LicenseStoreException {
  final DateTime availableAt;
  TransferCooldownException(this.availableAt)
      : super(
            'Transfer cooldown active until ${availableAt.toUtc().toIso8601String()}');
}

/// JWT is expired and the SDK could not refresh (offline + past exp).
/// Product UX: prompt user to go online or re-subscribe.
class LicenseExpiredException extends LicenseStoreException {
  LicenseExpiredException(
      [super.msg = 'License expired and could not refresh']);
}

/// HTTP-level failure (timeout, 5xx, DNS, TLS). Carries status code if known.
class NetworkException extends LicenseStoreException {
  final int? statusCode;
  NetworkException(super.message, {this.statusCode, super.cause});
}

/// TLS certificate did not match a pinned hash. Treat as MITM and refuse.
class CertificatePinException extends LicenseStoreException {
  CertificatePinException(
      [super.msg = 'Server certificate failed pinning check']);
}

/// Firebase App Check token could not be obtained or was rejected by the server.
/// On real devices this usually means the app instance is not recognized
/// (not signed with the correct dev/distribution cert).
class AppCheckFailedException extends LicenseStoreException {
  AppCheckFailedException([super.msg = 'App Check verification failed']);
}

/// JWT signature verification failed locally — caller MUST refuse the JWT
/// and clear the cached copy. Never fall open.
class JwtVerificationException extends LicenseStoreException {
  JwtVerificationException(super.message);
}

/// Server returned an authentication-level failure (HMAC mismatch, Firebase
/// token rejected, account mismatch). Usually means SDK secret rotation
/// missed, clock skew, or auth state is stale.
class AuthException extends LicenseStoreException {
  AuthException(super.message);
}

/// The SDK was not connected before a method that requires it.
class NotConnectedException extends LicenseStoreException {
  NotConnectedException()
      : super('Call LicenseClient.connect() before using this method');
}

// ---------------------------------------------------------------------------
// v2 / Vanaheim JWE-migration exceptions.
//
// These cover the new failure modes introduced by the JWE-required-by-default
// route policy + L2 device enrollment model. They are intentionally distinct
// from the generic [JwtVerificationException] family so product UX can
// branch precisely (retry / reauth / clear-cache / surface-to-user).
// ---------------------------------------------------------------------------

/// Thrown when the server returned a plaintext (JWS / unencrypted JSON)
/// response on a route the SDK's route policy classifies as JWE-required.
///
/// This is a SECURITY signal, not a transient one — the SDK MUST refuse the
/// response. Likely root causes (in order of likelihood):
///   * L2 misconfiguration (route policy disagreement between SDK + server)
///   * MITM stripping the JWE envelope
///   * A backend regression that bypassed the encrypt-on-egress middleware
///
/// Product UX: surface as a generic "secure connection failed" — do NOT
/// auto-retry, do NOT silently fall back to JWS.
class JweRequiredButGotJwsException extends LicenseStoreException {
  /// The route path that should have been JWE-wrapped (for diagnostics only).
  final String? routePath;
  JweRequiredButGotJwsException({
    String message = 'Server returned plaintext on a JWE-required route',
    this.routePath,
  }) : super(routePath != null ? '$message (route: $routePath)' : message);
}

/// Thrown when an outgoing JWE was rejected because its `kek_v` (recipient-key
/// epoch) doesn't match the current L2 recipient-key version.
///
/// This is a NORMAL operational signal during L2 recipient-key rotation. The
/// SDK should retry exactly once after force-refreshing the L2KeysClient
/// cache (`PEK retry-once` semantics per JWE_migration.md TODO-V2-D-05).
/// If the second attempt also fails with PekStale, surface to the caller.
class PekStaleException extends LicenseStoreException {
  /// `kek_v` the SDK sent (what we believed was current).
  final int? sentKekV;
  /// `kek_v` the server expects (what L2 actually rotated to).
  final int? expectedKekV;
  PekStaleException({
    String message = 'Recipient-key epoch (kek_v) is stale; refresh L2 keys',
    this.sentKekV,
    this.expectedKekV,
  }) : super(_format(message, sentKekV, expectedKekV));

  static String _format(String base, int? sent, int? expected) {
    if (sent == null && expected == null) return base;
    return '$base (sent=$sent, expected=$expected)';
  }
}

/// Thrown when L2 returns HTTP 410 Gone for this device's enrollment —
/// the device was revoked (admin action, fraud signal, manual rotation, …).
///
/// The caller (`LicenseClient` plumbing) MUST clear the
/// `device_registered_v1` SecureCache marker so the next boot re-enrolls
/// with a fresh keypair. Product UX: prompt the user to re-activate; never
/// silently continue (the previous JWT will not be re-issuable to a
/// revoked device).
class DeviceRevokedException extends LicenseStoreException {
  /// The device id that L2 reported as revoked (for diagnostics only —
  /// the SDK has already cleared it from local storage by the time this
  /// surfaces).
  final String? deviceId;
  DeviceRevokedException({
    String message = 'Device was revoked by the server; re-enrollment required',
    this.deviceId,
  }) : super(deviceId != null ? '$message (device: $deviceId)' : message);
}

/// Thrown when the inner JWS inside a decrypted JWE carries a `route_path`
/// header that doesn't match the path the request was actually served on.
///
/// In practice this should be RARE — the server rejects such mismatches in
/// L2's verify-egress middleware before they ever reach the client. We keep
/// the exception type so the SDK can fail closed on the unlikely case where
/// a misrouted JWE slips past server-side checks (defense in depth).
class JweRouteMismatchException extends LicenseStoreException {
  /// The route the SDK called.
  final String? expectedRoute;
  /// The `route_path` inside the inner-JWS header.
  final String? observedRoute;
  JweRouteMismatchException({
    String message = 'Inner JWS route_path does not match served path',
    this.expectedRoute,
    this.observedRoute,
  }) : super(_format(message, expectedRoute, observedRoute));

  static String _format(String base, String? exp, String? obs) {
    if (exp == null && obs == null) return base;
    return '$base (expected=$exp, observed=$obs)';
  }
}
