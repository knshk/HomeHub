// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Vanaheim SDK — Flutter/Dart client for License Store.
///
/// Quick start:
/// ```dart
/// // After Firebase.initializeApp() and FirebaseAppCheck.activate()
/// final client = await LicenseClient.connect(
///   controlPlaneUrl: Uri.parse('https://licenses.example.com'),
///   productSlug: 'zenkit',
///   sdkSecret: const String.fromEnvironment('LS_SDK_SECRET'),
/// );
///
/// await client.activate(deviceName: 'Kanishka iPhone 15');
///
/// if (client.hasFeature('export')) {
///   // unlock export button
/// }
/// final seats = client.quota<int>('max_seats');
///
/// client.stateChanges.listen((change) {
///   // re-render when entitlements_version bumps (tier change)
///   if (change.kind == LicenseStateChangeKind.entitlementsUpdated) setState(() {});
/// });
/// ```
///
/// See README.md and example/ for full usage including transfer flow,
/// session-revoked UX, and downgrade handling.
library vanaheim;

export 'src/api/account_api.dart' show AccountApi;
export 'src/api/assistant_api.dart' show AssistantApi;
export 'src/api/devices_api.dart' show DevicesAPI, DeviceEnrollment;
export 'src/api/docs_api.dart' show DocsApi;
export 'src/api/feedback_api.dart' show FeedbackApi;
export 'src/api/notifications_api.dart' show NotificationsApi;
export 'src/api/offers_api.dart' show OffersApi;
export 'src/api/organization_api.dart' show OrganizationApi;
export 'src/api/preferences_api.dart' show PreferencesApi;
export 'src/api/privacy_api.dart' show PrivacyApi;
export 'src/api/referrals_api.dart' show ReferralsApi;
export 'src/api/security_api.dart' show SecurityApi;
export 'src/api/status_api.dart' show StatusApi;
export 'src/api/subscription_api.dart' show SubscriptionApi;
export 'src/api/support_api.dart' show SupportApi;
export 'src/api/telemetry_api.dart' show TelemetryApi;
export 'src/apps/capabilities.dart'
    show
        CapabilityKeyInvalidException,
        CapabilityReportValidation,
        ReportCapabilityWire;
export 'src/capabilities.dart'
    show SdkCapabilities, CapabilityDisabledException;
export 'src/client.dart' show LicenseClient;
export 'src/config.dart' show VanaheimConfig, VanaheimMode, DirectConfig;
// FRON (Bifrost-Direct) surface — only relevant when
// `VanaheimConfig.mode == VanaheimMode.fron`. The existing L2 surface
// (`LicenseClient`) remains untouched.
export 'src/direct/direct_client.dart' show DirectClient;
export 'src/direct/direct_models.dart'
    show
        RegisterResult,
        ActivateResult,
        VerifyResult,
        HeartbeatResult,
        CatalogSnapshot,
        DirectTierInfo,
        DirectEntitlements,
        StatsResult,
        StatsEvent,
        ErrorResult,
        ErrorReport,
        DirectError,
        DirectBadRequestError,
        DirectLicenseInvalidError,
        DirectLicenseExpiredError,
        DirectSeatExceededError,
        DirectRateLimitError,
        DirectFcmTokenReusedError,
        DirectNoProviderConfiguredError,
        DirectProviderFailedError,
        DirectProjectDisabledError,
        DirectReplayDetectedError,
        DirectDeviceRevokedError,
        registerDirectErrorExtension;
// FRON payment surface — Tier 2 endpoints (checkout / intent / portal /
// restore / iap-verify / refresh). Methods land on [DirectClient] via
// the `DirectPaymentMethods` extension; browser-open glue ships as
// host-app-wired helpers in `direct_payment_browser.dart`.
export 'src/direct/direct_payment_methods.dart'
    show
        DirectPaymentMethods,
        kIapReceiptMaxBytes,
        kRestorePurchasesMaxRows;
export 'src/direct/direct_payment_models.dart'
    show
        CheckoutSession,
        PaymentIntent,
        PortalSession,
        RestoredPurchase,
        RestoreResult,
        IapVerifyResult,
        DirectPaymentProviderFailedError,
        DirectNoActiveSubscriptionError,
        DirectSessionNotFoundError,
        DirectSessionNotCompleteError,
        DirectIapReceiptInvalidError,
        directPaymentErrorFromCode,
        ensureDirectPaymentErrorsRegistered;
export 'src/direct/direct_payment_browser.dart'
    show
        DirectPaymentUrlOpener,
        DirectPaymentUrlOpenerFn,
        DirectPaymentReturn,
        DirectPaymentDeepLinkHandler,
        openCheckoutUrl,
        openPortalUrl;
// §2A.12 i18n message formatter — products may compose their own.
export 'src/i18n/formatter.dart' show Formatter;
// §2A.1 / §3A.3 push token provider — products implement to wire FCM/APNs.
export 'src/push/push_token_provider.dart'
    show PushTokenProvider, NoPushTokenProvider;
// §2A.5 JWE confidentiality wrapper — products plug in their own decryptor.
// v2: NoDeviceKeypairProvider is gone — host products MUST wire a real
// DeviceKeypairProvider (Cryptography-backed default available in the
// JWE-codec wave) since L2 device enrollment is mandatory.
export 'src/crypto/jwe.dart'
    show
        JwePayloadDecryptor,
        DeviceKeypairProvider,
        JweDecryptionRequiredException,
        JweDecryptionFailedException,
        LicenseTokenFormat,
        detectTokenFormat;
// v2 / Vanaheim L2 recipient-key client (single recipient; replaces v1's
// two-recipient Bifrost-direct flow).
export 'src/transport/l2_keys_client.dart' show L2KeysClient, L2RecipientKey;
export 'src/exceptions.dart';
export 'src/models.dart';
// Diagnostics: the persisted ring-buffer of recent error events. Products
// read this for "attach diagnostics" support flows; the SDK never
// auto-uploads.
export 'src/telemetry/error_telemetry.dart' show TelemetryEvent, TelemetrySeverity;

// Advanced: products that need custom auth wiring can inject providers.
// Defaults use Firebase plugins.
export 'src/auth/auth_providers.dart' show AuthTokenProvider, AppCheckTokenProvider;
