# vanaheim

Official Flutter/Dart SDK for the License Store backend (codename: Vanaheim). Activates a device, verifies entitlements offline against a signed JWT, and exposes typed accessors (`hasFeature`, `quota`, `tier`) for paywall logic.

One package covers iOS, iPadOS, Android (phones + tablets), macOS, Windows, Linux, and Web.

---

## Install

```yaml
dependencies:
  vanaheim:
    git:
      url: https://github.com/yourorg/license-store
      path: dart/vanaheim
```

(Switch to a pub.dev coordinate once published.)

## Onboarding — get your product credentials

Before any of the prerequisites below makes sense, your product needs to be **registered with License Store** so it has a slug and a secret. While the self-serve admin UI is post-MVP, the manual flow is:

1. **Open a ticket with the platform team** (Slack: `#license-store-onboarding`, email: `platform-team@<your-company>`) with:
   - Product name + a short URL-safe slug (e.g. `zenkit`, `bookworm`)
   - Tier ladder you want (e.g. `base`, `plus`, `pro`)
   - Per-tier entitlements (features + quotas) — see `DEVICE_BINDING.md` and `TIER_CHANGES.md` for what's possible
   - Pricing (if not free) and intended billing model (one-time / monthly / yearly / lifetime)
2. The platform team registers the product in the catalog (`POST /v1/admin/products`) and provisions a per-product SDK secret in GCP Secret Manager.
3. You receive **two values**:
   - `LS_PRODUCT_SLUG` — used as `productSlug` argument to `LicenseClient.connect`
   - `LS_SDK_SECRET` — embed at build time via `--dart-define=LS_SDK_SECRET=…`
4. **Secret rotation:** if you suspect a leak (or per the 90-day rotation cadence), email the platform team. Old + new secrets are valid in parallel for 30 days so you can roll the new version without breaking installed clients.

> The SDK secret is not the only line of defense — Firebase App Check is what actually proves "this is your real app on a non-rooted device." Both layers must be wired for the integration to be production-ready. See `LICENSE_FLOW.md` §4.

## Prerequisites

- Firebase project (Auth + App Check) configured for your product. App Check providers per platform:
  - iOS / iPadOS / macOS → App Attest (with DeviceCheck fallback)
  - Android → Play Integrity
  - **Web → reCAPTCHA Enterprise** (you must pass `webProvider:` when activating App Check — see Quick start)
  - Windows / Linux desktop → no first-party OS attestation; rely on cert pinning + code signing.
- A signed-in `FirebaseAuth` user (the SDK reads `currentUser.getIdToken()`).
- A per-product **SDK secret** issued by License Store (see Onboarding above).

## Quick start

```dart
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:vanaheim/vanaheim.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await FirebaseAppCheck.instance.activate(
    androidProvider: AndroidProvider.playIntegrity,
    appleProvider: AppleProvider.appAttestWithDeviceCheckFallback,
    // Web requires a site key from reCAPTCHA Enterprise — omit only if you
    // never build for web. Leaving this unset on a web build → runtime failure.
    webProvider: ReCaptchaEnterpriseProvider('<your-recaptcha-site-key>'),
  );

  // After your user signs in via FirebaseAuth…
  final client = await LicenseClient.connect(
    controlPlaneUrl: Uri.parse('https://licenses.example.com'),
    productSlug: 'zenkit',
    sdkSecret: const String.fromEnvironment('LS_SDK_SECRET'),
  );

  await client.activate(deviceName: 'iPhone 15 Pro');

  if (client.hasFeature('export')) {
    // unlock export button
  }
  final maxSeats = client.quota<int>('max_seats');

  client.stateChanges.listen((change) {
    switch (change.kind) {
      case LicenseStateChangeKind.entitlementsUpdated:
        // tier changed server-side; re-render gated UI
        break;
      case LicenseStateChangeKind.sessionRevoked:
        // user signed in on another device (floating tier) — lock UI
        break;
      case LicenseStateChangeKind.expired:
        // refresh failed past grace — show paywall
        break;
      default:
    }
  });
}
```

## Build-time configuration

```bash
flutter build apk \
  --dart-define=LS_SDK_SECRET=<your-product-secret> \
  --dart-define=LS_CONTROL_PLANE=https://licenses.example.com \
  --dart-define=LS_PRODUCT_SLUG=zenkit
```

The SDK secret ships inside the binary (defense-in-depth, not the only line of defense — Firebase App Check is what actually proves "this is your real app").

## Typed exceptions

Branch product UX on these:

| Exception | Trigger | UX |
|---|---|---|
| `SeatCapExceededException` | Hard-lock tier; cap is full | Prompt user to transfer or upgrade |
| `SessionRevokedException` | Floating tier; another device claimed the session | Lock UI; show "signed out elsewhere" |
| `TransferCooldownException` | Hard-lock; transfer attempted before cooldown | Surface `availableAt` |
| `LicenseExpiredException` | Cached JWT expired, refresh failed | Show paywall |
| `AppCheckFailedException` | Device failed Firebase App Check | Likely a non-genuine app; refuse |
| `NetworkException` | Transient network/server failure | Retry with backoff |
| `JwtVerificationException` | Server returned an invalid JWT | Treat as compromised; clear cache |

## What the SDK does for you

- **Online verify** — refreshes the JWT periodically (default ~1 day before expiry) in the background.
- **Offline verify** — every `hasFeature` / `quota` call is local: signature-checked against pinned JWKS, claims read from JWT. No network on hot path.
- **Offline grace** — uses the cached JWT until `exp`. Failures past `exp` are explicit exceptions, never fail-open.
- **Floating-tier bump** — `activate()` reports `kickedDevice`; verify on the bumped device raises `SessionRevokedException`.
- **Hard-lock transfer** — `transferToNewDevice()` with cooldown enforcement.
- **Entitlements staleness** — when the server bumps `entitlements_version` (tier change, refund), the next verify fires `entitlementsUpdated` so your UI can re-render.

## What the SDK does NOT do

- **Run Stripe/Paddle checkout** — that's the product's web/in-app purchase flow. The SDK just observes the resulting state change.
- **Display paywall UI** — product-team owned.
- **Manage Firebase login** — assumes a signed-in user.

## Diagnostics — recent errors

Every typed exception the SDK throws or catches is captured into a bounded
ring buffer that persists to secure storage. Use it to attach a diagnostic
bundle to support tickets:

```dart
// Last 20 events (or all if fewer captured). JSON-serializable shape
// {generated_at, events: [{ts, severity, source, error_class, message, stack, context}, ...]}.
final bundle = client.diagnostics(limit: 20);

// Send to your own support backend, write to a "Copy diagnostics" button,
// or display in a debug screen. The SDK never auto-uploads.
final report = jsonEncode(bundle);
```

Properties:

- **Non-blocking and never throws.** Capture is a synchronous write into
  an in-memory ring (default 50 events); persistence is debounced (2 s).
- **Bounded.** Oldest events drop first; no unbounded growth.
- **Survives app restarts.** Persisted to the same secure storage as the
  JWT, so a crash + relaunch still has the prior context.
- **NOT cleared by sign-out.** `LicenseClient.deactivate()` / cache clear
  leaves diagnostics intact. Call `client.clearDiagnostics()` to drop them.
- **No secrets.** The SDK never logs JWTs, secrets, or full HTTP bodies —
  only typed-exception messages + stack traces.

Behind the scenes the backend also records every panic / 5xx into an
`error_log` table (partitioned monthly). Pair an SDK-side diagnostic
bundle with the backend `request_id` (echoed in the typed exception
message) to trace a single failure end-to-end.

## Certificate pinning

For production, supply leaf-cert SPKI pins via [`LicenseStoreConfig.pinnedSpkiSha256`]. Keep two pins active during rotation windows.

```dart
LicenseStoreConfig(
  pinnedSpkiSha256: [
    'AAAAA…current SPKI hash…',
    'BBBBB…next SPKI hash…',
  ],
)
```

## Testing without Firebase

Inject custom providers:

```dart
LicenseClient.connect(
  controlPlaneUrl: Uri.parse('http://localhost:8080'),
  productSlug: 'zenkit',
  sdkSecret: 'dev-shared-secret',
  auth: DevAuthTokenProvider(uid: 'dev-uid', email: 'dev@example.com'),
  appCheck: NoAppCheckProvider(),
  cache: InMemorySecureCache(),
);
```

The dev backend (`FIREBASE_PROJECT_ID` / `FIREBASE_PROJECT_NUMBER` unset) accepts `dev:<uid>:<email>` tokens and bypasses App Check.

## License

Internal — see repo root.
