## 0.1.25

- Ecosystem-alignment bump; SDK source unchanged since 0.1.19; version bumped
  to match Bifrost v0.1.25 release.

## 0.1.19

- `AppsApi.reportCapability(key, value)` — new SDK surface for reporting per-app
  presence flags to the License Store catalog. Wire: `POST /v1/apps/capabilities`
  (PAK-JWE-authed, per-project scope from the PAK claim). Keys are `has_`-prefixed
  snake_case (`^has_[a-z0-9_]{2,64}$`), values are boolean (v0.1.19 scope: BOOL
  ONLY). Idempotent by `(project_id, key)`; retries on 429 with capped
  exponential backoff (5 attempts, ±30% jitter, 3.2s cap).
- Byte-shape parity with the TS + Swift SDKs — `{"key": ..., "value": ...}` with
  exactly 2 keys; validated by the cross-language parity fixture.
- Accessor: `LicenseClient.apps.reportCapability(...)`.

## 0.1.0

Initial release. Covers the full server contract:

- `LicenseClient.connect / activate / verify / transferToNewDevice / deactivate`
- `hasFeature`, `quota<T>`, `tier`, `expiresAt`, `entitlementsVersion`
- HMAC + Firebase ID token + Firebase App Check on every authenticated request
- Ed25519 JWT verification offline via pinned JWKS
- Floating-tier bump with `KickedDevice` surfacing
- Hard-lock transfer with cooldown
- `LicenseStateChange` stream (activated / entitlementsUpdated / sessionRevoked / expired / error)
- Per-platform device fingerprint (iOS/iPadOS/macOS/Android/Windows/Linux/Web)
- Secure storage via `flutter_secure_storage`
- Certificate pinning via `http_certificate_pinning`
