package com.licensestore.license_store_sdk_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
