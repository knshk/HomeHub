import 'dart:async';
import 'dart:typed_data';

import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:vanaheim/vanaheim.dart';

import 'firebase_options.dart';
import 'fron_example.dart';
import 'fron_payment_example.dart';

// Per-product secret embedded at build time via:
//   flutter build apk --dart-define=LS_SDK_SECRET=... \
//                     --dart-define=LS_CONTROL_PLANE=https://licenses.example.com \
//                     --dart-define=LS_PRODUCT_SLUG=zenkit
//                     --dart-define=LS_L2_BASE_URL=https://l2.example.com \
//                     --dart-define=LS_PROJECT_ID=42
const _sdkSecret = String.fromEnvironment('LS_SDK_SECRET');
const _controlPlane = String.fromEnvironment(
  'LS_CONTROL_PLANE',
  defaultValue: 'http://localhost:8080',
);
const _productSlug = String.fromEnvironment(
  'LS_PRODUCT_SLUG',
  defaultValue: 'zenkit',
);
const _l2BaseUrl = String.fromEnvironment(
  'LS_L2_BASE_URL',
  defaultValue: 'http://localhost:8081',
);
const _projectId =
    int.fromEnvironment('LS_PROJECT_ID', defaultValue: 1);

/// Demo-only JWE decryptor. Production apps wire the real
/// `CryptographyJweDecryptor` (X25519 ECDH-ES + A256GCM) backed by a
/// platform-secured device keypair. This stub satisfies the
/// [VanaheimConfig.jweDecryptor] required field so the example compiles
/// against an unencrypted local backend.
class _NoopJweDecryptor implements JwePayloadDecryptor {
  const _NoopJweDecryptor();
  @override
  Future<String> decrypt(String jwe) async => jwe;
}

/// Demo-only device keypair provider. Returns an all-zero 32-byte pubkey
/// so first-boot L2 enrollment can be exercised against a permissive local
/// backend. Production apps wire `CryptographyDeviceKeypairProvider`,
/// which persists the private scalar in platform-secured storage (Keychain
/// / Keystore / DPAPI / libsecret).
class _NoopDeviceKeypairProvider implements DeviceKeypairProvider {
  const _NoopDeviceKeypairProvider();
  @override
  Future<Uint8List> getPublicKey() async => Uint8List(32);
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await FirebaseAppCheck.instance.activate(
    androidProvider: AndroidProvider.playIntegrity,
    appleProvider: AppleProvider.appAttestWithDeviceCheckFallback,
    // Web — set webProvider to a reCAPTCHA Enterprise site key.
    // webProvider: ReCaptchaEnterpriseProvider('<your-site-key>'),
  );
  runApp(const ExampleApp());
}

class ExampleApp extends StatelessWidget {
  const ExampleApp({super.key});
  @override
  Widget build(BuildContext context) =>
      const MaterialApp(home: _ModeSelector());
}

/// Mode toggle — picks which demo to drive. The L2 demo (`_Home`) shows
/// the Alfheim-backed `LicenseClient` path; the FRON demos show the
/// `DirectClient` register/verify/payment paths against Bifrost
/// directly. Kept as a separate widget so each demo owns its own
/// lifecycle (the FRON `DirectClient` and L2 `LicenseClient` are
/// disposed when their screen is popped, not when the toggle flips).
class _ModeSelector extends StatelessWidget {
  const _ModeSelector();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Vanaheim demo — pick a mode')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'This example app ships three flows. The L2 demo talks to '
              'Alfheim; the FRON demos talk directly to Bifrost.',
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => Navigator.of(context).push<void>(
                MaterialPageRoute(builder: (_) => const _Home()),
              ),
              child: const Text('L2 mode (Alfheim) — license + entitlements'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => Navigator.of(context).push<void>(
                MaterialPageRoute(builder: (_) => const FronExampleScreen()),
              ),
              child: const Text(
                  'FRON mode (Bifrost-Direct) — register + verify'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => Navigator.of(context).push<void>(
                MaterialPageRoute(
                  builder: (_) => const FronPaymentExampleScreen(),
                ),
              ),
              child: const Text('FRON payment — checkout / portal / IAP'),
            ),
          ],
        ),
      ),
    );
  }
}

class _Home extends StatefulWidget {
  const _Home();
  @override
  State<_Home> createState() => _HomeState();
}

class _HomeState extends State<_Home> {
  LicenseClient? _client;
  String _status = 'Sign in to begin';
  String _tier = '-';
  bool _canExport = false;
  int? _seatLimit;

  @override
  void initState() {
    super.initState();
    FirebaseAuth.instance.authStateChanges().listen((u) async {
      if (u == null) {
        unawaited(_client?.dispose() ?? Future<void>.value());
        setState(() {
          _client = null;
          _status = 'Signed out';
        });
        return;
      }
      await _connectAndActivate();
    });
  }

  Future<void> _connectAndActivate() async {
    try {
      setState(() => _status = 'Connecting…');
      final client = await LicenseClient.connect(
        controlPlaneUrl: Uri.parse(_controlPlane),
        productSlug: _productSlug,
        sdkSecret: _sdkSecret,
        config: VanaheimConfig(
          projectId: _projectId,
          l2BaseUrl: Uri.parse(_l2BaseUrl),
          jweDecryptor: const _NoopJweDecryptor(),
          deviceKeypairProvider: const _NoopDeviceKeypairProvider(),
        ),
      );
      client.stateChanges.listen(_onStateChange);

      setState(() => _status = 'Activating device…');
      final res = await client.activate(deviceName: 'Example device');
      _client = client;
      _refreshUi();
      if (res.kickedDevice != null) {
        _toast('Signed out on ${res.kickedDevice!.deviceName ?? "another device"}');
      }
    } on SeatCapExceededException {
      _toast('All seats in use — free a device or upgrade');
    } on TransferCooldownException catch (e) {
      _toast('Transfer available at ${e.availableAt.toLocal()}');
    } catch (e) {
      setState(() => _status = 'Error: $e');
    }
  }

  void _onStateChange(LicenseStateChange c) {
    switch (c.kind) {
      case LicenseStateChangeKind.entitlementsUpdated:
        _refreshUi();
        _toast('Plan updated');
      case LicenseStateChangeKind.configUpdated:
        // Runtime config (cfg_v) bumped server-side — re-read anything
        // previously fetched via client.config<T>() / client.featureEnabled().
        _refreshUi();
      case LicenseStateChangeKind.preferencesUpdated:
        // Cross-product prefs (prefs_v) bumped — re-read any locale/theme
        // values pulled from client.preferences.
        _refreshUi();
      case LicenseStateChangeKind.notificationReceived:
        // A new inbox notification arrived via push wake-trigger; payload
        // is in c.notification. Real apps would route to an inbox screen.
        _toast('New notification');
      case LicenseStateChangeKind.sessionRevoked:
        unawaited(_client?.dispose() ?? Future<void>.value());
        _client = null;
        setState(() => _status = 'Signed out — used on another device');
      case LicenseStateChangeKind.expired:
        setState(() => _status = 'License expired — please re-subscribe');
      case LicenseStateChangeKind.error:
        _toast('Background error: ${c.error}');
      case LicenseStateChangeKind.activated:
        _refreshUi();
    }
  }

  void _refreshUi() {
    final c = _client;
    if (c == null) return;
    setState(() {
      _status = 'Active until ${c.expiresAt?.toLocal()}';
      _tier = c.tier ?? '-';
      _canExport = c.hasFeature('export');
      _seatLimit = c.quota<int>('max_seats');
    });
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('License Store demo')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_status),
            const SizedBox(height: 12),
            Text('Tier: $_tier'),
            Text('Can export: $_canExport'),
            Text('Seat limit: ${_seatLimit ?? "-"}'),
            const Spacer(),
            Row(children: [
              ElevatedButton(
                onPressed: _client == null ? null : () => _client!.verify(),
                child: const Text('Force verify'),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: _client == null
                    ? null
                    : () async {
                        try {
                          await _client!.transferToNewDevice();
                          _toast('Device freed — install on a new device');
                        } on TransferCooldownException catch (e) {
                          _toast('Wait until ${e.availableAt.toLocal()}');
                        }
                      },
                child: const Text('Move to new device'),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}
