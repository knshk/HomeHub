// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited
//
// FRON-mode example screen. Demonstrates the Bifrost-Direct path —
// register / activate / verify / heartbeat / hasFeature / quota /
// sendStats / reportError — with typed-error handling for each
// `DirectError` subclass.
//
// Built so it runs against a local Bifrost via:
//   flutter run --dart-define=LS_FRON_BIFROST_URL=http://localhost:8081 \
//               --dart-define=LS_FRON_PROJECT_ID=42
//
// Pair with `fron_payment_example.dart` for the billing surface.

import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:vanaheim/vanaheim.dart';

// --dart-define knobs (see file header).
const String _kBifrostUrl = String.fromEnvironment(
  'LS_FRON_BIFROST_URL',
  defaultValue: 'http://localhost:8081',
);
const String _kProjectId = String.fromEnvironment(
  'LS_FRON_PROJECT_ID',
  defaultValue: '1',
);
// License key used by `register()`. In production this is collected from
// the user (paste-in / OAuth-issued / IAP receipt). For the demo we pull
// it from a --dart-define so the example app stays driver-less.
const String _kLicenseKey = String.fromEnvironment(
  'LS_FRON_LICENSE_KEY',
  defaultValue: 'lic_demo_0000',
);

/// Standalone FRON-mode example. Drives the `DirectClient` lifecycle from
/// `connect → register → verify → heartbeat`, surfaces entitlement gates,
/// and demonstrates the full `DirectError` error-handling matrix.
class FronExampleScreen extends StatefulWidget {
  const FronExampleScreen({super.key});

  @override
  State<FronExampleScreen> createState() => _FronExampleScreenState();
}

class _FronExampleScreenState extends State<FronExampleScreen> {
  DirectClient? _client;
  String _status = 'Not connected';
  String _tier = '-';
  int _seatQuota = 0;
  bool _canExport = false;
  int _verifyCount = 0;

  @override
  void initState() {
    super.initState();
    unawaited(_connect());
  }

  @override
  void dispose() {
    unawaited(_client?.dispose());
    super.dispose();
  }

  // --------------------------------------------------------------------
  // Lifecycle
  // --------------------------------------------------------------------

  Future<void> _connect() async {
    setState(() => _status = 'Connecting to Bifrost…');
    try {
      // Build the unified config with mode=fron + nested DirectConfig.
      // The host product still hands us a real X25519 keypair provider
      // and JWE decryptor — even in FRON mode they're contract-required
      // by VanaheimConfig.
      final cfg = VanaheimConfig(
        // projectId on VanaheimConfig is the int used by the L2 path;
        // FRON ignores it and reads DirectConfig.projectId instead.
        projectId: int.tryParse(_kProjectId) ?? 0,
        l2BaseUrl: Uri.parse(_kBifrostUrl),
        jweDecryptor: const _NoopJweDecryptor(),
        deviceKeypairProvider: const _NoopDeviceKeypairProvider(),
        mode: VanaheimMode.fron,
        directConfig: DirectConfig(
          bifrostBaseUrl: Uri.parse(_kBifrostUrl),
          projectId: _kProjectId,
          // Speed up the demo — production defaults are 5 min / 50 events.
          statsFlushInterval: const Duration(seconds: 30),
          statsFlushBatchSize: 8,
        ),
      );
      final client = await LicenseClient.connectDirect(config: cfg);
      _client = client;
      if (client.isRegistered) {
        // Returning user — go straight to verify to refresh entitlements.
        await _verify();
      } else {
        // First-boot — register against the demo license key.
        await _register();
      }
    } on DirectError catch (e) {
      _handleDirectError(e, 'connect');
    } catch (e) {
      setState(() => _status = 'Connect failed: $e');
    }
  }

  Future<void> _register() async {
    final client = _client;
    if (client == null) return;
    setState(() => _status = 'Registering device…');
    try {
      final res = await client.register(
        licenseKey: _kLicenseKey,
        // Real apps hash device-specific signals (IDFV / install id / etc.)
        // and pass an opaque string. Keep it stable across re-installs to
        // let the server detect dupes.
        fingerprint: 'demo-fingerprint-${DateTime.now().day}',
        appMeta: {
          'app': 'vanaheim_example',
          'version': '0.1.0',
        },
      );
      setState(() {
        _status = 'Registered — device ${_shortId(res.deviceId)}';
        _tier = res.entitlements.tier;
        _canExport = res.entitlements.has('export');
        _seatQuota = res.entitlements.quotaFor('max_seats');
      });
    } on DirectError catch (e) {
      _handleDirectError(e, 'register');
    }
  }

  Future<void> _verify() async {
    final client = _client;
    if (client == null) return;
    setState(() => _status = 'Verifying…');
    try {
      final res = await client.verify();
      _verifyCount++;
      setState(() {
        _status = 'Verified ($_verifyCount) — issued at '
            '${DateTime.fromMillisecondsSinceEpoch(res.issuedAtMs).toLocal()}';
        _tier = res.entitlements.tier;
        _canExport = res.entitlements.has('export');
        _seatQuota = res.entitlements.quotaFor('max_seats');
      });
    } on DirectError catch (e) {
      _handleDirectError(e, 'verify');
    }
  }

  Future<void> _sendDemoStats() async {
    final client = _client;
    if (client == null) return;
    try {
      final res = await client.sendStats([
        StatsEvent(
          name: 'example.button_press',
          timestampMs: DateTime.now().toUtc().millisecondsSinceEpoch,
          attributes: const {'screen': 'fron_example'},
        ),
      ]);
      _toast('Queued ${res.accepted} stats event(s)');
    } on DirectError catch (e) {
      _handleDirectError(e, 'sendStats');
    }
  }

  Future<void> _reportDemoError() async {
    final client = _client;
    if (client == null) return;
    try {
      final res = await client.reportError(const ErrorReport(
        message: 'Demo error from FRON example',
        severity: 'warn',
        context: {'demo': true},
      ));
      _toast(res.throttled
          ? 'Error throttled (${res.errorId})'
          : 'Reported error ${_shortId(res.errorId)}');
    } on DirectError catch (e) {
      _handleDirectError(e, 'reportError');
    }
  }

  // --------------------------------------------------------------------
  // Error handling — one branch per DirectError subclass.
  // --------------------------------------------------------------------

  Future<void> _handleDirectError(DirectError err, String op) async {
    // Branch on the typed subclass so each surface gets the right UX.
    // The default branch keeps the code totalising — new server codes
    // surface as generic DirectError until we add a case here.
    if (err is DirectRateLimitError) {
      // Server-throttled — back off then retry once. Real apps would
      // schedule via WorkManager / BGTaskScheduler.
      final wait = Duration(milliseconds: err.retryAfterMs.clamp(250, 30000));
      setState(() => _status = 'Rate-limited on $op (retry in ${wait.inMilliseconds}ms)');
      await Future<void>.delayed(wait);
      _toast('Backoff complete — try $op again');
      return;
    }
    if (err is DirectDeviceRevokedError) {
      // Revocation is terminal — wipe local identity and re-register.
      setState(() => _status = 'Device revoked — wiping + re-registering');
      await _client?.deactivate('revoked-by-server');
      await _register();
      return;
    }
    if (err is DirectBadRequestError) {
      // User-facing: show the message verbatim. These are validation
      // failures the user can correct (e.g. bad license key).
      _toast('Request rejected: ${err.message}');
      setState(() => _status = 'Bad request on $op');
      return;
    }
    if (err is DirectLicenseInvalidError) {
      _toast('License key not recognised — paste a valid key');
      setState(() => _status = 'Invalid license on $op');
      return;
    }
    if (err is DirectLicenseExpiredError) {
      _toast('License expired — please renew');
      setState(() => _status = 'License expired on $op');
      return;
    }
    if (err is DirectSeatExceededError) {
      _toast('All seats in use — free a device or upgrade');
      setState(() => _status = 'Seat cap exceeded on $op');
      return;
    }
    if (err is DirectProjectDisabledError) {
      _toast('Direct mode not enabled for this project — contact the developer');
      setState(() => _status = 'Project disabled');
      return;
    }
    if (err is DirectReplayDetectedError) {
      // Cryptographic-safety net — clear keys and re-register.
      setState(() => _status = 'Replay detected — regenerating keypair');
      await _client?.deactivate('replay-detected');
      await _register();
      return;
    }
    if (err is DirectNoProviderConfiguredError) {
      _toast('No provider configured for $op on this project');
      return;
    }
    if (err is DirectProviderFailedError) {
      _toast('Upstream provider failed (${err.providerCode}) on $op');
      return;
    }
    if (err is DirectFcmTokenReusedError) {
      _toast('Push token reused — rotating');
      return;
    }
    // Unknown / generic — log + show.
    setState(() => _status = '${err.code} on $op: ${err.message}');
  }

  // --------------------------------------------------------------------
  // UI
  // --------------------------------------------------------------------

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  String _shortId(String id) => id.length > 10 ? '${id.substring(0, 10)}…' : id;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Vanaheim FRON demo')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Bifrost: $_kBifrostUrl'),
            const Text('Project: $_kProjectId'),
            const Divider(),
            Text('Status: $_status'),
            const SizedBox(height: 12),
            Text('Tier: $_tier'),
            Text('hasFeature(export): $_canExport'),
            Text('quota(max_seats): $_seatQuota'),
            const Spacer(),
            Wrap(spacing: 8, runSpacing: 8, children: [
              ElevatedButton(
                onPressed: _client == null ? null : _verify,
                child: const Text('Force verify'),
              ),
              ElevatedButton(
                onPressed: _client == null ? null : _sendDemoStats,
                child: const Text('Queue stats'),
              ),
              ElevatedButton(
                onPressed: _client == null ? null : _reportDemoError,
                child: const Text('Report error'),
              ),
              ElevatedButton(
                onPressed: _client == null
                    ? null
                    : () async {
                        await _client!.deactivate('user-requested');
                        setState(() {
                          _status = 'Deactivated';
                          _tier = '-';
                          _canExport = false;
                          _seatQuota = 0;
                        });
                      },
                child: const Text('Deactivate'),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}

/// Demo-only JWE decryptor — see `main.dart` for rationale. FRON mode
/// uses its own JWE path internally; this stub satisfies the
/// `VanaheimConfig.jweDecryptor` field so the example compiles.
class _NoopJweDecryptor implements JwePayloadDecryptor {
  const _NoopJweDecryptor();
  @override
  Future<String> decrypt(String jwe) async => jwe;
}

/// Demo-only device keypair provider — see `main.dart`.
class _NoopDeviceKeypairProvider implements DeviceKeypairProvider {
  const _NoopDeviceKeypairProvider();
  @override
  Future<Uint8List> getPublicKey() async => Uint8List(32);
}
