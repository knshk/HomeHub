// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited
//
// FRON payment-surface demo. Wires the six Tier-2 billing endpoints
// (checkout / portal / restore / iap-verify / refresh + DeepLink return)
// onto a Flutter screen.
//
// Reuses the same --dart-define knobs as `fron_example.dart`:
//   LS_FRON_BIFROST_URL, LS_FRON_PROJECT_ID, LS_FRON_LICENSE_KEY.
//
// The host-side browser opener is a placeholder that just shows the URL
// — production apps wire `url_launcher.launchUrl` (or an in-app
// SafariViewController / Chrome Custom Tab) into the
// `DirectPaymentUrlOpener` callback. The deep-link handler IS real and
// will dispatch a `refreshAfterPayment` when the system delivers a
// matching URI.

import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:vanaheim/vanaheim.dart';

const String _kBifrostUrl = String.fromEnvironment(
  'LS_FRON_BIFROST_URL',
  defaultValue: 'http://localhost:8081',
);
const String _kProjectId = String.fromEnvironment(
  'LS_FRON_PROJECT_ID',
  defaultValue: '1',
);
const String _kLicenseKey = String.fromEnvironment(
  'LS_FRON_LICENSE_KEY',
  defaultValue: 'lic_demo_0000',
);
// Deep-link return URL. The provider redirects the browser here once
// checkout finishes; the OS routes the URI back to our deep-link
// handler.
const String _kReturnUrl = 'vanaheimexample://upgrade-done';

/// Drives the full payment lifecycle — startCheckout, openPortal,
/// restorePurchases, verifyIapReceipt — and listens on
/// `DirectPaymentDeepLinkHandler.onReturn` for the post-checkout
/// callback so `refreshAfterPayment` is dispatched automatically.
class FronPaymentExampleScreen extends StatefulWidget {
  const FronPaymentExampleScreen({super.key});

  @override
  State<FronPaymentExampleScreen> createState() =>
      _FronPaymentExampleScreenState();
}

class _FronPaymentExampleScreenState extends State<FronPaymentExampleScreen> {
  DirectClient? _client;
  String _status = 'Connecting…';
  String _tier = '-';
  String? _sessionId;
  StreamSubscription<DirectPaymentReturn>? _deepLinkSub;

  late final DirectPaymentUrlOpener _opener;

  @override
  void initState() {
    super.initState();
    // Wire the host-app browser opener. In production swap in
    // `launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication)`.
    _opener = DirectPaymentUrlOpener(
      label: 'example-placeholder-opener',
      open: (url) async {
        // Surface the URL into the UI so a developer can copy-paste it
        // into a real browser while iterating without `url_launcher`.
        _toast('Open URL: $url');
      },
    );
    // Subscribe to the deep-link handler — refreshes entitlements
    // whenever the system delivers a payment-return URI to the app.
    _deepLinkSub =
        DirectPaymentDeepLinkHandler.instance.onReturn.listen(_onDeepLink);
    unawaited(_connect());
  }

  @override
  void dispose() {
    unawaited(_deepLinkSub?.cancel());
    unawaited(_client?.dispose());
    super.dispose();
  }

  Future<void> _connect() async {
    try {
      final cfg = VanaheimConfig(
        projectId: int.tryParse(_kProjectId) ?? 0,
        l2BaseUrl: Uri.parse(_kBifrostUrl),
        jweDecryptor: const _NoopJweDecryptor(),
        deviceKeypairProvider: const _NoopDeviceKeypairProvider(),
        mode: VanaheimMode.fron,
        directConfig: DirectConfig(
          bifrostBaseUrl: Uri.parse(_kBifrostUrl),
          projectId: _kProjectId,
        ),
      );
      _client = await LicenseClient.connectDirect(config: cfg);
      if (!_client!.isRegistered) {
        await _client!.register(
          licenseKey: _kLicenseKey,
          fingerprint: 'demo-payment-fingerprint',
        );
      } else {
        await _client!.verify();
      }
      _refreshUi('Connected');
    } on DirectError catch (e) {
      setState(() => _status = '${e.code}: ${e.message}');
    } catch (e) {
      setState(() => _status = 'Connect failed: $e');
    }
  }

  // --------------------------------------------------------------------
  // Payment actions
  // --------------------------------------------------------------------

  Future<void> _startCheckout() async {
    final client = _client;
    if (client == null) return;
    try {
      final session = await client.startCheckout(
        tier: 'pro_yearly',
        billingCycle: 'yearly',
        currency: 'USD',
        returnUrl: _kReturnUrl,
        cancelUrl: '$_kReturnUrl?status=cancel',
      );
      _sessionId = session.sessionId;
      await openCheckoutUrl(session, opener: _opener);
      setState(() => _status = 'Checkout opened (session $_sessionId)');
    } on DirectPaymentProviderFailedError catch (e) {
      _toast('Provider ${e.provider} failed: ${e.message}');
    } on DirectNoProviderConfiguredError {
      _toast('No payment provider wired for this project');
    } on DirectError catch (e) {
      _toast('${e.code}: ${e.message}');
    }
  }

  Future<void> _openCustomerPortal() async {
    final client = _client;
    if (client == null) return;
    try {
      final portal = await client.openPortal(returnUrl: _kReturnUrl);
      await openPortalUrl(portal, opener: _opener);
      setState(() => _status = 'Portal opened');
    } on DirectNoActiveSubscriptionError {
      // Route the user to checkout instead of failing loudly.
      _toast('No active subscription — opening checkout');
      await _startCheckout();
    } on DirectError catch (e) {
      _toast('${e.code}: ${e.message}');
    }
  }

  Future<void> _restorePurchases() async {
    final client = _client;
    if (client == null) return;
    try {
      final result = await client.restorePurchases(platform: 'ios');
      if (result.restoredCount == 0) {
        _toast('No purchases to restore');
      } else {
        _toast('Restored ${result.restoredCount} purchase(s)');
      }
      _refreshUi('Restore complete');
    } on DirectError catch (e) {
      _toast('${e.code}: ${e.message}');
    }
  }

  Future<void> _verifyIapReceipt() async {
    final client = _client;
    if (client == null) return;
    // Placeholder iOS receipt — in a real app this comes from
    // `Transaction.currentEntitlements` (StoreKit 2) or
    // `[NSBundle.mainBundle.appStoreReceiptURL]` (legacy).
    const placeholderReceipt =
        'MIIB...placeholder-base64-app-store-receipt...==';
    try {
      final result = await client.verifyIapReceipt(
        platform: 'ios',
        receipt: placeholderReceipt,
      );
      if (result.valid) {
        _toast('IAP verified — tier ${result.tier}');
        _refreshUi('IAP verified');
      } else {
        _toast('IAP rejected (${result.reason ?? "unknown"})');
      }
    } on DirectIapReceiptInvalidError catch (e) {
      _toast('Receipt invalid: ${e.reason ?? "unknown"}');
    } on DirectPaymentProviderFailedError catch (e) {
      _toast('IAP provider ${e.provider} failed');
    } on DirectError catch (e) {
      _toast('${e.code}: ${e.message}');
    }
  }

  Future<void> _onDeepLink(DirectPaymentReturn ret) async {
    if (ret.cancelled) {
      setState(() => _status = 'Checkout cancelled by user');
      return;
    }
    final client = _client;
    final sid = ret.sessionId ?? _sessionId;
    if (client == null) return;
    try {
      final res = await client.refreshAfterPayment(sessionId: sid);
      _refreshUi('Refreshed — tier ${res.entitlements.tier}');
    } on DirectSessionNotCompleteError {
      // Webhook hasn't reconciled yet — back off + retry once.
      _toast('Session not yet complete — retrying in 2s');
      await Future<void>.delayed(const Duration(seconds: 2));
      try {
        final res = await client.refreshAfterPayment(sessionId: sid);
        _refreshUi('Refreshed (retry) — tier ${res.entitlements.tier}');
      } on DirectError catch (e) {
        _toast('Retry failed: ${e.code}');
      }
    } on DirectSessionNotFoundError {
      _toast('Session expired — re-start checkout');
    } on DirectError catch (e) {
      _toast('${e.code}: ${e.message}');
    }
  }

  // --------------------------------------------------------------------
  // UI
  // --------------------------------------------------------------------

  void _refreshUi(String status) {
    final ent = _client?.entitlements;
    setState(() {
      _status = status;
      _tier = ent?.tier ?? '-';
    });
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FRON payment demo')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Status: $_status'),
            Text('Tier: $_tier'),
            if (_sessionId != null) Text('Session: $_sessionId'),
            const Spacer(),
            Wrap(spacing: 8, runSpacing: 8, children: [
              ElevatedButton(
                onPressed: _client == null ? null : _startCheckout,
                child: const Text('Start checkout'),
              ),
              ElevatedButton(
                onPressed: _client == null ? null : _openCustomerPortal,
                child: const Text('Open portal'),
              ),
              ElevatedButton(
                onPressed: _client == null ? null : _restorePurchases,
                child: const Text('Restore purchases'),
              ),
              ElevatedButton(
                onPressed: _client == null ? null : _verifyIapReceipt,
                child: const Text('Verify IAP receipt'),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}

class _NoopJweDecryptor implements JwePayloadDecryptor {
  const _NoopJweDecryptor();
  @override
  Future<String> decrypt(String jwe) async => jwe;
}

class _NoopDeviceKeypairProvider implements DeviceKeypairProvider {
  const _NoopDeviceKeypairProvider();
  @override
  Future<Uint8List> getPublicKey() async => Uint8List(32);
}
