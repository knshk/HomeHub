// REPLACE THIS FILE. This stub exists so the example app can compile without
// a real Firebase project. To get the real one:
//
//   $ dart pub global activate flutterfire_cli
//   $ cd dart/vanaheim/example
//   $ flutterfire configure
//
// `flutterfire configure` will pick your Firebase project and overwrite this
// file with platform-specific FirebaseOptions. It will also add the
// google-services.json (Android), GoogleService-Info.plist (iOS), etc.
//
// `firebase_options.dart` is .gitignored at the repo root — every developer
// generates their own for local testing.

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      'FirebaseOptions have not been configured. Run `flutterfire configure` '
      'in dart/vanaheim/example to generate real options for '
      'platform ${defaultTargetPlatform.name}. (TargetPlatform: '
      '${TargetPlatform.values})',
    );
  }
}
