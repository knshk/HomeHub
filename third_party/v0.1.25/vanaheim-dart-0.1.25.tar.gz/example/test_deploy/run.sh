#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Copyright © 2026-present AJTEK.IO (OPC) Private Limited
#
# Wrapper for the post-deployment smoke harness. Loads a sibling .env
# (if present) so contributors can drop a local file with their staging
# creds, then invokes `dart test --tags=deploy`.
#
# Usage:
#   ./run.sh                 # default: expanded reporter
#   ./run.sh --reporter=json # pass any extra args through to dart test

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Load .env (KEY=VALUE pairs) if present. Lines starting with # are skipped.
ENV_FILE="${HERE}/.env"
if [[ -f "${ENV_FILE}" ]]; then
  echo "[run.sh] loading env from ${ENV_FILE}"
  # shellcheck disable=SC2046
  set -o allexport
  # shellcheck source=/dev/null
  source "${ENV_FILE}"
  set +o allexport
else
  echo "[run.sh] no .env at ${ENV_FILE} — relying on already-exported env"
fi

# Sanity: tell the human which env vars the harness saw, but never print
# the secret values themselves.
for VAR in BIFROST_DEPLOY_URL BIFROST_PROJECT_ID BIFROST_TEST_LICENSE_KEY \
           BIFROST_L2_BASE_URL BIFROST_SDK_SECRET; do
  if [[ -n "${!VAR:-}" ]]; then
    echo "[run.sh] ${VAR} = (set)"
  else
    echo "[run.sh] ${VAR} = (unset — affected tests will skip)"
  fi
done

# Reporter defaults to expanded; callers can override by passing args.
REPORTER_ARG="--reporter=expanded"
if [[ "${*}" == *"--reporter="* ]]; then
  REPORTER_ARG=""
fi

cd "${HERE}/.."
exec dart test --tags=deploy ${REPORTER_ARG} "$@"
