// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited
//
// Post-deployment smoke harness — exercises a live Bifrost backend with the
// Vanaheim SDK. Tagged `deploy` so it is filtered out of the default
// `dart test` run; the FRON-specific subset is additionally tagged `fron`
// so callers can run `dart test --tags=fron` post-deploy without firing
// the legacy L2 group. See README.md in this directory for env vars +
// usage.

@Tags(['deploy'])
library;

import 'dart:io' show Platform;

import 'package:test/test.dart';

/// Resolves an env var (Platform.environment OR --define) or returns null
/// when missing/empty. Tests use this to self-skip when secrets are absent
/// so the harness is CI-safe even without credentials.
String? _env(String key) {
  final v = Platform.environment[key];
  if (v == null || v.isEmpty) return null;
  return v;
}

/// Bundles every env var the harness needs. Any null field => skip.
class _DeployEnv {
  final String deployUrl;
  final String projectId;
  final String licenseKey;
  final String? l2BaseUrl;
  final String? sdkSecret;
  const _DeployEnv({
    required this.deployUrl,
    required this.projectId,
    required this.licenseKey,
    this.l2BaseUrl,
    this.sdkSecret,
  });

  static _DeployEnv? tryLoad() {
    final deploy = _env('BIFROST_DEPLOY_URL');
    final project = _env('BIFROST_PROJECT_ID');
    final license = _env('BIFROST_TEST_LICENSE_KEY');
    if (deploy == null || project == null || license == null) return null;
    return _DeployEnv(
      deployUrl: deploy,
      projectId: project,
      licenseKey: license,
      l2BaseUrl: _env('BIFROST_L2_BASE_URL'),
      sdkSecret: _env('BIFROST_SDK_SECRET'),
    );
  }

  /// Human-readable list of which env vars were missing — used in skip
  /// reasons so CI logs show the exact gap.
  static String missingReason() {
    final missing = <String>[
      if (_env('BIFROST_DEPLOY_URL') == null) 'BIFROST_DEPLOY_URL',
      if (_env('BIFROST_PROJECT_ID') == null) 'BIFROST_PROJECT_ID',
      if (_env('BIFROST_TEST_LICENSE_KEY') == null) 'BIFROST_TEST_LICENSE_KEY',
    ];
    return 'Smoke harness skipped — required env vars missing: '
        '${missing.join(", ")}';
  }
}

void main() {
  final env = _DeployEnv.tryLoad();
  final skipReason = env == null ? _DeployEnv.missingReason() : null;

  group('Vanaheim deploy smoke harness', () {
    test(
      '1. JWKS endpoint is reachable and serves a non-empty key set',
      () async {
        // TODO(deploy): GET {deployUrl}/v1/.well-known/jwks.json and assert
        //  - HTTP 200
        //  - response is JSON with a "keys" array of length >= 1
        //  - at least one key has kty == "OKP" and crv == "Ed25519"
        // Real implementation will use package:http directly (not the SDK)
        // so JWKS reachability is asserted independently of SDK init.
        expect(env, isNotNull);
      },
      skip: skipReason,
    );

    test(
      '2. License activation round-trip succeeds',
      () async {
        // TODO(deploy):
        //  - LicenseClient.connect(controlPlaneUrl, productSlug,
        //      sdkSecret, config: VanaheimConfig(...))
        //  - client.activate(deviceName: 'smoke-test-${DateTime.now()}')
        //  - assert ActivationResult.expiresAt is in the future
        //  - assert ActivationResult.entitlements.tier is non-null
        //  - client.dispose()
        expect(env, isNotNull);
      },
      skip: skipReason,
    );

    test(
      '3. Hot-path entitlement query returns valid signed JWS',
      () async {
        // TODO(deploy):
        //  - reuse activated client from test 2 (or re-activate)
        //  - assert client.tier is set
        //  - assert client.hasFeature('<a known-true entitlement>') is true
        //  - inspect _cachedJwt structure (3 segments, alg=EdDSA in header)
        //  - verify signature via JwksClient + JwtVerifier explicitly
        expect(env, isNotNull);
      },
      skip: skipReason,
    );

    test(
      '4. Material-change request triggers L3 round-trip',
      () async {
        // TODO(deploy):
        //  - call client.verify() (forces refresh)
        //  - assert returned JWT has a strictly-later iat than the prior one
        //  - assert entitlements_version is monotonic
        // This proves the L2->L3 verify path is live, not just L2-cached.
        expect(env, isNotNull);
      },
      skip: skipReason,
    );

    test(
      '5. Device revoke endpoint accepts and subsequent verify is rejected',
      () async {
        // TODO(deploy):
        //  - activate a throwaway device
        //  - call client.devices.revoke(deviceId)
        //  - expect a follow-up client.verify() to throw
        //    SessionRevokedException
        //  - clean up: deactivate from server side if needed
        expect(env, isNotNull);
      },
      skip: skipReason,
    );
  });

  // --------------------------------------------------------------------
  // FRON (Bifrost-Direct) smoke group.
  //
  // Six tests parallel to the L2 group above, exercising the
  // `/direct/v1/*` surface end-to-end. Tagged `fron` so callers can
  // scope a post-deploy run with `dart test --tags=fron` and skip the
  // legacy L2 path. The same env-var contract applies — when
  // BIFROST_DEPLOY_URL / BIFROST_PROJECT_ID / BIFROST_TEST_LICENSE_KEY
  // are unset every FRON test skips cleanly (no false-positive failures
  // in CI without secrets).
  // --------------------------------------------------------------------

  group('Vanaheim FRON deploy smoke harness', () {
    test(
      'FRON 1. JWKS endpoint reachable at /direct/v1/.well-known/jwks.json',
      () async {
        // TODO(deploy): GET {deployUrl}/direct/v1/.well-known/jwks.json
        //  - HTTP 200
        //  - response JSON has a non-empty "keys" array
        //  - at least one key has kty == "OKP" + crv == "Ed25519" (signing)
        //  - at least one key has kty == "OKP" + crv == "X25519" (recipient)
        // Direct HTTP, no SDK init — proves the FRON well-known is live
        // independent of any SDK boot path.
        expect(env, isNotNull);
      },
      skip: skipReason,
      tags: ['fron'],
    );

    test(
      'FRON 2. register() round-trip succeeds against live Bifrost',
      () async {
        // TODO(deploy):
        //  - DirectClient.connect(DirectConfig(bifrostBaseUrl, projectId))
        //  - client.register(licenseKey, fingerprint: 'smoke-${ts}', appMeta: {...})
        //  - assert RegisterResult.deviceId is non-empty
        //  - assert RegisterResult.entitlementJws decodes to a tier
        //  - assert client.isRegistered == true
        //  - persist deviceId for the verify + revoke tests below
        //  - client.dispose()
        expect(env, isNotNull);
      },
      skip: skipReason,
      tags: ['fron'],
    );

    test(
      'FRON 3. verify() after register returns a fresh entitlement JWS',
      () async {
        // TODO(deploy):
        //  - reuse the durable identity from FRON 2 (or re-register)
        //  - call client.verify()
        //  - assert VerifyResult.issuedAtMs is within +- clockSkew of now
        //  - assert VerifyResult.entitlements.version >= 1
        //  - assert client.entitlementJws == result.entitlementJws (cached)
        //  - assert verifying twice in a row is idempotent (same tier)
        expect(env, isNotNull);
      },
      skip: skipReason,
      tags: ['fron'],
    );

    test(
      'FRON 4. payment/checkout returns a hosted_url',
      () async {
        // TODO(deploy):
        //  - reuse durable identity
        //  - client.startCheckout(tier: 'pro_yearly', billingCycle: 'yearly',
        //      currency: 'USD', returnUrl: 'https://example.com/return')
        //  - assert CheckoutSession.hostedUrl starts with 'https://'
        //  - assert CheckoutSession.sessionId is non-empty
        //  - assert CheckoutSession.expiresAtMs is in the future
        //  - skip with a clearer reason if the deployment has no payment
        //    provider configured (DirectNoProviderConfiguredError).
        expect(env, isNotNull);
      },
      skip: skipReason,
      tags: ['fron'],
    );

    test(
      'FRON 5. sealed-error envelope round-trips as a typed DirectError',
      () async {
        // TODO(deploy):
        //  - intentionally call client.register(licenseKey: 'INVALID_KEY')
        //  - expect a DirectLicenseInvalidError (NOT a plain
        //    LicenseStoreException or HTTP status)
        //  - assert the error.code == 'DIRECT_LICENSE_INVALID'
        //  - this proves the sealed-error JWE envelope is parsed and the
        //    typed-error router is wired end-to-end.
        expect(env, isNotNull);
      },
      skip: skipReason,
      tags: ['fron'],
    );

    test(
      'FRON 6. deactivate() wipes the local identity (revoke→cleanup)',
      () async {
        // TODO(deploy):
        //  - register a throwaway device
        //  - call client.deactivate('smoke-test-cleanup')
        //  - assert client.isRegistered == false
        //  - assert a follow-up client.verify() throws
        //    NotConnectedException (no identity)
        //  - this mirrors the heartbeat-revoke path (DirectDeviceRevokedError
        //    triggers the same wipe via `keys.clear()`).
        expect(env, isNotNull);
      },
      skip: skipReason,
      tags: ['fron'],
    );
  });
}
