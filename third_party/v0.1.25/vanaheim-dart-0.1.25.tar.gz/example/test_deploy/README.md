# Post-deployment smoke harness — Vanaheim SDK ↔ Bifrost

This directory holds the **post-deployment smoke harness**: a small set of
Dart integration tests that exercise a *live* Bifrost backend over the
network after each release. Run it from CI immediately after a deploy
(canary or full), and from a developer machine when validating a hotfix
against a staging environment.

The harness is **not** a unit-test suite — it requires network access,
real signing keys, and a real, healthy backend. Tests are tagged
`@Tags(['deploy'])` so they are filtered out of the default `dart test`
run and only execute when explicitly requested.

## What is covered

### L2 group (tag: `deploy`)

1. **JWKS endpoint reachable** — `GET /v1/.well-known/jwks.json` returns
   a non-empty key set with at least one Ed25519 key.
2. **License activation round-trip** — `POST /v1/licenses/.../activate`
   succeeds end-to-end with a test license key, returning a verifiable
   signed JWT.
3. **Hot-path entitlement query returns valid signed JWS** — the SDK can
   decode the JWT, verify its signature against the JWKS, and surface a
   tier + entitlements map.
4. **Material-change request triggers L3 round-trip** — a `POST /v1/licenses/verify`
   with a force-flag returns a freshly-issued JWT (proves L2→L3 path is live).
5. **Device revoke endpoint accepts** — `POST /v1/devices/{id}/revoke`
   accepts and the next `verify()` surfaces `SessionRevokedException`.

### FRON group (tags: `deploy`, `fron`)

1. **FRON JWKS reachable** — `GET /direct/v1/.well-known/jwks.json`
   returns a non-empty key set with at least one Ed25519 (signing) and
   one X25519 (recipient) key.
2. **Register round-trip** — `DirectClient.register()` against the test
   license key returns a non-empty `deviceId` and a decodable
   entitlement JWS; `client.isRegistered` flips to true.
3. **Verify after register** — `client.verify()` issues a fresh
   entitlement JWS, idempotent across two calls, with `issuedAtMs`
   within the configured clock-skew window.
4. **Payment checkout returns hosted_url** — `client.startCheckout(...)`
   returns a `https://` hosted URL plus a non-empty `sessionId` and a
   future `expiresAtMs`. Skips with a clear reason when the deployment
   has no payment provider configured.
5. **Sealed-error envelope round-trip** — calling
   `client.register(licenseKey: 'INVALID')` surfaces a typed
   `DirectLicenseInvalidError` (not a plain HTTP status) — proves the
   sealed-error JWE envelope and the typed-error router are wired
   end-to-end.
6. **Revoke → cleanup** — `client.deactivate(...)` wipes the durable
   identity (`isRegistered` flips to false; subsequent `verify()` throws
   `NotConnectedException`), mirroring the heartbeat-side revoke wipe
   that `DirectDeviceRevokedError` triggers.

## Required environment variables

| Variable                    | Description                                              |
| --------------------------- | -------------------------------------------------------- |
| `BIFROST_DEPLOY_URL`        | Base URL of the deployed control plane (e.g. `https://api.licenses.example.com`) |
| `BIFROST_PROJECT_ID`        | Numeric project id the test license belongs to           |
| `BIFROST_TEST_LICENSE_KEY`  | A pre-provisioned test license key with seat-cap > 0     |
| `BIFROST_L2_BASE_URL`       | (Optional) L2 base URL; defaults to deploy URL :8081     |
| `BIFROST_SDK_SECRET`        | (Optional) Per-product HMAC secret for SDK requests      |

When any required variable is missing the relevant test is **skipped**
with a clear reason message — so the harness can run safely in CI without
secrets (it just reports skipped) and only does real work when wired up
to a staging or production-canary environment.

## How to run

```bash
# Local — load .env (if present) and run (covers BOTH L2 + FRON groups)
./run.sh

# Or directly — both groups
dart test --tags=deploy

# FRON-only post-deploy smoke (tags are additive — `fron` is a subset of
# `deploy`):
dart test --tags=fron

# CI (with secrets exported)
BIFROST_DEPLOY_URL=https://api.staging.licenses.example.com \
BIFROST_PROJECT_ID=42 \
BIFROST_TEST_LICENSE_KEY=lic_test_... \
dart test --tags=deploy --reporter=expanded
```

## Exit codes

* `0` — every required test passed (or was skipped due to missing env).
* `1` — at least one test failed; do **not** mark the deploy healthy.
