// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:vanaheim/src/api/feedback_api.dart';
import 'package:vanaheim/src/api/notifications_api.dart';
import 'package:vanaheim/src/api/preferences_api.dart';
import 'package:vanaheim/src/api/privacy_api.dart';
import 'package:vanaheim/src/api/subscription_api.dart';
import 'package:vanaheim/src/api/support_api.dart';
import 'package:vanaheim/src/auth/auth_providers.dart';
import 'package:vanaheim/src/capabilities.dart';
import 'package:vanaheim/src/models.dart';
import 'package:vanaheim/src/transport/cert_pinning.dart';
import 'package:vanaheim/src/transport/hmac_signer.dart';
import 'package:vanaheim/src/transport/http_client.dart';
import 'package:test/test.dart';

/// Asserts every method on every gated sub-API throws
/// [CapabilityDisabledException] when its capability is disabled — BEFORE any
/// HTTP call is dispatched. We use a never-called HTTP client so a missed
/// gate would manifest as a network attempt + DNS failure instead of a clean
/// throw, surfacing as a different exception type.
SignedHttpClient _http() => SignedHttpClient(
      signer: HmacSigner(productSlug: 'test', sdkSecret: 'test-secret'),
      auth: DevAuthTokenProvider(uid: 'u', email: 't@example.com'),
      appCheck: NoAppCheckProvider(),
      pinner: CertificatePinner(pinnedSpkiSha256: const []),
    );

Uri _ep() => Uri.parse('https://never-called.invalid');

void main() {
  group('NotificationsApi gate', () {
    const caps = SdkCapabilities(notifications: false);
    final api = NotificationsApi(_http(), _ep, caps);

    test('inbox throws CapabilityDisabledException', () {
      expect(() => api.inbox(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('markRead throws', () {
      expect(() => api.markRead('id'),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('getPreferences throws', () {
      expect(() => api.getPreferences(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('updatePreferences throws', () {
      expect(
        () => api.updatePreferences(const NotificationPreferences()),
        throwsA(isA<CapabilityDisabledException>()),
      );
    });
  });

  group('FeedbackApi gate', () {
    const caps = SdkCapabilities(feedback: false);
    final api = FeedbackApi(_http(), _ep, caps);

    test('submit throws', () {
      expect(
        () => api.submit(category: 'bug'),
        throwsA(isA<CapabilityDisabledException>()),
      );
    });
    test('nps throws', () {
      expect(() => api.nps(score: 8),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('csat throws', () {
      expect(() => api.csat(score: 4),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('markPromptShown throws', () {
      expect(() => api.markPromptShown('nps_q3'),
          throwsA(isA<CapabilityDisabledException>()));
    });
  });

  group('SupportApi gate', () {
    const caps = SdkCapabilities(support: false);
    final api = SupportApi(_http(), _ep, caps);

    test('openTicket throws', () {
      expect(
        () => api.openTicket(subject: 's', body: 'b'),
        throwsA(isA<CapabilityDisabledException>()),
      );
    });
    test('listTickets throws', () {
      expect(() => api.listTickets(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('getTicket throws', () {
      expect(() => api.getTicket('id'),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('replyTo throws', () {
      expect(
        () => api.replyTo(ticketId: 'id', message: 'm'),
        throwsA(isA<CapabilityDisabledException>()),
      );
    });
  });

  group('SubscriptionApi gate', () {
    const caps = SdkCapabilities(subscription: false);
    final api = SubscriptionApi(_http(), _ep, caps);

    test('tiers throws', () {
      expect(() => api.tiers(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('currentPlan throws', () {
      expect(() => api.currentPlan(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('upgradeTo throws', () {
      expect(() => api.upgradeTo('pro'),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('cancel throws', () {
      expect(() => api.cancel(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('portalSessionUrl throws', () {
      expect(() => api.portalSessionUrl(),
          throwsA(isA<CapabilityDisabledException>()));
    });
  });

  group('PrivacyApi gate', () {
    const caps = SdkCapabilities(privacy: false);
    final api = PrivacyApi(_http(), _ep, caps);

    test('exportData throws', () {
      expect(() => api.exportData(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('requestErasure throws', () {
      expect(
        () => api.requestErasure(confirmation: 't@example.com'),
        throwsA(isA<CapabilityDisabledException>()),
      );
    });
    test('getConsents throws', () {
      expect(() => api.getConsents(),
          throwsA(isA<CapabilityDisabledException>()));
    });
  });

  group('PreferencesApi gate', () {
    const caps = SdkCapabilities(preferences: false);
    final api = PreferencesApi(_http(), _ep, caps);

    test('refresh throws', () {
      expect(() => api.refresh(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('update throws', () {
      expect(() => api.update('theme', 'dark'),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('updateMany throws', () {
      expect(() => api.updateMany(const {'k': 'v'}),
          throwsA(isA<CapabilityDisabledException>()));
    });

    test('cachedValue (sync local read) bypasses gate', () {
      // cachedValue is a pure-local read from the JWT-seeded snapshot. It does
      // NOT round-trip the server and intentionally bypasses the capability
      // gate — products that disable preferences for writes still want offline
      // read consistency.
      api.primeSnapshot({'theme': 'dark'});
      expect(api.cachedValue<String>('theme'), equals('dark'));
    });
  });
}
