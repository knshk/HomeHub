// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';

import 'package:vanaheim/src/api/telemetry_api.dart';
import 'package:vanaheim/src/capabilities.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';
import 'package:vanaheim/src/transport/cert_pinning.dart';
import 'package:vanaheim/src/transport/hmac_signer.dart';
import 'package:vanaheim/src/transport/http_client.dart';
import 'package:vanaheim/src/auth/auth_providers.dart';
import 'package:test/test.dart';

/// Tests for §2B.1 telemetry pipeline:
///   * PII auto-strip (email / phone / card-like sequences silently dropped)
///   * Offline buffer persistence (event survives `dispose() → restore()`)
///   * Bounded ring (oldest events drop on overflow)
///
/// Telemetry does NOT need a live HTTP client for these tests — the buffer
/// behavior is the load-bearing contract. We pass a never-called HTTP client
/// because the in-process flush path is exercised by the integration suite.
void main() {
  group('TelemetryApi — PII auto-strip', () {
    test('email value dropped from event props', () async {
      final cache = InMemorySecureCache();
      final api = TelemetryApi(
        http: neverCalledHttp(),
        endpoint: () => Uri.parse('https://localhost'),
        cache: cache,
        capabilities: const SdkCapabilities(),
        productSlug: 'test',
      );
      await api.track('feature_used', {
        'feature': 'export',
        'leaked_email': 'kanishka@example.com', // should be dropped
        'safe_count': 5,
      });
      // Persist then re-inspect by restoring into a fresh API.
      await api.dispose();

      final replay = TelemetryApi(
        http: neverCalledHttp(),
        endpoint: () => Uri.parse('https://localhost'),
        cache: cache,
        capabilities: const SdkCapabilities(),
        productSlug: 'test',
      );
      await replay.restore();
      final raw = await cache.getRaw('telemetry_buffer_v1');
      expect(raw, isNotNull);
      final decoded = jsonDecode(raw!) as List;
      expect(decoded, hasLength(1));
      final props = (decoded[0] as Map)['props'] as Map;
      expect(props['feature'], equals('export'));
      expect(props['safe_count'], equals(5));
      expect(props.containsKey('leaked_email'), isFalse,
          reason: 'email PII must be stripped at SDK layer');
    });

    test('phone-like 10-15 digit sequence dropped', () async {
      final cache = InMemorySecureCache();
      final api = TelemetryApi(
        http: neverCalledHttp(),
        endpoint: () => Uri.parse('https://localhost'),
        cache: cache,
        capabilities: const SdkCapabilities(),
        productSlug: 'test',
      );
      await api.track('contact_event', {
        'leaked_phone': '9876543210',
        'safe_country': 'IN',
      });
      await api.dispose();

      final raw = await cache.getRaw('telemetry_buffer_v1');
      final decoded = jsonDecode(raw!) as List;
      final props = (decoded[0] as Map)['props'] as Map;
      expect(props.containsKey('leaked_phone'), isFalse);
      expect(props['safe_country'], equals('IN'));
    });

    test('card-like 13-19 digit sequence dropped', () async {
      final cache = InMemorySecureCache();
      final api = TelemetryApi(
        http: neverCalledHttp(),
        endpoint: () => Uri.parse('https://localhost'),
        cache: cache,
        capabilities: const SdkCapabilities(),
        productSlug: 'test',
      );
      await api.track('payment_event', {
        'leaked_card': '4242 4242 4242 4242', // 16-digit, dashes/spaces OK
        'safe_currency': 'USD',
      });
      await api.dispose();
      final raw = await cache.getRaw('telemetry_buffer_v1');
      final decoded = jsonDecode(raw!) as List;
      final props = (decoded[0] as Map)['props'] as Map;
      expect(props.containsKey('leaked_card'), isFalse);
      expect(props['safe_currency'], equals('USD'));
    });

    test('PII inside nested map also stripped', () async {
      final cache = InMemorySecureCache();
      final api = TelemetryApi(
        http: neverCalledHttp(),
        endpoint: () => Uri.parse('https://localhost'),
        cache: cache,
        capabilities: const SdkCapabilities(),
        productSlug: 'test',
      );
      await api.track('nested', {
        'user': <String, dynamic>{
          'email': 'leak@example.com',
          'tier': 'pro',
        },
      });
      await api.dispose();
      final raw = await cache.getRaw('telemetry_buffer_v1');
      final decoded = jsonDecode(raw!) as List;
      final props = (decoded[0] as Map)['props'] as Map;
      final user = props['user'] as Map;
      expect(user['tier'], equals('pro'));
      expect(user.containsKey('email'), isFalse,
          reason: 'nested PII must also be stripped');
    });
  });

  group('TelemetryApi — capability gate', () {
    test('track is a no-op (no throw) when telemetry disabled', () async {
      final cache = InMemorySecureCache();
      const caps = SdkCapabilities(telemetry: false);
      final api = TelemetryApi(
        http: neverCalledHttp(),
        endpoint: () => Uri.parse('https://localhost'),
        cache: cache,
        capabilities: caps,
        productSlug: 'test',
      );
      // Calling through the public API should throw CapabilityDisabledException.
      expect(
        () => api.track('feature_used', {'k': 'v'}),
        throwsA(isA<CapabilityDisabledException>()),
      );
    });
  });

  group('TelemetryApi — bounded ring', () {
    test('exceeding telemetryMaxBuffer drops oldest events', () async {
      final cache = InMemorySecureCache();
      const caps = SdkCapabilities(telemetryMaxBuffer: 5);
      final api = TelemetryApi(
        http: neverCalledHttp(),
        endpoint: () => Uri.parse('https://localhost'),
        cache: cache,
        capabilities: caps,
        productSlug: 'test',
      );
      for (var i = 0; i < 10; i++) {
        await api.track('event_$i', {'idx': i});
      }
      await api.dispose();
      final raw = await cache.getRaw('telemetry_buffer_v1');
      final decoded = jsonDecode(raw!) as List;
      expect(decoded.length, equals(5));
      // Last 5 events retained: 5..9
      final firstName = (decoded[0] as Map)['name'];
      expect(firstName, equals('event_5'));
      final lastName = (decoded[4] as Map)['name'];
      expect(lastName, equals('event_9'));
    });
  });
}

/// Construct a real `SignedHttpClient` for buffer-behavior tests. The HTTP
/// path is never reached because the tests dispose before any periodic
/// flush could fire and never call `flush()` directly. Construction is
/// cheap; we don't mock the transport.
SignedHttpClient neverCalledHttp() {
  return SignedHttpClient(
    signer: HmacSigner(productSlug: 'test', sdkSecret: 'test-secret'),
    auth: DevAuthTokenProvider(uid: 'test-uid', email: 'test@example.com'),
    appCheck: NoAppCheckProvider(),
    pinner: CertificatePinner(pinnedSpkiSha256: const []),
  );
}
