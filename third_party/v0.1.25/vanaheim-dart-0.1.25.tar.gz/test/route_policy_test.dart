// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Lock-in tests for the v2 / Vanaheim route-policy table
/// (lib/src/crypto/route_policy.dart).
///
/// Default-deny is the load-bearing invariant — any route NOT explicitly in
/// `kJwsAllowedRoutes` MUST classify as `jweRequired`. Carve-outs must match
/// path-segment-aware so `/v1/meta` does not pull in `/v1/metadata`.
library;

import 'package:vanaheim/src/crypto/route_policy.dart';
import 'package:test/test.dart';

void main() {
  group('classify — JWE-required default-deny', () {
    test('unknown route → jweRequired', () {
      expect(classify('/v1/account/me'),
          equals(RouteConfidentiality.jweRequired));
      expect(classify('/v1/license/issue'),
          equals(RouteConfidentiality.jweRequired));
      expect(classify('/v1/subscriptions/list'),
          equals(RouteConfidentiality.jweRequired));
      expect(classify('/random/garbage'),
          equals(RouteConfidentiality.jweRequired));
      expect(classify(''), equals(RouteConfidentiality.jweRequired));
      expect(classify('/'), equals(RouteConfidentiality.jweRequired));
    });

    test('a route whose path SHARES a leading substring with an allowlisted '
        'entry is NOT downgraded (segment-aware match)', () {
      // The classic exploit: `/v1/meta` is allowlisted but `/v1/metadata`
      // is not. A naive String.startsWith match would downgrade it.
      expect(classify('/v1/metadata'),
          equals(RouteConfidentiality.jweRequired));
      // Same for /healthz vs /healthz-internal
      expect(classify('/healthzinternal'),
          equals(RouteConfidentiality.jweRequired));
      // Same for the docs prefix — `/v1/docs-internal` must NOT match.
      expect(classify('/v1/docs-internal'),
          equals(RouteConfidentiality.jweRequired));
    });
  });

  group('classify — explicit JWS-allowed entries', () {
    test('every entry in kJwsAllowedRoutes classifies as jwsAllowed', () {
      // Pull the constant directly so this test fails-loud the moment
      // someone adds an entry without thinking through the security impact.
      for (final prefix in kJwsAllowedRoutes) {
        // Prefix as-is (trim trailing slash for the equality test path).
        final p = prefix.endsWith('/') && prefix.length > 1
            ? prefix.substring(0, prefix.length - 1)
            : prefix;
        expect(classify(p), equals(RouteConfidentiality.jwsAllowed),
            reason: 'entry $prefix did not classify as jwsAllowed');
      }
    });

    test('exact-match JWS-allowed routes', () {
      expect(classify('/v1/explore/splash'),
          equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/catalog/explore'),
          equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/meta'), equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/healthz'), equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/readyz'), equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/.well-known/jwks.json'),
          equals(RouteConfidentiality.jwsAllowed));
    });

    test('trailing-slash prefix entries match nested paths (glob-ish behavior)',
        () {
      // /v1/status/ → any /v1/status/<x> route should classify as jwsAllowed.
      expect(classify('/v1/status/'),
          equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/status/incident/abc'),
          equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/status/foo/bar/baz'),
          equals(RouteConfidentiality.jwsAllowed));

      // /v1/docs/ → all nested doc paths.
      expect(classify('/v1/docs/getting-started'),
          equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/docs/'),
          equals(RouteConfidentiality.jwsAllowed));

      // /v1/marketing/ — all read-only marketing paths.
      expect(classify('/v1/marketing/blog/123'),
          equals(RouteConfidentiality.jwsAllowed));
    });

    test('classifier is robust to trailing slash on the request path', () {
      // Same logical route either way.
      expect(classify('/v1/meta'), equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/meta/'), equals(RouteConfidentiality.jwsAllowed));
    });

    test('strips query + fragment defensively before matching', () {
      expect(classify('/v1/meta?ver=1'),
          equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/docs/quickstart#install'),
          equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/account/me?token=x'),
          equals(RouteConfidentiality.jweRequired));
    });

    test('classifier matches /v1/meta sub-paths but NOT /v1/metadata', () {
      // Defense: ensure the segment-aware match works for both directions.
      expect(classify('/v1/meta'), equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/meta/build'),
          equals(RouteConfidentiality.jwsAllowed));
      expect(classify('/v1/metadata'),
          equals(RouteConfidentiality.jweRequired));
      expect(classify('/v1/metadata/x'),
          equals(RouteConfidentiality.jweRequired));
    });
  });

  group('classify — case sensitivity', () {
    test('matching is case-sensitive (no surprise downgrades on /HEALTHZ)', () {
      // Server normalizes to lowercase before its own check; the SDK never
      // sees a mixed-case path in practice, but the policy MUST default-deny
      // on any non-canonical spelling.
      expect(
          classify('/HEALTHZ'), equals(RouteConfidentiality.jweRequired));
      expect(classify('/V1/META'),
          equals(RouteConfidentiality.jweRequired));
    });
  });

  group('isMaterialChangeHint — telemetry tagging only', () {
    test('returns true for known material-change prefixes', () {
      expect(isMaterialChangeHint('/v1/license/issue'), isTrue);
      expect(isMaterialChangeHint('/v1/license/upgrade'), isTrue);
      expect(isMaterialChangeHint('/v1/checkout/start'), isTrue);
      expect(isMaterialChangeHint('/v1/payments/charge'), isTrue);
      expect(isMaterialChangeHint('/v1/kyc/upload'), isTrue);
    });

    test('returns false for hot-path routes', () {
      expect(isMaterialChangeHint('/v1/account/me'), isFalse);
      expect(isMaterialChangeHint('/v1/meta'), isFalse);
      expect(isMaterialChangeHint('/v1/explore/splash'), isFalse);
      expect(isMaterialChangeHint('/healthz'), isFalse);
    });
  });
}
