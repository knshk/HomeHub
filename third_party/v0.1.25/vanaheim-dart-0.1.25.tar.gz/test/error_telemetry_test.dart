// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';

import 'package:vanaheim/src/storage/secure_cache.dart';
import 'package:vanaheim/src/telemetry/error_telemetry.dart';
import 'package:test/test.dart';

void main() {
  group('ErrorTelemetry', () {
    test('capture is non-blocking, non-throwing, and ring-bounded', () {
      final t = ErrorTelemetry(maxBuffer: 3, persistDebounce: const Duration(seconds: 10));
      for (var i = 0; i < 10; i++) {
        t.capture(source: 'test', error: Exception('err-$i'));
      }
      final recent = t.recent();
      expect(recent.length, equals(3));
      // Oldest dropped first; we expect err-7, err-8, err-9.
      expect(recent.first.message, contains('err-7'));
      expect(recent.last.message, contains('err-9'));
    });

    test('capture does not throw when given malformed inputs', () {
      final t = ErrorTelemetry(maxBuffer: 5, persistDebounce: const Duration(seconds: 10));
      // Must not throw, ever — this is the safety contract.
      t.capture(source: '', error: 'plain string error');
      t.capture(source: 'x', error: Object());
      t.capture(source: 'x', error: 42);
      expect(t.recent().length, equals(3));
    });

    test('persist via InMemorySecureCache + restore round-trips', () async {
      final cache = InMemorySecureCache();
      final t1 = ErrorTelemetry(cache: cache, persistDebounce: const Duration(milliseconds: 1));
      t1.capture(source: 'verify', error: Exception('boom'));
      // Allow the debounce timer to fire + write
      await Future<void>.delayed(const Duration(milliseconds: 20));
      await t1.flush();

      final t2 = ErrorTelemetry(cache: cache);
      await t2.restore();
      final restored = t2.recent();
      expect(restored.length, equals(1));
      expect(restored.first.source, equals('verify'));
      expect(restored.first.message, contains('boom'));
    });

    test('clear empties both buffer and persisted blob', () async {
      final cache = InMemorySecureCache();
      final t = ErrorTelemetry(cache: cache);
      t.capture(source: 'x', error: Exception('y'));
      await t.flush();
      expect(await cache.getTelemetry(), isNotNull);
      await t.clear();
      expect(t.recent(), isEmpty);
      expect(await cache.getTelemetry(), equals('[]'));
    });

    test('exportForDiagnostics returns valid JSON-shape', () async {
      final t = ErrorTelemetry();
      t.capture(source: 'verify', error: const FormatException('bad jwt'));
      final bundle = t.exportForDiagnostics();
      // Round-trip through jsonEncode to prove it's serializable
      final encoded = jsonEncode(bundle);
      final decoded = jsonDecode(encoded) as Map<String, dynamic>;
      expect(decoded.containsKey('generated_at'), isTrue);
      expect(decoded['events'], isA<List<dynamic>>());
      expect((decoded['events'] as List<dynamic>).first, isA<Map<String, dynamic>>());
    });

    test('truncates very long messages and stacks', () {
      final t = ErrorTelemetry(maxBuffer: 1);
      final bigMsg = 'x' * 5000;
      t.capture(
        source: 'test',
        error: Exception(bigMsg),
        stack: StackTrace.fromString('y' * 10000),
      );
      final ev = t.recent().first.toJson();
      expect((ev['message'] as String).length, lessThanOrEqualTo(2100));
      expect((ev['stack'] as String).length, lessThanOrEqualTo(4100));
    });

    test('restore with corrupt blob does not throw and starts clean', () async {
      final cache = InMemorySecureCache();
      await cache.putTelemetry('not valid json at all');
      final t = ErrorTelemetry(cache: cache);
      await t.restore();
      expect(t.recent(), isEmpty);
    });

    test('clear preserves nothing in InMemorySecureCache.clear() — telemetry survives', () async {
      // FlutterSecureCache.clear documents that telemetry is preserved.
      // Mirror the same semantics in InMemorySecureCache so test parity holds.
      final cache = InMemorySecureCache();
      await cache.putTelemetry('[{"ts":"2026-01-01T00:00:00.000Z","severity":"error","source":"x","error_class":"y","message":"z"}]');
      await cache.putJwt('some-jwt');
      await cache.clear();
      expect(await cache.getJwt(), isNull);
      expect(await cache.getTelemetry(), isNotNull,
          reason: 'telemetry should NOT be wiped by SecureCache.clear()');
    });
  });
}
