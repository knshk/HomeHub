// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';
import 'dart:typed_data';

import 'package:ed25519_edwards/ed25519_edwards.dart' as ed;
import 'package:vanaheim/src/crypto/jwt_verifier.dart';
import 'package:test/test.dart';

/// Locks the day-1 SDK contract for §2A.1 / §2A.6 / §2A.12:
///
///   * cfg + cfg_v parsed; missing → safe defaults
///   * roles parsed as List<String>; non-string elements filtered
///   * org_id + org_role parsed as String?; empty → null
///   * prefs_v + locale parsed; missing → safe defaults
///   * unknown / wrong-typed claims silently ignored (forward-compat)
///
/// These tests intentionally avoid touching the full LicenseClient — they
/// exercise the verifier directly because that's the load-bearing layer
/// for all the new sync getters. Coverage of `client.config<T>()` etc. is
/// added once a mock backend stack ships (Phase 1 backend).
void main() {
  late ed.KeyPair keys;
  late Uint8List pub;

  setUpAll(() {
    keys = ed.generateKey();
    pub = Uint8List.fromList(keys.publicKey.bytes);
  });

  String makeJwt(Map<String, dynamic> claims) {
    final headerB64 = _b64u(utf8.encode(
        jsonEncode({'alg': 'EdDSA', 'typ': 'JWT', 'kid': 'test-kid'})));
    final claimsB64 = _b64u(utf8.encode(jsonEncode(claims)));
    final signingInput = utf8.encode('$headerB64.$claimsB64');
    final sig = ed.sign(keys.privateKey, Uint8List.fromList(signingInput));
    return '$headerB64.$claimsB64.${_b64u(sig)}';
  }

  Map<String, dynamic> baseClaims(DateTime exp) => {
        'iss': 'licenses.example.com',
        'sub': 'lic_x',
        'aud': 'zenkit',
        'acc': 'acc_x',
        'tier': 'pro',
        'ent': {'export': true},
        'ev': 1,
        'iat': DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000,
        'nbf': DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000 - 60,
        'exp': exp.toUtc().millisecondsSinceEpoch ~/ 1000,
      };

  group('JwtVerifier — runtime config (2A.1)', () {
    test('parses cfg + cfg_v when present', () {
      final claims = baseClaims(DateTime.now().add(const Duration(hours: 1)));
      claims['cfg'] = {
        'feature.support.tickets.enabled': true,
        'max_devices': 5,
        'region_kill_switch': false,
      };
      claims['cfg_v'] = 12;
      final jwt = makeJwt(claims);

      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );

      expect(out.configVersion, equals(12));
      expect(out.config['feature.support.tickets.enabled'], isTrue);
      expect(out.config['max_devices'], equals(5));
      expect(out.config['region_kill_switch'], isFalse);
    });

    test('defaults cfg to empty + cfg_v to 0 when missing', () {
      final jwt =
          makeJwt(baseClaims(DateTime.now().add(const Duration(hours: 1))));
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.config, isEmpty);
      expect(out.configVersion, equals(0));
    });

    test('cfg of wrong type (string) becomes empty (forward-compat)', () {
      final claims = baseClaims(DateTime.now().add(const Duration(hours: 1)));
      claims['cfg'] = 'not-a-map'; // unexpected, must not crash
      final jwt = makeJwt(claims);
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.config, isEmpty);
    });
  });

  group('JwtVerifier — roles + org (2A.6)', () {
    test('parses roles array; filters non-string elements', () {
      final claims = baseClaims(DateTime.now().add(const Duration(hours: 1)));
      claims['roles'] = ['customer', 'partner', 42, '', 'admin'];
      final jwt = makeJwt(claims);
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      // 42 and '' must be filtered; only the 3 non-empty strings remain.
      expect(out.roles, equals(['customer', 'partner', 'admin']));
    });

    test('roles defaults to empty when missing', () {
      final jwt =
          makeJwt(baseClaims(DateTime.now().add(const Duration(hours: 1))));
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.roles, isEmpty);
    });

    test('roles of wrong type (string instead of list) → empty', () {
      final claims = baseClaims(DateTime.now().add(const Duration(hours: 1)));
      claims['roles'] = 'customer'; // not a list
      final jwt = makeJwt(claims);
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.roles, isEmpty);
    });

    test('parses org_id + org_role when present', () {
      final claims = baseClaims(DateTime.now().add(const Duration(hours: 1)));
      claims['org_id'] = 'org_acme';
      claims['org_role'] = 'admin';
      final jwt = makeJwt(claims);
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.orgId, equals('org_acme'));
      expect(out.orgRole, equals('admin'));
    });

    test('org fields default to null when missing', () {
      final jwt =
          makeJwt(baseClaims(DateTime.now().add(const Duration(hours: 1))));
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.orgId, isNull);
      expect(out.orgRole, isNull);
    });

    test('empty-string org_id becomes null (defensive)', () {
      final claims = baseClaims(DateTime.now().add(const Duration(hours: 1)));
      claims['org_id'] = '';
      final jwt = makeJwt(claims);
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.orgId, isNull);
    });
  });

  group('JwtVerifier — preferences + locale (2A.10, 2A.12)', () {
    test('parses prefs_v + locale', () {
      final claims = baseClaims(DateTime.now().add(const Duration(hours: 1)));
      claims['prefs_v'] = 4;
      claims['locale'] = 'en-IN';
      final jwt = makeJwt(claims);
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.preferencesVersion, equals(4));
      expect(out.locale, equals('en-IN'));
    });

    test('prefs_v + locale default safely when missing', () {
      final jwt =
          makeJwt(baseClaims(DateTime.now().add(const Duration(hours: 1))));
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.preferencesVersion, equals(0));
      expect(out.locale, isNull);
    });
  });

  group('JwtVerifier — forward-compat', () {
    test('unknown claims silently ignored', () {
      final claims = baseClaims(DateTime.now().add(const Duration(hours: 1)));
      claims['some_future_claim'] = {'nested': [1, 2, 3]};
      claims['another_future'] = 'whatever';
      final jwt = makeJwt(claims);
      // Must succeed — we forward-compat over unknown claims.
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.licenseId, equals('lic_x'));
    });
  });
}

String _b64u(List<int> bytes) => base64Url.encode(bytes).replaceAll('=', '');
