// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Lock-in tests for v0.1.19 `LicenseClient.reportCapability`
/// (lib/src/apps/capabilities.dart + client.dart extension).
///
/// What we test:
///   * Client-side regex `^has_[a-z0-9_]{2,64}$` — accepts min/max, rejects
///     missing prefix, uppercase, hyphen, dot, PII-shape, whitespace, and
///     partial matches (anchored).
///   * `CapabilityKeyInvalidException` echoes the offending key.
///   * `ReportCapabilityWire` constants match the parity fixture
///     byte-for-byte (route, body keys, maxAttempts, key pattern).
///   * Body shape serializes to exactly
///     `{"key":"has_offline_export","value":true}` — mirror of the Swift
///     testReportCapabilityBodyShape check + the parity fixture's
///     `expected_body_bytes_json_sorted_keys`.
///
/// The full HTTP round-trip (429 retry ladder, JWE envelope, region
/// endpoint concatenation) is covered by an integration test that
/// requires the full LicenseClient wiring; here we test the client-side
/// validation + wire-shape parity primitives directly. This mirrors the
/// Swift twin (`CapabilitiesTests.testCapability*` + `test*Wire*`).
library;

import 'dart:convert';

import 'package:test/test.dart';
import 'package:vanaheim/src/apps/capabilities.dart';
import 'package:vanaheim/src/exceptions.dart';

void main() {
  group('CapabilityReportValidation — accepts valid keys', () {
    test('accepts minimum-length key (has_ + 2 chars = 6 total)', () {
      expect(() => CapabilityReportValidation.requireValidKey('has_ab'),
          returnsNormally);
    });

    test('accepts a typical snake_case key', () {
      expect(
          () => CapabilityReportValidation.requireValidKey(
              'has_offline_export'),
          returnsNormally);
      expect(
          () => CapabilityReportValidation.requireValidKey('has_feature_123'),
          returnsNormally);
    });

    test('accepts maximum-length key (has_ + 64 chars = 68 total)', () {
      final tail = 'a' * 64;
      expect(
          () => CapabilityReportValidation.requireValidKey('has_$tail'),
          returnsNormally);
    });

    test('accepts digits + underscores throughout the tail', () {
      expect(
          () => CapabilityReportValidation.requireValidKey(
              'has_v2_ai_assistant_beta'),
          returnsNormally);
    });
  });

  group('CapabilityReportValidation — rejects invalid keys', () {
    test('rejects empty string', () {
      expect(
        () => CapabilityReportValidation.requireValidKey(''),
        throwsA(isA<CapabilityKeyInvalidException>()
            .having((e) => e.key, 'key', '')),
      );
    });

    test('rejects missing has_ prefix', () {
      expect(
        () =>
            CapabilityReportValidation.requireValidKey('offline_export'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });

    test('rejects uppercase HAS_ prefix (case-sensitive)', () {
      expect(
        () => CapabilityReportValidation.requireValidKey('HAS_offline'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });

    test('rejects tail shorter than 2 chars', () {
      // has_ + 1 = 5 total; tail floor is {2}.
      expect(
        () => CapabilityReportValidation.requireValidKey('has_a'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });

    test('rejects tail longer than 64 chars', () {
      final tail = 'a' * 65;
      expect(
        () => CapabilityReportValidation.requireValidKey('has_$tail'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });

    test('rejects uppercase letters in tail', () {
      expect(
        () => CapabilityReportValidation.requireValidKey('has_Offline'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });

    test('rejects hyphen in tail (must be snake_case)', () {
      expect(
        () =>
            CapabilityReportValidation.requireValidKey('has_offline-export'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });

    test('rejects dot in tail', () {
      expect(
        () =>
            CapabilityReportValidation.requireValidKey('has_offline.export'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });

    test('rejects PII-shaped (email-like) key', () {
      // Defence-in-depth against accidental PII leaking into keys.
      expect(
        () => CapabilityReportValidation.requireValidKey(
            'has_user@example.com'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });

    test('rejects whitespace-only', () {
      expect(
        () => CapabilityReportValidation.requireValidKey('   '),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });

    test('rejects leading / trailing whitespace', () {
      expect(
        () => CapabilityReportValidation.requireValidKey(' has_ab'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
      expect(
        () => CapabilityReportValidation.requireValidKey('has_ab '),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });

    test('regex is fully anchored (rejects partial matches)', () {
      // A partial-match regex would let "prefixhas_valid_keysuffix" through.
      expect(
        () => CapabilityReportValidation.requireValidKey('xhas_offline'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
      expect(
        () => CapabilityReportValidation.requireValidKey('has_offline!'),
        throwsA(isA<CapabilityKeyInvalidException>()),
      );
    });
  });

  group('CapabilityKeyInvalidException', () {
    test('is a LicenseStoreException subtype', () {
      final e = CapabilityKeyInvalidException('bad_key');
      expect(e, isA<LicenseStoreException>());
    });

    test('echoes the offending key in `key` + message', () {
      try {
        CapabilityReportValidation.requireValidKey('nope');
        fail('expected throw');
      } on CapabilityKeyInvalidException catch (e) {
        expect(e.key, equals('nope'));
        expect(e.message, contains('nope'));
      }
    });
  });

  group('ReportCapabilityWire — parity constants', () {
    test('wire constants match fron-parity-fixtures.json §apps byte-for-byte',
        () {
      // Parity guard — if either side (Swift, TS, Dart, or Bifrost server)
      // drifts, this test surfaces it in CI before a cross-SDK bug ships.
      expect(ReportCapabilityWire.routePath, equals('/v1/apps/capabilities'));
      expect(ReportCapabilityWire.bodyKeyKey, equals('key'));
      expect(ReportCapabilityWire.bodyKeyValue, equals('value'));
      expect(ReportCapabilityWire.maxAttempts, equals(3));
    });

    test('key regex pattern is pinned to the server-enforced literal', () {
      // The exact regex the server enforces — if this literal ever shifts
      // on either side (Alfheim, Dart, TS, Swift) the entire capability
      // report path breaks silently. Pin the string here.
      expect(CapabilityReportValidation.keyPattern.pattern,
          equals(r'^has_[a-z0-9_]{2,64}$'));
    });

    test('backoff ladder starts at 100ms (matches Swift + fixture ladder)',
        () {
      // Fixture backoff_ms_ladder: [100, 200, 400] — capped exponential
      // starting at 100ms. We assert the seed value; the doubling schedule
      // is exercised by the integration test.
      expect(ReportCapabilityWire.backoffMsInitial, equals(100));
    });
  });

  group('reportCapability wire body shape (cross-language parity)', () {
    test(
        'serializes to exactly `{"key":"has_offline_export","value":true}` '
        '— matches fixture expected_body_bytes_json_sorted_keys', () {
      // Mirror of Swift's testReportCapabilityBodyShape. `key` sorts before
      // `value` alphabetically, so natural JSON encoding matches sorted-key
      // encoding for THIS 2-key body — no manual sort needed on the Dart
      // side. If the body ever grows a third key, revisit.
      final body = <String, dynamic>{
        ReportCapabilityWire.bodyKeyKey: 'has_offline_export',
        ReportCapabilityWire.bodyKeyValue: true,
      };
      final encoded = jsonEncode(body);
      expect(encoded, equals('{"key":"has_offline_export","value":true}'));
    });

    test('body has exactly 2 keys — no product_slug or project_id leaks', () {
      // The PAK claim carries the project + product scope server-side;
      // leaking either into the body would break the "single source of
      // truth" invariant.
      final body = <String, dynamic>{
        ReportCapabilityWire.bodyKeyKey: 'has_export',
        ReportCapabilityWire.bodyKeyValue: false,
      };
      expect(body.keys.toSet(), equals(<String>{'key', 'value'}));
      expect(body.containsKey('product_slug'), isFalse);
      expect(body.containsKey('project_id'), isFalse);
    });

    test('value=false serializes as JSON false (not omitted / not "false")',
        () {
      final body = <String, dynamic>{
        ReportCapabilityWire.bodyKeyKey: 'has_export',
        ReportCapabilityWire.bodyKeyValue: false,
      };
      final encoded = jsonEncode(body);
      expect(encoded, equals('{"key":"has_export","value":false}'));
    });
  });
}
