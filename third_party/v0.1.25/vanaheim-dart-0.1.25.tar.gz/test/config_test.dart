// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Lock-in tests for VanaheimConfig (lib/src/config.dart).
///
/// The v2 spec promotes 4 fields from optional → required:
///   * projectId   (was passed positionally to LicenseClient.connect in v1)
///   * l2BaseUrl   (new; replaces bifrostBaseUrl which is GONE in v2)
///   * jweDecryptor
///   * deviceKeypairProvider
///
/// This test pins the constructor signature with a tiny mirror compile check
/// (constructing the config with each required arg) plus an explicit absence
/// check against the deleted `bifrostBaseUrl` (compile-fail proxy: we use
/// the public export surface to confirm there is no such symbol).
library;

import 'dart:typed_data';

import 'package:vanaheim/vanaheim.dart';
import 'package:test/test.dart';

class _FakeDecryptor implements JwePayloadDecryptor {
  @override
  Future<String> decrypt(String jwe) async => 'noop';
}

class _FakeKeypair implements DeviceKeypairProvider {
  @override
  Future<Uint8List> getPublicKey() async => Uint8List(32);
}

void main() {
  group('VanaheimConfig — required surface', () {
    test('constructs with the v2 required four (projectId / l2BaseUrl / '
        'jweDecryptor / deviceKeypairProvider) + holds them', () {
      final cfg = VanaheimConfig(
        projectId: 42,
        l2BaseUrl: Uri.parse('https://l2.example.com'),
        jweDecryptor: _FakeDecryptor(),
        deviceKeypairProvider: _FakeKeypair(),
      );
      expect(cfg.projectId, equals(42));
      expect(cfg.l2BaseUrl, equals(Uri.parse('https://l2.example.com')));
      expect(cfg.jweDecryptor, isA<JwePayloadDecryptor>());
      expect(cfg.deviceKeypairProvider, isA<DeviceKeypairProvider>());
    });

    test('applies the documented defaults for the optional knobs', () {
      final cfg = VanaheimConfig(
        projectId: 1,
        l2BaseUrl: Uri.parse('https://l2.example.com'),
        jweDecryptor: _FakeDecryptor(),
        deviceKeypairProvider: _FakeKeypair(),
      );
      expect(cfg.refreshBefore, equals(const Duration(days: 1)));
      expect(cfg.jwksCacheTtl, equals(const Duration(hours: 1)));
      expect(cfg.httpTimeout, equals(const Duration(seconds: 15)));
      expect(cfg.clockSkew, equals(const Duration(minutes: 5)));
      expect(cfg.pinnedSpkiSha256, isEmpty);
      expect(cfg.allowDevAuthBypass, isFalse);
      expect(cfg.hardOfflineGrace, isNull);
    });

    test('accepts overrides for grace / pins / dev-auth flags', () {
      final cfg = VanaheimConfig(
        projectId: 1,
        l2BaseUrl: Uri.parse('https://l2.example.com'),
        jweDecryptor: _FakeDecryptor(),
        deviceKeypairProvider: _FakeKeypair(),
        refreshBefore: const Duration(hours: 6),
        hardOfflineGrace: const Duration(days: 30),
        pinnedSpkiSha256: const ['pin1', 'pin2'],
        jwksCacheTtl: const Duration(hours: 24),
        httpTimeout: const Duration(seconds: 30),
        clockSkew: const Duration(seconds: 60),
        allowDevAuthBypass: true,
      );
      expect(cfg.refreshBefore, equals(const Duration(hours: 6)));
      expect(cfg.hardOfflineGrace, equals(const Duration(days: 30)));
      expect(cfg.pinnedSpkiSha256, equals(['pin1', 'pin2']));
      expect(cfg.jwksCacheTtl, equals(const Duration(hours: 24)));
      expect(cfg.httpTimeout, equals(const Duration(seconds: 30)));
      expect(cfg.clockSkew, equals(const Duration(seconds: 60)));
      expect(cfg.allowDevAuthBypass, isTrue);
    });
  });

  group('VanaheimConfig — v1 surface deleted', () {
    test('the old LicenseStoreConfig name is NOT re-exported (only VanaheimConfig)',
        () {
      // Compile-time: trying to refer to LicenseStoreConfig (the v1 name) here
      // would fail to compile. We assert via a string-shaped runtime check
      // against the type name to make the intent explicit.
      final cfg = VanaheimConfig(
        projectId: 1,
        l2BaseUrl: Uri.parse('https://l2.example.com'),
        jweDecryptor: _FakeDecryptor(),
        deviceKeypairProvider: _FakeKeypair(),
      );
      expect(cfg.runtimeType.toString(), equals('VanaheimConfig'));
    });

    // Note on `bifrostBaseUrl`: the v1 field is gone. We can't write a
    // negative "no member" assertion at runtime in Dart, but if it returns
    // we'd see a compile-time error here (the test file does not reference
    // it, intentionally). The DevicesAPI test exercises l2BaseUrl as the
    // sole base URL for v2 device flows.
  });
}
