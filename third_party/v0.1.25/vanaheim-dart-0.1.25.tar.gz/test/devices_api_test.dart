// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Lock-in tests for the v2 / Vanaheim DevicesAPI
/// (lib/src/api/devices_api.dart).
///
/// What we test:
///   * register POSTs to `{l2BaseUrl}/v1/devices/enroll` with the device
///     pubkey base64url-encoded (no padding).
///   * heartbeat POSTs to `{l2BaseUrl}/v1/devices/heartbeat`.
///   * revoke POSTs to `{l2BaseUrl}/v1/devices/{deviceId}/revoke`.
///   * The response payload is parsed into a DeviceEnrollment record.
///
/// These tests construct a SignedHttpClient with a MockClient stub and the
/// real HmacSigner / cert-pinner-disabled wiring, then assert the captured
/// request shape. The JWE wrapping is OFF here (no RoutePolicy injected) so
/// we can assert against plaintext JSON bodies — the JWE-on-top behavior is
/// covered separately in http_client_jwe_test.dart.
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:vanaheim/src/api/devices_api.dart';
import 'package:vanaheim/src/auth/auth_providers.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:vanaheim/src/transport/cert_pinning.dart';
import 'package:vanaheim/src/transport/hmac_signer.dart';
import 'package:vanaheim/src/transport/http_client.dart';
import 'package:test/test.dart';

class _FakeAuth implements AuthTokenProvider {
  @override
  Future<String> getIdToken({bool forceRefresh = false}) async => 'tok-abc';
}

class _FakeAppCheck implements AppCheckTokenProvider {
  @override
  Future<String?> getToken({bool forceRefresh = false}) async => null;
}

void main() {
  final l2 = Uri.parse('https://l2.example.com');

  SignedHttpClient buildClient(MockClient mock) {
    return SignedHttpClient(
      signer: HmacSigner(productSlug: 'zenkit', sdkSecret: 'shh'),
      auth: _FakeAuth(),
      appCheck: _FakeAppCheck(),
      pinner: CertificatePinner(pinnedSpkiSha256: const []),
      inner: mock,
    );
  }

  group('DevicesAPI.register', () {
    test('POSTs to /v1/devices/enroll with base64url device_pubkey + parses '
        'device_id from the response', () async {
      late http.Request captured;
      final mock = MockClient((req) async {
        captured = req;
        return http.Response(
          jsonEncode({
            'device_id': 'dev_abc123',
            'enrolled_at': '2026-01-01T00:00:00Z',
          }),
          200,
          headers: {'content-type': 'application/json'},
        );
      });
      final api = DevicesAPI(http: buildClient(mock), l2BaseUrl: l2);

      // 32-byte X25519-shaped pubkey.
      final pub = Uint8List(32);
      for (var i = 0; i < 32; i++) {
        pub[i] = i + 1;
      }

      final result = await api.register(devicePubKey: pub);

      expect(captured.url.toString(),
          equals('https://l2.example.com/v1/devices/enroll'));
      expect(captured.method, equals('POST'));

      final body = jsonDecode(captured.body) as Map<String, dynamic>;
      // device_pubkey must be base64url WITHOUT padding (JOSE canonical).
      final expected = base64Url.encode(pub).replaceAll('=', '');
      expect(body['device_pubkey'], equals(expected));
      expect(body['device_pubkey'], isNot(contains('=')),
          reason: 'base64url-no-pad — JWS/JWE canonical form');

      expect(result.deviceId, equals('dev_abc123'));
      expect(result.enrolledAt.isUtc, isTrue);
      expect(result.enrolledAt.toIso8601String(),
          equals('2026-01-01T00:00:00.000Z'));
    });

    test('throws ArgumentError on empty pubkey', () async {
      final mock = MockClient((req) async => http.Response('', 200));
      final api = DevicesAPI(http: buildClient(mock), l2BaseUrl: l2);
      expect(
        () => api.register(devicePubKey: Uint8List(0)),
        throwsA(isA<ArgumentError>()),
      );
    });

    test('throws NetworkException when server omits device_id', () async {
      final mock = MockClient((req) async => http.Response(
            jsonEncode({'enrolled_at': '2026-01-01T00:00:00Z'}),
            200,
            headers: {'content-type': 'application/json'},
          ));
      final api = DevicesAPI(http: buildClient(mock), l2BaseUrl: l2);
      expect(
        () => api.register(devicePubKey: Uint8List(32)),
        throwsA(isA<NetworkException>()),
      );
    });
  });

  group('DevicesAPI.heartbeat', () {
    test('POSTs to /v1/devices/heartbeat with an empty JSON body', () async {
      late http.Request captured;
      final mock = MockClient((req) async {
        captured = req;
        return http.Response('{}', 200,
            headers: {'content-type': 'application/json'});
      });
      final api = DevicesAPI(http: buildClient(mock), l2BaseUrl: l2);

      await api.heartbeat();

      expect(captured.url.toString(),
          equals('https://l2.example.com/v1/devices/heartbeat'));
      expect(captured.method, equals('POST'));
      expect(jsonDecode(captured.body), equals(<String, dynamic>{}));
    });
  });

  group('DevicesAPI.revoke', () {
    test('POSTs to /v1/devices/{deviceId}/revoke', () async {
      late http.Request captured;
      final mock = MockClient((req) async {
        captured = req;
        return http.Response('{}', 200,
            headers: {'content-type': 'application/json'});
      });
      final api = DevicesAPI(http: buildClient(mock), l2BaseUrl: l2);

      await api.revoke('dev_xyz789');

      expect(captured.url.toString(),
          equals('https://l2.example.com/v1/devices/dev_xyz789/revoke'));
      expect(captured.method, equals('POST'));
    });

    test('throws ArgumentError on empty deviceId', () async {
      final mock = MockClient((req) async => http.Response('', 200));
      final api = DevicesAPI(http: buildClient(mock), l2BaseUrl: l2);
      expect(
        () => api.revoke(''),
        throwsA(isA<ArgumentError>()),
      );
    });
  });
}
