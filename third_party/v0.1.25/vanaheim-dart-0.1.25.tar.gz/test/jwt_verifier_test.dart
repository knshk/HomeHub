// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';
import 'dart:typed_data';

import 'package:ed25519_edwards/ed25519_edwards.dart' as ed;
import 'package:vanaheim/src/crypto/jwt_verifier.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:test/test.dart';

void main() {
  // Generate a real keypair once for the suite. ed25519_edwards is sync, so
  // this fits cleanly into setUpAll.
  late ed.KeyPair keys;
  late Uint8List pub;
  late Uint8List pubAlt;

  setUpAll(() {
    keys = ed.generateKey();
    pub = Uint8List.fromList(keys.publicKey.bytes);
    final altKeys = ed.generateKey();
    pubAlt = Uint8List.fromList(altKeys.publicKey.bytes);
  });

  String makeJwt({
    required ed.KeyPair signingKeys,
    required Map<String, dynamic> claims,
    String kid = 'test-kid',
    String alg = 'EdDSA',
  }) {
    final headerB64 = _b64u(utf8.encode(jsonEncode({'alg': alg, 'typ': 'JWT', 'kid': kid})));
    final claimsB64 = _b64u(utf8.encode(jsonEncode(claims)));
    final signingInput = utf8.encode('$headerB64.$claimsB64');
    final sig = ed.sign(signingKeys.privateKey, Uint8List.fromList(signingInput));
    final sigB64 = _b64u(sig);
    return '$headerB64.$claimsB64.$sigB64';
  }

  Map<String, dynamic> goodClaims(DateTime exp) => {
        'iss': 'licenses.example.com',
        'sub': 'lic_test_001',
        'aud': 'zenkit',
        'acc': 'acc_test_001',
        'tier': 'pro',
        'ent': {'export': true},
        'ev': 3,
        'iat': DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000,
        'nbf': DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000 - 60,
        'exp': exp.toUtc().millisecondsSinceEpoch ~/ 1000,
      };

  group('JwtVerifier — happy path', () {
    test('verifies a valid Ed25519-signed JWT and decodes claims', () {
      final jwt = makeJwt(
        signingKeys: keys,
        claims: goodClaims(DateTime.now().add(const Duration(hours: 1))),
      );
      final out = JwtVerifier.verifyAndDecode(
        jwt: jwt,
        publicKey: pub,
        expectedIssuer: 'licenses.example.com',
        expectedAudience: 'zenkit',
      );
      expect(out.licenseId, equals('lic_test_001'));
      expect(out.accountId, equals('acc_test_001'));
      expect(out.tier, equals('pro'));
      expect(out.entitlementsVersion, equals(3));
      expect(out.entitlements['export'], isTrue);
    });
  });

  group('JwtVerifier — failure paths', () {
    test('throws LicenseExpiredException (not JwtVerificationException) when exp is past', () {
      // Blocker 4 fix: expiry must be the DISTINCT exception type so callers
      // can branch between "stale, refresh" and "compromised, clear cache".
      final jwt = makeJwt(
        signingKeys: keys,
        claims: goodClaims(DateTime.now().subtract(const Duration(hours: 1))),
      );
      expect(
        () => JwtVerifier.verifyAndDecode(
          jwt: jwt,
          publicKey: pub,
          expectedIssuer: 'licenses.example.com',
          expectedAudience: 'zenkit',
          clockSkew: const Duration(seconds: 30),
        ),
        throwsA(isA<LicenseExpiredException>()),
      );
    });

    test('throws JwtVerificationException on signature tamper', () {
      // Sign with `keys` but verify against an unrelated public key.
      final jwt = makeJwt(
        signingKeys: keys,
        claims: goodClaims(DateTime.now().add(const Duration(hours: 1))),
      );
      expect(
        () => JwtVerifier.verifyAndDecode(
          jwt: jwt,
          publicKey: pubAlt,
          expectedIssuer: 'licenses.example.com',
          expectedAudience: 'zenkit',
        ),
        throwsA(isA<JwtVerificationException>()),
      );
    });

    test('rejects unsupported alg', () {
      final jwt = makeJwt(
        signingKeys: keys,
        claims: goodClaims(DateTime.now().add(const Duration(hours: 1))),
        alg: 'HS256',
      );
      expect(
        () => JwtVerifier.verifyAndDecode(
          jwt: jwt,
          publicKey: pub,
          expectedIssuer: 'licenses.example.com',
          expectedAudience: 'zenkit',
        ),
        throwsA(isA<JwtVerificationException>()),
      );
    });

    test('rejects wrong audience', () {
      final jwt = makeJwt(
        signingKeys: keys,
        claims: goodClaims(DateTime.now().add(const Duration(hours: 1))),
      );
      expect(
        () => JwtVerifier.verifyAndDecode(
          jwt: jwt,
          publicKey: pub,
          expectedIssuer: 'licenses.example.com',
          expectedAudience: 'other_product',
        ),
        throwsA(isA<JwtVerificationException>()),
      );
    });

    test('rejects wrong issuer', () {
      final jwt = makeJwt(
        signingKeys: keys,
        claims: goodClaims(DateTime.now().add(const Duration(hours: 1))),
      );
      expect(
        () => JwtVerifier.verifyAndDecode(
          jwt: jwt,
          publicKey: pub,
          expectedIssuer: 'attacker.example.com',
          expectedAudience: 'zenkit',
        ),
        throwsA(isA<JwtVerificationException>()),
      );
    });

    test('throws JwtVerificationException (not CastError) on missing sub claim', () {
      // Audit majors-coverage: unsafe `as String` cast on sub used to crash
      // with CastError. New code raises typed JwtVerificationException.
      final claims = goodClaims(DateTime.now().add(const Duration(hours: 1)));
      claims.remove('sub');
      final jwt = makeJwt(signingKeys: keys, claims: claims);
      expect(
        () => JwtVerifier.verifyAndDecode(
          jwt: jwt,
          publicKey: pub,
          expectedIssuer: 'licenses.example.com',
          expectedAudience: 'zenkit',
        ),
        throwsA(isA<JwtVerificationException>()),
      );
    });

    test('throws JwtVerificationException on missing acc claim', () {
      final claims = goodClaims(DateTime.now().add(const Duration(hours: 1)));
      claims.remove('acc');
      final jwt = makeJwt(signingKeys: keys, claims: claims);
      expect(
        () => JwtVerifier.verifyAndDecode(
          jwt: jwt,
          publicKey: pub,
          expectedIssuer: 'licenses.example.com',
          expectedAudience: 'zenkit',
        ),
        throwsA(isA<JwtVerificationException>()),
      );
    });

    test('throws JwtVerificationException on missing tier claim', () {
      final claims = goodClaims(DateTime.now().add(const Duration(hours: 1)));
      claims.remove('tier');
      final jwt = makeJwt(signingKeys: keys, claims: claims);
      expect(
        () => JwtVerifier.verifyAndDecode(
          jwt: jwt,
          publicKey: pub,
          expectedIssuer: 'licenses.example.com',
          expectedAudience: 'zenkit',
        ),
        throwsA(isA<JwtVerificationException>()),
      );
    });

    test('rejects malformed JWT (not 3 parts)', () {
      expect(
        () => JwtVerifier.verifyAndDecode(
          jwt: 'not-a-jwt',
          publicKey: pub,
          expectedIssuer: 'licenses.example.com',
          expectedAudience: 'zenkit',
        ),
        throwsA(isA<JwtVerificationException>()),
      );
    });

    test('rejects header with missing kid', () {
      final headerB64 = _b64u(utf8.encode(jsonEncode({'alg': 'EdDSA', 'typ': 'JWT'})));
      final claimsB64 = _b64u(utf8.encode(jsonEncode(
          goodClaims(DateTime.now().add(const Duration(hours: 1))))));
      final sig = ed.sign(keys.privateKey, utf8.encode('$headerB64.$claimsB64'));
      final jwt = '$headerB64.$claimsB64.${_b64u(sig)}';
      expect(
        () => JwtVerifier.verifyAndDecode(
          jwt: jwt,
          publicKey: pub,
          expectedIssuer: 'licenses.example.com',
          expectedAudience: 'zenkit',
        ),
        throwsA(isA<JwtVerificationException>()),
      );
    });
  });
}

String _b64u(List<int> bytes) =>
    base64Url.encode(bytes).replaceAll('=', '');
