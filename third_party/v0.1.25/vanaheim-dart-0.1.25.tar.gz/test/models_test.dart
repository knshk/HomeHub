// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:vanaheim/src/models.dart';
import 'package:test/test.dart';

void main() {
  group('KickedDevice.fromJson — defensive parsing', () {
    test('parses well-formed JSON', () {
      final k = KickedDevice.fromJson(const {
        'activation_id': 'act_abc',
        'device_name': 'iPad Pro',
        'os': 'iOS',
        'last_seen_at': '2026-05-31T12:00:00Z',
      });
      expect(k.activationId, 'act_abc');
      expect(k.deviceName, 'iPad Pro');
      expect(k.os, 'iOS');
      expect(k.lastSeenAt.isUtc, isTrue);
    });

    test('throws FormatException (not CastError) when activation_id missing', () {
      // Audit majors-coverage: previously `j['activation_id'] as String`
      // crashed with CastError on null. Now FormatException.
      expect(
        () => KickedDevice.fromJson(const {
          'last_seen_at': '2026-05-31T12:00:00Z',
        }),
        throwsA(isA<FormatException>()),
      );
    });

    test('throws FormatException when last_seen_at missing', () {
      expect(
        () => KickedDevice.fromJson(const {
          'activation_id': 'act_abc',
        }),
        throwsA(isA<FormatException>()),
      );
    });

    test('throws FormatException on wrong-typed last_seen_at', () {
      expect(
        () => KickedDevice.fromJson(const {
          'activation_id': 'act_abc',
          'last_seen_at': 12345,
        }),
        throwsA(isA<FormatException>()),
      );
    });

    test('tolerates missing optional device_name and os', () {
      final k = KickedDevice.fromJson(const {
        'activation_id': 'act_abc',
        'last_seen_at': '2026-05-31T12:00:00Z',
      });
      expect(k.deviceName, isNull);
      expect(k.os, isNull);
    });

    test('tolerates wrong-typed device_name / os (returns null)', () {
      final k = KickedDevice.fromJson(const {
        'activation_id': 'act_abc',
        'last_seen_at': '2026-05-31T12:00:00Z',
        'device_name': 42, // wrong type
        'os': null,
      });
      expect(k.deviceName, isNull);
      expect(k.os, isNull);
    });
  });
}
