// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:vanaheim/src/transport/hmac_signer.dart';
import 'package:test/test.dart';

void main() {
  group('HmacSigner', () {
    test('produces deterministic signature for the same body+ts', () {
      const body = '{"hello":"world"}';
      // Compute the expected sig manually so we don't depend on the signer's
      // own clock. (Real signer uses now(); this test uses a known input.)
      const ts = '1700000000';
      final mac = Hmac(sha256, utf8.encode('super-secret'));
      final input = utf8.encode('$ts\nzenkit\n$body');
      final expected = mac.convert(input).bytes;
      final expectedHex = expected
          .map((b) => b.toRadixString(16).padLeft(2, '0'))
          .join();

      final actual = _macHex(
          secret: 'super-secret', timestamp: ts, product: 'zenkit', body: body);
      expect(actual, equals(expectedHex));
      expect(actual.length, equals(64), reason: 'sha256 hex is 64 chars');
    });

    test('signature changes when any input changes', () {
      final base = _macHex(
        secret: 's', timestamp: '1', product: 'p', body: 'b');
      expect(_macHex(secret: 'X', timestamp: '1', product: 'p', body: 'b'),
          isNot(equals(base)));
      expect(_macHex(secret: 's', timestamp: '2', product: 'p', body: 'b'),
          isNot(equals(base)));
      expect(_macHex(secret: 's', timestamp: '1', product: 'q', body: 'b'),
          isNot(equals(base)));
      expect(_macHex(secret: 's', timestamp: '1', product: 'p', body: 'B'),
          isNot(equals(base)));
    });

    test('sign() returns a timestamp within a few seconds of now', () {
      final signer = HmacSigner(productSlug: 'p', sdkSecret: 's');
      final before = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
      final result = signer.sign('{}');
      final after = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
      final ts = int.parse(result.timestamp);
      expect(ts, inInclusiveRange(before, after));
      expect(result.signature.length, equals(64));
    });
  });
}

String _macHex({
  required String secret,
  required String timestamp,
  required String product,
  required String body,
}) {
  final mac = Hmac(sha256, utf8.encode(secret));
  final bytes = mac.convert(utf8.encode('$timestamp\n$product\n$body')).bytes;
  return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
}
