// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:vanaheim/src/i18n/formatter.dart';
import 'package:test/test.dart';

void main() {
  group('Formatter — simple substitution', () {
    test('returns key when not in catalog', () {
      final f = Formatter(catalog: const {});
      expect(f.format('hello.world'), equals('hello.world'));
    });

    test('substitutes a single variable', () {
      final f = Formatter(catalog: const {'greet': 'Hello, {name}!'});
      expect(f.format('greet', {'name': 'Kanishka'}),
          equals('Hello, Kanishka!'));
    });

    test('substitutes multiple variables', () {
      final f = Formatter(catalog: const {
        'msg': '{first} and {second} and {first} again',
      });
      expect(f.format('msg', {'first': 'A', 'second': 'B'}),
          equals('A and B and A again'));
    });

    test('preserves unknown vars verbatim (with braces)', () {
      final f = Formatter(catalog: const {'msg': 'Hello {missing}'});
      expect(f.format('msg', {'other': 'x'}), equals('Hello {missing}'));
    });

    test('withCatalog overrides existing keys', () {
      final f = Formatter(catalog: const {'k': 'old'});
      final f2 = f.withCatalog(const {'k': 'new'});
      expect(f.format('k'), equals('old'));
      expect(f2.format('k'), equals('new'));
    });
  });

  group('Formatter — select (categorical branch)', () {
    final f = Formatter(catalog: const {
      'partner_status':
          '{role, select, partner {Partner Portal} admin {Admin} other {Member}}',
    });

    test('selects matching branch', () {
      expect(f.format('partner_status', {'role': 'partner'}),
          equals('Partner Portal'));
      expect(f.format('partner_status', {'role': 'admin'}), equals('Admin'));
    });

    test('falls back to "other" branch on unmatched value', () {
      expect(f.format('partner_status', {'role': 'staff'}), equals('Member'));
    });

    test('falls back to "other" when variable missing', () {
      expect(f.format('partner_status', const {}), equals('Member'));
    });

    test('select with embedded substitution', () {
      final f2 = Formatter(catalog: const {
        'greet':
            '{role, select, partner {Welcome, partner {name}!} other {Hi, {name}}}',
      });
      expect(f2.format('greet', {'role': 'partner', 'name': 'Kanishka'}),
          equals('Welcome, partner Kanishka!'));
      expect(f2.format('greet', {'role': 'customer', 'name': 'Alex'}),
          equals('Hi, Alex'));
    });
  });

  group('Formatter — plural', () {
    final f = Formatter(catalog: const {
      'cart': '{count, plural, one {1 item} other {{count} items}}',
    });

    test('selects "one" branch for 1', () {
      expect(f.format('cart', {'count': 1}), equals('1 item'));
    });

    test('selects "other" branch for non-1 (with substitution)', () {
      expect(f.format('cart', {'count': 5}), equals('5 items'));
    });

    test('selects "zero" branch when defined', () {
      final f = Formatter(catalog: const {
        'cart':
            '{count, plural, zero {empty cart} one {1 item} other {{count} items}}',
      });
      expect(f.format('cart', {'count': 0}), equals('empty cart'));
    });

    test('handles num that is not an int (truncates)', () {
      expect(f.format('cart', {'count': 1.0}), equals('1 item'));
    });
  });
}
