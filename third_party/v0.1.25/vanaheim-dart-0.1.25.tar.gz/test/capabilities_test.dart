// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:vanaheim/src/capabilities.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:test/test.dart';

void main() {
  group('SdkCapabilities — defaults', () {
    test('all capabilities enabled by default', () {
      const caps = SdkCapabilities();
      expect(caps.notifications, isTrue);
      expect(caps.feedback, isTrue);
      expect(caps.support, isTrue);
      expect(caps.subscription, isTrue);
      expect(caps.privacy, isTrue);
      expect(caps.preferences, isTrue);
      expect(caps.telemetry, isTrue);
      expect(caps.assistant, isTrue);
      expect(caps.referrals, isTrue);
      expect(caps.status, isTrue);
      expect(caps.organization, isTrue);
      expect(caps.offers, isTrue);
      expect(caps.docs, isTrue);
    });

    test('default tunables match documented values', () {
      const caps = SdkCapabilities();
      expect(caps.feedbackMaxAttachmentMb, equals(5));
      expect(caps.notificationInboxPageSize, equals(50));
      expect(caps.telemetryBatchSize, equals(20));
      expect(caps.telemetryFlushInterval, equals(const Duration(seconds: 30)));
      expect(caps.telemetryMaxBuffer, equals(500));
    });
  });

  group('SdkCapabilities.fromYaml', () {
    test('parses rooted YAML', () {
      const yaml = '''
vanaheim:
  capabilities:
    assistant: false
    referrals: false
    telemetry: true
  defaults:
    telemetry_batch_size: 50
    notification_inbox_page_size: 25
''';
      final caps = SdkCapabilities.fromYaml(yaml);
      expect(caps.assistant, isFalse);
      expect(caps.referrals, isFalse);
      expect(caps.telemetry, isTrue);
      expect(caps.telemetryBatchSize, equals(50));
      expect(caps.notificationInboxPageSize, equals(25));
      // Unmentioned capabilities default to true (opt-out semantics).
      expect(caps.notifications, isTrue);
    });

    test('parses unrooted (top-level) YAML', () {
      const yaml = '''
capabilities:
  offers: false
''';
      final caps = SdkCapabilities.fromYaml(yaml);
      expect(caps.offers, isFalse);
      expect(caps.notifications, isTrue);
    });

    test('empty YAML returns defaults (all true)', () {
      final caps = SdkCapabilities.fromYaml('');
      expect(caps.notifications, isTrue);
      expect(caps.assistant, isTrue);
    });

    test('missing keys default to true (opt-out semantics)', () {
      const yaml = '''
capabilities:
  assistant: false
''';
      final caps = SdkCapabilities.fromYaml(yaml);
      expect(caps.assistant, isFalse);
      // Everything else stays on.
      expect(caps.notifications, isTrue);
      expect(caps.support, isTrue);
      expect(caps.feedback, isTrue);
    });

    test('wrong-typed flag value falls back to true', () {
      const yaml = '''
capabilities:
  assistant: "yes"
''';
      final caps = SdkCapabilities.fromYaml(yaml);
      // "yes" is not a bool — defaults to true (opt-out).
      expect(caps.assistant, isTrue);
    });
  });

  group('SdkCapabilities.require', () {
    test('does not throw when capability is enabled', () {
      const caps = SdkCapabilities();
      expect(() => caps.require('assistant'), returnsNormally);
      expect(() => caps.require('telemetry'), returnsNormally);
    });

    test('throws CapabilityDisabledException when disabled', () {
      const caps = SdkCapabilities(assistant: false);
      expect(
        () => caps.require('assistant'),
        throwsA(isA<CapabilityDisabledException>()),
      );
    });

    test('CapabilityDisabledException is a LicenseStoreException', () {
      const caps = SdkCapabilities(referrals: false);
      try {
        caps.require('referrals');
        fail('Expected throw');
      } on CapabilityDisabledException catch (e) {
        expect(e, isA<LicenseStoreException>());
        expect(e.capability, equals('referrals'));
        expect(e.message, contains('referrals'));
      }
    });

    test('unknown capability defaults to enabled (forward-compat)', () {
      const caps = SdkCapabilities();
      // A future capability that products don't know about yet defaults to
      // enabled — matches the opt-out semantics of the YAML loader.
      expect(() => caps.require('some_future_capability'), returnsNormally);
      expect(caps.isEnabled('some_future_capability'), isTrue);
    });
  });
}
