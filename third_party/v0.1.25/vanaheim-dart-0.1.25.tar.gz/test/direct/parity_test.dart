// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Cross-SDK wire-byte parity test for the Vanaheim FRON envelope.
///
/// Loads the shared canonical fixture at
/// `bifrost/packages/api-types/src/fron-parity-fixtures.json` — the
/// SAME file the Swift twin test (`Tests/VanaheimTests/Direct/
/// ParityTests.swift`) loads — and verifies the Dart SDK's emitted
/// inner-JWS claim shape, header, and outer-JWE header match exactly.
///
/// Inputs are deterministic (fixed Ed25519 seeds + fixed `nowMs` + fixed
/// `requestId`) so the result is reproducible across both languages.
///
/// What is NOT byte-equal across languages (by design):
///   * The outer JWE itself (fresh ephemeral X25519 per call + random
///     AES-GCM nonce).
///   * The Ed25519 signature on the inner JWS (depends on the random
///     ephemeral if a SignatureScheme variant is used; with deterministic
///     Ed25519 over the same inputs the signature IS deterministic — but
///     we don't assert on it because the headerB64/claimsB64 ordering may
///     differ between Dart's `jsonEncode` and Swift's
///     `JSONSerialization.data(.sortedKeys)`).
///
/// What MUST be byte-equal:
///   * JWS header fields (alg, typ, device_pub_jwk for ephemeral mode)
///   * JWS top-level claims (aud, iat, nbf, exp, jti, project_id,
///     device_id?) AS DEFINED BY THE SERVER'S `DirectJwsClaims` interface
///     — the source of truth lives in
///     `bifrost/packages/functions/src/direct/jws-verifier.ts`.
///   * JWS body wrapper keys (sorted, per `body_keys_sorted` fixture
///     field).
///   * Outer JWE header pins (alg, enc, typ, lcs_v).
library;

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:cryptography/cryptography.dart' as c;
import 'package:test/test.dart';

import 'package:vanaheim/src/crypto/jwe_codec.dart';
import 'package:vanaheim/src/direct/direct_client.dart'
    show
        kDirectAudActivate,
        kDirectAudCatalog,
        kDirectAudDeactivate,
        kDirectAudHeartbeat,
        kDirectAudKeysRotateAck,
        kDirectAudNotificationsAck,
        kDirectAudNotificationsRegisterFcm,
        kDirectAudRegister,
        kDirectAudTelemetryError,
        kDirectAudTelemetryStats,
        kDirectAudVerify;
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/direct/direct_payment_methods.dart'
    show
        kDirectAudPaymentCheckout,
        kDirectAudPaymentIapVerify,
        kDirectAudPaymentIntent,
        kDirectAudPaymentPortal,
        kDirectAudPaymentRefresh,
        kDirectAudPaymentRestore;
import 'package:vanaheim/src/direct/direct_recipient_resolver.dart';
import 'package:vanaheim/src/direct/direct_request_builder.dart';

/// Resolves the shared fixture absolute path. The Dart test runner
/// invokes from the package root (`vanaheim/dart/vanaheim`) so we walk
/// up to the monorepo root and then into bifrost.
File _fixtureFile() {
  // Try absolute path first — matches the path embedded in the
  // task spec so the fixture is locatable regardless of cwd.
  final abs = File(
      '/Users/kanishka/kk_apps/ajtek.io_lc/bifrost/packages/api-types/src/fron-parity-fixtures.json');
  if (abs.existsSync()) return abs;
  // Fallback — relative walk for portability.
  final rel = File(
      '../../../bifrost/packages/api-types/src/fron-parity-fixtures.json');
  return rel;
}

Map<String, dynamic> _loadFixture() {
  final raw = _fixtureFile().readAsStringSync();
  return (jsonDecode(raw) as Map).cast<String, dynamic>();
}

Uint8List _hexToBytes(String hex) {
  final out = Uint8List(hex.length ~/ 2);
  for (var i = 0; i < out.length; i++) {
    out[i] = int.parse(hex.substring(i * 2, i * 2 + 2), radix: 16);
  }
  return out;
}

Uint8List _b64UrlDecode(String s) {
  final pad = (4 - s.length % 4) % 4;
  return base64Url.decode(s.padRight(s.length + pad, '='));
}

/// Build a [DirectEphemeralIdentity] from a deterministic 32-byte seed.
/// We derive both halves (Ed25519 signing + X25519 ECDH) from the same
/// seed so the test inputs are a single 32-byte vector per identity. The
/// Swift twin does the same.
Future<DirectEphemeralIdentity> _ephemeralFromSeed(Uint8List seed) async {
  // Ed25519 — direct seed.
  final edPriv = ed25519.newKeyFromSeed(seed);
  final edPub = ed25519.public(edPriv);

  // X25519 — derive from the SAME seed bytes treated as a raw scalar.
  // This is NOT cryptographically standard (don't ship it!), but it's
  // deterministic and the test only cares about wire-shape invariants —
  // not the underlying ECDH security.
  final x25519 = c.X25519();
  final xKp = await x25519.newKeyPairFromSeed(seed);
  final xPub = await xKp.extractPublicKey();
  final xPriv = await xKp.extractPrivateKeyBytes();

  return DirectEphemeralIdentity(
    x25519Priv: Uint8List.fromList(xPriv),
    x25519Pub: Uint8List.fromList(xPub.bytes),
    ed25519Priv: Uint8List.fromList(edPriv.bytes),
    ed25519Pub: Uint8List.fromList(edPub.bytes),
  );
}

Future<DirectDurableIdentity> _durableFromSeed(
    Uint8List seed, String deviceId) async {
  final eph = await _ephemeralFromSeed(seed);
  return DirectDurableIdentity(
    deviceId: deviceId,
    x25519Priv: eph.x25519Priv,
    x25519Pub: eph.x25519Pub,
    ed25519Priv: eph.ed25519Priv,
    ed25519Pub: eph.ed25519Pub,
  );
}

/// Generate a fixed recipient X25519 keypair so the test owns the
/// decrypt side. We only need the pub byte vector for the builder + the
/// priv for decrypting the resulting outer JWE.
Future<({Uint8List pub, Uint8List priv})> _fixedRecipientKey() async {
  // Seed all-3s for the recipient — distinct from the ephemeral/durable
  // identities and stable across runs.
  final seed = Uint8List(32)..fillRange(0, 32, 3);
  final x25519 = c.X25519();
  final kp = await x25519.newKeyPairFromSeed(seed);
  final pub = await kp.extractPublicKey();
  final priv = await kp.extractPrivateKeyBytes();
  return (
    pub: Uint8List.fromList(pub.bytes),
    priv: Uint8List.fromList(priv),
  );
}

void main() {
  late Map<String, dynamic> fixture;
  late Map<String, dynamic> inputs;
  late Map<String, dynamic> regClaimsExp;
  late Map<String, dynamic> durClaimsExp;
  late Map<String, dynamic> regHeaderExp;
  late Map<String, dynamic> durHeaderExp;
  late Map<String, dynamic> jweHeaderExp;

  setUpAll(() {
    fixture = _loadFixture();
    inputs = (fixture['deterministic_test_inputs'] as Map)
        .cast<String, dynamic>();
    regClaimsExp = (fixture['expected_register_jws_claims'] as Map)
        .cast<String, dynamic>();
    durClaimsExp = (fixture['expected_durable_jws_claims'] as Map)
        .cast<String, dynamic>();
    regHeaderExp = (fixture['expected_inner_jws_header_register'] as Map)
        .cast<String, dynamic>();
    durHeaderExp = (fixture['expected_inner_jws_header_durable'] as Map)
        .cast<String, dynamic>();
    jweHeaderExp = (fixture['expected_outer_jwe_header'] as Map)
        .cast<String, dynamic>();
  });

  test('fixture file is reachable and well-formed', () {
    expect(fixture['\$schema_version'], isA<String>());
    expect(inputs['project_id'], equals('proj_parity_test'));
    expect(inputs['device_id'], equals('dev_parity_test_001'));
    expect(inputs['request_id'], equals('req-parity-fixed-0001'));
    expect(inputs['now_ms'], equals(1700000000000));
  });

  group('Register (Mode A / ephemeral) — inner JWS parity', () {
    test('emitted claims match fixture expected_register_jws_claims', () async {
      final seed = _hexToBytes(inputs['ephemeral_ed25519_seed_hex'] as String);
      final eph = await _ephemeralFromSeed(seed);
      final rec = await _fixedRecipientKey();
      final builder = DirectRequestBuilder(projectId: inputs['project_id'] as String);
      final env = await builder.buildEphemeral(
        // routePath becomes the inner JWS `aud` claim — pass the fixture's
        // canonical audience string (`direct:register`) so the emitted
        // claim matches the server's DirectJwsClaims schema.
        routePath: regClaimsExp['aud'] as String,
        requestId: inputs['request_id'] as String,
        body: {
          'license_key': inputs['license_key'],
          'fingerprint': inputs['fingerprint'],
          'app_meta': inputs['app_meta'],
        },
        ephemeral: eph,
        recipient: BifrostRecipientKey(
            kid: inputs['recipient_kid'] as String, pub: rec.pub),
        // Fixed nowMs from the fixture so iat/nbf/exp are deterministic
        // and the parity check against the fixture's expected values is
        // exact (otherwise wall-clock drift breaks reproducibility).
        nowMs: inputs['now_ms'] as int,
      );

      // Decrypt outer JWE and split inner JWS.
      final dec = await JweCodec.decryptCompact(
        jwe: env.compactJwe,
        devicePrivBytes: rec.priv,
      );
      final inner = utf8.decode(dec.plaintext);
      final parts = inner.split('.');
      expect(parts.length, equals(3));
      final hdr = (jsonDecode(utf8.decode(_b64UrlDecode(parts[0]))) as Map)
          .cast<String, dynamic>();
      final claims = (jsonDecode(utf8.decode(_b64UrlDecode(parts[1]))) as Map)
          .cast<String, dynamic>();

      // Outer JWE header pins per fixture.
      expect(dec.header['alg'], equals(jweHeaderExp['alg']));
      expect(dec.header['enc'], equals(jweHeaderExp['enc']));
      expect(dec.header['typ'], equals(jweHeaderExp['typ']));
      expect(dec.header['lcs_v'], equals(jweHeaderExp['lcs_v']));

      // Inner JWS header pins per fixture.
      expect(hdr['alg'], equals(regHeaderExp['alg']));
      expect(hdr['typ'], equals(regHeaderExp['typ']),
          reason: 'fixture pins ephemeral typ; SDK must emit it verbatim');
      expect(hdr.containsKey('device_pub_jwk'),
          equals(regHeaderExp['device_pub_jwk_present']),
          reason: 'register MUST embed device_pub_jwk in header');

      // CANONICAL CLAIM SHAPE — this is the source-of-truth from
      // bifrost/.../jws-verifier.ts (DirectJwsClaims interface).
      // The fixture expects aud + jti; the SDK MUST emit those exact
      // field names. If the SDK uses route_path/request_id instead,
      // this test fails — that's a wire-shape divergence the server
      // would reject with claims_invalid.
      expect(claims['aud'], equals(regClaimsExp['aud']),
          reason: 'server contract: top-level claim "aud" identifies '
              'the route (DirectJwsClaims.aud). SDK must NOT use '
              'route_path here.');
      expect(claims['iat'], equals(regClaimsExp['iat']));
      expect(claims['nbf'], equals(regClaimsExp['nbf']));
      expect(claims['exp'], equals(regClaimsExp['exp']));
      expect(claims['jti'], equals(regClaimsExp['jti']),
          reason: 'server contract: top-level claim "jti" is the '
              'caller-supplied request id (DirectJwsClaims.jti). SDK '
              'must NOT use request_id here.');
      expect(claims['project_id'], equals(regClaimsExp['project_id']));
      expect(claims.containsKey('device_id'),
          equals(regClaimsExp['device_id_present']));

      // Body wrapper keys (sorted) must match fixture.
      final body = (claims['body'] as Map).cast<String, dynamic>();
      final actualBodyKeys = body.keys.toList()..sort();
      expect(actualBodyKeys,
          equals((regClaimsExp['body_keys_sorted'] as List).cast<String>()));

      // ephemeral_pubkey body field MUST byte-equal header.device_pub_jwk.x.
      final jwk = (hdr['device_pub_jwk'] as Map).cast<String, dynamic>();
      expect(body['ephemeral_pubkey'], equals(jwk['x']));
    });
  });

  group('Verify (Mode B / durable) — inner JWS parity', () {
    test('emitted claims match fixture expected_durable_jws_claims', () async {
      final seed = _hexToBytes(inputs['durable_ed25519_seed_hex'] as String);
      final dur = await _durableFromSeed(seed, inputs['device_id'] as String);
      final rec = await _fixedRecipientKey();
      final builder = DirectRequestBuilder(projectId: inputs['project_id'] as String);
      final env = await builder.buildDurable(
        // routePath → inner JWS `aud` claim — pass the fixture audience.
        routePath: durClaimsExp['aud'] as String,
        requestId: inputs['request_id'] as String,
        body: const {},
        identity: dur,
        recipient: BifrostRecipientKey(
            kid: inputs['recipient_kid'] as String, pub: rec.pub),
        // Fixed nowMs for deterministic iat/nbf/exp.
        nowMs: inputs['now_ms'] as int,
      );

      final dec = await JweCodec.decryptCompact(
        jwe: env.compactJwe,
        devicePrivBytes: rec.priv,
      );
      final inner = utf8.decode(dec.plaintext);
      final parts = inner.split('.');
      final hdr = (jsonDecode(utf8.decode(_b64UrlDecode(parts[0]))) as Map)
          .cast<String, dynamic>();
      final claims = (jsonDecode(utf8.decode(_b64UrlDecode(parts[1]))) as Map)
          .cast<String, dynamic>();

      // Durable inner JWS header pins.
      expect(hdr['alg'], equals(durHeaderExp['alg']));
      expect(hdr['typ'], equals(durHeaderExp['typ']));
      expect(hdr.containsKey('device_pub_jwk'),
          equals(durHeaderExp['device_pub_jwk_present']));

      // Durable claim pins — same source-of-truth as register.
      expect(claims['aud'], equals(durClaimsExp['aud']));
      expect(claims['iat'], equals(durClaimsExp['iat']));
      expect(claims['nbf'], equals(durClaimsExp['nbf']));
      expect(claims['exp'], equals(durClaimsExp['exp']));
      expect(claims['jti'], equals(durClaimsExp['jti']));
      expect(claims['project_id'], equals(durClaimsExp['project_id']));
      expect(claims['device_id'], equals(durClaimsExp['device_id']),
          reason: 'durable mode REQUIRES top-level device_id per server '
              'contract (DirectJwsClaims.device_id, Mode B)');

      // Body wrapper present even when empty.
      expect(claims['body'], isA<Map<dynamic, dynamic>>());
    });
  });

  group('Error-envelope shape pins', () {
    test('every known error code in the fixture carries a complete record',
        () {
      final errs = (fixture['error_envelope'] as Map)
          .cast<String, dynamic>()['known_codes'] as Map;
      for (final entry in errs.entries) {
        final v = (entry.value as Map).cast<String, dynamic>();
        expect(v['http'], isA<int>(),
            reason: '${entry.key} missing http status');
        expect(v['sealed'], isA<bool>(),
            reason: '${entry.key} missing sealed flag');
        expect(v['sdk_action'], isA<String>(),
            reason: '${entry.key} missing sdk_action guidance');
      }
    });
  });

  // ─────────────────────────────────────────────────────────────────────
  // W6 — FRON payment surface parity (B-FRON.5.*)
  //
  // Six Tier-2 (durable mode) endpoints share the durable inner-JWS
  // shape. Body keys + `aud` differ per endpoint. Asserts both for every
  // endpoint using a single fixture-driven helper so adding a new
  // endpoint = adding a new fixture entry.
  // ─────────────────────────────────────────────────────────────────────

  group('Payment endpoints — inner JWS parity (W6)', () {
    late Map<String, dynamic> paymentClaims;
    late Map<String, dynamic> paymentBodies;

    setUpAll(() {
      paymentClaims = (fixture['expected_payment_jws_claims'] as Map)
          .cast<String, dynamic>();
      paymentBodies = (fixture['payment_endpoint_bodies'] as Map)
          .cast<String, dynamic>();
    });

    Future<({Map<String, dynamic> hdr, Map<String, dynamic> claims})>
        buildAndDecode({
      required String routePath,
      required Map<String, dynamic> body,
    }) async {
      final seed = _hexToBytes(inputs['durable_ed25519_seed_hex'] as String);
      final dur = await _durableFromSeed(seed, inputs['device_id'] as String);
      final rec = await _fixedRecipientKey();
      final builder = DirectRequestBuilder(projectId: inputs['project_id'] as String);
      final env = await builder.buildDurable(
        routePath: routePath,
        requestId: inputs['request_id'] as String,
        body: body,
        identity: dur,
        recipient: BifrostRecipientKey(
            kid: inputs['recipient_kid'] as String, pub: rec.pub),
        nowMs: inputs['now_ms'] as int,
      );
      final dec = await JweCodec.decryptCompact(
        jwe: env.compactJwe,
        devicePrivBytes: rec.priv,
      );
      final inner = utf8.decode(dec.plaintext);
      final parts = inner.split('.');
      expect(parts.length, equals(3),
          reason: 'inner JWS MUST be a 3-segment compact form');
      final hdr = (jsonDecode(utf8.decode(_b64UrlDecode(parts[0]))) as Map)
          .cast<String, dynamic>();
      final claims = (jsonDecode(utf8.decode(_b64UrlDecode(parts[1]))) as Map)
          .cast<String, dynamic>();
      return (hdr: hdr, claims: claims);
    }

    /// Per-endpoint assertion. Pulls the route's expected JWS claims +
    /// canonical body from the fixture, drives the durable builder, and
    /// asserts: durable header pins, every top-level claim, body-keys-
    /// sorted, body field-by-field round-trip.
    Future<void> assertEndpointParity({
      required String endpointKey,
      required String routePath,
    }) async {
      final exp = (paymentClaims[endpointKey] as Map).cast<String, dynamic>();
      final endpointMeta =
          (paymentBodies[routePath] as Map).cast<String, dynamic>();
      final body =
          (endpointMeta['body'] as Map).cast<String, dynamic>();

      final out = await buildAndDecode(routePath: routePath, body: body);
      final hdr = out.hdr;
      final claims = out.claims;

      // Durable header pins (matches expected_inner_jws_header_durable).
      expect(hdr['alg'], equals(durHeaderExp['alg']),
          reason: '$endpointKey durable header alg pin');
      expect(hdr['typ'], equals(durHeaderExp['typ']),
          reason: '$endpointKey durable header typ pin');
      expect(hdr.containsKey('device_pub_jwk'),
          equals(durHeaderExp['device_pub_jwk_present']),
          reason: '$endpointKey MUST NOT embed device_pub_jwk '
              '(Mode B — durable)');

      // Per-endpoint top-level claims. Dart SDK emits routePath verbatim
      // as `aud`; the fixture records this as `aud_dart`.
      expect(claims['aud'], equals(exp['aud_dart']),
          reason: '$endpointKey aud must match fixture aud_dart '
              '(Dart SDK emits routePath verbatim as `aud`; the cross-SDK '
              'audience-style divergence is documented in '
              '\$payment_audience_dialect_note)');
      expect(claims['iat'], equals(exp['iat']),
          reason: '$endpointKey iat parity');
      expect(claims['nbf'], equals(exp['nbf']),
          reason: '$endpointKey nbf parity');
      expect(claims['exp'], equals(exp['exp']),
          reason: '$endpointKey exp parity');
      expect(claims['jti'], equals(exp['jti']),
          reason: '$endpointKey jti parity');
      expect(claims['project_id'], equals(exp['project_id']),
          reason: '$endpointKey project_id parity');
      expect(claims['device_id'], equals(exp['device_id']),
          reason: '$endpointKey device_id REQUIRED in durable mode');

      // Body wrapper keys (sorted) must match fixture.
      final bodyMap = (claims['body'] as Map).cast<String, dynamic>();
      final actualKeys = bodyMap.keys.toList()..sort();
      expect(actualKeys,
          equals((exp['body_keys_sorted'] as List).cast<String>()),
          reason: '$endpointKey body_keys_sorted parity');

      // Body field-by-field round-trip (snake_case wire shape).
      for (final entry in body.entries) {
        expect(bodyMap[entry.key], equals(entry.value),
            reason: '$endpointKey body field "${entry.key}" round-trip');
      }
    }

    test('/payment/checkout claims + body parity', () async {
      await assertEndpointParity(
        endpointKey: 'checkout',
        routePath: '/direct/v1/payment/checkout',
      );
    });

    test('/payment/intent claims + body parity', () async {
      await assertEndpointParity(
        endpointKey: 'intent',
        routePath: '/direct/v1/payment/intent',
      );
    });

    test('/payment/portal claims + body parity', () async {
      await assertEndpointParity(
        endpointKey: 'portal',
        routePath: '/direct/v1/payment/portal',
      );
    });

    test('/payment/restore claims + body parity', () async {
      await assertEndpointParity(
        endpointKey: 'restore',
        routePath: '/direct/v1/payment/restore',
      );
    });

    test('/payment/iap-verify claims + body parity', () async {
      await assertEndpointParity(
        endpointKey: 'iap_verify',
        routePath: '/direct/v1/payment/iap-verify',
      );
    });

    test('/payment/refresh claims + body parity', () async {
      await assertEndpointParity(
        endpointKey: 'refresh',
        routePath: '/direct/v1/payment/refresh',
      );
    });
  });

  group('Payment response payloads — shape pins (W6)', () {
    test('every endpoint declares its required payload keys', () {
      final payloads = (fixture['payment_response_payloads'] as Map)
          .cast<String, dynamic>();
      for (final entry in payloads.entries) {
        if (entry.key.startsWith('\$')) continue;
        final v = (entry.value as Map).cast<String, dynamic>();
        // Either `payload_required` (most routes) OR
        // payload_{valid,invalid}_required (iap-verify) OR
        // payload_empty/payload_non_empty (restore) must be present.
        final hasRequired = v.containsKey('payload_required') ||
            (v.containsKey('payload_valid_required') &&
                v.containsKey('payload_invalid_required'));
        expect(hasRequired, isTrue,
            reason: '${entry.key} response payload spec must declare '
                'either payload_required OR the iap-verify-style '
                'payload_{valid,invalid}_required pair');
      }
    });

    test('restore invariants are recorded for SDK guardrails', () {
      final restore = ((fixture['payment_response_payloads'] as Map)
              .cast<String, dynamic>()['/direct/v1/payment/restore']
          as Map)
          .cast<String, dynamic>();
      expect(restore['payload_invariants'], isA<List>(),
          reason: 'restore must publish its hard invariants '
              '(B-FRON.5.4 / count>0 IMPLIES jws!=null)');
    });

    test('iap-verify reason taxonomy matches the SDK enum', () {
      final iap = ((fixture['payment_response_payloads'] as Map)
              .cast<String, dynamic>()['/direct/v1/payment/iap-verify']
          as Map)
          .cast<String, dynamic>();
      final reasons = (iap['reason_enum'] as List).cast<String>();
      // SDK's DirectIapReceiptInvalidReason taxonomy — these are the
      // narrow strings the SDK forks UX on.
      expect(reasons, containsAll(<String>[
        'expired',
        'malformed',
        'not_subscribed',
        'unknown',
      ]));
    });
  });

  // ─────────────────────────────────────────────────────────────────────
  // W6 Fix-pass-2 — response_envelope_shape + sealed_error_envelope_samples
  // + endpoint_response_samples
  //
  // Fixture-shape pins for the canonical FRON response shape (both success
  // and sealed-error legs) plus four concrete sealed-error sample envelopes
  // and per-endpoint success-payload samples. These are documentation-grade
  // pins — they ensure both SDKs see the same canonical wire shape in the
  // shared fixture so any divergence between server emission, Dart parser,
  // and Swift parser is visible in code review (the $claim_placement_note
  // in response_envelope_shape documents the current divergence — see the
  // W6 Fix-pass-2 follow-up).
  // ─────────────────────────────────────────────────────────────────────

  group('Response envelope shape pins (W6 Fix-pass-2)', () {
    test('response_envelope_shape block exists with success + sealed-error '
        'paths', () {
      final block = (fixture['response_envelope_shape'] as Map)
          .cast<String, dynamic>();
      expect(block.containsKey('success_path'), isTrue,
          reason: 'response_envelope_shape MUST declare a success_path');
      expect(block.containsKey('sealed_error_path'), isTrue,
          reason: 'response_envelope_shape MUST declare a sealed_error_path');

      final success = (block['success_path'] as Map).cast<String, dynamic>();
      final sealedErr = (block['sealed_error_path'] as Map)
          .cast<String, dynamic>();
      final successShape =
          (success['shape'] as Map).cast<String, dynamic>();
      final sealedShape =
          (sealedErr['shape'] as Map).cast<String, dynamic>();

      // Both shapes share the same envelope skeleton (iss/iat/nbf/exp/aud).
      for (final claim in const ['iss', 'iat', 'nbf', 'exp', 'aud']) {
        expect(successShape.containsKey(claim), isTrue,
            reason: 'success_path.shape missing claim "$claim"');
        expect(sealedShape.containsKey(claim), isTrue,
            reason: 'sealed_error_path.shape missing claim "$claim"');
      }

      // Iss pin: both legs use the same Bifrost issuer string.
      expect(successShape['iss'], equals('bifrost-direct'));
      expect(sealedShape['iss'], equals('bifrost-direct'));

      // Success carries `payload`; sealed-error carries `error` and NOT
      // `payload` (per the fixture's documented shape; matches the Dart
      // parser's verified.claims['error'] read path).
      expect(successShape.containsKey('payload'), isTrue,
          reason: 'success_path.shape MUST carry payload claim');
      expect(sealedShape.containsKey('error'), isTrue,
          reason: 'sealed_error_path.shape MUST carry error claim');
      expect(sealedShape.containsKey('payload'), isFalse,
          reason: 'sealed_error_path.shape MUST NOT carry payload claim '
              '(comment pins: "payload claim is absent")');

      // Sealed-error.error inner-shape carries the four-field projection
      // the SDK forks UX on.
      final errShape = (sealedShape['error'] as Map).cast<String, dynamic>();
      for (final field in const [
        'code',
        'reason',
        'provider',
        'retry_after_ms',
      ]) {
        expect(errShape.containsKey(field), isTrue,
            reason: 'sealed_error_path.shape.error missing "$field"');
      }
    });
  });

  group('Sealed-error envelope samples (W6 Fix-pass-2)', () {
    test('four canonical samples are present + well-formed', () {
      final samples = (fixture['sealed_error_envelope_samples'] as Map)
          .cast<String, dynamic>();
      for (final sampleKey in const [
        'DIRECT_IAP_RECEIPT_INVALID_expired',
        'DIRECT_PAYMENT_PROVIDER_FAILED_stripe',
        'DIRECT_RATE_LIMITED_5000ms',
        'DIRECT_BAD_REQUEST_plain',
      ]) {
        expect(samples.containsKey(sampleKey), isTrue,
            reason: 'sealed_error_envelope_samples missing "$sampleKey"');
        final s = (samples[sampleKey] as Map).cast<String, dynamic>();
        expect(s.containsKey('inner_jws_claims'), isTrue,
            reason: '$sampleKey missing inner_jws_claims');
        final claims = (s['inner_jws_claims'] as Map)
            .cast<String, dynamic>();
        // Standard envelope skeleton.
        for (final c in const ['iat', 'nbf', 'exp', 'iss', 'aud']) {
          expect(claims.containsKey(c), isTrue,
              reason: '$sampleKey claims missing "$c"');
        }
        // iss is the canonical Bifrost issuer.
        expect(claims['iss'], equals('bifrost-direct'),
            reason: '$sampleKey iss pin');
        // error claim is present + well-shaped.
        final err = (claims['error'] as Map).cast<String, dynamic>();
        expect(err['code'], isA<String>(),
            reason: '$sampleKey error.code must be a string');
        // payload claim is absent (sealed-error envelope contract).
        expect(claims.containsKey('payload'), isFalse,
            reason: '$sampleKey MUST NOT carry payload claim');
      }
    });

    test('IAP_RECEIPT_INVALID sample carries reason="expired"', () {
      final s = ((fixture['sealed_error_envelope_samples'] as Map)
              .cast<String, dynamic>()[
          'DIRECT_IAP_RECEIPT_INVALID_expired'] as Map)
          .cast<String, dynamic>();
      final err = ((s['inner_jws_claims'] as Map)
              .cast<String, dynamic>()['error'] as Map)
          .cast<String, dynamic>();
      expect(err['code'], equals('DIRECT_IAP_RECEIPT_INVALID'));
      expect(err['reason'], equals('expired'));
    });

    test('PAYMENT_PROVIDER_FAILED sample carries provider="stripe"', () {
      final s = ((fixture['sealed_error_envelope_samples'] as Map)
              .cast<String, dynamic>()[
          'DIRECT_PAYMENT_PROVIDER_FAILED_stripe'] as Map)
          .cast<String, dynamic>();
      final err = ((s['inner_jws_claims'] as Map)
              .cast<String, dynamic>()['error'] as Map)
          .cast<String, dynamic>();
      expect(err['code'], equals('DIRECT_PAYMENT_PROVIDER_FAILED'));
      expect(err['provider'], equals('stripe'));
    });

    test('RATE_LIMITED sample carries retry_after_ms=5000', () {
      final s = ((fixture['sealed_error_envelope_samples'] as Map)
              .cast<String, dynamic>()['DIRECT_RATE_LIMITED_5000ms'] as Map)
          .cast<String, dynamic>();
      final err = ((s['inner_jws_claims'] as Map)
              .cast<String, dynamic>()['error'] as Map)
          .cast<String, dynamic>();
      expect(err['code'], equals('DIRECT_RATE_LIMITED'));
      expect(err['retry_after_ms'], equals(5000));
    });

    test('BAD_REQUEST plain sample has only code (no reason / provider / '
        'retry_after_ms)', () {
      final s = ((fixture['sealed_error_envelope_samples'] as Map)
              .cast<String, dynamic>()['DIRECT_BAD_REQUEST_plain'] as Map)
          .cast<String, dynamic>();
      final err = ((s['inner_jws_claims'] as Map)
              .cast<String, dynamic>()['error'] as Map)
          .cast<String, dynamic>();
      expect(err['code'], equals('DIRECT_BAD_REQUEST'));
      expect(err.containsKey('reason'), isFalse);
      expect(err.containsKey('provider'), isFalse);
      expect(err.containsKey('retry_after_ms'), isFalse);
    });
  });

  group('Endpoint response samples (W6 Fix-pass-2)', () {
    test('every endpoint sample wraps its success body under payload claim',
        () {
      final samples = (fixture['endpoint_response_samples'] as Map)
          .cast<String, dynamic>();
      // Every entry (except $-prefixed metadata) must carry an
      // inner_jws_claims with a payload claim — matches the server's
      // sendDirectJweResponse contract.
      for (final entry in samples.entries) {
        if (entry.key.startsWith('\$')) continue;
        final sample = (entry.value as Map).cast<String, dynamic>();
        expect(sample.containsKey('inner_jws_claims'), isTrue,
            reason: '${entry.key} missing inner_jws_claims');
        final claims =
            (sample['inner_jws_claims'] as Map).cast<String, dynamic>();
        expect(claims.containsKey('payload'), isTrue,
            reason: '${entry.key} success sample MUST wrap body under '
                '"payload" claim (per sendDirectJweResponse contract)');
        // Envelope skeleton.
        for (final c in const ['iat', 'nbf', 'exp', 'iss', 'aud']) {
          expect(claims.containsKey(c), isTrue,
              reason: '${entry.key} claims missing "$c"');
        }
        expect(claims['iss'], equals('bifrost-direct'),
            reason: '${entry.key} iss pin');
      }
    });

    test('all 9 known FRON routes have a sample', () {
      final samples = (fixture['endpoint_response_samples'] as Map)
          .cast<String, dynamic>();
      for (final route in const [
        '/direct/v1/register',
        '/direct/v1/verify',
        '/direct/v1/heartbeat',
        '/direct/v1/payment/checkout',
        '/direct/v1/payment/intent',
        '/direct/v1/payment/portal',
        '/direct/v1/payment/restore',
        '/direct/v1/payment/iap-verify',
        '/direct/v1/payment/refresh',
      ]) {
        expect(samples.containsKey(route), isTrue,
            reason: 'endpoint_response_samples missing route "$route"');
      }
    });
  });

  group('Payment error codes — wire-shape pins (W6)', () {
    test('every new payment error code carries http + sealed + sdk_action',
        () {
      final codes = (fixture['payment_error_codes'] as Map)
          .cast<String, dynamic>();
      for (final entry in codes.entries) {
        if (entry.key.startsWith('\$')) continue;
        final v = (entry.value as Map).cast<String, dynamic>();
        expect(v['http'], isA<int>(),
            reason: '${entry.key} missing http status');
        expect(v['sealed'], isA<bool>(),
            reason: '${entry.key} missing sealed flag');
        expect(v['sdk_action'], isA<String>(),
            reason: '${entry.key} missing sdk_action guidance');
        expect(v['wire_shape'], isA<Map>(),
            reason: '${entry.key} missing wire_shape spec');
      }
    });

    test('DIRECT_IAP_RECEIPT_INVALID carries a top-level reason field', () {
      final iap = ((fixture['payment_error_codes'] as Map)
              .cast<String, dynamic>()['DIRECT_IAP_RECEIPT_INVALID']
          as Map)
          .cast<String, dynamic>();
      final wire = (iap['wire_shape'] as Map).cast<String, dynamic>();
      expect(wire.containsKey('reason'), isTrue,
          reason: 'DIRECT_IAP_RECEIPT_INVALID wire MUST carry the narrow '
              'reason taxonomy at top-level — SDK forks UX on it');
    });

    test(
        'DIRECT_PAYMENT_PROVIDER_FAILED + DIRECT_NO_ACTIVE_SUBSCRIPTION + '
        'DIRECT_SESSION_NOT_* + DIRECT_IAP_RECEIPT_INVALID are sealed', () {
      final codes = (fixture['payment_error_codes'] as Map)
          .cast<String, dynamic>();
      for (final code in const [
        'DIRECT_PAYMENT_PROVIDER_FAILED',
        'DIRECT_NO_PROVIDER_CONFIGURED',
        'DIRECT_NO_ACTIVE_SUBSCRIPTION',
        'DIRECT_SESSION_NOT_FOUND',
        'DIRECT_SESSION_NOT_COMPLETE',
        'DIRECT_IAP_RECEIPT_INVALID',
      ]) {
        final v = (codes[code] as Map).cast<String, dynamic>();
        expect(v['sealed'], isTrue,
            reason: '$code is a post-verify (handler) error and MUST '
                'be sealed inside the JWE envelope — the SDK refuses to '
                'drive destructive state on a plaintext payment error');
      }
    });
  });

  // ─────────────────────────────────────────────────────────────────────
  // D-Fix 3 regression — canonical `aud` namespace convergence.
  //
  // Per W6 fix-pass-2, every FRON SDK route MUST emit the canonical
  // colon-namespaced JWS `aud` claim (`direct:<area>[.endpoint]`). The
  // payment surface already converged in fix-pass-1; this pass extends
  // the convergence to register / activate / verify / heartbeat /
  // deactivate / catalog / keys.rotate_ack / notifications.* /
  // telemetry.* by routing each call through the new `kDirectAud*`
  // constants in `direct_client.dart`.
  //
  // The constants below are the SDK's source-of-truth for the audience
  // table. If a server-side rename ships, update both sides (constant +
  // fixture) — divergence here triggers a hard parity failure rather
  // than a silent server reject.
  // ─────────────────────────────────────────────────────────────────────

  group('Canonical aud table — convergence across ALL FRON routes '
      '(D-Fix 3 / W6 Fix-pass-2)', () {
    /// The expected, post-convergence aud value for every FRON route
    /// the SDK calls. Mirrors the `kDirectAud*` constants in
    /// `direct_client.dart` + `direct_payment_methods.dart`.
    const expected = <String, String>{
      // Tier 1
      'register': 'direct:register',
      // Tier 2 (durable)
      'activate': 'direct:activate',
      'verify': 'direct:verify',
      'heartbeat': 'direct:heartbeat',
      'deactivate': 'direct:deactivate',
      'catalog': 'direct:catalog',
      'keys.rotate_ack': 'direct:keys.rotate_ack',
      'notifications.register_fcm': 'direct:notifications.register_fcm',
      'notifications.ack': 'direct:notifications.ack',
      'telemetry.stats': 'direct:telemetry.stats',
      'telemetry.error': 'direct:telemetry.error',
      // Payment surface (already converged in fix-pass-1 — pin them
      // here so a future regression breaks this single test rather than
      // scattering across the payment suite).
      'payment.checkout': 'direct:payment.checkout',
      'payment.intent': 'direct:payment.intent',
      'payment.portal': 'direct:payment.portal',
      'payment.restore': 'direct:payment.restore',
      'payment.iap_verify': 'direct:payment.iap_verify',
      'payment.refresh': 'direct:payment.refresh',
    };

    test('every audience value is colon-namespaced + lowercase + non-empty', () {
      for (final entry in expected.entries) {
        final aud = entry.value;
        expect(aud, startsWith('direct:'),
            reason: '${entry.key} aud MUST start with the "direct:" '
                'prefix per the canonical namespace');
        expect(aud, equals(aud.toLowerCase()),
            reason: '${entry.key} aud MUST be lowercase '
                '(no Swift `direct:Catalog` drift)');
        expect(aud, isNot(contains('/')),
            reason: '${entry.key} aud MUST NOT carry HTTP path slashes — '
                'the URL stays in routePath; aud is the abstract audience');
        expect(aud.length, lessThan(64),
            reason: '${entry.key} aud should be a compact identifier');
      }
    });

    test('SDK kDirectAud* constants match the canonical table', () {
      // Imports of the SDK-side constants intentionally NOT at the file
      // top — keeps the parity_test free of SDK-internal symbols except
      // for the parity-critical ones used in this test.
      // ignore: prefer_const_constructors
      expect(kDirectAudRegister, equals(expected['register']));
      expect(kDirectAudActivate, equals(expected['activate']));
      expect(kDirectAudVerify, equals(expected['verify']));
      expect(kDirectAudHeartbeat, equals(expected['heartbeat']));
      expect(kDirectAudDeactivate, equals(expected['deactivate']));
      expect(kDirectAudCatalog, equals(expected['catalog']));
      expect(kDirectAudKeysRotateAck,
          equals(expected['keys.rotate_ack']));
      expect(kDirectAudNotificationsRegisterFcm,
          equals(expected['notifications.register_fcm']));
      expect(kDirectAudNotificationsAck,
          equals(expected['notifications.ack']));
      expect(kDirectAudTelemetryStats,
          equals(expected['telemetry.stats']));
      expect(kDirectAudTelemetryError,
          equals(expected['telemetry.error']));
      // Payment table (defined in direct_payment_methods.dart).
      expect(kDirectAudPaymentCheckout,
          equals(expected['payment.checkout']));
      expect(kDirectAudPaymentIntent,
          equals(expected['payment.intent']));
      expect(kDirectAudPaymentPortal,
          equals(expected['payment.portal']));
      expect(kDirectAudPaymentRestore,
          equals(expected['payment.restore']));
      expect(kDirectAudPaymentIapVerify,
          equals(expected['payment.iap_verify']));
      expect(kDirectAudPaymentRefresh,
          equals(expected['payment.refresh']));
    });

    test('non-payment routes emit canonical aud when explicitly passed', () async {
      // Drive the durable builder with each canonical aud and assert
      // the emitted `aud` claim survives round-trip through the JWE
      // envelope unmodified. This catches a future regression where
      // the builder silently rewrites or normalises the aud value.
      final seed = _hexToBytes(inputs['durable_ed25519_seed_hex'] as String);
      final dur = await _durableFromSeed(seed, inputs['device_id'] as String);
      final rec = await _fixedRecipientKey();
      final builder =
          DirectRequestBuilder(projectId: inputs['project_id'] as String);

      // (route → expected aud) for the eleven non-payment routes.
      final routeAud = <String, String>{
        '/direct/v1/activate': kDirectAudActivate,
        '/direct/v1/verify': kDirectAudVerify,
        '/direct/v1/heartbeat': kDirectAudHeartbeat,
        '/direct/v1/deactivate': kDirectAudDeactivate,
        '/direct/v1/catalog': kDirectAudCatalog,
        '/direct/v1/keys/rotate-ack': kDirectAudKeysRotateAck,
        '/direct/v1/notifications/register-fcm':
            kDirectAudNotificationsRegisterFcm,
        '/direct/v1/notifications/ack': kDirectAudNotificationsAck,
        '/direct/v1/telemetry/stats': kDirectAudTelemetryStats,
        '/direct/v1/telemetry/error': kDirectAudTelemetryError,
      };

      for (final entry in routeAud.entries) {
        final env = await builder.buildDurable(
          routePath: entry.key,
          requestId: inputs['request_id'] as String,
          body: const {},
          identity: dur,
          recipient: BifrostRecipientKey(
              kid: inputs['recipient_kid'] as String, pub: rec.pub),
          aud: entry.value,
          nowMs: inputs['now_ms'] as int,
        );
        final dec = await JweCodec.decryptCompact(
          jwe: env.compactJwe,
          devicePrivBytes: rec.priv,
        );
        final inner = utf8.decode(dec.plaintext);
        final parts = inner.split('.');
        final claims =
            (jsonDecode(utf8.decode(_b64UrlDecode(parts[1]))) as Map)
                .cast<String, dynamic>();
        expect(claims['aud'], equals(entry.value),
            reason: '${entry.key} MUST emit canonical aud ${entry.value} — '
                'the builder must not rewrite or normalise it');
      }
    });

    test('register also emits canonical direct:register aud', () async {
      final seed = _hexToBytes(inputs['ephemeral_ed25519_seed_hex'] as String);
      final eph = await _ephemeralFromSeed(seed);
      final rec = await _fixedRecipientKey();
      final builder =
          DirectRequestBuilder(projectId: inputs['project_id'] as String);
      final env = await builder.buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: inputs['request_id'] as String,
        body: const {
          'license_key': 'L',
          'fingerprint': 'f',
          'app_meta': <String, dynamic>{},
        },
        ephemeral: eph,
        recipient: BifrostRecipientKey(
            kid: inputs['recipient_kid'] as String, pub: rec.pub),
        aud: kDirectAudRegister,
        nowMs: inputs['now_ms'] as int,
      );
      final dec = await JweCodec.decryptCompact(
        jwe: env.compactJwe,
        devicePrivBytes: rec.priv,
      );
      final inner = utf8.decode(dec.plaintext);
      final parts = inner.split('.');
      final claims =
          (jsonDecode(utf8.decode(_b64UrlDecode(parts[1]))) as Map)
              .cast<String, dynamic>();
      expect(claims['aud'], equals('direct:register'));
    });
  });
}
