// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Tests for `DirectRequestBuilder` — the FRON envelope construction
/// (inner Ed25519 JWS wrapped in an X25519 ECDH-ES + A256GCM JWE).
///
/// Strategy: build a request, decrypt the outer JWE with the fake
/// Bifrost recipient's private key, then verify the inner JWS by hand.
/// This proves the SDK speaks the wire shape Bifrost expects.
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:test/test.dart';
import 'package:vanaheim/src/crypto/jwe_codec.dart';
import 'package:vanaheim/src/crypto/thumbprint.dart';
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/direct/direct_request_builder.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

import '_fake_bifrost_direct.dart';

void main() {
  late FakeBifrostDirectServer server;
  late DirectKeypairStore store;

  setUpAll(() async {
    server = await FakeBifrostDirectServer.create();
  });

  setUp(() {
    store = DirectKeypairStore(cache: InMemorySecureCache());
  });

  group('DirectRequestBuilder — ephemeral (register) envelope', () {
    test('produces a 5-segment JWE that decrypts to a valid inner JWS',
        () async {
      final ephemeral = await store.generateEphemeral();
      const builder = DirectRequestBuilder(projectId: 'proj_abc');

      final env = await builder.buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'req-001',
        body: {
          'license_key': 'LIC-1234',
          'fingerprint': 'fp-xyz',
          'app_meta': {'v': 1},
        },
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );

      expect(env.compactJwe.split('.').length, equals(5),
          reason: 'compact JWE serialization is exactly 5 segments');

      // Decrypt with the recipient's priv (what the server has).
      final dec = await JweCodec.decryptCompact(
        jwe: env.compactJwe,
        devicePrivBytes: server.recipientX25519PrivBytes,
      );

      // Outer header pin: typ=bifrost-direct+jwe + lcs_v=2 + correct route +
      // request id + project id.
      expect(dec.header['typ'], equals('bifrost-direct+jwe'));
      expect(dec.header['lcs_v'], equals(2));
      expect(dec.header['route_path'], equals('/direct/v1/register'));
      expect(dec.header['request_id'], equals('req-001'));
      expect(dec.header['project_id'], equals('proj_abc'));
      expect(dec.header['kid'], equals(server.recipientKid));

      // apu = b64url-SHA256(sender X25519 pub).
      final expectedApu =
          await pubKeyThumbprint(ephemeral.x25519Pub);
      expect(dec.header['apu'], equals(expectedApu));

      // Inner JWS shape.
      final inner = utf8.decode(dec.plaintext);
      final parts = inner.split('.');
      expect(parts.length, equals(3),
          reason: 'inner JWS is a 3-segment compact serialization');
    });

    test('inner JWS uses ephemeral typ + embeds device_pub_jwk in the header',
        () async {
      final ephemeral = await store.generateEphemeral();
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'req-x',
        body: const {'license_key': 'L', 'fingerprint': 'f'},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      final inner = await _decryptInner(env.compactJwe, server);
      final header = inner.header;
      expect(header['typ'], equals('bifrost-direct+ephemeral+jws'));
      expect(header['alg'], equals('EdDSA'));
      // device_pub_jwk embedded for server-side standalone verification.
      expect(header['device_pub_jwk'], isA<Map<dynamic, dynamic>>());
      final jwk = (header['device_pub_jwk'] as Map).cast<String, dynamic>();
      expect(jwk['kty'], equals('OKP'));
      expect(jwk['crv'], equals('Ed25519'));
      expect(jwk['x'], isA<String>());
      final pubBytes = _b64UrlDecode(jwk['x'] as String);
      expect(pubBytes, equals(ephemeral.ed25519Pub),
          reason: 'header pubkey must match the ephemeral signer');
    });

    test('inner JWS signature verifies against the embedded device_pub_jwk',
        () async {
      final ephemeral = await store.generateEphemeral();
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'rq',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      final inner = await _decryptInner(env.compactJwe, server);
      final jwk = (inner.header['device_pub_jwk'] as Map).cast<String, dynamic>();
      final pubBytes = _b64UrlDecode(jwk['x'] as String);
      final sigBytes = _b64UrlDecode(inner.rawParts[2]);
      final signingInput =
          ascii.encode('${inner.rawParts[0]}.${inner.rawParts[1]}');
      final ok = ed25519.verify(
        ed25519.PublicKey(pubBytes),
        Uint8List.fromList(signingInput),
        sigBytes,
      );
      expect(ok, isTrue,
          reason: 'inner JWS signature must verify against the embedded key');
    });

    test('claims carry project_id + jti + aud + iat/nbf/exp stamps',
        () async {
      final ephemeral = await store.generateEphemeral();
      final env = await const DirectRequestBuilder(projectId: 'project-alpha')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'req-stamp-1',
        body: const {'license_key': 'L', 'fingerprint': 'f'},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      final inner = await _decryptInner(env.compactJwe, server);
      expect(inner.claims['project_id'], equals('project-alpha'));
      // Inner JWS uses RFC 7519 standard claim names — jti for the
      // request id, aud for the route audience. The server contract
      // (DirectJwsClaims in bifrost/.../jws-verifier.ts) pins these
      // names; the legacy route_path/request_id keys would fail
      // server-side claims_invalid validation.
      expect(inner.claims['jti'], equals('req-stamp-1'));
      expect(inner.claims['aud'], equals('/direct/v1/register'));
      expect(inner.claims.containsKey('route_path'), isFalse,
          reason: 'inner JWS must NOT carry the legacy route_path key');
      expect(inner.claims.containsKey('request_id'), isFalse,
          reason: 'inner JWS must NOT carry the legacy request_id key');
      expect(inner.claims['iat'], isA<int>());
      expect(inner.claims['nbf'], isA<int>());
      expect(inner.claims['exp'], isA<int>());
      // iat/exp MUST be milliseconds-since-epoch, not seconds. A
      // millisecond timestamp for "now" is well above 10^12; a seconds
      // timestamp would be ~10^9. Pin the boundary.
      final iat = inner.claims['iat'] as int;
      final exp = inner.claims['exp'] as int;
      expect(iat, greaterThan(1000000000000),
          reason: 'iat must be milliseconds (not seconds) per server contract');
      expect(exp, greaterThan(1000000000000),
          reason: 'exp must be milliseconds (not seconds) per server contract');
      // Default expiry window is 60s (60000ms) per the FRON spec.
      final nowMs = DateTime.now().toUtc().millisecondsSinceEpoch;
      expect(exp, greaterThan(nowMs));
      expect(exp - iat, equals(60000),
          reason: 'default exp window per spec is iat + 60000ms (60s skew)');
      // Ephemeral envelope does NOT include device_id at the top level.
      expect(inner.claims.containsKey('device_id'), isFalse);
    });

    test('JWS payload nests caller fields under .body (wire-compat with '
        'Bifrost.parseDirectBody)', () async {
      final ephemeral = await store.generateEphemeral();
      final env = await const DirectRequestBuilder(projectId: 'proj_wrap')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'req-wrap',
        body: const {
          'license_key': 'LIC-NESTED',
          'fingerprint': 'fp-nested',
          'app_meta': {'v': 7},
        },
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      final inner = await _decryptInner(env.compactJwe, server);
      expect(inner.claims['body'], isA<Map<dynamic, dynamic>>(),
          reason: 'caller body must be wrapped under .body, not flattened');
      final body = (inner.claims['body'] as Map).cast<String, dynamic>();
      expect(body['license_key'], equals('LIC-NESTED'));
      expect(body['fingerprint'], equals('fp-nested'));
      expect(body['app_meta'], equals({'v': 7}));
      // license_key MUST NOT also leak to the top level (would shadow
      // the JWS claim namespace and confuse the server's parser).
      expect(inner.claims.containsKey('license_key'), isFalse,
          reason: 'caller fields must NOT also live at the top level');
    });

    test('register body carries ephemeral_pubkey byte-equal to JWS header '
        'device_pub_jwk.x', () async {
      final ephemeral = await store.generateEphemeral();
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'req-pk',
        body: const {'license_key': 'L', 'fingerprint': 'f'},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      final inner = await _decryptInner(env.compactJwe, server);
      final body = (inner.claims['body'] as Map).cast<String, dynamic>();
      final headerJwk =
          (inner.header['device_pub_jwk'] as Map).cast<String, dynamic>();
      expect(body['ephemeral_pubkey'], isA<String>(),
          reason: 'register must include ephemeral_pubkey in the body');
      expect(body['ephemeral_pubkey'], equals(headerJwk['x']),
          reason: 'ephemeral_pubkey MUST be byte-equal to header.device_pub_jwk.x '
              '(Bifrost server asserts this in handleRegister)');
    });
  });

  group('DirectRequestBuilder — durable envelope', () {
    test('inner typ is bifrost-direct+durable+jws + no device_pub_jwk in header',
        () async {
      final ephemeral = await store.generateEphemeral();
      final id = await store.promoteEphemeral(
        deviceId: 'dev_d1',
        ephemeral: ephemeral,
        serverNonce: 'srv-nonce',
      );
      final env = await const DirectRequestBuilder(projectId: 'pid')
          .buildDurable(
        routePath: '/direct/v1/verify',
        requestId: 'req-d',
        body: const {},
        identity: id,
        recipient: server.keySet().activeRecipient,
      );
      final inner = await _decryptInner(env.compactJwe, server);
      expect(inner.header['typ'], equals('bifrost-direct+durable+jws'));
      expect(inner.header.containsKey('device_pub_jwk'), isFalse,
          reason: 'durable envelopes rely on the server-side device registry, '
              'not an embedded pubkey');
    });

    test('durable claims carry device_id at top level + server_nonce inside body',
        () async {
      final ephemeral = await store.generateEphemeral();
      final id = await store.promoteEphemeral(
        deviceId: 'dev_with_nonce',
        ephemeral: ephemeral,
        serverNonce: 'nonce-abc',
      );
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildDurable(
        routePath: '/direct/v1/heartbeat',
        requestId: 'req-h',
        body: const {'kind': 'ping'},
        identity: id,
        recipient: server.keySet().activeRecipient,
      );
      final inner = await _decryptInner(env.compactJwe, server);
      // device_id at the top level — the server's verifyDirectInnerJws
      // looks for it on the JWS payload root, not inside the body.
      expect(inner.claims['device_id'], equals('dev_with_nonce'));
      // server_nonce + caller fields live INSIDE body so the server's
      // parseDirectBody can hand them to the route handler without
      // colliding with the JWS top-level claim namespace.
      final body = (inner.claims['body'] as Map).cast<String, dynamic>();
      expect(body['server_nonce'], equals('nonce-abc'));
      expect(body['kind'], equals('ping'),
          reason: 'caller body fields must be preserved under .body');
    });

    test('durable JWS signature verifies against the persisted Ed25519 pub',
        () async {
      final ephemeral = await store.generateEphemeral();
      final id = await store.promoteEphemeral(
        deviceId: 'dv',
        ephemeral: ephemeral,
      );
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildDurable(
        routePath: '/direct/v1/verify',
        requestId: 'rq',
        body: const {},
        identity: id,
        recipient: server.keySet().activeRecipient,
      );
      final inner = await _decryptInner(env.compactJwe, server);
      final sigBytes = _b64UrlDecode(inner.rawParts[2]);
      final signingInput =
          ascii.encode('${inner.rawParts[0]}.${inner.rawParts[1]}');
      final ok = ed25519.verify(
        ed25519.PublicKey(id.ed25519Pub),
        Uint8List.fromList(signingInput),
        sigBytes,
      );
      expect(ok, isTrue);
    });
  });

  group('DirectRequestBuilder — ephemeral epk freshness', () {
    test('two builds for the same route produce DIFFERENT outer envelopes',
        () async {
      final ephemeral = await store.generateEphemeral();
      final id = await store.promoteEphemeral(
        deviceId: 'd',
        ephemeral: ephemeral,
      );
      const builder = DirectRequestBuilder(projectId: 'p');
      final a = await builder.buildDurable(
        routePath: '/direct/v1/verify',
        requestId: 'r1',
        body: const {},
        identity: id,
        recipient: server.keySet().activeRecipient,
      );
      final b = await builder.buildDurable(
        routePath: '/direct/v1/verify',
        requestId: 'r2',
        body: const {},
        identity: id,
        recipient: server.keySet().activeRecipient,
      );
      expect(a.compactJwe, isNot(equals(b.compactJwe)));
      final decA = await JweCodec.decryptCompact(
        jwe: a.compactJwe,
        devicePrivBytes: server.recipientX25519PrivBytes,
      );
      final decB = await JweCodec.decryptCompact(
        jwe: b.compactJwe,
        devicePrivBytes: server.recipientX25519PrivBytes,
      );
      final epkA = (decA.header['epk'] as Map)['x'];
      final epkB = (decB.header['epk'] as Map)['x'];
      expect(epkA, isNot(equals(epkB)),
          reason: 'fresh ephemeral epk per call is the FRON anti-reuse '
              'contract');
    });
  });
}

class _InnerInfo {
  final Map<String, dynamic> header;
  final Map<String, dynamic> claims;
  final List<String> rawParts;
  _InnerInfo(this.header, this.claims, this.rawParts);
}

Future<_InnerInfo> _decryptInner(
  String jwe,
  FakeBifrostDirectServer server,
) async {
  final dec = await JweCodec.decryptCompact(
    jwe: jwe,
    devicePrivBytes: server.recipientX25519PrivBytes,
  );
  final inner = utf8.decode(dec.plaintext);
  final parts = inner.split('.');
  final hdr = (jsonDecode(utf8.decode(_b64UrlDecode(parts[0]))) as Map)
      .cast<String, dynamic>();
  final clm = (jsonDecode(utf8.decode(_b64UrlDecode(parts[1]))) as Map)
      .cast<String, dynamic>();
  return _InnerInfo(hdr, clm, parts);
}

Uint8List _b64UrlDecode(String s) {
  final pad = (4 - s.length % 4) % 4;
  return base64Url.decode(s.padRight(s.length + pad, '='));
}
