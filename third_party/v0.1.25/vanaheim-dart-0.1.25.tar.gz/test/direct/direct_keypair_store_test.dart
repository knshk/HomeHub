// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Tests for the FRON keypair store — ephemeral generation, promote-to-
/// durable, persistence across "restart" (re-creating the store from a
/// shared SecureCache), and the wipe path used on DIRECT_DEVICE_REVOKED.
library;

import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

void main() {
  group('DirectKeypairStore — ephemeral generation', () {
    test('generateEphemeral produces 32-byte X25519 + 32-byte Ed25519 pubs',
        () async {
      final store = DirectKeypairStore(cache: InMemorySecureCache());
      final ek = await store.generateEphemeral();
      expect(ek.x25519Pub.length, equals(32),
          reason: 'X25519 pub is exactly 32 raw bytes');
      expect(ek.ed25519Pub.length, equals(32),
          reason: 'Ed25519 pub is exactly 32 raw bytes');
      expect(ek.x25519Priv.length, equals(32));
      // ed25519_edwards stores the expanded private key (64 bytes).
      expect(ek.ed25519Priv.length, equals(64));
    });

    test('two ephemeral generations are distinct (no reuse)', () async {
      final store = DirectKeypairStore(cache: InMemorySecureCache());
      final a = await store.generateEphemeral();
      final b = await store.generateEphemeral();
      expect(a.x25519Pub, isNot(equals(b.x25519Pub)),
          reason: 'each register() must mint a fresh X25519 keypair');
      expect(a.ed25519Pub, isNot(equals(b.ed25519Pub)));
    });

    test('ephemeral generation does NOT touch SecureCache', () async {
      final cache = InMemorySecureCache();
      final store = DirectKeypairStore(cache: cache);
      await store.generateEphemeral();
      expect(await cache.getRaw(kDirectDeviceIdKey), isNull);
      expect(await cache.getRaw(kDirectDurableX25519PrivKey), isNull,
          reason: 'a failed register must leave NO persisted key behind');
    });
  });

  group('DirectKeypairStore — loadDurable', () {
    test('returns null on a fresh cache', () async {
      final store = DirectKeypairStore(cache: InMemorySecureCache());
      expect(await store.loadDurable(), isNull);
    });

    test('returns null on partial-write state (defensive)', () async {
      final cache = InMemorySecureCache();
      // Only device_id present — missing every keypair slot.
      await cache.putRaw(kDirectDeviceIdKey, 'dev_xyz');
      final store = DirectKeypairStore(cache: cache);
      expect(await store.loadDurable(), isNull,
          reason: 'partial state must be treated as not-registered so '
              'register() can overwrite cleanly');
    });
  });

  group('DirectKeypairStore — promote + persistence', () {
    test('promoteEphemeral persists every slot + returns matching identity',
        () async {
      final cache = InMemorySecureCache();
      final store = DirectKeypairStore(cache: cache);
      final ek = await store.generateEphemeral();

      final id = await store.promoteEphemeral(
        deviceId: 'dev_abc_001',
        ephemeral: ek,
        serverNonce: 'nonce-xyz',
      );

      expect(id.deviceId, equals('dev_abc_001'));
      expect(id.x25519Priv, equals(ek.x25519Priv));
      expect(id.ed25519Pub, equals(ek.ed25519Pub));
      expect(id.serverNonce, equals('nonce-xyz'));

      // Every slot must be in the cache after promotion.
      expect(await cache.getRaw(kDirectDeviceIdKey), equals('dev_abc_001'));
      expect(await cache.getRaw(kDirectServerNonceKey), equals('nonce-xyz'));
      expect(await cache.getRaw(kDirectDurableX25519PrivKey), isNotNull);
      expect(await cache.getRaw(kDirectDurableX25519PubKey), isNotNull);
      expect(await cache.getRaw(kDirectDurableEd25519PrivKey), isNotNull);
      expect(await cache.getRaw(kDirectDurableEd25519PubKey), isNotNull);
    });

    test('promoteEphemeral with no serverNonce omits that slot but keeps '
        'the rest', () async {
      final cache = InMemorySecureCache();
      final store = DirectKeypairStore(cache: cache);
      final ek = await store.generateEphemeral();

      final id = await store.promoteEphemeral(
        deviceId: 'dev_no_nonce',
        ephemeral: ek,
        // serverNonce intentionally omitted
      );
      expect(id.serverNonce, isNull);
      expect(await cache.getRaw(kDirectServerNonceKey), isNull);
      expect(await cache.getRaw(kDirectDeviceIdKey), equals('dev_no_nonce'));
    });

    test('loadDurable after restart returns byte-identical bytes', () async {
      final cache = InMemorySecureCache();
      final store1 = DirectKeypairStore(cache: cache);
      final ek = await store1.generateEphemeral();
      await store1.promoteEphemeral(
        deviceId: 'dev_persist',
        ephemeral: ek,
        serverNonce: 'srv',
      );

      // Simulate process restart — fresh store, same cache backing.
      final store2 = DirectKeypairStore(cache: cache);
      final loaded = await store2.loadDurable();
      expect(loaded, isNotNull);
      expect(loaded!.deviceId, equals('dev_persist'));
      expect(loaded.x25519Priv, equals(ek.x25519Priv),
          reason: 'X25519 priv must survive restart byte-for-byte');
      expect(loaded.x25519Pub, equals(ek.x25519Pub));
      expect(loaded.ed25519Priv, equals(ek.ed25519Priv));
      expect(loaded.ed25519Pub, equals(ek.ed25519Pub));
      expect(loaded.serverNonce, equals('srv'));
    });

    test('updateServerNonce replaces just the nonce slot', () async {
      final cache = InMemorySecureCache();
      final store = DirectKeypairStore(cache: cache);
      final ek = await store.generateEphemeral();
      await store.promoteEphemeral(
        deviceId: 'd',
        ephemeral: ek,
        serverNonce: 'old',
      );

      await store.updateServerNonce('new');

      expect(await cache.getRaw(kDirectServerNonceKey), equals('new'));
      // device id intact.
      expect(await cache.getRaw(kDirectDeviceIdKey), equals('d'));
    });
  });

  group('DirectKeypairStore — clear', () {
    test('clear() wipes every FRON slot', () async {
      final cache = InMemorySecureCache();
      final store = DirectKeypairStore(cache: cache);
      final ek = await store.generateEphemeral();
      await store.promoteEphemeral(
        deviceId: 'd',
        ephemeral: ek,
        serverNonce: 'n',
      );

      await store.clear();

      expect(await cache.getRaw(kDirectDeviceIdKey), isNull);
      expect(await cache.getRaw(kDirectDurableX25519PrivKey), isNull);
      expect(await cache.getRaw(kDirectDurableX25519PubKey), isNull);
      expect(await cache.getRaw(kDirectDurableEd25519PrivKey), isNull);
      expect(await cache.getRaw(kDirectDurableEd25519PubKey), isNull);
      expect(await cache.getRaw(kDirectServerNonceKey), isNull);
      expect(await store.loadDurable(), isNull);
    });
  });
}
