// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// W6 — FRON payment surface: `openPortal` end-to-end tests.
///
/// Exercises the `DirectClient.openPortal` extension against the shared
/// `FakeBifrostDirectServer`. Covers:
///   * happy-path portal-session minting + wire body shape
///   * client-side validation (non-https returnUrl, oversize returnUrl,
///     empty returnUrl, javascript: scheme)
///   * server-side error envelopes (no active subscription, provider
///     failure, rate limit)
///   * security guardrails (plaintext error rejected; project_id pinned
///     in body alongside top-level claim)
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' as c;
import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_client.dart';
import 'package:vanaheim/src/direct/direct_config.dart';
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/direct/direct_models.dart';
import 'package:vanaheim/src/direct/direct_payment_methods.dart';
import 'package:vanaheim/src/direct/direct_payment_models.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

import '_fake_bifrost_direct.dart';

void main() {
  late FakeBifrostDirectServer server;
  late InMemorySecureCache cache;

  DirectConfig cfg() => DirectConfig(
        bifrostBaseUrl: Uri.parse('https://bifrost.test'),
        projectId: 'proj_main',
        initialHeartbeatCadence: const Duration(hours: 1),
        statsFlushInterval: const Duration(hours: 1),
      );

  Future<void> seedDurableIdentity() async {
    final xkp = await c.X25519().newKeyPair();
    final xPub = await xkp.extractPublicKey();
    final xPriv = await xkp.extractPrivateKeyBytes();
    final edkp = ed25519.generateKey();
    String b64(Uint8List b) => base64Url.encode(b).replaceAll('=', '');
    await cache.putRaw(kDirectDeviceIdKey, 'dev_pre_seeded');
    await cache.putRaw(kDirectDurableX25519PrivKey, b64(Uint8List.fromList(xPriv)));
    await cache.putRaw(kDirectDurableX25519PubKey, b64(Uint8List.fromList(xPub.bytes)));
    await cache.putRaw(kDirectDurableEd25519PrivKey, b64(Uint8List.fromList(edkp.privateKey.bytes)));
    await cache.putRaw(kDirectDurableEd25519PubKey, b64(Uint8List.fromList(edkp.publicKey.bytes)));
    await cache.putRaw(kDirectServerNonceKey, 'srv-seeded');
    server.clientX25519Pub = Uint8List.fromList(xPub.bytes);
  }

  Future<DirectClient> connected() async {
    await seedDurableIdentity();
    return DirectClient.connect(
      config: cfg(),
      cache: cache,
      httpClient: server.httpClient(),
    );
  }

  setUp(() async {
    server = await FakeBifrostDirectServer.create();
    cache = InMemorySecureCache();
    server.responses['/direct/v1/payment/portal'] = const FakeResponseSpec(
      claims: {
        'portal_url': 'https://billing.example/portal/abc',
        'expires_at_ms': 1900000000000,
      },
    );
    ensureDirectPaymentErrorsRegistered();
  });

  group('openPortal — happy paths', () {
    test('returns PortalSession parsed from the server response', () async {
      final client = await connected();
      final portal = await client.openPortal(
        returnUrl: 'https://app.example/back',
      );
      expect(portal.portalUrl, equals('https://billing.example/portal/abc'));
      expect(portal.expiresAtMs, equals(1900000000000));
      await client.dispose();
    });

    test('wire body carries project_id + return_url at the body level',
        () async {
      final client = await connected();
      await client.openPortal(returnUrl: 'https://app.example/back');
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/portal')
          .toList();
      expect(reqs, hasLength(1));
      final body = (reqs.first.jwsClaims['body'] as Map).cast<String, dynamic>();
      expect(body['project_id'], equals('proj_main'));
      expect(body['return_url'], equals('https://app.example/back'));
      // Top-level claim must also carry project_id (cross-project guard).
      expect(reqs.first.jwsClaims['project_id'], equals('proj_main'));
      await client.dispose();
    });
  });

  group('openPortal — client-side validation', () {
    test('non-https returnUrl is rejected client-side (no wire hit)', () async {
      final client = await connected();
      await expectLater(
        client.openPortal(returnUrl: 'http://insecure.example/back'),
        throwsA(isA<DirectBadRequestError>()),
      );
      expect(
        server.requests
            .where((r) => r.routePath == '/direct/v1/payment/portal')
            .length,
        equals(0),
        reason: 'pre-check must short-circuit before wire',
      );
      await client.dispose();
    });

    test('empty returnUrl is rejected', () async {
      final client = await connected();
      await expectLater(
        client.openPortal(returnUrl: ''),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('returnUrl longer than 2048 chars is rejected', () async {
      final client = await connected();
      await expectLater(
        client.openPortal(returnUrl: 'https://app.example/${'b' * 3000}'),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('javascript: scheme returnUrl is rejected client-side', () async {
      final client = await connected();
      await expectLater(
        client.openPortal(returnUrl: 'javascript:alert(1)'),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });
  });

  group('openPortal — server error envelopes', () {
    test('DIRECT_NO_ACTIVE_SUBSCRIPTION → DirectNoActiveSubscriptionError',
        () async {
      server.responses['/direct/v1/payment/portal'] = const FakeResponseSpec(
        statusCode: 409,
        claims: {
          'code': 'DIRECT_NO_ACTIVE_SUBSCRIPTION',
          'message': 'no active sub',
        },
      );
      final client = await connected();
      await expectLater(
        client.openPortal(returnUrl: 'https://app.example/back'),
        throwsA(isA<DirectNoActiveSubscriptionError>()),
      );
      await client.dispose();
    });

    test('DIRECT_PAYMENT_PROVIDER_FAILED on portal surfaces provider error',
        () async {
      server.responses['/direct/v1/payment/portal'] = const FakeResponseSpec(
        statusCode: 502,
        claims: {
          'code': 'DIRECT_PAYMENT_PROVIDER_FAILED',
          'message': 'stripe',
        },
      );
      final client = await connected();
      await expectLater(
        client.openPortal(returnUrl: 'https://app.example/back'),
        throwsA(isA<DirectPaymentProviderFailedError>()),
      );
      await client.dispose();
    });

    test('DIRECT_RATE_LIMITED on portal surfaces DirectRateLimitError',
        () async {
      server.responses['/direct/v1/payment/portal'] = const FakeResponseSpec(
        statusCode: 429,
        claims: {
          'code': 'DIRECT_RATE_LIMITED',
          'retry_after_ms': 3000,
        },
      );
      final client = await connected();
      try {
        await client.openPortal(returnUrl: 'https://app.example/back');
        fail('expected DirectRateLimitError');
      } on DirectRateLimitError catch (e) {
        expect(e.retryAfterMs, equals(3000));
      }
      await client.dispose();
    });
  });

  group('openPortal — security guardrails', () {
    test('plaintext error body NEVER triggers DirectNoActiveSubscriptionError '
        '— forged plaintext has no authority', () async {
      server.responses['/direct/v1/payment/portal'] = const FakeResponseSpec(
        statusCode: 503,
        rawBody: '{"code":"DIRECT_NO_ACTIVE_SUBSCRIPTION","message":"forged"}',
      );
      final client = await connected();
      await expectLater(
        client.openPortal(returnUrl: 'https://app.example/back'),
        throwsA(isA<NetworkException>()),
      );
      await client.dispose();
    });

    test('openPortal before connect (no durable identity) raises '
        'NotConnectedException — no portal_url leak path on unregistered devs',
        () async {
      // Note: this group bypasses the seed; we want a fresh, unregistered
      // client to confirm openPortal pre-condition.
      final freshCache = InMemorySecureCache();
      final freshServer = await FakeBifrostDirectServer.create();
      final client = await DirectClient.connect(
        config: cfg(),
        cache: freshCache,
        httpClient: freshServer.httpClient(),
      );
      await expectLater(
        client.openPortal(returnUrl: 'https://app.example/back'),
        throwsA(isA<NotConnectedException>()),
      );
      await client.dispose();
    });
  });

  // D-Fix 4 regression — aud namespace convergence (B-Fix 2).
  group('openPortal — aud namespace (D-Fix 4)', () {
    test('inner JWS aud claim is direct:payment.portal', () async {
      final client = await connected();
      await client.openPortal(returnUrl: 'https://app.example/back');
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/portal')
          .toList();
      expect(reqs, hasLength(1));
      expect(reqs.first.jwsClaims['aud'], equals(kDirectAudPaymentPortal));
      expect(kDirectAudPaymentPortal, equals('direct:payment.portal'));
      await client.dispose();
    });
  });
}
