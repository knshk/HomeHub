// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Tests for `DirectResponseParser` — outer-JWE decrypt + inner-Ed25519-JWS
/// verify + typed error mapping on non-2xx envelopes.
///
/// We mint server-side envelopes through the fake Bifrost server's
/// signing/recipient keypair so the assertions exercise the real
/// `JweCodec` + Ed25519 verify path end-to-end.
library;

import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/direct/direct_models.dart';
import 'package:vanaheim/src/direct/direct_request_builder.dart';
import 'package:vanaheim/src/direct/direct_response_parser.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

import '_fake_bifrost_direct.dart';

void main() {
  late FakeBifrostDirectServer server;
  late DirectKeypairStore store;

  setUpAll(() async {
    server = await FakeBifrostDirectServer.create();
  });

  setUp(() {
    store = DirectKeypairStore(cache: InMemorySecureCache());
  });

  group('DirectResponseParser — 2xx happy path', () {
    test('round-trips an inner-JWS response and exposes its claims',
        () async {
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'req-1',
        body: const {'license_key': 'L', 'fingerprint': 'f'},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );

      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        statusCode: 200,
      );
      final http.Response res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'req-1');

      final parsed = await DirectResponseParser().parseResponse(
        response: res,
        identity: null,
        ephemeralX25519Priv: ephemeral.x25519Priv,
        keySet: server.keySet(),
        expectedRequestId: 'req-1',
        expectedRoutePath: '/direct/v1/register',
      );
      expect(parsed.claims['device_id'], isNotEmpty);
      expect(parsed.claims['entitlement_jws'], isA<String>());
      expect(parsed.kid, equals(server.signingKid));
    });

    test('round-trips with a durable identity (no ephemeral key needed)',
        () async {
      final ephemeral = await store.generateEphemeral();
      final id = await store.promoteEphemeral(
        deviceId: 'd',
        ephemeral: ephemeral,
      );
      server.clientX25519Pub = id.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildDurable(
        routePath: '/direct/v1/verify',
        requestId: 'r',
        body: const {},
        identity: id,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/verify'] = const FakeResponseSpec(claims: {
        'entitlement_jws': 'placeholder',
        'issued_at_ms': 1700000000000,
      });
      final res = await _post(server, env.compactJwe, '/direct/v1/verify', 'r');

      final parsed = await DirectResponseParser().parseResponse(
        response: res,
        identity: id,
        ephemeralX25519Priv: null,
        keySet: server.keySet(),
        expectedRequestId: 'r',
        expectedRoutePath: '/direct/v1/verify',
      );
      expect(parsed.claims, isNotEmpty);
      expect(parsed.kid, equals(server.signingKid));
    });
  });

  group('DirectResponseParser — envelope pinning', () {
    test('rejects an envelope with the wrong outer typ', () async {
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'r',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        outerTypOverride: 'lcs+jwe', // L2-style envelope replayed onto FRON
      );
      final res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'r');

      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: ephemeral.x25519Priv,
          keySet: server.keySet(),
          expectedRequestId: 'r',
          expectedRoutePath: '/direct/v1/register',
        ),
        throwsA(isA<LicenseStoreException>().having(
            (e) => e.message, 'message', contains('typ mismatch'))),
      );
    });

    test('rejects an envelope with the wrong lcs_v', () async {
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'r2',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        outerLcsVOverride: 99,
      );
      final res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'r2');

      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: ephemeral.x25519Priv,
          keySet: server.keySet(),
          expectedRequestId: 'r2',
          expectedRoutePath: '/direct/v1/register',
        ),
        throwsA(isA<LicenseStoreException>().having(
            (e) => e.message, 'message', contains('lcs_v mismatch'))),
      );
    });

    test('rejects an envelope with a route mismatch', () async {
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'r3',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        outerRoutePathOverride: '/direct/v1/heartbeat', // mismatched
      );
      final res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'r3');

      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: ephemeral.x25519Priv,
          keySet: server.keySet(),
          expectedRequestId: 'r3',
          expectedRoutePath: '/direct/v1/register',
        ),
        throwsA(isA<LicenseStoreException>().having(
            (e) => e.message, 'message', contains('route mismatch'))),
      );
    });

    test('rejects an envelope with a request_id mismatch', () async {
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'r4',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        outerRequestIdOverride: 'WRONG-ID',
      );
      final res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'r4');

      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: ephemeral.x25519Priv,
          keySet: server.keySet(),
          expectedRequestId: 'r4',
          expectedRoutePath: '/direct/v1/register',
        ),
        throwsA(isA<LicenseStoreException>().having(
            (e) => e.message, 'message', contains('request_id mismatch'))),
      );
    });
  });

  group('DirectResponseParser — error envelopes', () {
    test('JWE-wrapped error code maps to the typed DirectError', () async {
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'r-err',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        statusCode: 400,
        claims: {
          'code': 'DIRECT_LICENSE_INVALID',
          'message': 'bad license',
        },
      );
      final res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'r-err');

      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: ephemeral.x25519Priv,
          keySet: server.keySet(),
          expectedRequestId: 'r-err',
          expectedRoutePath: '/direct/v1/register',
        ),
        throwsA(isA<DirectLicenseInvalidError>()),
      );
    });

    test('plaintext error JSON is NEVER mapped to a typed DirectError '
        '(security: only authenticated JWE-wrapped errors may drive '
        'destructive state transitions like keypair wipe)', () async {
      // Status >= 400 + body that isn't a 5-segment JWE → MUST surface
      // as NetworkException. A network proxy / MITM can trivially
      // synthesize {"code":"DIRECT_DEVICE_REVOKED"} as a plaintext HTTP
      // response; honouring it would let the attacker force-wipe the
      // SDK's keypair without ever speaking real FRON.
      final res = http.Response(
        '{"code":"DIRECT_DEVICE_REVOKED"}',
        503,
        headers: {'content-type': 'application/json'},
      );
      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: Uint8List(32),
          keySet: server.keySet(),
          expectedRequestId: 'rid',
          expectedRoutePath: '/direct/v1/verify',
        ),
        throwsA(isA<NetworkException>()),
      );
    });

    test('5xx with no parseable body throws NetworkException', () async {
      final res = http.Response('<html>oops</html>', 502);
      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: Uint8List(32),
          keySet: server.keySet(),
          expectedRequestId: 'rid',
          expectedRoutePath: '/direct/v1/verify',
        ),
        throwsA(isA<NetworkException>()),
      );
    });
  });

  // ─────────────────────────────────────────────────────────────────────
  // D-Fix 1 regression — sealed-error envelope round-trip.
  //
  // Verifies the parser handles the post-B-Fix 1 sealed-error wire
  // shape: success and failure share the same JWE+JWS envelope; failures
  // surface under an `error` claim instead of a top-level `code` field.
  // The reason + provider fields must round-trip into the typed
  // DirectError subclass so the host UX can fork on them.
  // ─────────────────────────────────────────────────────────────────────

  group('DirectResponseParser — sealed-error envelope (D-Fix 1)', () {
    test('error claim with code maps to typed DirectError on a 2xx wrapper '
        '(the wire is authoritative, not the HTTP status)', () async {
      // The server can wrap an error inside a 200 envelope — an upstream
      // proxy CAN flip the HTTP status freely, but it cannot forge the
      // inner Ed25519 signature. The parser must honour the sealed
      // error regardless of the visible status code.
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'r-sealed-200',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        statusCode: 200,
        claims: {
          'error': {
            'code': 'DIRECT_LICENSE_INVALID',
            'message': 'bad license (sealed)',
          },
        },
      );
      final res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'r-sealed-200');

      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: ephemeral.x25519Priv,
          keySet: server.keySet(),
          expectedRequestId: 'r-sealed-200',
          expectedRoutePath: '/direct/v1/register',
        ),
        throwsA(isA<DirectLicenseInvalidError>()),
      );
    });

    test('sealed error round-trips retry_after_ms into DirectRateLimitError',
        () async {
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'r-sealed-429',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        statusCode: 429,
        claims: {
          'error': {
            'code': 'DIRECT_RATE_LIMITED',
            'retry_after_ms': 4200,
            'message': 'too many',
          },
        },
      );
      final res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'r-sealed-429');

      try {
        await DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: ephemeral.x25519Priv,
          keySet: server.keySet(),
          expectedRequestId: 'r-sealed-429',
          expectedRoutePath: '/direct/v1/register',
        );
        fail('expected DirectRateLimitError');
      } on DirectRateLimitError catch (e) {
        expect(e.retryAfterMs, equals(4200),
            reason: 'sealed-error retry_after_ms must round-trip into the '
                'typed DirectRateLimitError so the SDK retry classifier '
                'paces correctly');
      }
    });

    test('sealed error with malformed envelope (missing code) refuses '
        'rather than falling open', () async {
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'r-sealed-bad',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        statusCode: 200,
        claims: {
          'error': {
            // missing `code` field
            'message': 'something is wrong',
          },
        },
      );
      final res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'r-sealed-bad');

      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: ephemeral.x25519Priv,
          keySet: server.keySet(),
          expectedRequestId: 'r-sealed-bad',
          expectedRoutePath: '/direct/v1/register',
        ),
        throwsA(isA<LicenseStoreException>().having(
            (e) => e.message,
            'message',
            contains('sealed-error envelope missing usable code'))),
        reason: 'a sealed error whose inner code is missing MUST refuse — '
            'never quietly treat a malformed error as success',
      );
    });

    test('malformed sealed error (error claim is a string) is rejected '
        'rather than mistaken for the success path', () async {
      // The fake server only wraps `error` into the envelope when the
      // spec.claims already carries an `error` key. To force a
      // non-dict `error` we mint the response directly via the
      // FakeResponseSpec.claims `error` field — _wrapEnvelope honours
      // the shape and copies it verbatim.
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'r-sealed-string',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        statusCode: 200,
        claims: {
          'error': 'oops not a dict',
        },
      );
      final res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'r-sealed-string');

      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: ephemeral.x25519Priv,
          keySet: server.keySet(),
          expectedRequestId: 'r-sealed-string',
          expectedRoutePath: '/direct/v1/register',
        ),
        throwsA(isA<LicenseStoreException>().having(
            (e) => e.message,
            'message',
            contains('error claim must be a dict'))),
        reason: 'sealed-error envelope with non-dict error claim MUST '
            'refuse — never fall through to the success path on a '
            'malformed shape (D-Fix 2 of W6 fix-pass-2)',
      );
    });
  });

  // ─────────────────────────────────────────────────────────────────────
  // D-Fix 1 regression — success-path `payload` unwrap.
  //
  // Post W6 fix-pass-2 the Bifrost response envelope is:
  //   { iat, nbf, exp, iss, aud, payload: { ...successBody } }
  // (or `error: {...}` on the failure path). Older versions of the
  // SDK consumed the OUTER claims map verbatim — which silently broke
  // every call site that looked up business fields at the top level
  // (e.g. `claims['device_id']`, `claims['entitlement_jws']`,
  // `claims['heartbeat_cadence_ms']`).
  //
  // These tests pin the unwrap: the parser MUST return
  // `envelopeClaims['payload']` as `claims` so callers can keep using
  // `parsed.claims[...]` unchanged.
  // ─────────────────────────────────────────────────────────────────────

  group('DirectResponseParser — payload unwrap (D-Fix 1)', () {
    test('parsed.claims is the unwrapped payload, not the envelope', () async {
      final ephemeral = await store.generateEphemeral();
      final id = await store.promoteEphemeral(
        deviceId: 'd',
        ephemeral: ephemeral,
      );
      server.clientX25519Pub = id.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildDurable(
        routePath: '/direct/v1/verify',
        requestId: 'r-unwrap',
        body: const {},
        identity: id,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/verify'] = const FakeResponseSpec(claims: {
        'entitlement_jws': 'ent_jws_value',
        'issued_at_ms': 1700000000000,
        'heartbeat_cadence_ms': 3600000,
      });
      final res = await _post(server, env.compactJwe,
          '/direct/v1/verify', 'r-unwrap');

      final parsed = await DirectResponseParser().parseResponse(
        response: res,
        identity: id,
        ephemeralX25519Priv: null,
        keySet: server.keySet(),
        expectedRequestId: 'r-unwrap',
        expectedRoutePath: '/direct/v1/verify',
      );

      // The result body MUST be the inner `payload`, not the outer
      // envelope. Concretely: `parsed.claims` carries the business
      // fields (entitlement_jws, issued_at_ms, …) and DOES NOT carry
      // the envelope plumbing (iss, aud, payload).
      expect(parsed.claims['entitlement_jws'], equals('ent_jws_value'),
          reason: 'parser must unwrap envelope.payload so callers can keep '
              'reading business fields at parsed.claims top level');
      expect(parsed.claims['issued_at_ms'], equals(1700000000000));
      expect(parsed.claims['heartbeat_cadence_ms'], equals(3600000));
      expect(parsed.claims.containsKey('payload'), isFalse,
          reason: 'claims is the unwrapped payload — must not contain '
              'an inner `payload` key');
      expect(parsed.claims.containsKey('iss'), isFalse,
          reason: 'envelope-level claims (iss/aud) must not leak into '
              'parsed.claims');

      // Envelope-level claims remain inspectable via envelopeClaims.
      expect(parsed.envelopeClaims['iss'], equals('bifrost-direct'));
      expect(parsed.envelopeClaims['aud'], equals('/direct/v1/verify'));
      expect(parsed.envelopeClaims['payload'], isA<Map<String, dynamic>>(),
          reason: 'envelopeClaims preserves the full envelope for the '
              'rare caller that wants to cross-check iat/aud/etc.');
    });

    test('error claim takes precedence over payload (mutually exclusive on '
        'a well-formed envelope, but if both appear the error wins)', () async {
      // Construct a scenario where the spec.claims carries an `error`
      // key — the fake server's _wrapEnvelope branches on that and
      // emits a sealed-error envelope. The parser MUST throw the
      // typed DirectError without ever touching the payload path.
      final ephemeral = await store.generateEphemeral();
      server.clientX25519Pub = ephemeral.x25519Pub;
      final env = await const DirectRequestBuilder(projectId: 'p')
          .buildEphemeral(
        routePath: '/direct/v1/register',
        requestId: 'r-err-wins',
        body: const {},
        ephemeral: ephemeral,
        recipient: server.keySet().activeRecipient,
      );
      server.responses['/direct/v1/register'] = const FakeResponseSpec(
        statusCode: 200,
        claims: {
          'error': {
            'code': 'DIRECT_DEVICE_REVOKED',
          },
        },
      );
      final res = await _post(server, env.compactJwe,
          '/direct/v1/register', 'r-err-wins');

      await expectLater(
        DirectResponseParser().parseResponse(
          response: res,
          identity: null,
          ephemeralX25519Priv: ephemeral.x25519Priv,
          keySet: server.keySet(),
          expectedRequestId: 'r-err-wins',
          expectedRoutePath: '/direct/v1/register',
        ),
        throwsA(isA<DirectDeviceRevokedError>()),
        reason: 'error claim MUST be checked before payload — the parser '
            'must never honour the payload path when an authenticated '
            'error envelope is present',
      );
    });
  });
}

Future<http.Response> _post(
  FakeBifrostDirectServer server,
  String compact,
  String path,
  String requestId,
) async {
  final client = server.httpClient();
  try {
    return await client.post(
      Uri.parse('https://bifrost.test$path'),
      headers: {
        'X-LS-Request-Id': requestId,
        'Content-Type': 'application/jose+json',
      },
      body: compact,
    );
  } finally {
    client.close();
  }
}
