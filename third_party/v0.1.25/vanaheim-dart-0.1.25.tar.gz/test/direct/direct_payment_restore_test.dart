// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// W6 — FRON payment surface: `restorePurchases` end-to-end tests.
///
/// Exercises the `DirectClient.restorePurchases` extension against the
/// shared `FakeBifrostDirectServer`. Covers:
///   * happy paths (empty restore list, single-row restore, multi-row
///     restore — the SDK adopts the minted entitlement_jws automatically)
///   * client-side validation (invalid platform, web platform rejected)
///   * server-side error envelopes (provider failure, rate limit,
///     project disabled)
///   * security guardrails (100-row cap on parsed list defends against
///     a malicious / buggy server; plaintext error rejected)
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' as c;
import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_client.dart';
import 'package:vanaheim/src/direct/direct_config.dart';
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/direct/direct_models.dart';
import 'package:vanaheim/src/direct/direct_payment_methods.dart';
import 'package:vanaheim/src/direct/direct_payment_models.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

import '_fake_bifrost_direct.dart';

/// Synthesize a minimal entitlement JWS the DirectClient can decode.
/// The SDK only reads the claims segment (the outer JWS that carried
/// this string IS the trust root); the signature can be any byte string.
String _entitlementJws({required String tier, required bool export}) {
  String b64(String s) => base64Url.encode(utf8.encode(s)).replaceAll('=', '');
  final header = b64(jsonEncode({
    'alg': 'EdDSA',
    'typ': 'bifrost-direct+entitlement+jws',
  }));
  final claims = b64(jsonEncode({
    'tier': tier,
    'version': 1,
    'features': {'export': export},
    'quotas': {'max_seats': 5},
  }));
  return '$header.$claims.sig';
}

void main() {
  late FakeBifrostDirectServer server;
  late InMemorySecureCache cache;

  DirectConfig cfg() => DirectConfig(
        bifrostBaseUrl: Uri.parse('https://bifrost.test'),
        projectId: 'proj_main',
        initialHeartbeatCadence: const Duration(hours: 1),
        statsFlushInterval: const Duration(hours: 1),
      );

  Future<void> seedDurableIdentity() async {
    final xkp = await c.X25519().newKeyPair();
    final xPub = await xkp.extractPublicKey();
    final xPriv = await xkp.extractPrivateKeyBytes();
    final edkp = ed25519.generateKey();
    String b64(Uint8List b) => base64Url.encode(b).replaceAll('=', '');
    await cache.putRaw(kDirectDeviceIdKey, 'dev_pre_seeded');
    await cache.putRaw(kDirectDurableX25519PrivKey, b64(Uint8List.fromList(xPriv)));
    await cache.putRaw(kDirectDurableX25519PubKey, b64(Uint8List.fromList(xPub.bytes)));
    await cache.putRaw(kDirectDurableEd25519PrivKey, b64(Uint8List.fromList(edkp.privateKey.bytes)));
    await cache.putRaw(kDirectDurableEd25519PubKey, b64(Uint8List.fromList(edkp.publicKey.bytes)));
    await cache.putRaw(kDirectServerNonceKey, 'srv-seeded');
    server.clientX25519Pub = Uint8List.fromList(xPub.bytes);
  }

  Future<DirectClient> connected() async {
    await seedDurableIdentity();
    return DirectClient.connect(
      config: cfg(),
      cache: cache,
      httpClient: server.httpClient(),
    );
  }

  setUp(() async {
    server = await FakeBifrostDirectServer.create();
    cache = InMemorySecureCache();
    // Default: empty restore list.
    server.responses['/direct/v1/payment/restore'] = const FakeResponseSpec(
      claims: {
        'restored': [],
        'restored_count': 0,
      },
    );
    ensureDirectPaymentErrorsRegistered();
  });

  group('restorePurchases — happy paths', () {
    test('empty result returns empty list, null entitlementJws, count=0',
        () async {
      final client = await connected();
      final r = await client.restorePurchases(platform: 'ios');
      expect(r.restored, isEmpty);
      expect(r.entitlementJws, isNull);
      expect(r.restoredCount, equals(0));
      // SDK should NOT adopt an entitlement on empty restore.
      expect(client.entitlements, isNull,
          reason: 'empty restore must not mint entitlements');
      await client.dispose();
    });

    test('non-empty restore mints entitlement_jws + SDK adopts it', () async {
      final ent = _entitlementJws(tier: 'pro', export: true);
      server.responses['/direct/v1/payment/restore'] = FakeResponseSpec(
        claims: {
          'restored': [
            {
              'license_key': 'LIC-RESTORED-001',
              'tier': 'pro',
              'valid_until': 1900000000000,
            },
          ],
          'restored_count': 1,
          'entitlement_jws': ent,
        },
      );
      final client = await connected();
      final r = await client.restorePurchases(platform: 'ios');
      expect(r.restored, hasLength(1));
      expect(r.restored.first.licenseKey, equals('LIC-RESTORED-001'));
      expect(r.restored.first.tier, equals('pro'));
      expect(r.restored.first.validUntil, equals(1900000000000));
      expect(r.restoredCount, equals(1));
      expect(r.entitlementJws, equals(ent));
      // Critical: SDK must adopt the entitlement so subsequent hasFeature
      // reflects the restored tier immediately.
      expect(client.entitlements?.tier, equals('pro'));
      expect(client.hasFeature('export'), isTrue);
      await client.dispose();
    });

    test('multi-row restore preserves order + per-row fields', () async {
      final ent = _entitlementJws(tier: 'enterprise', export: true);
      server.responses['/direct/v1/payment/restore'] = FakeResponseSpec(
        claims: {
          'restored': [
            {'license_key': 'L1', 'tier': 'pro', 'valid_until': 1700000000000},
            {'license_key': 'L2', 'tier': 'pro_yearly', 'valid_until': 1800000000000},
            {'license_key': 'L3', 'tier': 'enterprise', 'valid_until': 1900000000000},
          ],
          'restored_count': 3,
          'entitlement_jws': ent,
        },
      );
      final client = await connected();
      final r = await client.restorePurchases(platform: 'android');
      expect(r.restored, hasLength(3));
      expect(r.restored.map((p) => p.licenseKey).toList(),
          equals(['L1', 'L2', 'L3']));
      expect(r.restoredCount, equals(3));
      await client.dispose();
    });
  });

  group('restorePurchases — client-side validation', () {
    test('invalid platform (windows) is rejected client-side', () async {
      final client = await connected();
      await expectLater(
        client.restorePurchases(platform: 'windows'),
        throwsA(isA<DirectBadRequestError>()),
      );
      expect(
        server.requests
            .where((r) => r.routePath == '/direct/v1/payment/restore')
            .length,
        equals(0),
      );
      await client.dispose();
    });

    test('web platform is rejected on restore (only ios|android allowed)',
        () async {
      final client = await connected();
      await expectLater(
        client.restorePurchases(platform: 'web'),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('empty platform is rejected', () async {
      final client = await connected();
      await expectLater(
        client.restorePurchases(platform: ''),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });
  });

  group('restorePurchases — server error envelopes', () {
    test('DIRECT_PAYMENT_PROVIDER_FAILED surfaces typed provider error',
        () async {
      server.responses['/direct/v1/payment/restore'] = const FakeResponseSpec(
        statusCode: 502,
        claims: {
          'code': 'DIRECT_PAYMENT_PROVIDER_FAILED',
          'message': 'restore',
        },
      );
      final client = await connected();
      await expectLater(
        client.restorePurchases(platform: 'ios'),
        throwsA(isA<DirectPaymentProviderFailedError>()),
      );
      await client.dispose();
    });

    test('DIRECT_RATE_LIMITED surfaces DirectRateLimitError', () async {
      server.responses['/direct/v1/payment/restore'] = const FakeResponseSpec(
        statusCode: 429,
        claims: {
          'code': 'DIRECT_RATE_LIMITED',
          'retry_after_ms': 5000,
        },
      );
      final client = await connected();
      try {
        await client.restorePurchases(platform: 'ios');
        fail('expected DirectRateLimitError');
      } on DirectRateLimitError catch (e) {
        expect(e.retryAfterMs, equals(5000));
      }
      await client.dispose();
    });

    test('DIRECT_PROJECT_DISABLED surfaces typed exception', () async {
      server.responses['/direct/v1/payment/restore'] = const FakeResponseSpec(
        statusCode: 403,
        claims: {
          'code': 'DIRECT_PROJECT_DISABLED',
        },
      );
      final client = await connected();
      await expectLater(
        client.restorePurchases(platform: 'ios'),
        throwsA(isA<DirectProjectDisabledError>()),
      );
      await client.dispose();
    });
  });

  group('restorePurchases — security guardrails', () {
    test('parsed restored list is capped at 100 rows (defence-in-depth '
        'against a malicious / buggy server)', () async {
      // Build a malicious server response with 500 rows.
      final huge = List<Map<String, dynamic>>.generate(
        500,
        (i) => {
          'license_key': 'LIC-$i',
          'tier': 'pro',
          'valid_until': 1900000000000,
        },
      );
      final ent = _entitlementJws(tier: 'pro', export: true);
      server.responses['/direct/v1/payment/restore'] = FakeResponseSpec(
        claims: {
          'restored': huge,
          'restored_count': 500,
          'entitlement_jws': ent,
        },
      );
      final client = await connected();
      final r = await client.restorePurchases(platform: 'ios');
      expect(r.restored, hasLength(kRestorePurchasesMaxRows),
          reason: 'SDK must cap the parsed list at $kRestorePurchasesMaxRows '
              'rows so an unbounded server response cannot OOM the SDK');
      expect(r.restored.length, equals(100));
      await client.dispose();
    });

    test('plaintext error body NEVER triggers a typed restore error',
        () async {
      server.responses['/direct/v1/payment/restore'] = const FakeResponseSpec(
        statusCode: 503,
        rawBody: '{"code":"DIRECT_PAYMENT_PROVIDER_FAILED","message":"forged"}',
      );
      final client = await connected();
      await expectLater(
        client.restorePurchases(platform: 'ios'),
        throwsA(isA<NetworkException>()),
      );
      // Entitlements (none) must remain untouched.
      expect(client.entitlements, isNull);
      await client.dispose();
    });
  });

  // D-Fix 4 regression — aud namespace convergence (B-Fix 2).
  group('restorePurchases — aud namespace (D-Fix 4)', () {
    test('inner JWS aud claim is direct:payment.restore', () async {
      final client = await connected();
      await client.restorePurchases(platform: 'ios');
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/restore')
          .toList();
      expect(reqs, hasLength(1));
      expect(reqs.first.jwsClaims['aud'], equals(kDirectAudPaymentRestore));
      expect(kDirectAudPaymentRestore, equals('direct:payment.restore'));
      await client.dispose();
    });
  });
}
