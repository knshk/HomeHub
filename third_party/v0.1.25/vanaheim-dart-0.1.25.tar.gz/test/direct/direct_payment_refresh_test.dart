// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// W6 — FRON payment surface: `refreshAfterPayment` end-to-end tests.
///
/// Exercises the `DirectClient.refreshAfterPayment` extension against the
/// shared `FakeBifrostDirectServer`. Covers:
///   * happy paths (with sessionId echoed back; without sessionId acts
///     like /verify; refreshed_at_ms preferred over issued_at_ms)
///   * client-side / response-shape validation (missing entitlement_jws
///     → LicenseStoreException; not registered → NotConnectedException)
///   * server-side error envelopes (session not found, session not
///     complete, rate limited, provider failure)
///   * security guardrails (plaintext error not trusted; refresh
///     adopts the new entitlement immediately so hasFeature reflects)
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' as c;
import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_client.dart';
import 'package:vanaheim/src/direct/direct_config.dart';
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/direct/direct_models.dart';
import 'package:vanaheim/src/direct/direct_payment_methods.dart';
import 'package:vanaheim/src/direct/direct_payment_models.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

import '_fake_bifrost_direct.dart';

String _entitlementJws({required String tier, required bool export}) {
  String b64(String s) => base64Url.encode(utf8.encode(s)).replaceAll('=', '');
  final header = b64(jsonEncode({
    'alg': 'EdDSA',
    'typ': 'bifrost-direct+entitlement+jws',
  }));
  final claims = b64(jsonEncode({
    'tier': tier,
    'version': 1,
    'features': {'export': export},
    'quotas': {'max_seats': 5},
  }));
  return '$header.$claims.sig';
}

void main() {
  late FakeBifrostDirectServer server;
  late InMemorySecureCache cache;

  DirectConfig cfg() => DirectConfig(
        bifrostBaseUrl: Uri.parse('https://bifrost.test'),
        projectId: 'proj_main',
        initialHeartbeatCadence: const Duration(hours: 1),
        statsFlushInterval: const Duration(hours: 1),
      );

  Future<void> seedDurableIdentity() async {
    final xkp = await c.X25519().newKeyPair();
    final xPub = await xkp.extractPublicKey();
    final xPriv = await xkp.extractPrivateKeyBytes();
    final edkp = ed25519.generateKey();
    String b64(Uint8List b) => base64Url.encode(b).replaceAll('=', '');
    await cache.putRaw(kDirectDeviceIdKey, 'dev_pre_seeded');
    await cache.putRaw(kDirectDurableX25519PrivKey, b64(Uint8List.fromList(xPriv)));
    await cache.putRaw(kDirectDurableX25519PubKey, b64(Uint8List.fromList(xPub.bytes)));
    await cache.putRaw(kDirectDurableEd25519PrivKey, b64(Uint8List.fromList(edkp.privateKey.bytes)));
    await cache.putRaw(kDirectDurableEd25519PubKey, b64(Uint8List.fromList(edkp.publicKey.bytes)));
    await cache.putRaw(kDirectServerNonceKey, 'srv-seeded');
    server.clientX25519Pub = Uint8List.fromList(xPub.bytes);
  }

  Future<DirectClient> connected() async {
    await seedDurableIdentity();
    return DirectClient.connect(
      config: cfg(),
      cache: cache,
      httpClient: server.httpClient(),
    );
  }

  setUp(() async {
    server = await FakeBifrostDirectServer.create();
    cache = InMemorySecureCache();
    final ent = _entitlementJws(tier: 'pro', export: true);
    server.responses['/direct/v1/payment/refresh'] = FakeResponseSpec(
      claims: {
        'entitlement_jws': ent,
        'refreshed_at_ms': 1750000000000,
      },
    );
    ensureDirectPaymentErrorsRegistered();
  });

  group('refreshAfterPayment — happy paths', () {
    test('with sessionId: server returns fresh entitlement, SDK adopts it',
        () async {
      final client = await connected();
      final r = await client.refreshAfterPayment(sessionId: 'cs_test_xyz');
      expect(r.entitlements.tier, equals('pro'));
      expect(r.issuedAtMs, equals(1750000000000),
          reason: 'refreshed_at_ms claim is preferred when present');
      expect(r.entitlementJws, isNotEmpty);
      // SDK state is updated post-refresh so subsequent hasFeature is fresh.
      expect(client.hasFeature('export'), isTrue);
      // Wire body must carry session_id.
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/refresh')
          .toList();
      expect(reqs, hasLength(1));
      final body = (reqs.first.jwsClaims['body'] as Map).cast<String, dynamic>();
      expect(body['session_id'], equals('cs_test_xyz'));
      expect(body['project_id'], equals('proj_main'));
      await client.dispose();
    });

    test('without sessionId: degrades to /verify-equivalent (no session_id '
        'on wire)', () async {
      final client = await connected();
      final r = await client.refreshAfterPayment();
      expect(r.entitlements.tier, equals('pro'));
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/refresh')
          .toList();
      expect(reqs, hasLength(1));
      final body = (reqs.first.jwsClaims['body'] as Map).cast<String, dynamic>();
      expect(body.containsKey('session_id'), isFalse,
          reason: 'omitted sessionId must NOT serialise as null on the wire');
      await client.dispose();
    });

    test('falls back to issued_at_ms when refreshed_at_ms is absent',
        () async {
      final ent = _entitlementJws(tier: 'enterprise', export: true);
      server.responses['/direct/v1/payment/refresh'] = FakeResponseSpec(
        claims: {
          'entitlement_jws': ent,
          'issued_at_ms': 1650000000000,
        },
      );
      final client = await connected();
      final r = await client.refreshAfterPayment(sessionId: 'cs_x');
      expect(r.issuedAtMs, equals(1650000000000));
      expect(r.entitlements.tier, equals('enterprise'));
      await client.dispose();
    });
  });

  group('refreshAfterPayment — response-shape validation', () {
    test('missing entitlement_jws raises LicenseStoreException', () async {
      server.responses['/direct/v1/payment/refresh'] = const FakeResponseSpec(
        claims: {
          'refreshed_at_ms': 1750000000000,
        },
      );
      final client = await connected();
      await expectLater(
        client.refreshAfterPayment(sessionId: 'cs_x'),
        throwsA(isA<LicenseStoreException>()),
      );
      await client.dispose();
    });

    test('empty entitlement_jws is treated as missing', () async {
      server.responses['/direct/v1/payment/refresh'] = const FakeResponseSpec(
        claims: {
          'entitlement_jws': '',
          'refreshed_at_ms': 1750000000000,
        },
      );
      final client = await connected();
      await expectLater(
        client.refreshAfterPayment(sessionId: 'cs_x'),
        throwsA(isA<LicenseStoreException>()),
      );
      await client.dispose();
    });

    test('refresh before connect (no durable identity) raises '
        'NotConnectedException', () async {
      final freshCache = InMemorySecureCache();
      final freshServer = await FakeBifrostDirectServer.create();
      final client = await DirectClient.connect(
        config: cfg(),
        cache: freshCache,
        httpClient: freshServer.httpClient(),
      );
      await expectLater(
        client.refreshAfterPayment(sessionId: 'cs_x'),
        throwsA(isA<NotConnectedException>()),
      );
      await client.dispose();
    });
  });

  group('refreshAfterPayment — server error envelopes', () {
    test('DIRECT_SESSION_NOT_FOUND → DirectSessionNotFoundError', () async {
      server.responses['/direct/v1/payment/refresh'] = const FakeResponseSpec(
        statusCode: 404,
        claims: {
          'code': 'DIRECT_SESSION_NOT_FOUND',
          'message': 'session unknown',
        },
      );
      final client = await connected();
      await expectLater(
        client.refreshAfterPayment(sessionId: 'cs_missing'),
        throwsA(isA<DirectSessionNotFoundError>()),
      );
      await client.dispose();
    });

    test('DIRECT_SESSION_NOT_COMPLETE → DirectSessionNotCompleteError',
        () async {
      server.responses['/direct/v1/payment/refresh'] = const FakeResponseSpec(
        statusCode: 409,
        claims: {
          'code': 'DIRECT_SESSION_NOT_COMPLETE',
          'message': 'webhook not yet processed',
        },
      );
      final client = await connected();
      await expectLater(
        client.refreshAfterPayment(sessionId: 'cs_pending'),
        throwsA(isA<DirectSessionNotCompleteError>()),
      );
      await client.dispose();
    });

    test('DIRECT_RATE_LIMITED on refresh surfaces DirectRateLimitError',
        () async {
      server.responses['/direct/v1/payment/refresh'] = const FakeResponseSpec(
        statusCode: 429,
        claims: {
          'code': 'DIRECT_RATE_LIMITED',
          'retry_after_ms': 4000,
        },
      );
      final client = await connected();
      try {
        await client.refreshAfterPayment(sessionId: 'cs_x');
        fail('expected DirectRateLimitError');
      } on DirectRateLimitError catch (e) {
        expect(e.retryAfterMs, equals(4000));
      }
      await client.dispose();
    });

    test('DIRECT_PAYMENT_PROVIDER_FAILED on refresh surfaces typed error',
        () async {
      server.responses['/direct/v1/payment/refresh'] = const FakeResponseSpec(
        statusCode: 502,
        claims: {
          'code': 'DIRECT_PAYMENT_PROVIDER_FAILED',
          'message': 'stripe',
        },
      );
      final client = await connected();
      await expectLater(
        client.refreshAfterPayment(sessionId: 'cs_x'),
        throwsA(isA<DirectPaymentProviderFailedError>()),
      );
      await client.dispose();
    });
  });

  group('refreshAfterPayment — security guardrails', () {
    test('plaintext error body NEVER triggers DirectSessionNotFoundError '
        '— forged plaintext has no authority', () async {
      server.responses['/direct/v1/payment/refresh'] = const FakeResponseSpec(
        statusCode: 503,
        rawBody: '{"code":"DIRECT_SESSION_NOT_FOUND","message":"forged"}',
      );
      final client = await connected();
      await expectLater(
        client.refreshAfterPayment(sessionId: 'cs_x'),
        throwsA(isA<NetworkException>()),
      );
      await client.dispose();
    });

    test('refresh adopts new entitlement into client state synchronously '
        '— host product does NOT need a separate verify() call', () async {
      // Pre-state: entitlements should be null since we haven't verified.
      final client = await connected();
      expect(client.entitlements, isNull);
      expect(client.hasFeature('export'), isFalse);

      // Refresh with a "free → pro" upgrade JWS.
      final ent = _entitlementJws(tier: 'pro', export: true);
      server.responses['/direct/v1/payment/refresh'] = FakeResponseSpec(
        claims: {
          'entitlement_jws': ent,
          'refreshed_at_ms': 1750000000000,
        },
      );
      final r = await client.refreshAfterPayment(sessionId: 'cs_x');
      expect(r.entitlements.tier, equals('pro'));
      // Synchronous adoption is the guarantee — no second fetch needed.
      expect(client.entitlements?.tier, equals('pro'));
      expect(client.hasFeature('export'), isTrue);
      expect(client.entitlementJws, equals(ent));
      await client.dispose();
    });
  });

  // D-Fix 4 regression — aud namespace convergence (B-Fix 2).
  group('refreshAfterPayment — aud namespace (D-Fix 4)', () {
    test('inner JWS aud claim is direct:payment.refresh', () async {
      final ent = _entitlementJws(tier: 'pro', export: true);
      server.responses['/direct/v1/payment/refresh'] = FakeResponseSpec(
        claims: {
          'entitlement_jws': ent,
          'refreshed_at_ms': 1750000000000,
        },
      );
      final client = await connected();
      await client.refreshAfterPayment(sessionId: 'cs_aud_check');
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/refresh')
          .toList();
      expect(reqs, hasLength(1));
      expect(reqs.first.jwsClaims['aud'], equals(kDirectAudPaymentRefresh));
      expect(kDirectAudPaymentRefresh, equals('direct:payment.refresh'));
      await client.dispose();
    });
  });
}
