// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// W6 — FRON payment surface: `startCheckout` end-to-end tests.
///
/// Exercises the `DirectClient.startCheckout` extension against the
/// shared `FakeBifrostDirectServer`. Covers:
///   * happy-path hosted-checkout session minting + body shape on the wire
///   * client-side validation (non-https returnUrl, malformed cancelUrl,
///     bad tier slug, bad currency, bad billing cycle, blocked scheme)
///   * server-side error envelopes (provider failure, rate limit,
///     no-provider-configured)
///   * security guardrails (oversize returnUrl, plaintext error not
///     trusted, javascript: scheme rejected)
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' as c;
import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_client.dart';
import 'package:vanaheim/src/direct/direct_config.dart';
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/direct/direct_models.dart';
import 'package:vanaheim/src/direct/direct_payment_methods.dart';
import 'package:vanaheim/src/direct/direct_payment_models.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

import '_fake_bifrost_direct.dart';

void main() {
  late FakeBifrostDirectServer server;
  late InMemorySecureCache cache;

  DirectConfig cfg() => DirectConfig(
        bifrostBaseUrl: Uri.parse('https://bifrost.test'),
        projectId: 'proj_main',
        initialHeartbeatCadence: const Duration(hours: 1),
        statsFlushInterval: const Duration(hours: 1),
      );

  Future<void> seedDurableIdentity() async {
    final xkp = await c.X25519().newKeyPair();
    final xPub = await xkp.extractPublicKey();
    final xPriv = await xkp.extractPrivateKeyBytes();
    final edkp = ed25519.generateKey();
    String b64(Uint8List b) => base64Url.encode(b).replaceAll('=', '');
    await cache.putRaw(kDirectDeviceIdKey, 'dev_pre_seeded');
    await cache.putRaw(kDirectDurableX25519PrivKey, b64(Uint8List.fromList(xPriv)));
    await cache.putRaw(kDirectDurableX25519PubKey, b64(Uint8List.fromList(xPub.bytes)));
    await cache.putRaw(kDirectDurableEd25519PrivKey, b64(Uint8List.fromList(edkp.privateKey.bytes)));
    await cache.putRaw(kDirectDurableEd25519PubKey, b64(Uint8List.fromList(edkp.publicKey.bytes)));
    await cache.putRaw(kDirectServerNonceKey, 'srv-seeded');
    server.clientX25519Pub = Uint8List.fromList(xPub.bytes);
  }

  Future<DirectClient> connected() async {
    await seedDurableIdentity();
    return DirectClient.connect(
      config: cfg(),
      cache: cache,
      httpClient: server.httpClient(),
    );
  }

  setUp(() async {
    server = await FakeBifrostDirectServer.create();
    cache = InMemorySecureCache();
    // Default happy-path response.
    server.responses['/direct/v1/payment/checkout'] = const FakeResponseSpec(
      claims: {
        'session_id': 'cs_test_abc',
        'hosted_url': 'https://pay.example/cs_test_abc',
        'expires_at_ms': 1900000000000,
      },
    );
    // Payment surface routes payment-specific wire codes; eagerly install
    // so any error envelope a test stages routes to the typed exception.
    ensureDirectPaymentErrorsRegistered();
  });

  group('startCheckout — happy paths', () {
    test('returns CheckoutSession parsed from the server response', () async {
      final client = await connected();
      final session = await client.startCheckout(
        tier: 'pro_yearly',
        billingCycle: 'yearly',
        currency: 'USD',
        returnUrl: 'https://app.example/return',
      );
      expect(session.sessionId, equals('cs_test_abc'));
      expect(session.hostedUrl, equals('https://pay.example/cs_test_abc'));
      expect(session.expiresAtMs, equals(1900000000000));
      await client.dispose();
    });

    test('body carries project_id, tier, billing_cycle, currency, return_url, '
        'optional cancel_url + provider', () async {
      final client = await connected();
      await client.startCheckout(
        tier: 'pro',
        billingCycle: 'monthly',
        currency: 'INR',
        returnUrl: 'https://app.example/done',
        cancelUrl: 'https://app.example/cancel',
        provider: 'stripe',
      );
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/checkout')
          .toList();
      expect(reqs, hasLength(1));
      final body = (reqs.first.jwsClaims['body'] as Map).cast<String, dynamic>();
      expect(body['project_id'], equals('proj_main'));
      expect(body['tier'], equals('pro'));
      expect(body['billing_cycle'], equals('monthly'));
      expect(body['currency'], equals('INR'));
      expect(body['return_url'], equals('https://app.example/done'));
      expect(body['cancel_url'], equals('https://app.example/cancel'));
      expect(body['provider'], equals('stripe'));
      await client.dispose();
    });

    test('custom app scheme (myapp://) is accepted for returnUrl '
        '(deep-link round-trip)', () async {
      final client = await connected();
      final session = await client.startCheckout(
        tier: 'pro',
        billingCycle: 'monthly',
        currency: 'USD',
        returnUrl: 'myapp://upgrade-done',
      );
      expect(session.sessionId, equals('cs_test_abc'));
      await client.dispose();
    });
  });

  group('startCheckout — client-side validation', () {
    test('non-https returnUrl is rejected client-side (no wire hit)', () async {
      final client = await connected();
      await expectLater(
        client.startCheckout(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          returnUrl: 'http://insecure.example/return',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      expect(
        server.requests
            .where((r) => r.routePath == '/direct/v1/payment/checkout')
            .length,
        equals(0),
        reason: 'client-side validation must short-circuit before the wire',
      );
      await client.dispose();
    });

    test('non-https cancelUrl is rejected client-side', () async {
      final client = await connected();
      await expectLater(
        client.startCheckout(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          returnUrl: 'https://app.example/done',
          cancelUrl: 'http://insecure.example/cancel',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('malformed tier slug (uppercase / punctuation) is rejected', () async {
      final client = await connected();
      await expectLater(
        client.startCheckout(
          tier: 'PRO!',
          billingCycle: 'monthly',
          currency: 'USD',
          returnUrl: 'https://app.example/return',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('non-ISO-4217 currency is rejected', () async {
      final client = await connected();
      await expectLater(
        client.startCheckout(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'usd', // lowercase fails [A-Z]{3}
          returnUrl: 'https://app.example/return',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('billing cycle other than monthly|yearly is rejected', () async {
      final client = await connected();
      await expectLater(
        client.startCheckout(
          tier: 'pro',
          billingCycle: 'quarterly',
          currency: 'USD',
          returnUrl: 'https://app.example/return',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('unknown provider tag is rejected', () async {
      final client = await connected();
      await expectLater(
        client.startCheckout(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          returnUrl: 'https://app.example/return',
          provider: 'unknown_pay',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });
  });

  group('startCheckout — server error envelopes', () {
    test('DIRECT_PAYMENT_PROVIDER_FAILED → DirectPaymentProviderFailedError',
        () async {
      server.responses['/direct/v1/payment/checkout'] = const FakeResponseSpec(
        statusCode: 502,
        claims: {
          'code': 'DIRECT_PAYMENT_PROVIDER_FAILED',
          'message': 'stripe',
        },
      );
      final client = await connected();
      await expectLater(
        client.startCheckout(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          returnUrl: 'https://app.example/return',
        ),
        throwsA(isA<DirectPaymentProviderFailedError>()),
      );
      await client.dispose();
    });

    test('DIRECT_RATE_LIMITED → DirectRateLimitError with retry_after_ms',
        () async {
      server.responses['/direct/v1/payment/checkout'] = const FakeResponseSpec(
        statusCode: 429,
        claims: {
          'code': 'DIRECT_RATE_LIMITED',
          'retry_after_ms': 2500,
          'message': 'slow down',
        },
      );
      final client = await connected();
      try {
        await client.startCheckout(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          returnUrl: 'https://app.example/return',
        );
        fail('expected DirectRateLimitError');
      } on DirectRateLimitError catch (e) {
        expect(e.retryAfterMs, equals(2500));
      }
      await client.dispose();
    });

    test('DIRECT_NO_PROVIDER_CONFIGURED → DirectNoProviderConfiguredError',
        () async {
      server.responses['/direct/v1/payment/checkout'] = const FakeResponseSpec(
        statusCode: 409,
        claims: {
          'code': 'DIRECT_NO_PROVIDER_CONFIGURED',
          'message': 'project has no payment provider',
        },
      );
      final client = await connected();
      await expectLater(
        client.startCheckout(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          returnUrl: 'https://app.example/return',
        ),
        throwsA(isA<DirectNoProviderConfiguredError>()),
      );
      await client.dispose();
    });
  });

  group('startCheckout — security guardrails', () {
    test('javascript: scheme returnUrl is rejected client-side', () async {
      final client = await connected();
      await expectLater(
        client.startCheckout(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          returnUrl: 'javascript:alert(1)',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      // Verify no wire hit — the scheme allowlist must close before the
      // payload escapes the SDK.
      expect(
        server.requests
            .where((r) => r.routePath == '/direct/v1/payment/checkout')
            .length,
        equals(0),
        reason: 'javascript: scheme must never escape the SDK',
      );
      await client.dispose();
    });

    test('returnUrl over 2048 chars is rejected client-side', () async {
      final client = await connected();
      final huge = 'https://app.example/${'a' * 3000}';
      await expectLater(
        client.startCheckout(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          returnUrl: huge,
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('plaintext-JSON error body (not a JWE) surfaces as NetworkException, '
        'NOT a payment-typed error — forged bodies have no authority',
        () async {
      server.responses['/direct/v1/payment/checkout'] = const FakeResponseSpec(
        statusCode: 503,
        rawBody: '{"code":"DIRECT_PAYMENT_PROVIDER_FAILED","message":"forged"}',
      );
      final client = await connected();
      await expectLater(
        client.startCheckout(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          returnUrl: 'https://app.example/return',
        ),
        throwsA(isA<NetworkException>()),
      );
      await client.dispose();
    });
  });

  // D-Fix 4 regression — aud namespace convergence (B-Fix 2).
  group('startCheckout — aud namespace (D-Fix 4)', () {
    test('inner JWS aud claim is direct:payment.checkout', () async {
      final client = await connected();
      await client.startCheckout(
        tier: 'pro',
        billingCycle: 'monthly',
        currency: 'USD',
        returnUrl: 'https://app.example/return',
      );
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/checkout')
          .toList();
      expect(reqs, hasLength(1));
      expect(reqs.first.jwsClaims['aud'],
          equals(kDirectAudPaymentCheckout));
      expect(kDirectAudPaymentCheckout, equals('direct:payment.checkout'));
      await client.dispose();
    });
  });
}
