// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Lock-in tests for the FRON wire-code → [DirectError] mapping.
///
/// The mapping is the contract host products write `catch` blocks against —
/// any drift here is a silent change in product UX, so each code is pinned.
library;

import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_models.dart';
import 'package:vanaheim/src/exceptions.dart';

void main() {
  group('directErrorFromCode — pinned wire codes', () {
    test('DIRECT_BAD_REQUEST → DirectBadRequestError', () {
      final e = directErrorFromCode('DIRECT_BAD_REQUEST');
      expect(e, isA<DirectBadRequestError>());
      expect(e.code, equals('DIRECT_BAD_REQUEST'));
      expect(e, isA<LicenseStoreException>(),
          reason: 'all DirectError must inherit LicenseStoreException so '
              'existing try/catch blocks keep working');
    });

    test('DIRECT_LICENSE_INVALID → DirectLicenseInvalidError', () {
      final e = directErrorFromCode('DIRECT_LICENSE_INVALID');
      expect(e, isA<DirectLicenseInvalidError>());
      expect(e.code, equals('DIRECT_LICENSE_INVALID'));
    });

    test('DIRECT_LICENSE_EXPIRED → DirectLicenseExpiredError', () {
      final e = directErrorFromCode('DIRECT_LICENSE_EXPIRED');
      expect(e, isA<DirectLicenseExpiredError>());
    });

    test('DIRECT_LICENSE_SEAT_EXCEEDED → DirectSeatExceededError', () {
      final e = directErrorFromCode('DIRECT_LICENSE_SEAT_EXCEEDED');
      expect(e, isA<DirectSeatExceededError>());
    });

    test('DIRECT_RATE_LIMITED preserves retryAfterMs', () {
      final e = directErrorFromCode('DIRECT_RATE_LIMITED', retryAfterMs: 1500);
      expect(e, isA<DirectRateLimitError>());
      expect((e as DirectRateLimitError).retryAfterMs, equals(1500));
    });

    test('DIRECT_RATE_LIMITED defaults retryAfterMs to 0 when missing', () {
      final e = directErrorFromCode('DIRECT_RATE_LIMITED');
      expect(e, isA<DirectRateLimitError>());
      expect((e as DirectRateLimitError).retryAfterMs, equals(0));
    });

    test('DIRECT_FCM_TOKEN_REUSED → DirectFcmTokenReusedError', () {
      final e = directErrorFromCode('DIRECT_FCM_TOKEN_REUSED');
      expect(e, isA<DirectFcmTokenReusedError>());
    });

    test('DIRECT_NO_PROVIDER_CONFIGURED → DirectNoProviderConfiguredError', () {
      final e = directErrorFromCode('DIRECT_NO_PROVIDER_CONFIGURED');
      expect(e, isA<DirectNoProviderConfiguredError>());
    });

    test('DIRECT_PROJECT_DISABLED → DirectProjectDisabledError', () {
      final e = directErrorFromCode('DIRECT_PROJECT_DISABLED');
      expect(e, isA<DirectProjectDisabledError>());
    });

    test('DIRECT_REPLAY_DETECTED → DirectReplayDetectedError', () {
      final e = directErrorFromCode('DIRECT_REPLAY_DETECTED');
      expect(e, isA<DirectReplayDetectedError>());
    });

    test('DIRECT_DEVICE_REVOKED → DirectDeviceRevokedError', () {
      final e = directErrorFromCode('DIRECT_DEVICE_REVOKED');
      expect(e, isA<DirectDeviceRevokedError>());
    });
  });

  group('directErrorFromCode — provider-failed fallback', () {
    test('DIRECT_PAYMENT_FAILED → DirectProviderFailedError', () {
      final e = directErrorFromCode('DIRECT_PAYMENT_FAILED');
      expect(e, isA<DirectProviderFailedError>());
      expect((e as DirectProviderFailedError).providerCode,
          equals('DIRECT_PAYMENT_FAILED'));
    });

    test('DIRECT_KYC_FAILED → DirectProviderFailedError', () {
      final e = directErrorFromCode('DIRECT_KYC_FAILED');
      expect(e, isA<DirectProviderFailedError>());
      expect((e as DirectProviderFailedError).providerCode,
          equals('DIRECT_KYC_FAILED'));
    });
  });

  group('directErrorFromCode — unknown codes', () {
    test('unknown DIRECT_ code falls through to a generic DirectError',
        () {
      final e = directErrorFromCode('DIRECT_BRAND_NEW_CODE');
      expect(e, isA<DirectError>());
      // Not a provider-failed; not a known typed subclass.
      expect(e, isNot(isA<DirectProviderFailedError>()));
      expect(e.code, equals('DIRECT_BRAND_NEW_CODE'));
    });

    test('non-DIRECT_ prefix still produces a DirectError (caller can '
        'still pattern-match on the base type)', () {
      final e = directErrorFromCode('SOMETHING_ELSE');
      expect(e, isA<DirectError>());
      expect(e.code, equals('SOMETHING_ELSE'));
    });

    test('custom messages flow through to .message', () {
      final e = directErrorFromCode(
        'DIRECT_LICENSE_INVALID',
        message: 'overridden message body',
      );
      expect(e.message, equals('overridden message body'));
    });
  });
}
