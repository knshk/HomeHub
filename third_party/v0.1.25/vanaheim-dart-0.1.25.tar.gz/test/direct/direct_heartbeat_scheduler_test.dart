// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Tests for the heartbeat scheduler.
///
/// Cadences are kept short (≤ 50ms) so the suite runs fast. The
/// scheduler itself is `Timer.periodic`-based, so we use real time
/// rather than `fakeAsync` to avoid pulling in `package:fake_async`.
library;

import 'dart:async';

import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_heartbeat_scheduler.dart';

void main() {
  group('DirectHeartbeatScheduler — basic cadence', () {
    test('fires at the configured cadence', () async {
      var count = 0;
      final s = DirectHeartbeatScheduler(
        tick: () async => count++,
        initialCadence: const Duration(milliseconds: 25),
      );
      s.start();
      await Future<void>.delayed(const Duration(milliseconds: 120));
      s.dispose();
      expect(count, greaterThanOrEqualTo(2),
          reason: 'at least two ticks should fire in 120ms at 25ms cadence');
    });

    test('stop() halts further ticks', () async {
      var count = 0;
      final s = DirectHeartbeatScheduler(
        tick: () async => count++,
        initialCadence: const Duration(milliseconds: 20),
      );
      s.start();
      await Future<void>.delayed(const Duration(milliseconds: 70));
      final snapshot = count;
      s.stop();
      await Future<void>.delayed(const Duration(milliseconds: 60));
      s.dispose();
      expect(count, equals(snapshot),
          reason: 'no further ticks after stop()');
    });

    test('isRunning reflects timer state', () async {
      final s = DirectHeartbeatScheduler(
        tick: () async {},
        initialCadence: const Duration(milliseconds: 100),
      );
      expect(s.isRunning, isFalse);
      s.start();
      expect(s.isRunning, isTrue);
      s.stop();
      expect(s.isRunning, isFalse);
      s.dispose();
    });
  });

  group('DirectHeartbeatScheduler — pause / resume', () {
    test('pause() skips ticks; resume() restarts firing', () async {
      var count = 0;
      final s = DirectHeartbeatScheduler(
        tick: () async => count++,
        initialCadence: const Duration(milliseconds: 25),
      );
      s.start();
      await Future<void>.delayed(const Duration(milliseconds: 70));
      s.pause();
      final atPause = count;
      await Future<void>.delayed(const Duration(milliseconds: 80));
      expect(count, equals(atPause),
          reason: 'paused scheduler must not fire user-visible ticks');
      s.resume(fireImmediately: false);
      await Future<void>.delayed(const Duration(milliseconds: 80));
      s.dispose();
      expect(count, greaterThan(atPause),
          reason: 'ticks must resume firing once resume() is called');
    });

    test('resume(fireImmediately: true) catches up an extra tick', () async {
      var count = 0;
      final s = DirectHeartbeatScheduler(
        tick: () async => count++,
        initialCadence: const Duration(seconds: 30), // long
      );
      s.start();
      s.pause();
      await Future<void>.delayed(const Duration(milliseconds: 5));
      s.resume(fireImmediately: true);
      // Give the immediate tick a microtask to run.
      await Future<void>.delayed(const Duration(milliseconds: 30));
      s.dispose();
      expect(count, equals(1),
          reason: 'fireImmediately must trigger exactly one tick');
    });
  });

  group('DirectHeartbeatScheduler — cadence updates', () {
    test('setCadence(same) is a no-op', () async {
      // Use a cadence at the clamp floor (1s) so the test pins the
      // identity behaviour rather than the clamp behaviour.
      final s = DirectHeartbeatScheduler(
        tick: () async {},
        initialCadence: const Duration(seconds: 1),
      );
      s.start();
      final timer1 = s.isRunning;
      s.setCadence(const Duration(seconds: 1));
      expect(s.cadence, equals(const Duration(seconds: 1)));
      expect(s.isRunning, equals(timer1));
      s.dispose();
    });

    test('setCadence clamps a zero / negative cadence to kMinCadence — a '
        'buggy server response must NOT create a runaway tick loop',
        () async {
      final s = DirectHeartbeatScheduler(
        tick: () async {},
        initialCadence: const Duration(seconds: 30),
      );
      s.setCadence(Duration.zero);
      expect(s.cadence, equals(DirectHeartbeatScheduler.kMinCadence),
          reason: 'zero cadence must clamp UP to the safe floor');
      s.setCadence(const Duration(milliseconds: -5000));
      expect(s.cadence, equals(DirectHeartbeatScheduler.kMinCadence),
          reason: 'negative cadence must clamp UP to the safe floor');
      s.setCadence(const Duration(milliseconds: 100));
      expect(s.cadence, equals(DirectHeartbeatScheduler.kMinCadence),
          reason: 'sub-1s cadence must clamp UP to the safe floor');
      s.dispose();
    });

    test('setCadence clamps an over-large cadence to kMaxCadence — a '
        'malicious server cannot silently extend session TTL beyond '
        'the SDK\'s safety ceiling', () async {
      final s = DirectHeartbeatScheduler(
        tick: () async {},
        initialCadence: const Duration(seconds: 30),
      );
      s.setCadence(const Duration(days: 30));
      expect(s.cadence, equals(DirectHeartbeatScheduler.kMaxCadence),
          reason: '30-day cadence must clamp DOWN to the safe ceiling');
      s.dispose();
    });

    test('setCadence(different) updates + restarts the timer', () async {
      var count = 0;
      final s = DirectHeartbeatScheduler(
        tick: () async => count++,
        initialCadence: const Duration(seconds: 30), // long
      );
      s.start();
      // Shorten to the clamp floor (1s) — any shorter value would be
      // clamped UP and never actually exercise the restart path.
      s.setCadence(const Duration(seconds: 1));
      expect(s.cadence, equals(const Duration(seconds: 1)));
      await Future<void>.delayed(const Duration(milliseconds: 1500));
      s.dispose();
      expect(count, greaterThan(0),
          reason: 'shortened cadence must take effect immediately');
    });
  });

  group('DirectHeartbeatScheduler — error handling', () {
    test('tick exceptions are routed to onError instead of bubbling',
        () async {
      Object? lastError;
      final s = DirectHeartbeatScheduler(
        tick: () async => throw StateError('boom'),
        initialCadence: const Duration(milliseconds: 20),
        onError: (e, _) => lastError = e,
      );
      s.start();
      await Future<void>.delayed(const Duration(milliseconds: 70));
      s.dispose();
      expect(lastError, isA<StateError>(),
          reason: 'background tick failures must NOT crash the timer');
    });

    test('re-entrant tick is skipped (no overlapping invocations)',
        () async {
      var inFlight = 0;
      var maxConcurrent = 0;
      final s = DirectHeartbeatScheduler(
        tick: () async {
          inFlight++;
          if (inFlight > maxConcurrent) maxConcurrent = inFlight;
          await Future<void>.delayed(const Duration(milliseconds: 60));
          inFlight--;
        },
        initialCadence: const Duration(milliseconds: 15),
      );
      s.start();
      await Future<void>.delayed(const Duration(milliseconds: 150));
      s.stop();
      // Wait for the in-flight tick to drain.
      await Future<void>.delayed(const Duration(milliseconds: 80));
      s.dispose();
      expect(maxConcurrent, equals(1),
          reason: 'a slow tick must NOT be re-entered by the next timer fire');
    });

    test('dispose() makes start() and setCadence() into no-ops', () async {
      var count = 0;
      final s = DirectHeartbeatScheduler(
        tick: () async => count++,
        initialCadence: const Duration(milliseconds: 10),
      );
      s.dispose();
      s.start();
      s.setCadence(const Duration(milliseconds: 5));
      await Future<void>.delayed(const Duration(milliseconds: 40));
      expect(count, equals(0));
    });
  });
}
