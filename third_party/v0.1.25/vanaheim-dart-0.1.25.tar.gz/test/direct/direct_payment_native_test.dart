// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// W6 — FRON payment surface: `startNativePayment` end-to-end tests.
///
/// Exercises the `DirectClient.startNativePayment` extension against the
/// shared `FakeBifrostDirectServer`. Covers:
///   * happy paths (ios, android, web) + wire body shape
///   * client-side validation (invalid platform, bad currency, bad
///     billing cycle, bad tier, bad provider)
///   * server-side error envelopes (provider failure, rate limit)
///   * security guardrails (clientSecret + intentId never logged on a
///     bad-shape parse; plaintext error not trusted)
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' as c;
import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_client.dart';
import 'package:vanaheim/src/direct/direct_config.dart';
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/direct/direct_models.dart';
import 'package:vanaheim/src/direct/direct_payment_methods.dart';
import 'package:vanaheim/src/direct/direct_payment_models.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

import '_fake_bifrost_direct.dart';

void main() {
  late FakeBifrostDirectServer server;
  late InMemorySecureCache cache;

  DirectConfig cfg() => DirectConfig(
        bifrostBaseUrl: Uri.parse('https://bifrost.test'),
        projectId: 'proj_main',
        initialHeartbeatCadence: const Duration(hours: 1),
        statsFlushInterval: const Duration(hours: 1),
      );

  Future<void> seedDurableIdentity() async {
    final xkp = await c.X25519().newKeyPair();
    final xPub = await xkp.extractPublicKey();
    final xPriv = await xkp.extractPrivateKeyBytes();
    final edkp = ed25519.generateKey();
    String b64(Uint8List b) => base64Url.encode(b).replaceAll('=', '');
    await cache.putRaw(kDirectDeviceIdKey, 'dev_pre_seeded');
    await cache.putRaw(kDirectDurableX25519PrivKey, b64(Uint8List.fromList(xPriv)));
    await cache.putRaw(kDirectDurableX25519PubKey, b64(Uint8List.fromList(xPub.bytes)));
    await cache.putRaw(kDirectDurableEd25519PrivKey, b64(Uint8List.fromList(edkp.privateKey.bytes)));
    await cache.putRaw(kDirectDurableEd25519PubKey, b64(Uint8List.fromList(edkp.publicKey.bytes)));
    await cache.putRaw(kDirectServerNonceKey, 'srv-seeded');
    server.clientX25519Pub = Uint8List.fromList(xPub.bytes);
  }

  Future<DirectClient> connected() async {
    await seedDurableIdentity();
    return DirectClient.connect(
      config: cfg(),
      cache: cache,
      httpClient: server.httpClient(),
    );
  }

  setUp(() async {
    server = await FakeBifrostDirectServer.create();
    cache = InMemorySecureCache();
    server.responses['/direct/v1/payment/intent'] = const FakeResponseSpec(
      claims: {
        'intent_id': 'pi_test_42',
        'client_secret': 'pi_test_42_secret_zzz',
        'expires_at_ms': 1900000000000,
      },
    );
    ensureDirectPaymentErrorsRegistered();
  });

  group('startNativePayment — happy paths', () {
    test('ios native payment returns PaymentIntent', () async {
      final client = await connected();
      final intent = await client.startNativePayment(
        tier: 'pro',
        billingCycle: 'monthly',
        currency: 'USD',
        platform: 'ios',
      );
      expect(intent.intentId, equals('pi_test_42'));
      expect(intent.clientSecret, equals('pi_test_42_secret_zzz'));
      expect(intent.expiresAtMs, equals(1900000000000));
      await client.dispose();
    });

    test('android native payment carries platform=android on the wire',
        () async {
      final client = await connected();
      await client.startNativePayment(
        tier: 'pro_yearly',
        billingCycle: 'yearly',
        currency: 'EUR',
        platform: 'android',
        provider: 'razorpay',
      );
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/intent')
          .toList();
      expect(reqs, hasLength(1));
      final body = (reqs.first.jwsClaims['body'] as Map).cast<String, dynamic>();
      expect(body['platform'], equals('android'));
      expect(body['tier'], equals('pro_yearly'));
      expect(body['billing_cycle'], equals('yearly'));
      expect(body['currency'], equals('EUR'));
      expect(body['provider'], equals('razorpay'));
      expect(body['project_id'], equals('proj_main'));
      await client.dispose();
    });

    test('web platform is accepted by intent (unlike restore / iap-verify)',
        () async {
      final client = await connected();
      final intent = await client.startNativePayment(
        tier: 'pro',
        billingCycle: 'monthly',
        currency: 'USD',
        platform: 'web',
      );
      expect(intent.intentId, equals('pi_test_42'));
      await client.dispose();
    });
  });

  group('startNativePayment — client-side validation', () {
    test('invalid platform (e.g. macos) is rejected client-side', () async {
      final client = await connected();
      await expectLater(
        client.startNativePayment(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          platform: 'macos',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      expect(
        server.requests
            .where((r) => r.routePath == '/direct/v1/payment/intent')
            .length,
        equals(0),
        reason: 'platform allowlist must short-circuit before the wire',
      );
      await client.dispose();
    });

    test('empty currency (treated as missing) is rejected client-side',
        () async {
      final client = await connected();
      await expectLater(
        client.startNativePayment(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: '', // empty → fails [A-Z]{3} regex
          platform: 'ios',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('non-ISO-4217 currency (4-letter code) is rejected', () async {
      final client = await connected();
      await expectLater(
        client.startNativePayment(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USDX',
          platform: 'ios',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('empty tier is rejected', () async {
      final client = await connected();
      await expectLater(
        client.startNativePayment(
          tier: '',
          billingCycle: 'monthly',
          currency: 'USD',
          platform: 'ios',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('tier longer than 64 chars is rejected', () async {
      final client = await connected();
      await expectLater(
        client.startNativePayment(
          tier: 'a' * 65,
          billingCycle: 'monthly',
          currency: 'USD',
          platform: 'ios',
        ),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });
  });

  group('startNativePayment — server error envelopes', () {
    test('DIRECT_PAYMENT_PROVIDER_FAILED → DirectPaymentProviderFailedError',
        () async {
      server.responses['/direct/v1/payment/intent'] = const FakeResponseSpec(
        statusCode: 502,
        claims: {
          'code': 'DIRECT_PAYMENT_PROVIDER_FAILED',
          'message': 'apple_iap',
        },
      );
      final client = await connected();
      await expectLater(
        client.startNativePayment(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          platform: 'ios',
        ),
        throwsA(isA<DirectPaymentProviderFailedError>()),
      );
      await client.dispose();
    });

    test('DIRECT_RATE_LIMITED on intent surfaces DirectRateLimitError',
        () async {
      server.responses['/direct/v1/payment/intent'] = const FakeResponseSpec(
        statusCode: 429,
        claims: {
          'code': 'DIRECT_RATE_LIMITED',
          'retry_after_ms': 1000,
        },
      );
      final client = await connected();
      try {
        await client.startNativePayment(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          platform: 'ios',
        );
        fail('expected DirectRateLimitError');
      } on DirectRateLimitError catch (e) {
        expect(e.retryAfterMs, equals(1000));
      }
      await client.dispose();
    });
  });

  group('startNativePayment — security guardrails', () {
    test('plaintext error body NEVER triggers a typed payment error',
        () async {
      server.responses['/direct/v1/payment/intent'] = const FakeResponseSpec(
        statusCode: 503,
        rawBody: '{"code":"DIRECT_PAYMENT_PROVIDER_FAILED","message":"forged"}',
      );
      final client = await connected();
      await expectLater(
        client.startNativePayment(
          tier: 'pro',
          billingCycle: 'monthly',
          currency: 'USD',
          platform: 'ios',
        ),
        throwsA(isA<NetworkException>()),
      );
      await client.dispose();
    });

    test('intent response with empty client_secret still parses cleanly '
        '(no crash) — host app surfaces the missing field upstream',
        () async {
      // Defence-in-depth: a server-side regression that drops client_secret
      // must not crash the parse. PaymentIntent.fromJson coalesces missing
      // strings to '' so the host app can surface it without an SDK throw.
      server.responses['/direct/v1/payment/intent'] = const FakeResponseSpec(
        claims: {
          'intent_id': 'pi_only',
          'expires_at_ms': 1900000000000,
        },
      );
      final client = await connected();
      final intent = await client.startNativePayment(
        tier: 'pro',
        billingCycle: 'monthly',
        currency: 'USD',
        platform: 'ios',
      );
      expect(intent.intentId, equals('pi_only'));
      expect(intent.clientSecret, equals(''),
          reason: 'missing client_secret must coalesce to "" not throw');
      await client.dispose();
    });
  });

  // D-Fix 4 regression — aud namespace convergence (B-Fix 2).
  group('startNativePayment — aud namespace (D-Fix 4)', () {
    test('inner JWS aud claim is direct:payment.intent', () async {
      final client = await connected();
      await client.startNativePayment(
        tier: 'pro',
        billingCycle: 'monthly',
        currency: 'USD',
        platform: 'ios',
      );
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/intent')
          .toList();
      expect(reqs, hasLength(1));
      expect(reqs.first.jwsClaims['aud'], equals(kDirectAudPaymentIntent));
      expect(kDirectAudPaymentIntent, equals('direct:payment.intent'));
      await client.dispose();
    });
  });
}
