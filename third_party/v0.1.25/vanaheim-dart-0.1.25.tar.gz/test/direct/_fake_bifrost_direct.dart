// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Shared test infrastructure for the FRON DirectClient suite.
///
/// Provides:
///   * A `FakeBifrostDirectServer` — fakes the wire side of every
///     `/direct/v1/*` endpoint plus the JWKS endpoint. It owns a real
///     X25519 + Ed25519 keypair and uses the production [JweCodec] +
///     `ed25519_edwards` to:
///       - decrypt + parse the inbound request JWE/JWS
///       - mint a server-side response JWE wrapping an Ed25519-signed
///         inner JWS the SDK can verify
///   * Helpers to build a `BifrostKeySet` directly so individual unit
///     tests (e.g. `direct_response_parser_test.dart`) don't need to
///     spin up the whole server.
///
/// The fake is intentionally minimal: it exercises the *protocol* path
/// (decrypt → verify → mint), not Bifrost's business logic. Tests assert
/// the SDK speaks the wire shape the server expects; they don't try to
/// reproduce the server's authorization / billing / rate-limit logic.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' as c;
import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:vanaheim/src/crypto/jwe_codec.dart';
import 'package:vanaheim/src/crypto/thumbprint.dart';
import 'package:vanaheim/src/direct/direct_recipient_resolver.dart';
import 'package:vanaheim/src/direct/direct_request_builder.dart'
    show kDirectJweTyp, kDirectLcsVersion;

/// One canned response (or error) the fake server returns for a given
/// route. Each test registers the shape it needs before kicking off the
/// SDK call.
///
/// IMPORTANT — POST W6 fix-pass-2 wire shape:
///
/// The fake server now wraps `claims` UNDER an envelope of the form
/// `{ iat, nbf, exp, iss, aud, payload: <claims>  }` when the claims
/// don't already carry an `error` key. If the test specifies an `error`
/// claim (sealed error path), the server emits
/// `{ iat, nbf, exp, iss, aud, error: <claim['error']> }`. This mirrors
/// the production Bifrost wire shape so the response-parser tests catch
/// drift between the SDK parser and the server envelope.
class FakeResponseSpec {
  /// Claims to embed inside the inner JWS payload. On 2xx these become
  /// the body the SDK consumes; on >=400 the SDK looks for `code` /
  /// `retry_after_ms` and raises a typed [DirectError].
  ///
  /// On the success path the fake server moves this map into the
  /// envelope's `payload` slot — UNLESS it contains an `error` key, in
  /// which case the server emits a sealed-error envelope instead.
  final Map<String, dynamic> claims;

  /// HTTP status to return. Default 200.
  final int statusCode;

  /// Inner JWS `typ` header value. Default `bifrost-direct+response+jws`.
  final String innerTyp;

  /// Optional override for the outer JWE `typ` — the SDK pins this to
  /// `bifrost-direct+jwe`; setting anything else is a negative-test knob.
  final String? outerTypOverride;

  /// Optional override for the outer JWE `lcs_v` — same negative-test role.
  final int? outerLcsVOverride;

  /// Optional override for the outer JWE `route_path` — defaults to the
  /// route the request was actually sent on.
  final String? outerRoutePathOverride;

  /// Optional override for the outer JWE `request_id` — defaults to the
  /// request id from the inbound envelope.
  final String? outerRequestIdOverride;

  /// Optional non-JWE body (e.g. plain JSON error from a gateway).
  final String? rawBody;

  const FakeResponseSpec({
    this.claims = const {},
    this.statusCode = 200,
    this.innerTyp = 'bifrost-direct+response+jws',
    this.outerTypOverride,
    this.outerLcsVOverride,
    this.outerRoutePathOverride,
    this.outerRequestIdOverride,
    this.rawBody,
  });
}

/// Records one inbound request so tests can assert on the wire shape.
class FakeRequestRecord {
  final String routePath;
  final String requestId;
  final Map<String, String> headers;
  final Map<String, dynamic> jweHeader;
  final Map<String, dynamic> jwsHeader;
  final Map<String, dynamic> jwsClaims;
  final String compactJwe;
  final String innerJws;

  FakeRequestRecord({
    required this.routePath,
    required this.requestId,
    required this.headers,
    required this.jweHeader,
    required this.jwsHeader,
    required this.jwsClaims,
    required this.compactJwe,
    required this.innerJws,
  });
}

/// Wraps a [MockClient] with canned JWE responses + records every call.
class FakeBifrostDirectServer {
  /// Bifrost's recipient (X25519) keypair — what the SDK encrypts FOR.
  final c.SimpleKeyPair recipientX25519;
  final Uint8List recipientX25519PubBytes;
  final Uint8List recipientX25519PrivBytes;

  /// Bifrost's signing (Ed25519) keypair — what the SDK verifies inner JWS
  /// signatures against.
  final ed25519.KeyPair signingEd25519;
  final Uint8List signingEd25519PubBytes;

  /// kid for the recipient X25519 key.
  final String recipientKid;

  /// kid for the signing Ed25519 key.
  final String signingKid;

  /// Mutable map of route → response spec. Tests overwrite freely.
  final Map<String, FakeResponseSpec> responses = {};

  /// Per-call log of inbound requests (any route).
  final List<FakeRequestRecord> requests = [];

  /// Optional default device id minted for /register responses.
  String defaultDeviceId = 'dev_test_001';
  String defaultServerNonce = 'nonce_test_001';

  /// Optional JWKS response override (e.g. for malformed-JWKS tests).
  String? jwksRawOverride;
  int jwksStatusCode = 200;

  /// JWKS fetch counter (lets tests assert refresh behaviour).
  int jwksFetchCount = 0;

  /// X25519 pub the response JWE should be encrypted FOR. The SDK calls the
  /// response parser with its DEVICE X25519 priv (ephemeral on /register,
  /// durable on every other call) — the fake server encrypts to that pub
  /// so the parser's `JweCodec.decryptCompact` round-trip succeeds.
  ///
  /// Tests register the device X25519 pub on this field BEFORE making the
  /// request whose response they care about. For the DirectClient-level
  /// end-to-end tests we don't have a clean way to know that key in
  /// advance, so the client-level tests use [recordSdkClientX25519Pub]
  /// (set via an HTTP interceptor wrapped around the fake's mock client).
  Uint8List? clientX25519Pub;

  FakeBifrostDirectServer._({
    required this.recipientX25519,
    required this.recipientX25519PubBytes,
    required this.recipientX25519PrivBytes,
    required this.signingEd25519,
    required this.signingEd25519PubBytes,
    required this.recipientKid,
    required this.signingKid,
  });

  static Future<FakeBifrostDirectServer> create({
    String recipientKid = 'fron-enc-1',
    String signingKid = 'fron-sig-1',
  }) async {
    final x = await c.X25519().newKeyPair();
    final xPub = await x.extractPublicKey();
    final xPriv = await x.extractPrivateKeyBytes();
    final ed = ed25519.generateKey();
    return FakeBifrostDirectServer._(
      recipientX25519: x,
      recipientX25519PubBytes: Uint8List.fromList(xPub.bytes),
      recipientX25519PrivBytes: Uint8List.fromList(xPriv),
      signingEd25519: ed,
      signingEd25519PubBytes: Uint8List.fromList(ed.publicKey.bytes),
      recipientKid: recipientKid,
      signingKid: signingKid,
    );
  }

  /// Construct a [BifrostKeySet] that points at this fake's keys —
  /// useful for tests of [DirectResponseParser] / [DirectRequestBuilder]
  /// that don't need a live HTTP server.
  BifrostKeySet keySet() {
    final recipient = BifrostRecipientKey(
      kid: recipientKid,
      pub: recipientX25519PubBytes,
    );
    final signer = BifrostSigningKey(
      kid: signingKid,
      pub: signingEd25519PubBytes,
    );
    return BifrostKeySet(
      activeRecipient: recipient,
      recipientsByKid: {recipientKid: recipient},
      signersByKid: {signingKid: signer},
      revokedKids: const {},
    );
  }

  /// Build the JWKS JSON body the resolver expects.
  String jwksBody() {
    final keys = <Map<String, dynamic>>[
      {
        'kid': recipientKid,
        'kty': 'OKP',
        'crv': 'X25519',
        'use': 'enc',
        'x': _b64Url(recipientX25519PubBytes),
      },
      {
        'kid': signingKid,
        'kty': 'OKP',
        'crv': 'Ed25519',
        'use': 'sig',
        'x': _b64Url(signingEd25519PubBytes),
      },
    ];
    return jsonEncode({'keys': keys});
  }

  /// Returns an http.Client wired to this fake server.
  http.Client httpClient() {
    return MockClient((req) async {
      final path = req.url.path;
      if (path.endsWith('/.well-known/jwks.json')) {
        jwksFetchCount++;
        final raw = jwksRawOverride ?? jwksBody();
        return http.Response(
          raw,
          jwksStatusCode,
          headers: {'content-type': 'application/json'},
        );
      }
      return await _handle(req);
    });
  }

  Future<http.Response> _handle(http.BaseRequest req) async {
    if (req is! http.Request) {
      return http.Response('expected Request', 500);
    }
    final routePath = req.url.path;
    final compact = req.body;
    final reqId = req.headers['X-LS-Request-Id'] ?? '';

    final decoded = await _decryptIncoming(compact);

    // ─── Wire-shape enforcement (mirrors Bifrost's jws-verifier +
    //     parseDirectBody so SDK drift surfaces here, not in prod).
    _assertInnerJwsClaimShape(routePath, decoded.jwsClaims);
    if (routePath.endsWith('/register')) {
      _assertEphemeralPubkeyBinding(decoded.jwsHeader, decoded.jwsClaims);
    }

    requests.add(FakeRequestRecord(
      routePath: routePath,
      requestId: reqId,
      headers: Map<String, String>.from(req.headers),
      jweHeader: decoded.jweHeader,
      jwsHeader: decoded.jwsHeader,
      jwsClaims: decoded.jwsClaims,
      compactJwe: compact,
      innerJws: decoded.innerJws,
    ));

    final spec =
        responses[routePath] ?? const FakeResponseSpec(statusCode: 404);
    if (spec.rawBody != null) {
      return http.Response(spec.rawBody!, spec.statusCode,
          headers: {'content-type': 'application/json'});
    }

    // For /register the SDK has no durable identity yet — we must reply
    // to the *ephemeral* X25519 pub the SDK used as the sender. For
    // Tier-2 calls we reply to the durable X25519 pub. Both come
    // out-of-band via [clientX25519Pub]; if unset we fall back to the
    // JWE's epk (only correct if the test wrote the SDK to use the JWE
    // epk as the device key, which the production SDK does not — so the
    // fallback only works for tests that don't exercise the parser's
    // decrypt path).
    final senderX25519Pub = clientX25519Pub ?? decoded.senderX25519Pub;

    // Default-fill register response with deviceId + nonce + entitlement.
    final claims = Map<String, dynamic>.from(spec.claims);
    if (routePath.endsWith('/register')) {
      claims.putIfAbsent('device_id', () => defaultDeviceId);
      claims.putIfAbsent('server_nonce', () => defaultServerNonce);
      claims.putIfAbsent(
        'entitlement_jws',
        () => _mintEntitlementJws({
          'tier': 'pro',
          'version': 1,
          'features': {'export': true},
          'quotas': {'max_seats': 5},
        }),
      );
      claims.putIfAbsent('heartbeat_cadence_ms', () => 3600000);
    }

    final outerTyp = spec.outerTypOverride ?? kDirectJweTyp;
    final outerLcsV = spec.outerLcsVOverride ?? kDirectLcsVersion;
    final outerRoute = spec.outerRoutePathOverride ?? routePath;
    final outerReqId = spec.outerRequestIdOverride ?? reqId;

    // Wrap the response claims in the post-W6-fix-pass-2 envelope shape:
    //   { iat, nbf, exp, iss, aud, payload: <claims> }
    //     OR (sealed error)
    //   { iat, nbf, exp, iss, aud, error: <error> }
    //
    // This mirrors the production Bifrost server so the SDK's response
    // parser exercises the same unwrap path it will see in prod. Tests
    // that pass an `error` claim through `FakeResponseSpec.claims` get
    // sealed-error envelopes; everything else gets a success envelope
    // with the claims under `payload`.
    final envelopeClaims = _wrapEnvelope(
      payloadOrError: claims,
      audForRoute: routePath,
    );
    final innerJws = _signEdJws(
      typ: spec.innerTyp,
      kid: signingKid,
      claims: envelopeClaims,
    );
    final outerJwe = await _wrapResponseJwe(
      innerJwsBytes: Uint8List.fromList(utf8.encode(innerJws)),
      recipientPub: c.SimplePublicKey(senderX25519Pub, type: c.KeyPairType.x25519),
      headerExtras: {
        'typ': outerTyp,
        'lcs_v': outerLcsV,
        'route_path': outerRoute,
        'request_id': outerReqId,
        'kid': recipientKid,
      },
    );

    return http.Response(
      outerJwe,
      spec.statusCode,
      headers: {'content-type': 'application/jose+json'},
    );
  }

  Future<_Decoded> _decryptIncoming(String compact) async {
    final dec = await JweCodec.decryptCompact(
      jwe: compact,
      devicePrivBytes: recipientX25519PrivBytes,
    );
    final innerJws = utf8.decode(dec.plaintext);
    final parts = innerJws.split('.');
    final hdrBytes = _b64UrlDecode(parts[0]);
    final clmBytes = _b64UrlDecode(parts[1]);
    final hdr = (jsonDecode(utf8.decode(hdrBytes)) as Map).cast<String, dynamic>();
    final clm = (jsonDecode(utf8.decode(clmBytes)) as Map).cast<String, dynamic>();

    // Recover the sender's X25519 pub from the epk in the JWE header.
    final epk = (dec.header['epk'] as Map).cast<String, dynamic>();
    final epkX = _b64UrlDecode(epk['x'] as String);

    return _Decoded(
      jweHeader: dec.header,
      jwsHeader: hdr,
      jwsClaims: clm,
      innerJws: innerJws,
      senderX25519Pub: epkX,
    );
  }

  /// Mint an entitlement JWS the SDK can parse (the SDK's decoder is
  /// payload-only; the signature segment is irrelevant for that path
  /// but we sign properly to keep the format honest).
  String _mintEntitlementJws(Map<String, dynamic> entitlements) {
    return _signEdJws(
      typ: 'bifrost-direct+entitlement+jws',
      kid: signingKid,
      claims: entitlements,
    );
  }

  /// Wrap a per-test claims map into the post-W6-fix-pass-2 response
  /// envelope. If `payloadOrError` carries an `error` key, the envelope
  /// is built as a sealed-error envelope (no `payload` slot); otherwise
  /// the entire map is moved under `payload` so the SDK parser's
  /// `claims['payload']` unwrap returns it intact.
  Map<String, dynamic> _wrapEnvelope({
    required Map<String, dynamic> payloadOrError,
    required String audForRoute,
  }) {
    final nowMs = DateTime.now().toUtc().millisecondsSinceEpoch;
    final base = <String, dynamic>{
      'iat': nowMs,
      'nbf': nowMs,
      'exp': nowMs + 300000, // 5min
      'iss': 'bifrost-direct',
      'aud': audForRoute,
    };
    if (payloadOrError.containsKey('error')) {
      return <String, dynamic>{
        ...base,
        'error': payloadOrError['error'],
      };
    }
    return <String, dynamic>{
      ...base,
      'payload': payloadOrError,
    };
  }

  String _signEdJws({
    required String typ,
    required String kid,
    required Map<String, dynamic> claims,
  }) {
    final header = {
      'alg': 'EdDSA',
      'typ': typ,
      'kid': kid,
    };
    // Stamp iat/exp so the response parser's clock-skew check passes.
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final stamped = {
      'iat': now,
      'exp': now + 300,
      ...claims,
    };
    final hdrB64 = _b64Url(Uint8List.fromList(utf8.encode(jsonEncode(header))));
    final clmB64 = _b64Url(Uint8List.fromList(utf8.encode(jsonEncode(stamped))));
    final signingInput = ascii.encode('$hdrB64.$clmB64');
    final sig = ed25519.sign(
      signingEd25519.privateKey,
      Uint8List.fromList(signingInput),
    );
    final sigB64 = _b64Url(Uint8List.fromList(sig));
    return '$hdrB64.$clmB64.$sigB64';
  }

  Future<String> _wrapResponseJwe({
    required Uint8List innerJwsBytes,
    required c.SimplePublicKey recipientPub,
    required Map<String, dynamic> headerExtras,
  }) async {
    final ekp = await c.X25519().newKeyPair();
    final ekpPub = await ekp.extractPublicKey();

    final apu = await pubKeyThumbprint(ekpPub.bytes);
    final apv = await pubKeyThumbprint(recipientPub.bytes);

    final header = <String, dynamic>{
      'alg': 'ECDH-ES',
      'enc': 'A256GCM',
      'epk': {
        'kty': 'OKP',
        'crv': 'X25519',
        'x': _b64Url(Uint8List.fromList(ekpPub.bytes)),
      },
      'apu': apu,
      'apv': apv,
      ...headerExtras,
    };
    final headerBytes = Uint8List.fromList(utf8.encode(jsonEncode(header)));
    final protectedB64 = _b64Url(headerBytes);

    final cek = await _deriveCek(
      myKp: ekp,
      peerPub: recipientPub,
      apu: apu,
      apv: apv,
    );
    final aes = c.AesGcm.with256bits();
    final box = await aes.encrypt(
      innerJwsBytes,
      secretKey: c.SecretKey(cek),
      aad: ascii.encode(protectedB64),
    );

    return [
      protectedB64,
      '',
      _b64Url(Uint8List.fromList(box.nonce)),
      _b64Url(Uint8List.fromList(box.cipherText)),
      _b64Url(Uint8List.fromList(box.mac.bytes)),
    ].join('.');
  }

  static Future<Uint8List> _deriveCek({
    required c.SimpleKeyPair myKp,
    required c.SimplePublicKey peerPub,
    required String apu,
    required String apv,
  }) async {
    final shared = await c.X25519().sharedSecretKey(
      keyPair: myKp,
      remotePublicKey: peerPub,
    );
    final z = Uint8List.fromList(await shared.extractBytes());
    final algId = utf8.encode('A256GCM');
    final apuBytes = utf8.encode(apu);
    final apvBytes = utf8.encode(apv);

    final otherInfo = BytesBuilder()
      ..add(_u32be(algId.length))
      ..add(algId)
      ..add(_u32be(apuBytes.length))
      ..add(apuBytes)
      ..add(_u32be(apvBytes.length))
      ..add(apvBytes)
      ..add(_u32be(256));

    final hashInput = BytesBuilder()
      ..add(_u32be(1))
      ..add(z)
      ..add(otherInfo.toBytes());

    final digest = await c.Sha256().hash(hashInput.toBytes());
    return Uint8List.fromList(digest.bytes);
  }

  /// Mirrors Bifrost's `verifyDirectInnerJws` claims-shape check:
  ///   * iat / nbf / exp are NUMBERS in MILLISECONDS-SINCE-EPOCH (not
  ///     seconds — a seconds-based payload would fail the server's
  ///     clock-skew arithmetic because skew is also in ms).
  ///   * aud (audience / route-name) + jti (request id) + project_id are
  ///     present — RFC 7519 standard claim names, per the server's
  ///     `DirectJwsClaims` interface.
  ///   * device_id present iff the route is NOT /register.
  ///   * Endpoint payload is nested under `body` so the server's
  ///     parseDirectBody can lift it without colliding with the
  ///     top-level claim fields.
  ///
  /// The fake throws a StateError on drift so tests fail loudly rather
  /// than silently masking a wire bug.
  static void _assertInnerJwsClaimShape(
    String routePath,
    Map<String, dynamic> claims,
  ) {
    final iat = claims['iat'];
    final nbf = claims['nbf'];
    final exp = claims['exp'];
    if (iat is! num || nbf is! num || exp is! num) {
      throw StateError(
        'FRON wire drift: iat/nbf/exp must be numbers '
        '(iat=$iat nbf=$nbf exp=$exp)',
      );
    }
    // A timestamp under 10^12 is almost certainly seconds-since-epoch
    // (year 2001) rather than ms-since-epoch (year 33658+). Reject so
    // a seconds-mode regression on the SDK side surfaces immediately.
    const msFloor = 1000000000000; // ms-since-epoch as of 2001-09-09
    if (iat.toInt() < msFloor || exp.toInt() < msFloor) {
      throw StateError(
        'FRON wire drift: iat/exp look like SECONDS, must be MILLISECONDS '
        '(iat=$iat exp=$exp)',
      );
    }
    if (exp.toInt() <= iat.toInt()) {
      throw StateError(
        'FRON wire drift: exp ($exp) must be greater than iat ($iat)',
      );
    }
    if (claims['aud'] is! String) {
      throw StateError('FRON wire drift: aud missing or non-string');
    }
    if (claims['jti'] is! String) {
      throw StateError('FRON wire drift: jti missing or non-string');
    }
    if (claims['project_id'] is! String) {
      throw StateError('FRON wire drift: project_id missing or non-string');
    }
    final body = claims['body'];
    if (body is! Map) {
      throw StateError(
        'FRON wire drift: claims.body must be an object (got '
        '${body.runtimeType})',
      );
    }
    if (!routePath.endsWith('/register')) {
      if (claims['device_id'] is! String) {
        throw StateError(
          'FRON wire drift: durable routes must carry device_id at the '
          'top level of the JWS claims (route=$routePath)',
        );
      }
    } else {
      if (claims.containsKey('device_id')) {
        throw StateError(
          'FRON wire drift: ephemeral /register MUST NOT carry device_id '
          '(claims=$claims)',
        );
      }
    }
  }

  /// Mirrors Bifrost's defence-in-depth check in `handleRegister`: the
  /// body's `ephemeral_pubkey` MUST be byte-equal (base64url-no-pad)
  /// to the JWS header's `device_pub_jwk.x`. A swap would let an
  /// attacker bind the device to a different durable pubkey than the
  /// one that actually signed the registration.
  static void _assertEphemeralPubkeyBinding(
    Map<String, dynamic> jwsHeader,
    Map<String, dynamic> jwsClaims,
  ) {
    final body = (jwsClaims['body'] as Map).cast<String, dynamic>();
    final pubkey = body['ephemeral_pubkey'];
    if (pubkey is! String || pubkey.isEmpty) {
      throw StateError(
        'FRON wire drift: register body must carry ephemeral_pubkey',
      );
    }
    final headerJwk = jwsHeader['device_pub_jwk'];
    if (headerJwk is! Map) {
      throw StateError(
        'FRON wire drift: register JWS header must carry device_pub_jwk',
      );
    }
    final headerX = headerJwk.cast<String, dynamic>()['x'];
    if (headerX != pubkey) {
      throw StateError(
        'FRON wire drift: body.ephemeral_pubkey ($pubkey) MUST equal '
        'header.device_pub_jwk.x ($headerX)',
      );
    }
  }

  static String _b64Url(Uint8List bytes) =>
      base64Url.encode(bytes).replaceAll('=', '');

  static Uint8List _b64UrlDecode(String s) {
    final pad = (4 - s.length % 4) % 4;
    return base64Url.decode(s.padRight(s.length + pad, '='));
  }

  static Uint8List _u32be(int v) {
    final out = ByteData(4)..setUint32(0, v, Endian.big);
    return out.buffer.asUint8List();
  }
}

class _Decoded {
  final Map<String, dynamic> jweHeader;
  final Map<String, dynamic> jwsHeader;
  final Map<String, dynamic> jwsClaims;
  final String innerJws;
  final Uint8List senderX25519Pub;

  _Decoded({
    required this.jweHeader,
    required this.jwsHeader,
    required this.jwsClaims,
    required this.innerJws,
    required this.senderX25519Pub,
  });
}
