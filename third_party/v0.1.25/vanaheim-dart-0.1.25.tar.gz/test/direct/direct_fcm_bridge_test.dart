// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Tests for the FRON FCM bridge.
///
/// We feed it a fake [PushTokenProvider] whose `getToken()` + `tokenChanges`
/// + `incomingMessages` we drive from the test, then assert the bridge:
///   * sends the initial token on `start()`
///   * re-sends on rotation
///   * deduplicates a re-send of the same token
///   * ACKs incoming messages that carry `notification_id`
///   * routes errors to onError instead of crashing the stream
library;

import 'dart:async';

import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_fcm_bridge.dart';
import 'package:vanaheim/src/push/push_token_provider.dart';

class _FakePushProvider implements PushTokenProvider {
  String currentToken;
  final StreamController<String> _tokenCtrl =
      StreamController<String>.broadcast();
  final StreamController<Map<String, dynamic>> _msgCtrl =
      StreamController<Map<String, dynamic>>.broadcast();

  _FakePushProvider({this.currentToken = ''});

  @override
  Future<String> getToken() async => currentToken;

  @override
  Stream<String> get tokenChanges => _tokenCtrl.stream;

  @override
  Stream<Map<String, dynamic>> get incomingMessages => _msgCtrl.stream;

  void emitToken(String tok) {
    currentToken = tok;
    _tokenCtrl.add(tok);
  }

  void emitMessage(Map<String, dynamic> msg) => _msgCtrl.add(msg);

  Future<void> close() async {
    await _tokenCtrl.close();
    await _msgCtrl.close();
  }
}

void main() {
  group('DirectFcmBridge — initial send', () {
    test('sends the current token on start()', () async {
      final sent = <List<String>>[];
      final push = _FakePushProvider(currentToken: 'tok-init');
      final bridge = DirectFcmBridge(
        push: push,
        sendToken: (t, p) async => sent.add([t, p]),
        ack: (_, __, {bool? displayed}) async {},
      );
      await bridge.start();
      // small grace for the listener to settle.
      await Future<void>.delayed(const Duration(milliseconds: 10));

      expect(sent, hasLength(1));
      expect(sent.first[0], equals('tok-init'));
      expect(sent.first[1], isNotEmpty,
          reason: 'platform string must be filled in (ios/android/web/...)');
      await bridge.dispose();
      await push.close();
    });

    test('empty initial token does NOT send', () async {
      var sendCount = 0;
      final push = _FakePushProvider(currentToken: '');
      final bridge = DirectFcmBridge(
        push: push,
        sendToken: (_, __) async => sendCount++,
        ack: (_, __, {bool? displayed}) async {},
      );
      await bridge.start();
      await Future<void>.delayed(const Duration(milliseconds: 10));
      expect(sendCount, equals(0));
      await bridge.dispose();
      await push.close();
    });

    test('NoPushTokenProvider short-circuits start() (no send, no listener)',
        () async {
      // NoPushTokenProvider hits the early-return branch.
      var sendCount = 0;
      final bridge = DirectFcmBridge(
        push: const NoPushTokenProvider(),
        sendToken: (_, __) async => sendCount++,
        ack: (_, __, {bool? displayed}) async {},
      );
      await bridge.start();
      await Future<void>.delayed(const Duration(milliseconds: 10));
      expect(sendCount, equals(0));
      await bridge.dispose();
    });
  });

  group('DirectFcmBridge — rotation', () {
    test('token rotation triggers a re-send', () async {
      final sent = <String>[];
      final push = _FakePushProvider(currentToken: 'tok-init');
      final bridge = DirectFcmBridge(
        push: push,
        sendToken: (t, _) async => sent.add(t),
        ack: (_, __, {bool? displayed}) async {},
      );
      await bridge.start();
      await Future<void>.delayed(const Duration(milliseconds: 10));

      push.emitToken('tok-rotated-1');
      await Future<void>.delayed(const Duration(milliseconds: 10));
      push.emitToken('tok-rotated-2');
      await Future<void>.delayed(const Duration(milliseconds: 10));

      expect(sent, equals(['tok-init', 'tok-rotated-1', 'tok-rotated-2']));
      await bridge.dispose();
      await push.close();
    });

    test('duplicate token emission is deduplicated', () async {
      final sent = <String>[];
      final push = _FakePushProvider(currentToken: 'tok-x');
      final bridge = DirectFcmBridge(
        push: push,
        sendToken: (t, _) async => sent.add(t),
        ack: (_, __, {bool? displayed}) async {},
      );
      await bridge.start();
      await Future<void>.delayed(const Duration(milliseconds: 10));
      push.emitToken('tok-x'); // same as initial
      push.emitToken('tok-x'); // same again
      await Future<void>.delayed(const Duration(milliseconds: 10));

      expect(sent, equals(['tok-x']),
          reason: 'identical re-emissions must NOT hammer the server');
      await bridge.dispose();
      await push.close();
    });
  });

  group('DirectFcmBridge — incoming messages', () {
    test('message with notification_id triggers an ack call', () async {
      final acks = <String>[];
      final push = _FakePushProvider(currentToken: 'tok');
      final bridge = DirectFcmBridge(
        push: push,
        sendToken: (_, __) async {},
        ack: (id, _, {bool? displayed}) async => acks.add(id),
      );
      await bridge.start();
      push.emitMessage({'notification_id': 'noti-001', 'body': 'hello'});
      await Future<void>.delayed(const Duration(milliseconds: 10));

      expect(acks, equals(['noti-001']));
      await bridge.dispose();
      await push.close();
    });

    test('message without notification_id is silently skipped', () async {
      var ackCount = 0;
      final push = _FakePushProvider();
      final bridge = DirectFcmBridge(
        push: push,
        sendToken: (_, __) async {},
        ack: (_, __, {bool? displayed}) async => ackCount++,
      );
      await bridge.start();
      push.emitMessage({'body': 'no id here'});
      await Future<void>.delayed(const Duration(milliseconds: 10));

      expect(ackCount, equals(0));
      await bridge.dispose();
      await push.close();
    });
  });

  group('DirectFcmBridge — error routing', () {
    test('sendToken failure surfaces via onError, NOT a thrown exception',
        () async {
      Object? lastError;
      final push = _FakePushProvider(currentToken: 'tok');
      final bridge = DirectFcmBridge(
        push: push,
        sendToken: (_, __) async => throw StateError('boom'),
        ack: (_, __, {bool? displayed}) async {},
        onError: (e, _) => lastError = e,
      );
      await bridge.start();
      await Future<void>.delayed(const Duration(milliseconds: 10));

      expect(lastError, isA<StateError>());
      await bridge.dispose();
      await push.close();
    });
  });
}
