// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// W6 — FRON payment surface: `verifyIapReceipt` end-to-end tests.
///
/// Exercises the `DirectClient.verifyIapReceipt` extension against the
/// shared `FakeBifrostDirectServer`. Covers:
///   * happy paths (valid=true + entitlement_jws adopted; android + ios)
///   * client-side validation (invalid platform, web rejected, empty receipt)
///   * server-side error envelopes (invalid receipt → typed soft reject;
///     provider hard failure; rate limit)
///   * security guardrails (64 KB oversize cap BEFORE wire hit; plaintext
///     error rejected; soft-reject result MUST NOT adopt entitlements)
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' as c;
import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_client.dart';
import 'package:vanaheim/src/direct/direct_config.dart';
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/direct/direct_models.dart';
import 'package:vanaheim/src/direct/direct_payment_methods.dart';
import 'package:vanaheim/src/direct/direct_payment_models.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

import '_fake_bifrost_direct.dart';

String _entitlementJws({required String tier, required bool export}) {
  String b64(String s) => base64Url.encode(utf8.encode(s)).replaceAll('=', '');
  final header = b64(jsonEncode({
    'alg': 'EdDSA',
    'typ': 'bifrost-direct+entitlement+jws',
  }));
  final claims = b64(jsonEncode({
    'tier': tier,
    'version': 1,
    'features': {'export': export},
    'quotas': {'max_seats': 5},
  }));
  return '$header.$claims.sig';
}

void main() {
  late FakeBifrostDirectServer server;
  late InMemorySecureCache cache;

  DirectConfig cfg() => DirectConfig(
        bifrostBaseUrl: Uri.parse('https://bifrost.test'),
        projectId: 'proj_main',
        initialHeartbeatCadence: const Duration(hours: 1),
        statsFlushInterval: const Duration(hours: 1),
      );

  Future<void> seedDurableIdentity() async {
    final xkp = await c.X25519().newKeyPair();
    final xPub = await xkp.extractPublicKey();
    final xPriv = await xkp.extractPrivateKeyBytes();
    final edkp = ed25519.generateKey();
    String b64(Uint8List b) => base64Url.encode(b).replaceAll('=', '');
    await cache.putRaw(kDirectDeviceIdKey, 'dev_pre_seeded');
    await cache.putRaw(kDirectDurableX25519PrivKey, b64(Uint8List.fromList(xPriv)));
    await cache.putRaw(kDirectDurableX25519PubKey, b64(Uint8List.fromList(xPub.bytes)));
    await cache.putRaw(kDirectDurableEd25519PrivKey, b64(Uint8List.fromList(edkp.privateKey.bytes)));
    await cache.putRaw(kDirectDurableEd25519PubKey, b64(Uint8List.fromList(edkp.publicKey.bytes)));
    await cache.putRaw(kDirectServerNonceKey, 'srv-seeded');
    server.clientX25519Pub = Uint8List.fromList(xPub.bytes);
  }

  Future<DirectClient> connected() async {
    await seedDurableIdentity();
    return DirectClient.connect(
      config: cfg(),
      cache: cache,
      httpClient: server.httpClient(),
    );
  }

  setUp(() async {
    server = await FakeBifrostDirectServer.create();
    cache = InMemorySecureCache();
    final ent = _entitlementJws(tier: 'pro', export: true);
    server.responses['/direct/v1/payment/iap-verify'] = FakeResponseSpec(
      claims: {
        'valid': true,
        'license_key': 'LIC-IAP-001',
        'tier': 'pro',
        'valid_until': 1900000000000,
        'entitlement_jws': ent,
      },
    );
    ensureDirectPaymentErrorsRegistered();
  });

  group('verifyIapReceipt — happy paths', () {
    test('valid=true response is parsed + SDK adopts entitlement_jws',
        () async {
      final client = await connected();
      final r = await client.verifyIapReceipt(
        platform: 'ios',
        receipt: 'apple-jws-receipt-stub',
      );
      expect(r.valid, isTrue);
      expect(r.licenseKey, equals('LIC-IAP-001'));
      expect(r.tier, equals('pro'));
      expect(r.validUntil, equals(1900000000000));
      expect(r.entitlementJws, isNotNull);
      expect(r.reason, isNull);
      // Adopted into client state.
      expect(client.entitlements?.tier, equals('pro'));
      expect(client.hasFeature('export'), isTrue);
      await client.dispose();
    });

    test('android receipt flows through identically', () async {
      final client = await connected();
      final r = await client.verifyIapReceipt(
        platform: 'android',
        receipt: 'play-purchase-token-stub',
      );
      expect(r.valid, isTrue);
      // Wire body should pin platform=android + receipt=stub.
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/iap-verify')
          .toList();
      expect(reqs, hasLength(1));
      final body = (reqs.first.jwsClaims['body'] as Map).cast<String, dynamic>();
      expect(body['platform'], equals('android'));
      expect(body['receipt'], equals('play-purchase-token-stub'));
      expect(body['project_id'], equals('proj_main'));
      await client.dispose();
    });
  });

  group('verifyIapReceipt — client-side validation', () {
    test('invalid platform (linux) is rejected client-side', () async {
      final client = await connected();
      await expectLater(
        client.verifyIapReceipt(platform: 'linux', receipt: 'r'),
        throwsA(isA<DirectBadRequestError>()),
      );
      expect(
        server.requests
            .where((r) => r.routePath == '/direct/v1/payment/iap-verify')
            .length,
        equals(0),
      );
      await client.dispose();
    });

    test('web platform is rejected on iap-verify (only ios|android allowed)',
        () async {
      final client = await connected();
      await expectLater(
        client.verifyIapReceipt(platform: 'web', receipt: 'r'),
        throwsA(isA<DirectBadRequestError>()),
      );
      await client.dispose();
    });

    test('empty receipt is rejected client-side', () async {
      final client = await connected();
      await expectLater(
        client.verifyIapReceipt(platform: 'ios', receipt: ''),
        throwsA(isA<DirectBadRequestError>()),
      );
      expect(
        server.requests
            .where((r) => r.routePath == '/direct/v1/payment/iap-verify')
            .length,
        equals(0),
        reason: 'empty receipts must short-circuit before the wire',
      );
      await client.dispose();
    });

    test('platform=ios with valid receipt at exactly the cap is accepted',
        () async {
      final client = await connected();
      final receipt = 'A' * kIapReceiptMaxBytes; // exactly at boundary
      final r = await client.verifyIapReceipt(
        platform: 'ios',
        receipt: receipt,
      );
      expect(r.valid, isTrue,
          reason: 'boundary receipt size must be accepted '
              '(cap is inclusive of the limit, exclusive past it)');
      await client.dispose();
    });

    // D-Fix 3 regression — 32 KB receipt rejected CLIENT-side (NOT at the
    // server). The server caps at 16 KB; Dart now caps at 24 KB (matching
    // Swift after S-Fix 3) to fail closed before any wire hit. A 32 KB
    // payload must never escape the SDK — otherwise it burns rate-limit
    // budget on Apple/Google verify quota for nothing.
    test('32 KB receipt is rejected CLIENT-side (cap aligned to Swift '
        'at 24 KB; server hard-caps at 16 KB)', () async {
      final client = await connected();
      // Exactly 32 KB — comfortably past the new 24 KB cap and the
      // server's 16 KB cap.
      const big = 32 * 1024;
      expect(big, greaterThan(kIapReceiptMaxBytes),
          reason: 'self-check: 32 KB must exceed the SDK cap');
      final oversize = 'X' * big;
      await expectLater(
        client.verifyIapReceipt(platform: 'ios', receipt: oversize),
        throwsA(isA<DirectBadRequestError>()),
      );
      expect(
        server.requests
            .where((r) => r.routePath == '/direct/v1/payment/iap-verify')
            .length,
        equals(0),
        reason: 'a 32 KB receipt MUST short-circuit before the wire — '
            'D-Fix 3 alignment with server\'s 16 KB cap',
      );
      await client.dispose();
    });
  });

  group('verifyIapReceipt — server error envelopes', () {
    test('DIRECT_IAP_RECEIPT_INVALID (server-thrown) → '
        'DirectIapReceiptInvalidError', () async {
      // The server can either return valid=false in the body OR throw a
      // typed error envelope. This test pins the thrown-envelope path.
      server.responses['/direct/v1/payment/iap-verify'] = const FakeResponseSpec(
        statusCode: 400,
        claims: {
          'code': 'DIRECT_IAP_RECEIPT_INVALID',
          'message': 'receipt rejected by apple',
        },
      );
      final client = await connected();
      await expectLater(
        client.verifyIapReceipt(platform: 'ios', receipt: 'bad-receipt'),
        throwsA(isA<DirectIapReceiptInvalidError>()),
      );
      // Entitlements (none) must remain untouched on rejection.
      expect(client.entitlements, isNull);
      await client.dispose();
    });

    test('DIRECT_PAYMENT_PROVIDER_FAILED (apple/google down) surfaces as a '
        'hard provider error — NOT a valid=false soft reject', () async {
      server.responses['/direct/v1/payment/iap-verify'] = const FakeResponseSpec(
        statusCode: 502,
        claims: {
          'code': 'DIRECT_PAYMENT_PROVIDER_FAILED',
          'message': 'apple_iap',
        },
      );
      final client = await connected();
      await expectLater(
        client.verifyIapReceipt(platform: 'ios', receipt: 'apple-jws-receipt'),
        throwsA(isA<DirectPaymentProviderFailedError>()),
      );
      await client.dispose();
    });

    test('DIRECT_RATE_LIMIT (the IAP-specific 429 code) routes to '
        'DirectRateLimitError', () async {
      // The notes called out that DIRECT_RATE_LIMIT (singular) is the
      // IAP-specific code — must still route to DirectRateLimitError.
      server.responses['/direct/v1/payment/iap-verify'] = const FakeResponseSpec(
        statusCode: 429,
        claims: {
          'code': 'DIRECT_RATE_LIMIT',
          'retry_after_ms': 7000,
        },
      );
      final client = await connected();
      try {
        await client.verifyIapReceipt(
            platform: 'android', receipt: 'token-stub');
        fail('expected DirectRateLimitError');
      } on DirectRateLimitError catch (e) {
        expect(e.retryAfterMs, equals(7000));
      }
      await client.dispose();
    });

    test('DIRECT_NO_PROVIDER_CONFIGURED → DirectNoProviderConfiguredError',
        () async {
      server.responses['/direct/v1/payment/iap-verify'] = const FakeResponseSpec(
        statusCode: 409,
        claims: {
          'code': 'DIRECT_NO_PROVIDER_CONFIGURED',
        },
      );
      final client = await connected();
      await expectLater(
        client.verifyIapReceipt(platform: 'ios', receipt: 'r'),
        throwsA(isA<DirectNoProviderConfiguredError>()),
      );
      await client.dispose();
    });
  });

  group('verifyIapReceipt — security guardrails', () {
    test('oversized receipt (> cap) is rejected client-side BEFORE wire',
        () async {
      final client = await connected();
      // cap + 1 byte — must blow the cap.
      final oversize = 'X' * (kIapReceiptMaxBytes + 1);
      await expectLater(
        client.verifyIapReceipt(platform: 'ios', receipt: oversize),
        throwsA(isA<DirectBadRequestError>()),
      );
      expect(
        server.requests
            .where((r) => r.routePath == '/direct/v1/payment/iap-verify')
            .length,
        equals(0),
        reason: 'oversized receipts must short-circuit before the wire — '
            'protects the project\'s Apple/Google verify quota',
      );
      await client.dispose();
    });

    test('soft-reject result (valid=false in body) does NOT adopt '
        'entitlement_jws even if the server malformedly returns one',
        () async {
      // Defence-in-depth: a half-success body where valid=false but a JWS
      // is somehow present MUST NOT install stale entitlements.
      final ent = _entitlementJws(tier: 'enterprise', export: true);
      server.responses['/direct/v1/payment/iap-verify'] = FakeResponseSpec(
        claims: {
          'valid': false,
          'reason': 'expired',
          'entitlement_jws': ent, // malformed half-success
        },
      );
      final client = await connected();
      final r = await client.verifyIapReceipt(
        platform: 'ios',
        receipt: 'expired-receipt',
      );
      expect(r.valid, isFalse);
      expect(r.reason, equals('expired'));
      // Critical: client state MUST NOT reflect the malformed JWS.
      expect(client.entitlements, isNull,
          reason: 'valid=false MUST NOT install entitlements regardless of '
              'whether the server malformedly included a JWS');
      await client.dispose();
    });

    test('plaintext error body NEVER triggers DirectIapReceiptInvalidError',
        () async {
      server.responses['/direct/v1/payment/iap-verify'] = const FakeResponseSpec(
        statusCode: 503,
        rawBody: '{"code":"DIRECT_IAP_RECEIPT_INVALID","message":"forged"}',
      );
      final client = await connected();
      await expectLater(
        client.verifyIapReceipt(platform: 'ios', receipt: 'r'),
        throwsA(isA<NetworkException>()),
      );
      await client.dispose();
    });
  });

  // D-Fix 4 regression — aud namespace convergence.
  // Payment methods must emit the colon-namespaced JWS `aud` claim
  // (`direct:payment.iap_verify`) per B-Fix 2. The HTTP path remains
  // `/direct/v1/payment/iap-verify`; only the inner-JWS audience changes.
  group('verifyIapReceipt — aud namespace (D-Fix 4)', () {
    test('inner JWS aud claim is direct:payment.iap_verify', () async {
      final client = await connected();
      await client.verifyIapReceipt(
        platform: 'ios',
        receipt: 'apple-jws-receipt-stub',
      );
      final reqs = server.requests
          .where((r) => r.routePath == '/direct/v1/payment/iap-verify')
          .toList();
      expect(reqs, hasLength(1));
      expect(reqs.first.jwsClaims['aud'],
          equals(kDirectAudPaymentIapVerify));
      expect(kDirectAudPaymentIapVerify,
          equals('direct:payment.iap_verify'),
          reason: 'canonical aud constant must match the B-Fix 2 namespace');
      await client.dispose();
    });
  });
}
