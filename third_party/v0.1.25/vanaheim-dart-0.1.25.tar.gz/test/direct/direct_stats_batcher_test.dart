// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Tests for the FRON stats batcher — flush on size, flush on time,
/// rollback on shipper failure, persistence across restarts, and the
/// ring-buffer drop semantics when the buffer is full and offline.
library;

import 'dart:async';

import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_models.dart';
import 'package:vanaheim/src/direct/direct_stats_batcher.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

void main() {
  group('DirectStatsBatcher — enqueue + size-triggered flush', () {
    test('flushes when buffer hits flushBatchSize', () async {
      final cache = InMemorySecureCache();
      final shipped = <List<StatsEvent>>[];
      final b = DirectStatsBatcher(
        cache: cache,
        flushInterval: const Duration(seconds: 30),
        flushBatchSize: 3,
        capacity: 100,
        shipper: (events) async {
          shipped.add(List.of(events));
          return StatsResult(accepted: events.length, rejected: 0);
        },
      );
      await b.start();
      await b.enqueue(_ev('a'));
      await b.enqueue(_ev('b'));
      await b.enqueue(_ev('c'));
      // size trigger fires fire-and-forget — let it land.
      await Future<void>.delayed(const Duration(milliseconds: 30));
      await b.dispose();

      expect(shipped, hasLength(1));
      expect(shipped.first.map((e) => e.name), equals(['a', 'b', 'c']));
    });

    test('manual flush() returns the shipper result + clears the buffer',
        () async {
      final cache = InMemorySecureCache();
      final b = DirectStatsBatcher(
        cache: cache,
        flushInterval: const Duration(seconds: 30),
        flushBatchSize: 100,
        capacity: 100,
        shipper: (events) async =>
            StatsResult(accepted: events.length, rejected: 0),
      );
      await b.start();
      await b.enqueue(_ev('x'));
      await b.enqueue(_ev('y'));
      final result = await b.flush();
      expect(result, isNotNull);
      expect(result!.accepted, equals(2));
      expect(b.bufferedCount, equals(0));
      await b.dispose();
    });

    test('flush() on empty buffer returns null (no spurious network call)',
        () async {
      var calls = 0;
      final b = DirectStatsBatcher(
        cache: InMemorySecureCache(),
        flushInterval: const Duration(seconds: 30),
        flushBatchSize: 100,
        capacity: 100,
        shipper: (_) async {
          calls++;
          return const StatsResult(accepted: 0, rejected: 0);
        },
      );
      await b.start();
      final r = await b.flush();
      expect(r, isNull);
      expect(calls, equals(0));
      await b.dispose();
    });
  });

  group('DirectStatsBatcher — failure handling', () {
    test('shipper failure rolls events back into the buffer + persists',
        () async {
      final cache = InMemorySecureCache();
      Object? lastError;
      final b = DirectStatsBatcher(
        cache: cache,
        flushInterval: const Duration(seconds: 30),
        flushBatchSize: 100,
        capacity: 100,
        shipper: (_) async => throw StateError('network down'),
        onError: (e, _) => lastError = e,
      );
      await b.start();
      await b.enqueue(_ev('keep1'));
      await b.enqueue(_ev('keep2'));
      final r = await b.flush();
      expect(r, isNull);
      expect(lastError, isA<StateError>());
      expect(b.bufferedCount, equals(2),
          reason: 'failed batch must roll back into the buffer for retry');

      // Persisted blob is non-empty so a process kill won't lose them.
      expect(await cache.getRaw(kDirectStatsBufferKey), isNotNull);
      await b.dispose();
    });
  });

  group('DirectStatsBatcher — capacity + drops', () {
    test('oldest event dropped when full + droppedCount increments',
        () async {
      final b = DirectStatsBatcher(
        cache: InMemorySecureCache(),
        flushInterval: const Duration(seconds: 30),
        flushBatchSize: 100,
        capacity: 3,
        shipper: (_) async => const StatsResult(accepted: 0, rejected: 0),
      );
      await b.start();
      await b.enqueue(_ev('a'));
      await b.enqueue(_ev('b'));
      await b.enqueue(_ev('c'));
      await b.enqueue(_ev('d')); // forces drop of 'a'
      await b.enqueue(_ev('e')); // forces drop of 'b'

      expect(b.bufferedCount, equals(3));
      expect(b.droppedCount, equals(2));
      await b.dispose();
    });
  });

  group('DirectStatsBatcher — persistence across restart', () {
    test('persisted events are restored on the next start()', () async {
      final cache = InMemorySecureCache();

      // Run 1: enqueue but never flush (shipper always fails).
      final b1 = DirectStatsBatcher(
        cache: cache,
        flushInterval: const Duration(seconds: 30),
        flushBatchSize: 100,
        capacity: 100,
        shipper: (_) async => throw StateError('offline'),
      );
      await b1.start();
      await b1.enqueue(_ev('survives_1'));
      await b1.enqueue(_ev('survives_2'));
      await b1.dispose();

      // Simulate restart with a fresh batcher + the same cache.
      final shipped = <List<StatsEvent>>[];
      final b2 = DirectStatsBatcher(
        cache: cache,
        flushInterval: const Duration(seconds: 30),
        flushBatchSize: 100,
        capacity: 100,
        shipper: (events) async {
          shipped.add(List.of(events));
          return StatsResult(accepted: events.length, rejected: 0);
        },
      );
      await b2.start();
      expect(b2.bufferedCount, equals(2),
          reason: 'restored events must reappear in the buffer');
      await b2.flush();
      await b2.dispose();
      expect(shipped, hasLength(1));
      expect(shipped.first.map((e) => e.name),
          equals(['survives_1', 'survives_2']));
    });

    test('corrupt persisted blob is wiped + start() succeeds clean',
        () async {
      final cache = InMemorySecureCache();
      await cache.putRaw(kDirectStatsBufferKey, 'not valid json');
      final b = DirectStatsBatcher(
        cache: cache,
        flushInterval: const Duration(seconds: 30),
        flushBatchSize: 100,
        capacity: 100,
        shipper: (_) async => const StatsResult(accepted: 0, rejected: 0),
      );
      await b.start();
      expect(b.bufferedCount, equals(0));
      await b.dispose();
    });
  });
}

StatsEvent _ev(String name) => StatsEvent(
      name: name,
      timestampMs: DateTime.now().toUtc().millisecondsSinceEpoch,
      attributes: const {'k': 'v'},
    );
