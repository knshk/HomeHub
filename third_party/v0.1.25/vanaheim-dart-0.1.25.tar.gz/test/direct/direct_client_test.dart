// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// End-to-end tests for `DirectClient` covering the Tier-2 durable surface
/// (activate, verify, heartbeat, deactivate, catalog, ack-rotate) plus
/// register at the integration level.
///
/// The current FRON wire format does NOT transmit the device's X25519
/// public key in the request envelope — so to encrypt the response the
/// fake server needs that key out-of-band. For Tier-2 tests we pre-seed
/// the SecureCache with a known durable identity whose X25519 pub we
/// register on the fake server before each call. For the register test
/// we use a one-shot ephemeral identity that we generate in the test +
/// inject into a special-purpose keypair store the SDK uses.
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart' as c;
import 'package:ed25519_edwards/ed25519_edwards.dart' as ed25519;
import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_client.dart';
import 'package:vanaheim/src/direct/direct_config.dart';
import 'package:vanaheim/src/direct/direct_keypair_store.dart';
import 'package:vanaheim/src/direct/direct_models.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';

import '_fake_bifrost_direct.dart';

void main() {
  late FakeBifrostDirectServer server;
  late InMemorySecureCache cache;

  /// Pre-seeded durable identity bytes. Tests that exercise Tier-2 calls
  /// pre-populate the cache with these so the SDK rehydrates the identity
  /// on `connect()` and the fake server can target its responses to a
  /// known X25519 pub.
  late Uint8List devX25519Priv;
  late Uint8List devX25519Pub;
  late Uint8List devEd25519Priv;
  late Uint8List devEd25519Pub;

  DirectConfig cfg() => DirectConfig(
        bifrostBaseUrl: Uri.parse('https://bifrost.test'),
        projectId: 'proj_main',
        initialHeartbeatCadence: const Duration(hours: 1),
        statsFlushInterval: const Duration(hours: 1),
      );

  /// Pre-populate the cache with a known durable identity + tell the
  /// fake server to use its X25519 pub as the response recipient.
  Future<void> seedDurableIdentity() async {
    final xkp = await c.X25519().newKeyPair();
    final xPub = await xkp.extractPublicKey();
    final xPriv = await xkp.extractPrivateKeyBytes();
    devX25519Priv = Uint8List.fromList(xPriv);
    devX25519Pub = Uint8List.fromList(xPub.bytes);
    final edkp = ed25519.generateKey();
    devEd25519Priv = Uint8List.fromList(edkp.privateKey.bytes);
    devEd25519Pub = Uint8List.fromList(edkp.publicKey.bytes);

    String b64(Uint8List b) =>
        base64Url.encode(b).replaceAll('=', '');
    await cache.putRaw(kDirectDeviceIdKey, 'dev_pre_seeded');
    await cache.putRaw(kDirectDurableX25519PrivKey, b64(devX25519Priv));
    await cache.putRaw(kDirectDurableX25519PubKey, b64(devX25519Pub));
    await cache.putRaw(kDirectDurableEd25519PrivKey, b64(devEd25519Priv));
    await cache.putRaw(kDirectDurableEd25519PubKey, b64(devEd25519Pub));
    await cache.putRaw(kDirectServerNonceKey, 'srv-seeded');

    server.clientX25519Pub = devX25519Pub;
  }

  setUp(() async {
    server = await FakeBifrostDirectServer.create();
    cache = InMemorySecureCache();
    server.responses['/direct/v1/register'] = const FakeResponseSpec();
    server.responses['/direct/v1/activate'] = FakeResponseSpec(claims: {
      'entitlement_jws': _entitlementJws(tier: 'pro', export: true),
    });
    server.responses['/direct/v1/verify'] = FakeResponseSpec(claims: {
      'entitlement_jws': _entitlementJws(tier: 'pro', export: true),
      'issued_at_ms': 1700000000000,
      'heartbeat_cadence_ms': 3600000,
      'server_nonce': 'srv-rotated',
    });
    server.responses['/direct/v1/heartbeat'] =
        const FakeResponseSpec(claims: {'heartbeat_cadence_ms': 7200000});
    server.responses['/direct/v1/deactivate'] =
        const FakeResponseSpec(claims: {});
    server.responses['/direct/v1/catalog'] = const FakeResponseSpec(claims: {
      'catalog': {
        'version': 3,
        'tiers': [
          {'id': 'free', 'display_name': 'Free', 'features': ['x']},
          {
            'id': 'pro',
            'display_name': 'Pro',
            'features': ['x', 'y'],
            'price_minor': 999,
            'currency': 'USD',
          },
        ],
      },
    });
    server.responses['/direct/v1/keys/rotate-ack'] =
        const FakeResponseSpec(claims: {});
  });

  group('DirectClient — connect', () {
    test('connect pulls JWKS + reports isRegistered=false on fresh cache',
        () async {
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      expect(client.isRegistered, isFalse);
      expect(server.jwksFetchCount, equals(1),
          reason: 'connect() must pull JWKS up-front');
      await client.dispose();
    });

    test('connect rehydrates a pre-seeded durable identity', () async {
      await seedDurableIdentity();
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      expect(client.isRegistered, isTrue,
          reason: 'durable identity must rehydrate from SecureCache');
      await client.dispose();
    });

    test('connect tolerates JWKS HTTP failure (lazy retry later)',
        () async {
      server.jwksStatusCode = 500;
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      // No throw — JWKS is fetched lazily on the next call.
      expect(client.isRegistered, isFalse);
      await client.dispose();
    });
  });

  group('DirectClient — Tier 2 calls (pre-seeded identity)', () {
    test('activate refreshes entitlements + reports the device id',
        () async {
      await seedDurableIdentity();
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      // Swap activate to deliver "free" so we can confirm the switch.
      server.responses['/direct/v1/activate'] = FakeResponseSpec(claims: {
        'entitlement_jws': _entitlementJws(tier: 'free', export: false),
      });
      final a = await client.activate('LIC-NEW');
      expect(a.entitlements.tier, equals('free'));
      expect(client.hasFeature('export'), isFalse);
      await client.dispose();
    });

    test('verify pulls fresh entitlements + persists rotated nonce',
        () async {
      await seedDurableIdentity();
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      final v = await client.verify();
      expect(v.entitlements.tier, equals('pro'));
      expect(v.issuedAtMs, equals(1700000000000));
      expect(await cache.getRaw(kDirectServerNonceKey), equals('srv-rotated'));
      await client.dispose();
    });

    test('heartbeat updates cadence + reports alive=true', () async {
      await seedDurableIdentity();
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      final hb = await client.heartbeat();
      expect(hb.alive, isTrue);
      expect(hb.heartbeatCadenceMs, equals(7200000));
      await client.dispose();
    });

    test('deactivate wipes durable identity', () async {
      await seedDurableIdentity();
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      expect(await cache.getRaw(kDirectDeviceIdKey), isNotNull);

      await client.deactivate('user requested uninstall');

      expect(client.isRegistered, isFalse);
      expect(client.entitlements, isNull);
      expect(await cache.getRaw(kDirectDeviceIdKey), isNull,
          reason: 'deactivate must wipe every persisted keypair slot');
      await client.dispose();
    });

    test('getCatalog returns a parsed CatalogSnapshot', () async {
      await seedDurableIdentity();
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      final snap = await client.getCatalog();
      expect(snap.version, equals(3));
      expect(snap.tiers, hasLength(2));
      expect(snap.tiers.first.id, equals('free'));
      expect(snap.tiers.last.id, equals('pro'));
      expect(snap.tiers.last.priceMinor, equals(999));
      expect(snap.tiers.last.currency, equals('USD'));
      await client.dispose();
    });

    test('acknowledgeKidRotation hits /keys/rotate-ack + refreshes JWKS',
        () async {
      await seedDurableIdentity();
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      final jwksBefore = server.jwksFetchCount;
      await client.acknowledgeKidRotation('fron-sig-1');
      expect(server.jwksFetchCount, greaterThan(jwksBefore),
          reason: 'kid-rotation ack must force a JWKS refresh');
      final acked = server.requests
          .where((r) => r.routePath == '/direct/v1/keys/rotate-ack')
          .toList();
      expect(acked, hasLength(1));
      final ackBody =
          (acked.first.jwsClaims['body'] as Map).cast<String, dynamic>();
      expect(ackBody['kid'], equals('fron-sig-1'),
          reason: 'caller body fields live under .body, not the JWS top level');
      await client.dispose();
    });
  });

  group('DirectClient — pre-condition guards', () {
    test('activate before register throws NotConnectedException', () async {
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      await expectLater(
        client.activate('L'),
        throwsA(isA<NotConnectedException>()),
      );
      await client.dispose();
    });

    test('hasFeature / quota return safe defaults before register', () async {
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      expect(client.hasFeature('anything'), isFalse);
      expect(client.quota('anything'), equals(0));
      await client.dispose();
    });

    test('sendStats with empty list is a no-op', () async {
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      final r = await client.sendStats(const []);
      expect(r.accepted, equals(0));
      expect(r.rejected, equals(0));
      await client.dispose();
    });

    test('dispose is idempotent', () async {
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      await client.dispose();
      await client.dispose(); // must not throw
    });
  });

  group('DirectClient — request shape on the wire', () {
    test('Tier-2 calls carry X-LS-Project-Id + JOSE content-type', () async {
      await seedDurableIdentity();
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      await client.verify();
      final verifyReqs = server.requests
          .where((r) => r.routePath == '/direct/v1/verify')
          .toList();
      expect(verifyReqs, hasLength(1));
      final req = verifyReqs.first;
      expect(req.headers['X-LS-Project-Id'], equals('proj_main'));
      expect(req.headers['Content-Type'], equals('application/jose+json'));
      // Durable JWS embeds device_id at the top of the claims (server
      // verifier looks for it there); server_nonce lives inside .body
      // alongside any caller fields so the server's parseDirectBody can
      // surface it.
      expect(req.jwsClaims['device_id'], equals('dev_pre_seeded'));
      final body =
          (req.jwsClaims['body'] as Map).cast<String, dynamic>();
      expect(body['server_nonce'], equals('srv-seeded'));
      expect(req.jwsHeader['typ'], equals('bifrost-direct+durable+jws'));
      await client.dispose();
    });
  });

  group('DirectClient — DIRECT_DEVICE_REVOKED handling', () {
    test('heartbeat that returns DIRECT_DEVICE_REVOKED inside a JWE '
        'envelope clears entitlements + cached JWS so hasFeature/quota '
        'fail-CLOSED immediately', () async {
      await seedDurableIdentity();
      // Stand up a verify response so the client gets entitlements
      // first, THEN the next heartbeat returns the revoked envelope.
      server.responses['/direct/v1/verify'] = FakeResponseSpec(claims: {
        'entitlement_jws': _entitlementJws(tier: 'pro', export: true),
        'issued_at_ms': 1700000000000,
        'heartbeat_cadence_ms': 3600000,
        'server_nonce': 'srv-rotated',
      });
      server.responses['/direct/v1/heartbeat'] = const FakeResponseSpec(
        statusCode: 410,
        claims: {
          'code': 'DIRECT_DEVICE_REVOKED',
          'message': 'admin revoked',
        },
      );
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      // Prime entitlements via verify().
      await client.verify();
      expect(client.hasFeature('export'), isTrue,
          reason: 'pre-revoke verify must populate entitlements');
      // Heartbeat → revoked envelope (authenticated inside the JWE).
      await expectLater(
        client.heartbeat(),
        throwsA(isA<DirectDeviceRevokedError>()),
      );
      // Critical: hasFeature/quota MUST fail-closed AFTER the throw.
      expect(client.hasFeature('export'), isFalse,
          reason: 'entitlements must be wiped synchronously on '
              'DIRECT_DEVICE_REVOKED — a stale cache would leak access '
              'to a revoked session');
      expect(client.quota('max_seats'), equals(0));
      expect(client.entitlements, isNull);
      expect(client.entitlementJws, isNull);
      // Durable keypair slots must also be wiped (defence-in-depth).
      expect(await cache.getRaw(kDirectDeviceIdKey), isNull);
      expect(await cache.getRaw(kDirectDurableX25519PrivKey), isNull);
      await client.dispose();
    });

    test('plaintext HTTP error body (NOT inside a JWE) NEVER triggers '
        'keypair wipe — surfaces as NetworkException', () async {
      await seedDurableIdentity();
      // Pre-populate entitlements so we can confirm they survive the
      // plaintext error.
      server.responses['/direct/v1/verify'] = FakeResponseSpec(claims: {
        'entitlement_jws': _entitlementJws(tier: 'pro', export: true),
        'issued_at_ms': 1700000000000,
        'heartbeat_cadence_ms': 3600000,
        'server_nonce': 'srv-rotated',
      });
      // Heartbeat replies with a plaintext-JSON error envelope (e.g. a
      // gateway proxy returning 503 + a body that *looks* like a wire
      // error code). The SDK MUST NOT honour this — only JWE-wrapped,
      // Ed25519-verified error envelopes may trigger destructive flows.
      server.responses['/direct/v1/heartbeat'] = const FakeResponseSpec(
        statusCode: 503,
        rawBody: '{"code":"DIRECT_DEVICE_REVOKED",'
            '"message":"forged by attacker"}',
      );
      final client = await DirectClient.connect(
        config: cfg(),
        cache: cache,
        httpClient: server.httpClient(),
      );
      await client.verify();
      expect(client.hasFeature('export'), isTrue);
      // The heartbeat should surface a NetworkException (because the
      // body wasn't a valid 5-segment JWE), NOT a DirectDeviceRevokedError.
      await expectLater(
        client.heartbeat(),
        throwsA(isA<NetworkException>()),
      );
      // Entitlements + keypair must survive intact — a forged plaintext
      // body has no authority over SDK state.
      expect(client.hasFeature('export'), isTrue,
          reason: 'plaintext error body MUST NOT clear entitlements');
      expect(client.isRegistered, isTrue,
          reason: 'plaintext error body MUST NOT wipe the durable keypair');
      expect(await cache.getRaw(kDirectDeviceIdKey), isNotNull);
      await client.dispose();
    });
  });
}

/// Synthesize a minimal entitlement JWS the DirectClient can decode.
/// The SDK only reads the claims segment (the outer JWS that carried
/// this string IS the trust root); the signature can be any byte string.
String _entitlementJws({required String tier, required bool export}) {
  String b64(String s) =>
      base64Url.encode(utf8.encode(s)).replaceAll('=', '');
  final header = b64(jsonEncode({
    'alg': 'EdDSA',
    'typ': 'bifrost-direct+entitlement+jws',
  }));
  final claims = b64(jsonEncode({
    'tier': tier,
    'version': 1,
    'features': {'export': export},
    'quotas': {'max_seats': 5},
  }));
  return '$header.$claims.sig';
}

