// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Tests for `DirectRecipientResolver` — JWKS fetch + base-URL validation.
///
/// The JWKS body IS the trust root for every FRON call (it carries
/// Bifrost's X25519 recipient pubkey + Ed25519 signing pubkey). If we
/// let the SDK fetch it over plain HTTP a network attacker could swap
/// the entire key set and silently MITM the SDK — so the resolver
/// MUST reject non-HTTPS base URLs at construction time, with the only
/// exception being explicit loopback for local testing.
library;

import 'package:test/test.dart';
import 'package:vanaheim/src/direct/direct_recipient_resolver.dart';

void main() {
  group('DirectRecipientResolver — base URL scheme validation', () {
    test('accepts an https:// base URL', () {
      expect(
        () => DirectRecipientResolver(
          bifrostBaseUrl: Uri.parse('https://bifrost.example.com'),
        ),
        returnsNormally,
      );
    });

    test('accepts http://localhost (loopback escape hatch for tests)', () {
      expect(
        () => DirectRecipientResolver(
          bifrostBaseUrl: Uri.parse('http://localhost:8787'),
        ),
        returnsNormally,
      );
    });

    test('accepts http://127.0.0.1 (loopback escape hatch for tests)', () {
      expect(
        () => DirectRecipientResolver(
          bifrostBaseUrl: Uri.parse('http://127.0.0.1:8787'),
        ),
        returnsNormally,
      );
    });

    test('rejects a non-loopback http:// URL with ArgumentError', () {
      expect(
        () => DirectRecipientResolver(
          bifrostBaseUrl: Uri.parse('http://bifrost.example.com'),
        ),
        throwsA(isA<ArgumentError>().having(
          (e) => e.message.toString(),
          'message',
          contains('https'),
        )),
      );
    });

    test('rejects an http:// URL with a hostname that merely contains '
        '"localhost" but isn\'t actually loopback', () {
      // A naïve `contains("localhost")` check would let
      // `localhost.attacker.com` through. The validator must compare
      // the host EXACTLY.
      expect(
        () => DirectRecipientResolver(
          bifrostBaseUrl: Uri.parse('http://localhost.attacker.com'),
        ),
        throwsA(isA<ArgumentError>()),
      );
    });

    test('rejects an unknown scheme (ws://, file://, etc.)', () {
      expect(
        () => DirectRecipientResolver(
          bifrostBaseUrl: Uri.parse('ws://bifrost.example.com'),
        ),
        throwsA(isA<ArgumentError>()),
      );
    });
  });
}
