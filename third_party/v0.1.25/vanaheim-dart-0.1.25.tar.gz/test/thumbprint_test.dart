// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Cross-SDK lock-in for the JWE `apu` (PartyUInfo) thumbprint helper.
///
/// Twin of `sdk/swift/LicenseStoreSDK/Tests/LicenseStoreSDKTests/ThumbprintTests.swift`.
/// The same three byte-vectors (zero/ones/range) are pinned to the SAME
/// expected b64url-SHA256 strings. If a future code change drifts the
/// encoding on either side (e.g. swaps to padded base64url, or hashes the
/// SubjectPublicKeyInfo instead of the raw pub), one of these tests fails
/// loudly BEFORE the change ships and breaks cross-SDK interop with the
/// server's AAD cross-check.
///
/// Reference values were computed independently via Python:
///   `base64.urlsafe_b64encode(hashlib.sha256(bytes).digest()).rstrip(b'=')`
///
/// Keep these strings IN LOCKSTEP with the Swift twin — never edit one
/// without the other.
library;

import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:vanaheim/src/crypto/jwe.dart'
    show DeviceKeypairProvider;
import 'package:vanaheim/src/crypto/thumbprint.dart';
import 'package:test/test.dart';

/// Minimal `DeviceKeypairProvider` that returns a fixed pubkey. The interface
/// only mandates `getPublicKey()`, so we don't need to fake a private key.
/// Used to drive the async overload of `devicePubThumbprint` without touching
/// the platform secure store.
class _StubKeypair implements DeviceKeypairProvider {
  _StubKeypair(this.pub);

  final Uint8List pub;

  @override
  Future<Uint8List> getPublicKey() async => pub;
}

void main() {
  group('thumbprint — cross-SDK lock-in fixed vectors', () {
    // ===== Hardcoded vectors — KEEP IN SYNC WITH SWIFT TWIN =====
    //
    // Swift file:
    //   sdk/swift/LicenseStoreSDK/Tests/LicenseStoreSDKTests/ThumbprintTests.swift
    //
    // Any divergence here means the two SDKs are about to compute different
    // `apu` values for the same pubkey, which would break server-side AAD
    // cross-check on JWE traffic encrypted by the "wrong" SDK.

    test('zero32 vector matches Swift expected b64url-SHA256', () async {
      // All-zero 32-byte pub. Python:
      //   base64url(sha256(b'\\x00' * 32))
      //   → 'Zmh6rfhivXdsj8GLjp-OIAiXFIVu4jOzkCpZHQ1fKSU'
      final pub = Uint8List(32); // all zeros
      final out = await pubKeyThumbprint(pub);
      expect(out, equals('Zmh6rfhivXdsj8GLjp-OIAiXFIVu4jOzkCpZHQ1fKSU'));
    });

    test('ones32 vector matches Swift expected b64url-SHA256', () async {
      // All-0x01 32-byte pub. Python:
      //   base64url(sha256(b'\\x01' * 32))
      //   → 'cs1uhCLEB_ttCYaQ8RMLfe1-wvf14dML2dUh8BU2N5M'
      final pub = Uint8List.fromList(List<int>.filled(32, 0x01));
      final out = await pubKeyThumbprint(pub);
      expect(out, equals('cs1uhCLEB_ttCYaQ8RMLfe1-wvf14dML2dUh8BU2N5M'));
    });

    test('range32 vector matches Swift expected b64url-SHA256', () async {
      // Incrementing-bytes 32-byte pub (0x00..0x1F). Python:
      //   base64url(sha256(bytes(range(32))))
      //   → 'Yw3NKWbEM2aRElRIu7JbT_QSpJxzLbLIq8G4WBvXEN0'
      final pub = Uint8List.fromList(List<int>.generate(32, (i) => i));
      final out = await pubKeyThumbprint(pub);
      expect(out, equals('Yw3NKWbEM2aRElRIu7JbT_QSpJxzLbLIq8G4WBvXEN0'));
    });
  });

  group('thumbprint — encoding invariants', () {
    // base64url MUST be unpadded — JWS/JWE compact form forbids '=' padding
    // inside any header field (RFC 7515 Appendix C, RFC 7518 §4.6.1.2).
    test('is unpadded base64url alphabet', () async {
      final pub = Uint8List.fromList(List<int>.filled(32, 0xab));
      final out = await pubKeyThumbprint(pub);
      expect(out.contains('='), isFalse,
          reason: 'thumbprint must be unpadded base64url');
      expect(out.contains('+'), isFalse,
          reason: 'must use base64url alphabet (- and _)');
      expect(out.contains('/'), isFalse,
          reason: 'must use base64url alphabet (- and _)');
    });

    // SHA-256 is 32 bytes → base64url is exactly ceil(32 * 4 / 3) = 43 chars
    // once padding is stripped.
    test('output length is 43 chars (unpadded b64url of SHA-256)', () async {
      final pub = Uint8List.fromList(List<int>.filled(32, 0x42));
      final out = await pubKeyThumbprint(pub);
      expect(out.length, equals(43));
    });

    test('is deterministic — same input always yields same output', () async {
      final pub = Uint8List.fromList(List<int>.filled(32, 0x7f));
      final a = await pubKeyThumbprint(pub);
      final b = await pubKeyThumbprint(pub);
      expect(a, equals(b));
    });
  });

  group('thumbprint — provider overload', () {
    // The async `devicePubThumbprint(DeviceKeypairProvider)` overload threads
    // through `getPublicKey()` and must produce the same byte-for-byte output
    // as the direct `pubKeyThumbprint(bytes)` helper.
    test('provider overload matches direct-bytes overload', () async {
      final pub = Uint8List.fromList(List<int>.filled(32, 0x99));
      final stub = _StubKeypair(pub);
      final viaProvider = await devicePubThumbprint(stub);
      final viaBytes = await pubKeyThumbprint(pub);
      expect(viaProvider, equals(viaBytes));
    });

    // Real X25519 pub — exercises the typical production input shape
    // (32 bytes from a generated keypair).
    test('works on real X25519 generated keypair', () async {
      final kp = await X25519().newKeyPair();
      final pub = await kp.extractPublicKey();
      final pubBytes = Uint8List.fromList(pub.bytes);
      expect(pubBytes.length, equals(32));
      final stub = _StubKeypair(pubBytes);
      final out = await devicePubThumbprint(stub);
      expect(out.length, equals(43));
    });
  });
}
