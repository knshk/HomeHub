// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Cross-SDK parity lock-in for the v2 / Vanaheim single-recipient JWE codec.
///
/// Twin of `sdk/swift/LicenseStoreSDK/Tests/LicenseStoreSDKTests/JweCodecParityTests.swift`.
/// Both files hold the IDENTICAL hardcoded test vector (recipient X25519 priv,
/// sender X25519 priv, AAD context, expected CEK hex). Any divergence here
/// means the two SDKs are about to fail to interop with each other.
///
/// What this asserts:
///   1. The JWE protected header decodes to the expected JSON shape — same
///      `apu`, `apv`, `alg`, `enc`, `kid`, `project_id`, `route_path`,
///      `request_id`, `typ`, `lcs_v` as the Swift twin. These fields are
///      load-bearing for AAD binding (RFC 7516 §5.1).
///   2. Given the same (recipient priv, peer epk pub, apu, apv), the
///      ConcatKDF-derived CEK is byte-identical to the hardcoded expected
///      CEK below. The hex string is the cross-SDK lock-in — change in
///      lockstep with the Swift twin or both sides break.
///
/// Why we can't pin a hardcoded ciphertext: `encryptForRecipient` always
/// generates a fresh ephemeral keypair and AES-GCM uses a fresh nonce, so
/// the compact JWE is non-deterministic. We pin the deterministic primitives
/// (header shape + ConcatKDF math) instead.
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:vanaheim/src/crypto/jwe_codec.dart';
import 'package:test/test.dart';

// ===== Hardcoded test vector — KEEP IN SYNC WITH SWIFT TWIN =====

/// Recipient X25519 private scalar — 32 raw bytes, lowercase hex.
/// Deterministic dev-only key; do NOT use in production. The Swift twin
/// reads the IDENTICAL hex string.
const _recipientPrivHex =
    'a0b1c2d3e4f5061728394a5b6c7d8e9faabbccddeeff00112233445566778899';

/// Sender ephemeral X25519 private scalar — fixed so the shared secret is
/// deterministic. In real traffic the codec randomises this per request;
/// here we drive ConcatKDF directly with a pinned scalar to lock the CEK.
const _senderPrivHex =
    '112233445566778899aabbccddeeff00112233445566778899aabbccddeeff00';

const _projectId = 42;
const _routePath = '/v1/account/me';
const _requestId = '01890000-7000-7000-8000-000000000000';
const _senderId = 'device-thumb-abc';
const _recipientKid = 'l2-enc-7';
const _plaintextStr = 'header.payload.sig';

/// Expected CEK hex — the canonical lock-in value. Both SDKs MUST derive
/// this from the inputs above using ConcatKDF (NIST SP 800-56A §5.8.1) per
/// RFC 7518 §4.6.2.
///
/// Lock-in: if you change ConcatKDF inputs (counter, AlgorithmID,
/// PartyUInfo / PartyVInfo encoding, SuppPubInfo bit-length), this hex
/// changes — and so must the Swift twin. NEVER update one without the
/// other; this is the cross-SDK contract.
const _expectedCekHex =
    'c43c62cefd139871b2e0ff8ed3bcc6ffb18b041cda38433caf8447e6cf09c577';

// ===== Helpers =====

Uint8List _hexToBytes(String hex) {
  final out = Uint8List(hex.length ~/ 2);
  for (var i = 0; i < out.length; i++) {
    out[i] = int.parse(hex.substring(i * 2, i * 2 + 2), radix: 16);
  }
  return out;
}

String _bytesToHex(List<int> bytes) =>
    bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();

/// ConcatKDF (NIST SP 800-56A §5.8.1) for `enc = A256GCM`. Mirrors the
/// private `_deriveCek` impl in jwe_codec.dart — kept inline here so any
/// divergence in the real codec surfaces as a mismatch against
/// `_expectedCekHex` rather than being silently re-derived from the same
/// buggy source.
Future<Uint8List> _concatKdfA256GCM({
  required Uint8List sharedZ,
  required String apu,
  required String apv,
}) async {
  Uint8List be32(int n) {
    final b = ByteData(4)..setUint32(0, n, Endian.big);
    return b.buffer.asUint8List();
  }

  final algId = Uint8List.fromList(utf8.encode('A256GCM'));
  final apuBytes = Uint8List.fromList(utf8.encode(apu));
  final apvBytes = Uint8List.fromList(utf8.encode(apv));

  final otherInfo = BytesBuilder()
    ..add(be32(algId.length))
    ..add(algId)
    ..add(be32(apuBytes.length))
    ..add(apuBytes)
    ..add(be32(apvBytes.length))
    ..add(apvBytes)
    ..add(be32(256));

  final input = BytesBuilder()
    ..add(be32(1)) // counter
    ..add(sharedZ)
    ..add(otherInfo.toBytes());

  final digest = await Sha256().hash(input.toBytes());
  return Uint8List.fromList(digest.bytes);
}

void main() {
  // X25519 primitive used to do shared-secret derivation directly so we can
  // verify ConcatKDF without going through the codec's round-trip.
  final x25519 = X25519();

  JweAadContext aadCtx() => const JweAadContext(
        senderId: _senderId,
        recipientId: _recipientKid,
        projectId: _projectId,
        routePath: _routePath,
        requestId: _requestId,
      );

  group('JweCodec — cross-SDK parity lock-in', () {
    test('protected header shape matches parity vector (Swift twin)',
        () async {
      final recipientKp =
          await x25519.newKeyPairFromSeed(_hexToBytes(_recipientPrivHex));
      final recipientPub = await recipientKp.extractPublicKey();
      final pt = Uint8List.fromList(utf8.encode(_plaintextStr));

      final compact = await JweCodec.encryptForRecipient(
        innerJwsBytes: pt,
        recipientPub: recipientPub,
        recipientKid: _recipientKid,
        aad: aadCtx(),
      );

      final result = await JweCodec.decryptCompact(
        jwe: compact,
        devicePrivBytes: _hexToBytes(_recipientPrivHex),
      );
      expect(result.plaintext, equals(pt),
          reason: 'round-trip must recover plaintext');

      final header = result.header;
      expect(header['alg'], 'ECDH-ES');
      expect(header['enc'], 'A256GCM');
      expect(header['kid'], _recipientKid);
      expect(header['apu'], _senderId);
      expect(header['apv'], _recipientKid);
      expect(header['project_id'], _projectId);
      expect(header['route_path'], _routePath);
      expect(header['request_id'], _requestId);
      expect(header['typ'], 'lcs+jwe');
      expect(header['lcs_v'], 2);

      final epk = header['epk'] as Map<String, dynamic>?;
      expect(epk?['kty'], 'OKP');
      expect(epk?['crv'], 'X25519');
      expect(epk?['x'], isA<String>());
    });

    test('ConcatKDF CEK matches Swift twin lock-in', () async {
      final recipientKp =
          await x25519.newKeyPairFromSeed(_hexToBytes(_recipientPrivHex));
      final senderKp =
          await x25519.newKeyPairFromSeed(_hexToBytes(_senderPrivHex));
      final recipientPub = await recipientKp.extractPublicKey();
      final senderPub = await senderKp.extractPublicKey();

      // Drive ConcatKDF from BOTH sides — they must produce identical CEKs
      // (commutative X25519 shared secret) and both must match the lock-in.
      final zSender = Uint8List.fromList(await (await x25519.sharedSecretKey(
        keyPair: senderKp,
        remotePublicKey: recipientPub,
      ))
          .extractBytes());
      final zRecipient = Uint8List.fromList(await (await x25519.sharedSecretKey(
        keyPair: recipientKp,
        remotePublicKey: senderPub,
      ))
          .extractBytes());
      expect(zSender, equals(zRecipient),
          reason: 'X25519 shared secret must be commutative');

      final cekFromSender = await _concatKdfA256GCM(
        sharedZ: zSender,
        apu: _senderId,
        apv: _recipientKid,
      );
      final cekFromRecipient = await _concatKdfA256GCM(
        sharedZ: zRecipient,
        apu: _senderId,
        apv: _recipientKid,
      );
      expect(cekFromSender, equals(cekFromRecipient));
      expect(cekFromSender.length, 32);

      // The actual lock-in. Update Swift twin in lockstep if this ever changes.
      expect(
        _bytesToHex(cekFromSender),
        equals(_expectedCekHex),
        reason: 'ConcatKDF CEK diverged from cross-SDK lock-in. '
            'If this is intentional, update the Swift twin '
            'sdk/swift/.../JweCodecParityTests.swift with the same new hex.',
      );
    });
  });
}
