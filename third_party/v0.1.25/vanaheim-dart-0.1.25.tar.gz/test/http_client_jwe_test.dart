// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Lock-in tests for SignedHttpClient's v2 / Vanaheim JWE path.
///
/// What we test:
///   1. postJson on a JWE-required route wraps the body, sets the four v2
///      request headers (X-LS-Recipient-Kid / X-LS-Device-Id / X-LS-Request-Id /
///      X-LS-KEK-V), and uses `application/jose+json` content-type.
///   2. PekStaleException (412 with reason_code=KEK_V_STALE) triggers a
///      forceRefresh on L2KeysClient + exactly-one retry.
///   3. DeviceRevokedException (410 with reason_code=DEVICE_REVOKED) clears
///      the `device_registered_v1` SecureCache marker.
///   4. A JWE-required response that comes back without the
///      `X-LS-Confidentiality: jwe` header is rejected as
///      JweRequiredButGotJwsException (fail-closed, no downgrade).
///
/// Stub strategy: we inject a fake JweTransportCodec that returns its `innerJwsBytes`
/// argument as the "ciphertext" (compact form is just a marker string), and
/// reverses it on decrypt. The inner JWS is itself a hand-rolled 3-part
/// compact string with a JSON payload, so the transport can `peekJwsPayload`
/// it without an InnerJwsVerifier.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:vanaheim/src/auth/auth_providers.dart';
import 'package:vanaheim/src/exceptions.dart';
import 'package:vanaheim/src/storage/secure_cache.dart';
import 'package:vanaheim/src/transport/cert_pinning.dart';
import 'package:vanaheim/src/transport/headers.dart';
import 'package:vanaheim/src/transport/hmac_signer.dart';
import 'package:vanaheim/src/transport/http_client.dart';
import 'package:vanaheim/src/transport/l2_keys_client.dart';
import 'package:test/test.dart';

// ---------------------------------------------------------------- fakes

class _FakeAuth implements AuthTokenProvider {
  @override
  Future<String> getIdToken({bool forceRefresh = false}) async => 'tok';
}

class _FakeAppCheck implements AppCheckTokenProvider {
  @override
  Future<String?> getToken({bool forceRefresh = false}) async => null;
}

class _AllJweRoutePolicy implements RoutePolicy {
  @override
  RouteConfidentiality classify(String path) =>
      RouteConfidentiality.jweRequired;
}

class _FakeJweCodec implements JweTransportCodec {
  final List<Uint8List> encrypted = [];
  final List<String> decryptedAads = [];
  /// Optional override so a test can inject a synthetic response payload
  /// (the inner JWS to be returned on `decryptForDevice`).
  String? responseInnerJws;

  @override
  Future<String> encryptForRecipient({
    required Uint8List recipientPub,
    required String recipientKid,
    required Uint8List innerJwsBytes,
    required Map<String, String> aad,
  }) async {
    encrypted.add(innerJwsBytes);
    // Encode the inner JWS bytes as the "compact" so the test can confirm
    // it was sent — prefix with a marker so it's distinguishable.
    return 'JWE:${utf8.decode(innerJwsBytes)}';
  }

  @override
  Future<Uint8List> decryptForDevice({
    required String compactJwe,
    required Map<String, String> expectedAad,
  }) async {
    decryptedAads.add(jsonEncode(expectedAad));
    final inner = responseInnerJws;
    if (inner == null) {
      throw StateError('no responseInnerJws configured');
    }
    return Uint8List.fromList(utf8.encode(inner));
  }
}

class _FakeSigner implements DeviceJwsSigner {
  @override
  final String deviceId;
  @override
  final String sigKid;
  _FakeSigner({this.deviceId = 'dev_001'}) : sigKid = 'sig_001';
  @override
  Future<String> signClaims(Map<String, dynamic> claims) async {
    // Fake compact JWS: header.<b64u(claims)>.signature
    final h = base64Url
        .encode(utf8.encode('{"alg":"EdDSA","kid":"$sigKid","typ":"device+jws"}'))
        .replaceAll('=', '');
    final c = base64Url
        .encode(utf8.encode(jsonEncode(claims)))
        .replaceAll('=', '');
    return '$h.$c.fakesig';
  }
}

class _FakeProjectId implements ProjectIdProvider {
  @override
  final String projectId;
  _FakeProjectId(this.projectId);
}

/// L2KeysClient stub that records calls and lets a test force a stale->refresh
/// cycle. We subclass the real client so the SignedHttpClient can call
/// `.get()` / `.forceRefresh()` against the real interface; the http.Client
/// stub never fires because we override the two public methods.
class _FakeL2KeysClient implements L2KeysClient {
  int getCalls = 0;
  int forceRefreshCalls = 0;
  L2RecipientKey firstKey;
  L2RecipientKey refreshedKey;
  _FakeL2KeysClient(this.firstKey, this.refreshedKey);

  @override
  Uri get url => Uri.parse('https://stub/.well-known/lcs-keys');

  @override
  Future<L2RecipientKey> get() async {
    getCalls++;
    return firstKey;
  }

  @override
  Future<L2RecipientKey> forceRefresh() async {
    forceRefreshCalls++;
    return refreshedKey;
  }

  @override
  void invalidate() {}

  @override
  void close() {}
}

/// In-memory secure cache that records deletes so the test can confirm the
/// device-revoked marker was cleared.
class _RecordingSecureCache extends InMemorySecureCache {
  final List<String> deletedKeys = [];
  @override
  Future<void> deleteRaw(String key) async {
    deletedKeys.add(key);
    await super.deleteRaw(key);
  }
}

// -------------------------------------------------------------- helpers

L2RecipientKey _l2Key({String kid = 'l2-enc-7', int kekV = 7}) {
  final x = Uint8List(32);
  for (var i = 0; i < 32; i++) {
    x[i] = i;
  }
  return L2RecipientKey(
    kid: kid,
    x25519Pub: x,
    sigKid: 'l2-sig-7',
    ed25519Pub: x,
    kekVersion: kekV,
  );
}

/// Build a compact inner JWS the transport's _peekJwsPayload helper can
/// decode (header.b64u(json).signature, 3 segments).
String _innerJws(Map<String, dynamic> payload) {
  final h = base64Url
      .encode(utf8.encode('{"alg":"EdDSA","kid":"l2-sig-7","typ":"device+jws"}'))
      .replaceAll('=', '');
  final c = base64Url
      .encode(utf8.encode(jsonEncode(payload)))
      .replaceAll('=', '');
  return '$h.$c.fakesig';
}

SignedHttpClient _buildClient({
  required MockClient mock,
  required _FakeL2KeysClient l2,
  required _FakeJweCodec codec,
  SecureCache? cache,
  _FakeSigner? signer,
  String projectId = '42',
}) {
  return SignedHttpClient(
    signer: HmacSigner(productSlug: 'zenkit', sdkSecret: 'shh'),
    auth: _FakeAuth(),
    appCheck: _FakeAppCheck(),
    pinner: CertificatePinner(pinnedSpkiSha256: const []),
    inner: mock,
    routePolicy: _AllJweRoutePolicy(),
    jweCodec: codec,
    deviceSigner: signer ?? _FakeSigner(),
    l2Keys: l2,
    projectIdProvider: _FakeProjectId(projectId),
    secureCache: cache,
  );
}

void main() {
  group('SignedHttpClient.postJson — JWE-required happy path', () {
    test('wraps the body, sets the v2 request headers + content-type, and '
        'decrypts the JWE response', () async {
      final codec = _FakeJweCodec();
      final l2 = _FakeL2KeysClient(_l2Key(), _l2Key());

      // Configure the codec to return a known inner JWS on decrypt.
      codec.responseInnerJws = _innerJws({
        'body': {'ok': true, 'tier': 'pro'},
      });

      late http.Request captured;
      final mock = MockClient((req) async {
        captured = req;
        return http.Response(
          'JWE:<response-body-ciphertext>',
          200,
          headers: {
            LsHeaders.confidentiality.toLowerCase():
                LsHeaders.confidentialityJwe,
            'content-type': LsHeaders.joseJson,
          },
        );
      });

      final client = _buildClient(mock: mock, l2: l2, codec: codec);
      final res = await client.postJson(
        Uri.parse('https://l2.example.com/v1/account/me'),
        body: {'hello': 'world'},
      );

      // 1. Request was sent with the JOSE content-type.
      expect(captured.headers['Content-Type'], equals(LsHeaders.joseJson));

      // 2. v2 headers were set with the recipient + kek-v + device + request id.
      expect(captured.headers[LsHeaders.recipientKid], equals('l2-enc-7'));
      expect(captured.headers[LsHeaders.kekVersion], equals('7'));
      expect(captured.headers[LsHeaders.deviceId], equals('dev_001'));
      expect(captured.headers[LsHeaders.requestId], isNotEmpty);

      // 3. HMAC + Bearer were preserved.
      expect(captured.headers['Authorization'], equals('Bearer tok'));
      expect(captured.headers['X-LS-Signature'], isNotEmpty);
      expect(captured.headers['X-LS-Timestamp'], isNotEmpty);

      // 4. Body bytes are the codec's "JWE:" marker — confirming the
      //    transport handed the inner JWS bytes to encryptForRecipient.
      expect(captured.body, startsWith('JWE:'));

      // 5. Decrypt AAD covered project_id / route_path / request_id.
      expect(codec.decryptedAads, hasLength(1));
      final aad = jsonDecode(codec.decryptedAads.first) as Map<String, dynamic>;
      expect(aad['project_id'], equals('42'));
      expect(aad['route_path'], equals('/v1/account/me'));
      expect(aad['request_id'], isNotEmpty);

      // 6. Response was unwrapped to the inner JWS's `body` claim.
      expect(res['ok'], isTrue);
      expect(res['tier'], equals('pro'));

      // L2 keys client was hit exactly once (no PEK retry needed).
      expect(l2.getCalls, equals(1));
      expect(l2.forceRefreshCalls, equals(0));
    });
  });

  group('SignedHttpClient.postJson — PEK retry-once on 412 pek_stale', () {
    test('forceRefresh + one retry; success on second attempt', () async {
      final codec = _FakeJweCodec();
      final l2 = _FakeL2KeysClient(
        _l2Key(kid: 'l2-enc-7', kekV: 7),
        _l2Key(kid: 'l2-enc-8', kekV: 8),
      );

      codec.responseInnerJws = _innerJws({
        'body': {'retried': true},
      });

      var calls = 0;
      final mock = MockClient((req) async {
        calls++;
        if (calls == 1) {
          // First call: server says the KEK version is stale.
          return http.Response(
            jsonEncode({
              'error': 'pek_stale',
              'reason_code': 'KEK_V_STALE',
              'sent_kek_v': 7,
              'expected_kek_v': 8,
            }),
            412,
            headers: {'content-type': 'application/json'},
          );
        }
        // Second call: success, JWE-confidential response.
        return http.Response(
          'JWE:<after-retry>',
          200,
          headers: {
            LsHeaders.confidentiality.toLowerCase():
                LsHeaders.confidentialityJwe,
          },
        );
      });

      final client = _buildClient(mock: mock, l2: l2, codec: codec);
      final res = await client.postJson(
        Uri.parse('https://l2.example.com/v1/account/me'),
        body: {'x': 1},
      );

      expect(calls, equals(2),
          reason: 'pek_stale must trigger exactly one retry');
      expect(l2.forceRefreshCalls, equals(1),
          reason: 'transport must force-refresh L2 keys before retry');
      expect(res['retried'], isTrue);
    });

    test('second pek_stale propagates as PekStaleException (no infinite '
        'retry loop)', () async {
      final codec = _FakeJweCodec();
      final l2 = _FakeL2KeysClient(_l2Key(), _l2Key(kid: 'l2-enc-8', kekV: 8));
      codec.responseInnerJws = _innerJws({});

      final mock = MockClient((req) async => http.Response(
            jsonEncode({
              'error': 'pek_stale',
              'reason_code': 'KEK_V_STALE',
              'sent_kek_v': 8,
              'expected_kek_v': 9,
            }),
            412,
            headers: {'content-type': 'application/json'},
          ));

      final client = _buildClient(mock: mock, l2: l2, codec: codec);
      await expectLater(
        client.postJson(
          Uri.parse('https://l2.example.com/v1/account/me'),
          body: const {},
        ),
        throwsA(isA<PekStaleException>().having(
            (e) => e.expectedKekV, 'expectedKekV', equals(9))),
      );
      // Confirmed: forceRefresh was called exactly once (the retry path),
      // not on every 412.
      expect(l2.forceRefreshCalls, equals(1));
    });
  });

  group('SignedHttpClient.postJson — 410 device revoked', () {
    test('clears device_registered_v1 SecureCache marker + raises '
        'DeviceRevokedException', () async {
      final codec = _FakeJweCodec();
      final l2 = _FakeL2KeysClient(_l2Key(), _l2Key());
      final cache = _RecordingSecureCache();
      // Seed the marker so we can confirm it was cleared.
      await cache.putRaw('device_registered_v1', '1');

      codec.responseInnerJws = _innerJws({});

      final mock = MockClient((req) async => http.Response(
            jsonEncode({
              'reason_code': 'DEVICE_REVOKED',
            }),
            410,
            headers: {'content-type': 'application/json'},
          ));

      final client = _buildClient(
        mock: mock,
        l2: l2,
        codec: codec,
        cache: cache,
        signer: _FakeSigner(deviceId: 'dev_revoked_xxx'),
      );
      await expectLater(
        client.postJson(
          Uri.parse('https://l2.example.com/v1/account/me'),
          body: const {},
        ),
        throwsA(isA<DeviceRevokedException>().having(
            (e) => e.deviceId, 'deviceId', equals('dev_revoked_xxx'))),
      );
      expect(cache.deletedKeys, contains('device_registered_v1'),
          reason: 'transport must clear the device-registered marker on 410');
      // And the marker should now be gone from the store.
      expect(await cache.getRaw('device_registered_v1'), isNull);
    });
  });

  group('SignedHttpClient.postJson — fail-closed when server returns plain', () {
    test('JWE-required route + missing X-LS-Confidentiality response header '
        '→ JweRequiredButGotJwsException', () async {
      final codec = _FakeJweCodec();
      final l2 = _FakeL2KeysClient(_l2Key(), _l2Key());
      codec.responseInnerJws = _innerJws({});

      final mock = MockClient((req) async => http.Response(
            jsonEncode({'tier': 'pro'}),
            200,
            // NOTE: no X-LS-Confidentiality header.
            headers: {'content-type': 'application/json'},
          ));

      final client = _buildClient(mock: mock, l2: l2, codec: codec);
      await expectLater(
        client.postJson(
          Uri.parse('https://l2.example.com/v1/account/me'),
          body: const {},
        ),
        throwsA(isA<JweRequiredButGotJwsException>().having(
            (e) => e.routePath, 'routePath', equals('/v1/account/me'))),
      );
    });
  });
}
