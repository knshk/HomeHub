// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:vanaheim/src/grace/grace_state_machine.dart';
import 'package:test/test.dart';

void main() {
  const sm = GraceStateMachine(
    refreshBefore: Duration(days: 1),
    clockSkew: Duration(minutes: 5),
  );
  final now = DateTime.utc(2026, 5, 24, 12);

  group('GraceStateMachine', () {
    test('returns noJwt when there is no cached jwt', () {
      final d = sm.evaluate(jwtExpiresAt: null, now: now);
      expect(d.state, GraceState.noJwt);
    });

    test('returns fresh when exp is far away', () {
      final d = sm.evaluate(
          jwtExpiresAt: now.add(const Duration(days: 7)), now: now);
      expect(d.state, GraceState.fresh);
      expect(d.timeUntilExpiry, const Duration(days: 7));
    });

    test('returns refreshNeeded inside the refreshBefore window', () {
      final d = sm.evaluate(
          jwtExpiresAt: now.add(const Duration(hours: 12)), now: now);
      expect(d.state, GraceState.refreshNeeded);
    });

    test('boundary: exactly at refreshBefore is treated as refreshNeeded', () {
      final d = sm.evaluate(
          jwtExpiresAt: now.add(const Duration(days: 1)), now: now);
      expect(d.state, GraceState.refreshNeeded);
    });

    test('returns expired when past exp + clockSkew', () {
      final d = sm.evaluate(
          jwtExpiresAt: now.subtract(const Duration(minutes: 10)), now: now);
      expect(d.state, GraceState.expired);
      expect(d.sinceExpiry, const Duration(minutes: 10));
    });

    test('still refreshNeeded if within clockSkew past exp (clock drift forgiven)', () {
      final d = sm.evaluate(
          jwtExpiresAt: now.subtract(const Duration(minutes: 2)), now: now);
      // -2 min is within +/-5min skew → still refreshNeeded (caller refreshes)
      expect(d.state, GraceState.refreshNeeded);
    });
  });
}
