// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Lock-in tests for the v2 / Vanaheim JWE codec
/// (lib/src/crypto/jwe_codec.dart).
///
/// What this test exercises:
///   * encryptForRecipient → decryptCompact round-trips for the canonical
///     ECDH-ES + A256GCM single-recipient envelope.
///   * AAD binding via the protected header: project_id / route_path /
///     request_id are inside the header, so flipping any of them after
///     encrypt MUST surface as a tag-mismatch on decrypt.
///   * alg/enc allowlist is enforced BEFORE any asymmetric work, including
///     the explicit v1-downgrade attempt (ECDH-ES+A256KW).
///   * each encrypt call emits a fresh ephemeral epk (no caching).
library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:vanaheim/src/crypto/jwe.dart'
    show JweDecryptionFailedException;
import 'package:vanaheim/src/crypto/jwe_codec.dart';
import 'package:test/test.dart';

void main() {
  // Recipient X25519 keypair generated once for the whole suite. The codec is
  // stateless so re-using the keypair across tests is fine — every encrypt
  // call generates its own ephemeral sender keypair internally.
  late SimpleKeyPair recipientKp;
  late SimplePublicKey recipientPub;
  late Uint8List recipientPrivBytes;

  setUpAll(() async {
    recipientKp = await X25519().newKeyPair();
    recipientPub = await recipientKp.extractPublicKey();
    recipientPrivBytes =
        Uint8List.fromList(await recipientKp.extractPrivateKeyBytes());
  });

  JweAadContext aad({
    int projectId = 42,
    String routePath = '/v1/account/me',
    String requestId = '01890000-7000-7000-8000-000000000000',
  }) =>
      JweAadContext(
        senderId: 'device-thumb-abc',
        recipientId: 'l2-enc-7',
        projectId: projectId,
        routePath: routePath,
        requestId: requestId,
      );

  Uint8List plaintext([String s = 'inner.jws.signature']) =>
      Uint8List.fromList(utf8.encode(s));

  group('JweCodec — round trip', () {
    test('encrypt → decrypt recovers the inner JWS bytes verbatim', () async {
      final pt = plaintext('header.payload.sig');
      final compact = await JweCodec.encryptForRecipient(
        innerJwsBytes: pt,
        recipientPub: recipientPub,
        recipientKid: 'l2-enc-7',
        aad: aad(),
      );

      // 5-segment compact serialization per RFC 7516 §7.
      expect(compact.split('.').length, equals(5));
      // ECDH-ES direct → encrypted_key segment empty.
      expect(compact.split('.')[1], isEmpty);

      final out = await JweCodec.decryptCompact(
        jwe: compact,
        devicePrivBytes: recipientPrivBytes,
      );
      expect(out.plaintext, equals(pt));
      expect(out.header['alg'], equals('ECDH-ES'));
      expect(out.header['enc'], equals('A256GCM'));
      expect(out.header['kid'], equals('l2-enc-7'));
      expect(out.header['project_id'], equals(42));
      expect(out.header['route_path'], equals('/v1/account/me'));
      expect(out.header['typ'], equals('lcs+jwe'));
      expect(out.header['lcs_v'], equals(2));
    });

    test('protected header carries epk OKP/X25519 32-byte pub', () async {
      final compact = await JweCodec.encryptForRecipient(
        innerJwsBytes: plaintext(),
        recipientPub: recipientPub,
        recipientKid: 'l2-enc-7',
        aad: aad(),
      );
      final headerJson = utf8.decode(_b64u(compact.split('.')[0]));
      final header = jsonDecode(headerJson) as Map<String, dynamic>;
      final epk = header['epk'] as Map<String, dynamic>;
      expect(epk['kty'], equals('OKP'));
      expect(epk['crv'], equals('X25519'));
      final epkX = _b64u(epk['x'] as String);
      expect(epkX.length, equals(32),
          reason: 'epk.x is the raw 32-byte X25519 pub');
    });
  });

  group('JweCodec — ephemeral epk per call', () {
    test('two encrypts of the same plaintext produce DIFFERENT epk + ciphertext',
        () async {
      final a = await JweCodec.encryptForRecipient(
        innerJwsBytes: plaintext('same'),
        recipientPub: recipientPub,
        recipientKid: 'l2-enc-7',
        aad: aad(),
      );
      final b = await JweCodec.encryptForRecipient(
        innerJwsBytes: plaintext('same'),
        recipientPub: recipientPub,
        recipientKid: 'l2-enc-7',
        aad: aad(),
      );
      expect(a, isNot(equals(b)),
          reason: 'fresh ephemeral keypair MUST make the envelope unique');

      final headerA =
          jsonDecode(utf8.decode(_b64u(a.split('.')[0]))) as Map<String, dynamic>;
      final headerB =
          jsonDecode(utf8.decode(_b64u(b.split('.')[0]))) as Map<String, dynamic>;
      final epkA = (headerA['epk'] as Map)['x'] as String;
      final epkB = (headerB['epk'] as Map)['x'] as String;
      expect(epkA, isNot(equals(epkB)),
          reason: 'epk MUST be regenerated for every encrypt');
    });
  });

  group('JweCodec — AAD covers project_id / route_path / request_id', () {
    // The codec puts these fields INSIDE the protected header and uses
    // ASCII(b64url(protected_header)) as the AAD per RFC 7516 §5.1, so any
    // post-encrypt header tweak should flip the GCM tag.
    Future<String> tamperHeader(
      String jwe,
      String key,
      Object newValue,
    ) async {
      final parts = jwe.split('.');
      final header =
          jsonDecode(utf8.decode(_b64u(parts[0]))) as Map<String, dynamic>;
      header[key] = newValue;
      final tampered = base64Url
          .encode(utf8.encode(jsonEncode(header)))
          .replaceAll('=', '');
      parts[0] = tampered;
      return parts.join('.');
    }

    test('flipping project_id in the header makes decrypt fail', () async {
      final compact = await JweCodec.encryptForRecipient(
        innerJwsBytes: plaintext(),
        recipientPub: recipientPub,
        recipientKid: 'l2-enc-7',
        aad: aad(projectId: 42),
      );
      final tampered = await tamperHeader(compact, 'project_id', 99);
      await expectLater(
        JweCodec.decryptCompact(
          jwe: tampered,
          devicePrivBytes: recipientPrivBytes,
        ),
        throwsA(isA<JweDecryptionFailedException>()),
      );
    });

    test('flipping route_path in the header makes decrypt fail', () async {
      final compact = await JweCodec.encryptForRecipient(
        innerJwsBytes: plaintext(),
        recipientPub: recipientPub,
        recipientKid: 'l2-enc-7',
        aad: aad(routePath: '/v1/account/me'),
      );
      final tampered =
          await tamperHeader(compact, 'route_path', '/v1/billing/charge');
      await expectLater(
        JweCodec.decryptCompact(
          jwe: tampered,
          devicePrivBytes: recipientPrivBytes,
        ),
        throwsA(isA<JweDecryptionFailedException>()),
      );
    });

    test('flipping request_id in the header makes decrypt fail', () async {
      final compact = await JweCodec.encryptForRecipient(
        innerJwsBytes: plaintext(),
        recipientPub: recipientPub,
        recipientKid: 'l2-enc-7',
        aad: aad(requestId: '01890000-7000-7000-8000-000000000000'),
      );
      final tampered = await tamperHeader(compact, 'request_id',
          '01890000-7000-7000-8000-aaaaaaaaaaaa');
      await expectLater(
        JweCodec.decryptCompact(
          jwe: tampered,
          devicePrivBytes: recipientPrivBytes,
        ),
        throwsA(isA<JweDecryptionFailedException>()),
      );
    });
  });

  group('JweCodec — alg/enc allowlist enforcement', () {
    // Build a 5-segment compact with the alg/enc fields tweaked by re-encoding
    // the header. The cipher segments are left untouched — the allowlist
    // gate MUST reject before any AES-GCM call runs.
    Future<String> swapHeaderField({
      required String base,
      required String key,
      required String value,
    }) async {
      final parts = base.split('.');
      final header =
          jsonDecode(utf8.decode(_b64u(parts[0]))) as Map<String, dynamic>;
      header[key] = value;
      parts[0] = base64Url
          .encode(utf8.encode(jsonEncode(header)))
          .replaceAll('=', '');
      return parts.join('.');
    }

    late String good;
    setUpAll(() async {
      good = await JweCodec.encryptForRecipient(
        innerJwsBytes: plaintext(),
        recipientPub: recipientPub,
        recipientKid: 'l2-enc-7',
        aad: aad(),
      );
    });

    test('rejects v1 alg downgrade (ECDH-ES+A256KW)', () async {
      final swapped =
          await swapHeaderField(base: good, key: 'alg', value: 'ECDH-ES+A256KW');
      await expectLater(
        JweCodec.decryptCompact(
          jwe: swapped,
          devicePrivBytes: recipientPrivBytes,
        ),
        throwsA(
          isA<JweDecryptionFailedException>().having(
              (e) => e.message, 'message', contains('disallowed alg')),
        ),
      );
    });

    test('rejects disallowed enc (A128GCM)', () async {
      final swapped =
          await swapHeaderField(base: good, key: 'enc', value: 'A128GCM');
      await expectLater(
        JweCodec.decryptCompact(
          jwe: swapped,
          devicePrivBytes: recipientPrivBytes,
        ),
        throwsA(
          isA<JweDecryptionFailedException>().having(
              (e) => e.message, 'message', contains('disallowed enc')),
        ),
      );
    });

    test('rejects non-empty encrypted_key (ECDH-ES direct only)', () async {
      final parts = good.split('.');
      parts[1] = 'AAAA'; // any non-empty value
      final tampered = parts.join('.');
      await expectLater(
        JweCodec.decryptCompact(
          jwe: tampered,
          devicePrivBytes: recipientPrivBytes,
        ),
        throwsA(
          isA<JweDecryptionFailedException>().having((e) => e.message,
              'message', contains('encrypted_key must be empty')),
        ),
      );
    });

    test('allowlist override that accepts a different alg/enc still works',
        () async {
      // Sanity: the allowlist parameter is honored. We feed in a custom
      // allowlist that includes our real alg/enc plus an extra one to
      // confirm the lookup is set-membership.
      final compact = await JweCodec.encryptForRecipient(
        innerJwsBytes: plaintext('xyz'),
        recipientPub: recipientPub,
        recipientKid: 'l2-enc-7',
        aad: aad(),
      );
      final out = await JweCodec.decryptCompact(
        jwe: compact,
        devicePrivBytes: recipientPrivBytes,
        allowlist: const JweAlgorithmAllowlist(
          algs: {'ECDH-ES', 'OTHER'},
          encs: {'A256GCM', 'OTHER'},
        ),
      );
      expect(utf8.decode(out.plaintext), equals('xyz'));
    });
  });

  group('JweCodec — wrong-recipient + structural failures', () {
    test('decrypt with the WRONG device priv fails the AES-GCM tag', () async {
      final compact = await JweCodec.encryptForRecipient(
        innerJwsBytes: plaintext(),
        recipientPub: recipientPub,
        recipientKid: 'l2-enc-7',
        aad: aad(),
      );
      final wrong = await X25519().newKeyPair();
      final wrongPriv =
          Uint8List.fromList(await wrong.extractPrivateKeyBytes());
      await expectLater(
        JweCodec.decryptCompact(
          jwe: compact,
          devicePrivBytes: wrongPriv,
        ),
        throwsA(isA<JweDecryptionFailedException>()),
      );
    });

    test('rejects a 4-segment string (malformed)', () async {
      await expectLater(
        JweCodec.decryptCompact(
          jwe: 'a.b.c.d',
          devicePrivBytes: recipientPrivBytes,
        ),
        throwsA(isA<JweDecryptionFailedException>()),
      );
    });

    test('rejects encrypt for a non-X25519 recipient pubkey type', () async {
      final ed = await Ed25519().newKeyPair();
      final edPub = await ed.extractPublicKey();
      await expectLater(
        JweCodec.encryptForRecipient(
          innerJwsBytes: plaintext(),
          recipientPub: edPub,
          recipientKid: 'l2-enc-7',
          aad: aad(),
        ),
        throwsA(isA<JweDecryptionFailedException>()),
      );
    });
  });
}

/// Base64url-decode helper (no padding).
Uint8List _b64u(String s) {
  final pad = (4 - s.length % 4) % 4;
  return base64Url.decode(s.padRight(s.length + pad, '='));
}
