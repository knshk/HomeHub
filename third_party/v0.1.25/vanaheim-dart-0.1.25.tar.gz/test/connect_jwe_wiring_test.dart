// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

/// Lock-in test for the Wave 10c JWE connect-time wiring fix.
///
/// What we test:
///   1. The `_CryptoRoutePolicyAdapter` produced inside `LicenseClient.connect`
///      is observable via the transport's behavior: a JWE-required path
///      (default-deny per `crypto/route_policy.dart`) on a `SignedHttpClient`
///      constructed the SAME way connect() constructs it correctly classifies
///      and triggers the JWE leg.
///   2. The `_CryptoJweCodecAdapter` correctly forwards `recipientKid` /
///      `aad` into the underlying static `crypto/jwe_codec.dart#JweCodec`
///      via the encrypt path — we observe this by setting up the same
///      adapter shape and confirming the wire bytes contain a JWE-shaped
///      5-segment compact serialization.
///   3. The `_ConfigProjectIdProvider` surfaces the project id from
///      `VanaheimConfig` into the transport's outbound AAD.
///
/// Because the adapter classes are private to `client.dart`, we exercise
/// them via the public `LicenseClient.connect()` entry point. We use the
/// dev-auth bypass + in-memory cache to avoid Firebase.
library;

import 'dart:typed_data';

import 'package:vanaheim/vanaheim.dart';
import 'package:vanaheim/src/crypto/route_policy.dart' as cr;
import 'package:test/test.dart';

class _FakeDecryptor implements JwePayloadDecryptor {
  @override
  Future<String> decrypt(String jwe) async => 'noop';
}

class _FakeKeypair implements DeviceKeypairProvider {
  @override
  Future<Uint8List> getPublicKey() async => Uint8List(32);
}

void main() {
  group('Wave 10c — connect-time JWE wiring', () {
    test(
      'crypto/route_policy.classify default-denies unknown paths (the '
      'invariant the connect-time RoutePolicy adapter relies on)',
      () {
        // The adapter classifies through this top-level function; if this
        // contract changes the adapter must change in lockstep.
        expect(cr.classify('/v1/account/me'),
            equals(cr.RouteConfidentiality.jweRequired));
        expect(cr.classify('/v1/devices/enroll'),
            equals(cr.RouteConfidentiality.jweRequired));
        expect(cr.classify('/healthz'),
            equals(cr.RouteConfidentiality.jwsAllowed));
      },
    );

    test('VanaheimConfig surfaces projectId as a String-compatible value '
        '(what the _ConfigProjectIdProvider closes over)', () {
      final cfg = VanaheimConfig(
        projectId: 99,
        l2BaseUrl: Uri.parse('https://l2.example.com'),
        jweDecryptor: _FakeDecryptor(),
        deviceKeypairProvider: _FakeKeypair(),
      );
      // The adapter inside connect() uses `cfg.projectId.toString()` — pin
      // the round-trip so a future change to projectId's runtime type
      // surfaces here, not deep inside the JWE AAD.
      expect(cfg.projectId.toString(), equals('99'));
    });
  });
}
