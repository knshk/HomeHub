// SPDX-License-Identifier: Apache-2.0
// Copyright © 2026-present AJTEK.IO (OPC) Private Limited

import 'package:vanaheim/src/api/security_api.dart';
import 'package:vanaheim/src/auth/auth_providers.dart';
import 'package:vanaheim/src/capabilities.dart';
import 'package:vanaheim/src/models.dart';
import 'package:vanaheim/src/transport/cert_pinning.dart';
import 'package:vanaheim/src/transport/hmac_signer.dart';
import 'package:vanaheim/src/transport/http_client.dart';
import 'package:test/test.dart';

/// Tests for §2A.8 MFA SDK surface:
///   * SecurityApi is fully capability-gated (every method throws when
///     `capabilities.mfa` is false)
///   * MFA model parsing handles both Go PascalCase + snake_case payloads
///   * SdkCapabilities `mfa` defaults to true (opt-out semantics) and
///     `isEnabled('mfa')` flips correctly.
SignedHttpClient _http() => SignedHttpClient(
      signer: HmacSigner(productSlug: 'test', sdkSecret: 'test-secret'),
      auth: DevAuthTokenProvider(uid: 'u', email: 't@example.com'),
      appCheck: NoAppCheckProvider(),
      pinner: CertificatePinner(pinnedSpkiSha256: const []),
    );

Uri _ep() => Uri.parse('https://never-called.invalid');

void main() {
  group('SdkCapabilities — mfa flag', () {
    test('defaults to true', () {
      const caps = SdkCapabilities();
      expect(caps.mfa, isTrue);
      expect(caps.isEnabled('mfa'), isTrue);
    });

    test('can be disabled programmatically', () {
      const caps = SdkCapabilities(mfa: false);
      expect(caps.mfa, isFalse);
      expect(caps.isEnabled('mfa'), isFalse);
    });

    test('parses mfa: false from YAML', () {
      const yaml = '''
vanaheim:
  capabilities:
    mfa: false
''';
      final caps = SdkCapabilities.fromYaml(yaml);
      expect(caps.mfa, isFalse);
    });
  });

  group('SecurityApi gate', () {
    const caps = SdkCapabilities(mfa: false);
    final api = SecurityApi(_http(), _ep, caps);

    test('status throws', () {
      expect(() => api.status(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('enrollTotp throws', () {
      expect(() => api.enrollTotp(accountEmail: 't@example.com'),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('verifyTotp throws', () {
      expect(
        () => api.verifyTotp(factorId: 'f', code: '123456'),
        throwsA(isA<CapabilityDisabledException>()),
      );
    });
    test('regenerateRecoveryCodes throws', () {
      expect(() => api.regenerateRecoveryCodes(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('verifyRecoveryCode throws', () {
      expect(() => api.verifyRecoveryCode('12345-67890'),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('listSessions throws', () {
      expect(() => api.listSessions(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('revokeSession throws', () {
      expect(() => api.revokeSession('id'),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('revokeAllSessions throws', () {
      expect(() => api.revokeAllSessions(),
          throwsA(isA<CapabilityDisabledException>()));
    });
    test('mintStepUp throws', () {
      expect(() => api.mintStepUp(scope: 'billing.cancel'),
          throwsA(isA<CapabilityDisabledException>()));
    });
  });

  group('MFA model parsing — PascalCase (Go server emission)', () {
    test('MfaFactor parses Go-style payload', () {
      final f = MfaFactor.fromJson(const {
        'ID': '01HABC',
        'Type': 'totp',
        'Label': 'iPhone Auth',
        'ConfirmedAt': '2026-06-14T10:00:00Z',
        'CreatedAt': '2026-06-14T09:00:00Z',
      });
      expect(f.id, equals('01HABC'));
      expect(f.type, equals('totp'));
      expect(f.label, equals('iPhone Auth'));
      expect(f.isConfirmed, isTrue);
    });

    test('MfaFactor accepts snake_case as forward-compat', () {
      final f = MfaFactor.fromJson(const {
        'id': '01HABC',
        'type': 'webauthn',
        'label': 'YubiKey',
        'created_at': '2026-06-14T09:00:00Z',
      });
      expect(f.id, equals('01HABC'));
      expect(f.isConfirmed, isFalse);
    });

    test('MfaStatus parses with empty factors', () {
      final s = MfaStatus.fromJson(const {
        'enabled': false,
        'factors': [],
        'recovery_codes_left': 0,
      });
      expect(s.enabled, isFalse);
      expect(s.factors, isEmpty);
      expect(s.recoveryCodesLeft, equals(0));
    });

    test('TotpEnrollment parses', () {
      final t = TotpEnrollment.fromJson(const {
        'factor_id': '01HABC',
        'type': 'totp',
        'otpauth_uri':
            'otpauth://totp/License%20Store:user@example.com?secret=JBSWY3DPEHPK3PXP&issuer=License+Store',
        'base32_secret': 'JBSWY3DPEHPK3PXP',
      });
      expect(t.factorId, equals('01HABC'));
      expect(t.otpAuthUri, startsWith('otpauth://totp/'));
      expect(t.base32Secret, equals('JBSWY3DPEHPK3PXP'));
    });

    test('TotpEnrollment rejects missing factor_id', () {
      expect(
        () => TotpEnrollment.fromJson(const {
          'type': 'totp',
          'otpauth_uri': 'x',
          'base32_secret': 'y',
        }),
        throwsA(isA<FormatException>()),
      );
    });

    test('MfaSession parses Go PascalCase', () {
      final s = MfaSession.fromJson(const {
        'ID': '01HSESS',
        'AccountID': '01HACC',
        'DeviceFingerprint': 'fp-abc',
        'DeviceName': 'Kanishka iPhone 15',
        'OS': 'iOS 17',
        'LastSeenAt': '2026-06-14T10:00:00Z',
        'ExpiresAt': '2026-07-14T10:00:00Z',
        'CreatedAt': '2026-06-14T09:00:00Z',
      });
      expect(s.id, equals('01HSESS'));
      expect(s.deviceName, equals('Kanishka iPhone 15'));
      expect(s.isRevoked, isFalse);
    });

    test('MfaSession.isRevoked true when RevokedAt present', () {
      final s = MfaSession.fromJson(const {
        'ID': '01HSESS',
        'DeviceFingerprint': 'fp-abc',
        'LastSeenAt': '2026-06-14T10:00:00Z',
        'ExpiresAt': '2026-07-14T10:00:00Z',
        'CreatedAt': '2026-06-14T09:00:00Z',
        'RevokedAt': '2026-06-14T10:30:00Z',
        'RevokedReason': 'user_revoked',
      });
      expect(s.isRevoked, isTrue);
      expect(s.revokedReason, equals('user_revoked'));
    });

    test('StepUpGrant.isValidFor honors scope + expiry', () {
      final g = StepUpGrant.fromJson(const {
        'ID': '01HGRANT',
        'Scope': 'billing.cancel',
        'ExpiresAt': '2026-06-14T10:05:00Z',
      });
      expect(
          g.isValidFor('billing.cancel', DateTime.utc(2026, 6, 14, 10, 1)),
          isTrue);
      expect(
          g.isValidFor('account.delete', DateTime.utc(2026, 6, 14, 10, 1)),
          isFalse);
      expect(
          g.isValidFor('billing.cancel', DateTime.utc(2026, 6, 14, 10, 6)),
          isFalse);
    });
  });
}
